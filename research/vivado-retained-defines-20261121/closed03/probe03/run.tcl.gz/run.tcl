set ::env(BASEJUMP_STL_DIR) /home/coyang/zynq-parrot-linux-capacity/import/black-parrot/external/basejump_stl
source /home/coyang/zynq-parrot-linux-capacity/cosim/tcl/vivado-utils.tcl
set_param general.maxThreads 2
foreach {name value} {BP_RETAINED_BUFFER 1 BP_RETAINED_I_LINES 1280 BP_RETAINED_D_LINES 1280 BP_RETAINED_SETS 256 BP_RETAINED_OBSERVE 1 BP_AXI_RESPONSE_DELAY 200} {set ::env($name) $value}
set ip_script [file normalize bd.tcl]
vivado_create_ip_proj macro_source macro_bd_1 top xc7z020clg400-1 $ip_script
vivado_package_ip macro_bd_1 top $ip_script
vivado_customize_ip macro_bd_1 top $ip_script
close_project
# A new final project must explicitly receive the same allowlist. The IP
# package alone is not assumed to carry project-level Verilog defines.
proc vivado_create_ip {args} {
    create_bd_cell -type ip -vlnv user.org:user:top:1.0 top_0
    make_bd_pins_external [get_bd_pins top_0/signature_0]
}
set fd [open consumer.tcl w]
puts $fd {proc vivado_create_ip {args} {
    create_bd_cell -type ip -vlnv user.org:user:top:1.0 top_0
    make_bd_pins_external [get_bd_pins top_0/signature_0]
}}
close $fd
vivado_create_ip_proj macro_consumer consumer_bd_1 unused xc7z020clg400-1 [file normalize consumer.tcl]
generate_target all [get_files consumer_bd_1.bd]
vivado_synth_wrap 1 2
write_verilog -force positive_signature.v
close_project
# Package-only negative control: a fresh consumer with no experiment env or
# project defines. Same package must yield defaults, exposing accidental loss.
foreach name {BP_RETAINED_BUFFER BP_RETAINED_I_LINES BP_RETAINED_D_LINES BP_RETAINED_SETS BP_RETAINED_OBSERVE BP_AXI_RESPONSE_DELAY} {unset ::env($name)}
vivado_create_ip_proj negative_consumer negative_bd_1 unused xc7z020clg400-1 [file normalize consumer.tcl]
generate_target all [get_files negative_bd_1.bd]
vivado_synth_wrap 1 2
write_verilog -force negative_signature.v
puts "BP-MACRO-PROBE: positive/negative launched-child netlists ready for exact192bit check"
close_project
