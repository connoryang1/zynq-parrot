`ifndef BP_RETAINED_BUFFER
`define BP_RETAINED_BUFFER 0
`endif
`ifndef BP_RETAINED_I_LINES
`define BP_RETAINED_I_LINES 64
`endif
`ifndef BP_RETAINED_D_LINES
`define BP_RETAINED_D_LINES 64
`endif
`ifndef BP_RETAINED_SETS
`define BP_RETAINED_SETS 64
`endif
`ifndef BP_RETAINED_OBSERVE
`define BP_RETAINED_OBSERVE 0
`endif
`ifndef BP_AXI_RESPONSE_DELAY
`define BP_AXI_RESPONSE_DELAY 0
`endif
module top(output wire [191:0] signature);
localparam [31:0] v0 = `BP_RETAINED_BUFFER;
localparam [31:0] v1 = `BP_RETAINED_I_LINES;
localparam [31:0] v2 = `BP_RETAINED_D_LINES;
localparam [31:0] v3 = `BP_RETAINED_SETS;
localparam [31:0] v4 = `BP_RETAINED_OBSERVE;
localparam [31:0] v5 = `BP_AXI_RESPONSE_DELAY;
assign signature = {v0,v1,v2,v3,v4,v5};
endmodule
