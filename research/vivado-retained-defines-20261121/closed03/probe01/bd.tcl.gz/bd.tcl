proc vivado_create_ip {args} {
    vivado_create_design {} [list [file normalize top.sv]] {}
    create_bd_cell -type module -reference top -name top
    make_bd_pins_external [get_bd_pins top/signature]
}
proc vivado_ipx_customize {args} {}
