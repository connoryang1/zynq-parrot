"""Exact CheckedReader/archive_group from accepted close256; bind supplied by owner."""
import gzip,hashlib,tarfile
from pathlib import Path
bind=None
def require(ok,message):
 if not ok:raise ValueError(message)

class CheckedReader:
    def __init__(self,path,guard):self.stream=Path(path).open('rb');self.guard=guard
    def read(self,n=-1):self.guard();return self.stream.read(n)
    def close(self):self.stream.close()


def archive_group(path,rows,guard):
    members=[]
    with path.open('xb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
        for i,row in enumerate(rows):
            guard();require(bind(row['path'])==row,'archive input changed')
            name='files/%04d/%s'%(i,Path(row['path']).name)
            header=tarfile.TarInfo(name);header.size=row['bytes'];header.mode=0o444;header.mtime=0
            reader=CheckedReader(row['path'],guard)
            try:tar.addfile(header,reader)
            finally:reader.close()
            members.append(dict(member=name,original=row))
    with tarfile.open(path,'r|gz') as tar:
        count=0
        for member in tar:
            guard();expected=members[count];require(member.name==expected['member'] and member.isfile(),'exact safe archive member')
            h=hashlib.sha256();size=0
            stream=tar.extractfile(member)
            for block in iter(lambda:stream.read(1048576),b''):guard();h.update(block);size+=len(block)
            require(size==expected['original']['bytes'] and h.hexdigest()==expected['original']['sha256'],'lossless source/metadata roundtrip')
            count+=1
        require(count==len(members),'all archive members')
    return dict(archive=bind(path),members=members,roundtrip=True)

