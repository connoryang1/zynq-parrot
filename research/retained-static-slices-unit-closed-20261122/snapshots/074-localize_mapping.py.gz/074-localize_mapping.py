"""Read closed mapped artifacts only; raw naming groups are not area deltas."""
import csv
import hashlib
import json
from pathlib import Path
import re
R=Path('/home/coyang/fpga-artifacts/linux-cell36-mapping-20261122-02/run01')
O=Path(__file__).resolve().parent

def bind(p):
 p=Path(p);h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b);n+=len(b)
 return dict(path=str(p),bytes=n,sha256=h.hexdigest())
def require(ok,msg):
 if not ok:raise ValueError(msg)
def main():
 session=json.loads((R/'session.json').read_text());require(session['state']=='PASS all3 production mapping acquisitions; no fit or mapped-function claim','closed mapping')
 require(session['ownership_final']['linux_claim_state']=='RELEASED' and session['ownership_final']['owned_group_remaining'] is False,'ownership closed')
 require(not session['foreign_inventory_events'] and session['no_board_operations'],'no conflict/board')
 rows={};inventory=[]
 for p in sorted(R.rglob('*')):
  if p.is_file():inventory.append(bind(p))
 for arm in session['arms']:
  name=arm['arm'];life=arm['owned_receipt'];require(life['returncode']==0 and life['failure'] is None and not life['owned_group_remaining'],'own actual command0')
  require(not arm['prelaunch_global_idle']['vendor_processes'],'perarm global idle')
  cells=list(csv.DictReader((R/name/'primitives.tsv').open(),delimiter='\t'));primitive=[x for x in cells if x['IS_PRIMITIVE']=='1']
  require(not (R/name/'blackboxes.txt').read_text().strip(),'no unresolved blackbox')
  groups={}
  for lane in (0,1):
   chosen=[x for x in primitive if f'lane_fsm[{lane}].resp_data' in x['name']]
   groups[str(lane)]=dict(raw_named_primitive_counts={k:sum(x['REF_NAME']==k for x in chosen) for k in sorted({x['REF_NAME'] for x in chosen})})
  dsp=[x for x in primitive if x['REF_NAME'].startswith('DSP')]
  rows[name]=dict(resources=arm['analysis']['resources'],elapsed_seconds=life['elapsed_s'],DSP_names=[x['name'] for x in dsp],raw_response_named_groups=groups)
 require(rows['baseline1792']['resources']['LUT']==1142 and rows['packed1792']['resources']['LUT']==2617 and rows['packed1911']['resources']['LUT']==2256,'exact measured totals')
 text=(R/'packed1792/functional.v').read_text();start=text.index('  DSP48E1 #(');end=text.index('endmodule',start)
 excerpt=text[start:min(end,start+9000)];(O/'DSP-and-word-driver.excerpt.txt').write_text(excerpt)
 require('.USE_MULT("MULTIPLY")' in excerpt and "p_4_in,1'b0" in excerpt,'actual DSP word-index input')
 require(re.search(r'\.B\(\{(?:1\x27b[01],?)+\}\)',excerpt) is not None,'constant DSP B')
 result=dict(state='PASS independently hashed closed mapping; negative area result preserved',root=bind(R/'session.json'),admission=session['admission'],inventory=inventory,arms=rows,
  finding='DSP p_0_out has A={zeroes,p_4_in[2:0],0}, B=36; p_4_in drivers use word_r/control. Variable72bit slice arithmetic is a concrete candidate, not a line*15 DSP. Fixed slice/index rewrite requires fresh functional/mapping gates.',
  limits='Raw named LUT/MUX/FF groups overlap and do not establish additive savings or exclusive cone costs. Standalone production mapping, not whole FPGA fit/performance or mapped simulation.')
 (O/'mapping-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(bind(O/'mapping-review.json')))
if __name__=='__main__':main()
