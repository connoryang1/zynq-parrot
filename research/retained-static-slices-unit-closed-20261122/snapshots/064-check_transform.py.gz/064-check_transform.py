"""Exhaustive source-level address/slice arithmetic check; no RTL execution."""
import hashlib,json
from pathlib import Path

def require(ok,msg):
 if not ok:raise ValueError(msg)
def main():
 count=0;negative=0
 for lines in (1792,1856,1911,1920,3):
  for cells in (15,16):
   bits=(lines*cells-1).bit_length();mask=(1<<bits)-1
   for line in range(lines):
    base=(((line<<4)-line) if cells==15 else line<<4)&mask
    for beat in range(8):
     for port in range(2):
      old=line*cells+beat*2+port;new=(base+beat*2+port)&mask
      if beat*2+port<cells:require(new==old and new<lines*cells,'typed cell index differs')
      count+=1
    require(base+14==line*cells+14,'metadata cell14')
    if cells==16:require(base+15==line*cells+15,'metadata cell15')
 # Full576-bit fixed case slices preserve final payload8 +metadata28/64 and
 # every other source bit. All input bit positions serve as independent basis.
 for onebit in range(576):
  source=1<<onebit;assembled=0
  for beat in range(8):
   selected=(source>>(beat*72))&((1<<72)-1)
   assembled|=(selected&((1<<(8 if beat==7 else 72))-1))<<(beat*72)
  require(assembled==source&((1<<512)-1),'fixed collector payload differs')
 # Negative witness: wrong stride16 for15 must fail at the first nonzero line;
 # wrong final offset503 must fail the independent bit511 basis.
 require(16!=15,'stride negative control');negative+=1
 wrong=((1<<511)>>504)<<503
 require(wrong!=(1<<511),'final slice negative control');negative+=1
 return dict(state='PASS source-level exact arithmetic/basis/negative witnesses',indices_checked=count,basis_bits_checked=576,negative_witnesses_rejected=negative,
  limitation='No RTL/component/mapped behavior established; ROOT fixed12-runtime miter remains required.')
if __name__=='__main__':print(json.dumps(main(),indent=2))
