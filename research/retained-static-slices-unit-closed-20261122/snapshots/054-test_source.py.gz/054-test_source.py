"""Preparation/refusal tests only; no generator/compiler/model/reader."""
import copy,importlib.util,json,unittest
from pathlib import Path
import run_host as h

class Source(unittest.TestCase):
 def test_frozen_source_preflight(self):
  a=json.loads(h.A.read_text());self.assertEqual(h.preflight(a)['expected_runtimes'],12)
 def test_candidate_anchor_rejected(self):
  a=json.loads(h.A.read_text());a['candidate']['sha256']='0'*64
  with self.assertRaisesRegex(ValueError,'exact static-slice candidate'):h.preflight(a)
 def test_controller_change_rejected(self):
  old=(h.HERE/'baseline-8df.sv.txt').read_bytes();new=(h.WORKTREE/h.REL).read_bytes()
  self.assertTrue(h.unchanged_controller(old,new))
  altered=new.replace(b"resp_hit_r <= 1'b1;",b"resp_hit_r <= 1'b0;")
  self.assertNotEqual(altered,new)
  with self.assertRaisesRegex(ValueError,'FSM/epochs/RR/handshake changed'):h.unchanged_controller(old,altered)
 def test_fixed_resources_not_old_underestimate(self):
  self.assertEqual(h.TRACE_CAP,96*1024**2);self.assertEqual(h.CAP,128*1024**2)
  self.assertGreater(h.TRACE_CAP,68366449)
  self.assertGreater(h.CAP-h.TRACE_CAP,84207521-68366449)
  self.assertEqual(h.LIMITS['workers'],4);self.assertFalse(h.LIMITS['PCH'])
  src=Path(h.__file__).read_text();self.assertIn("'-f',STAGE/'source/no-pch.mk'",src)
  self.assertIn('CCACHE_DISABLE',src);self.assertIn('SCCACHE_DISABLE',src)
if __name__=='__main__':unittest.main()
