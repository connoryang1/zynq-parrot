This prepares a narrow implementation remedy for the measured negative area result of the15-cell retained payload store. The old b12 prototype, all12 functional passes, separate derived correctness closure, original operational trace-budget failure and three-arm synthesis results remain unchanged. No improvement in mapped resources or whole-device fit is claimed for this new source.

Closed mapping packet: `/home/coyang/fpga-artifacts/linux-cell36-mapping-20261122-02/run01`, actual blackparrot1, allthree commands0 and ownership released. Matched baseline1792:1142LUT/2211FF/56BRAM tiles/0DSP. Packed1792:2617LUT/2375FF/54tiles/1DSP. Packed1911:2256LUT/2367FF/56tiles/1DSP. These are constrained standalone production-wrapper results, not whole-chip utilization or mapped functional equivalence.

`mapping-review.json` hashes the complete closed packet. Exact functional.v DSP48E1 `p_0_out` has B=36 and A={zeroes,p_4_in[2:0],0}; the p_4_in drivers use word_r/control. Therefore the actual DSP comes from wide word×72 slice/index logic, not an evidenced line×15 multiplier. Named response groups have586FDRE/lane (baseline512), and additional named LUT/mux logic. Raw name groups overlap and do not provide additive savings estimates or exclusive cones. Deep two-port RAM output selection remains a separate measured cost candidate; this first remedy does not change its layout.

New isolated BP worktree `/home/coyang/bp-retained-cell36-static-slices-20261122`, branch `experiment/retained-cell36-static-slices-20261122`, base b12caa67. Only `bp_common/src/v/bp_retained_line_store.sv` changes. Candidate915815d0 uses constant eight-case72-bit input/destination slices plus typed line×15=(line<<4)−line or line×16 addressing with shared adjacent port offsets. Same15/16cell format,512-bit payload, epoch8/tag20, separate valid publication, READ_FIRST ports, FSM/client cycles, fallback and coherence behavior. No additional line staging. The source controller normalization against exact8df is unchanged except declared collector changes.

Source-only checks PASS:239424 exact address cases,576 independent payload bit bases, two deliberate wrong arithmetic witnesses rejected; four preparation/refusal tests including source drift/controller changes. These do not replace the pending actual RTL gate.

ROOT prospective component command, after source/admission review:

```sh
python3 -B /home/coyang/fpga-artifacts/context-resume/retained-cell36-static-slices-20261122/preparation01/helper/run_host.py --preflight
python3 -B /home/coyang/fpga-artifacts/context-resume/retained-cell36-static-slices-20261122/preparation01/helper/run_host.py --execute
```

One fresh actual-host stage `/dev/shm/zp-retained-cell36-static-slices-unit-20261122-01`; no private namespace allocations. Same six geometries and twelve runtimes:1792,1856,1911,1920 eachside/sets256/epoch8; sparse93/131/sets256/epoch2; disabledI0/D3/sets1/epoch2 (generic16cell format); inverted and different-period clocks. Same full512hit/control/cycle/logical RAM intent miter, full slots, nonzero initial memories, held reset/clear, wrap, concurrent invalidation/publication and partial72-bit collector hazards. Every run requires all original complete markers and closed FST metadata.

Measured prior12 FSTs totaled68,366,449B; old64MiB cap underestimated them and remains FAIL. This NEW source family prospectively reserves **96MiB aggregate FST within128MiB total stage**, leaving32MiB nontrace (prior15,841,072B). All attempted outputs count, no retries or extensions. Same generation120s+compile180s/build300s; run120s/reader30s; four workers, explicit no-PCH make overlay, cache disabled, owning process group/subreaper and bounded5s cleanup. HOME source/helper8MiB plus3GiB floor; RAM512MiB floor plus all remaining allocation. No source/model/fullcore/vendor/board operation is authorized by this preparation alone.

A separate matched two-arm mapping draft will compare exact8df1792 and this source1792 with the same wrapper/settings. It remains unlaunchable until ROOT binds actual componentPASS and reviews the independent per-VM ownership admission. No whole packed FPGA job is proposed.
