#!/usr/bin/env python3
"""Lossless archive of CLOSED static-slice unit/proofs; no build/reader/vendor/cleanup."""
import argparse,hashlib,json,os,shutil,signal,stat,time
from pathlib import Path
import archive_api
HERE=Path(__file__).resolve().parent
BASE=HERE.parent
OUT=BASE/'closed01'
A=HERE/'admission.json'
STAGE=Path('/dev/shm/zp-retained-cell36-static-slices-unit-20261122-02')
FAMILY=Path('/home/coyang/fpga-artifacts/context-resume/retained-cell36-static-slices-20261122')
WORK=Path('/home/coyang/bp-retained-cell36-static-slices-20261122')
CAP=96*1024**2;FLOOR=3*1024**3;SOURCE_CAP=16*1024**2;DEADLINE=600
GUARD=lambda:None

def require(ok,msg):
 if not ok:raise ValueError(msg)
def size(path):return sum(q.stat().st_size for q in path.rglob('*')if q.is_file())if path.exists()else 0
def bind(path):
 path=Path(path);before=path.stat();h=hashlib.sha256();n=0
 with path.open('rb')as f:
  while True:
   GUARD();block=f.read(1048576)
   if not block:break
   h.update(block);n+=len(block)
 after=path.stat();require((before.st_ino,before.st_size,before.st_mtime_ns,before.st_ctime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns),'file changed during hash '+str(path))
 return dict(path=str(path),bytes=n,sha256=h.hexdigest())
def save(path,obj):
 tmp=path.with_name(path.name+'.tmp');tmp.write_text(json.dumps(obj,indent=2)+'\n');tmp.replace(path)
def stage_inventory():
 rows=[]
 for p in sorted(STAGE.rglob('*')):
  st=p.lstat();require(not stat.S_ISLNK(st.st_mode),'no stage symlinks')
  if stat.S_ISREG(st.st_mode):rows.append(dict(path=str(p.relative_to(STAGE)),bytes=st.st_size,mode=stat.S_IMODE(st.st_mode),inode=st.st_ino,mtime_ns=st.st_mtime_ns,ctime_ns=st.st_ctime_ns))
 return rows

def inputs(a):
 for row in a['inputs']:require(bind(row['path'])==row,'frozen small input '+row['path'])
 require(bind(STAGE/'session.json')['sha256']==a['component_sha256'],'actual accepted8bd1 component receipt')
 q=json.loads((STAGE/'session.json').read_text());require(q['state']=='PASS component full-cycle-defined-client/full512-hit/logical-intent/coherence family','actual component PASS')
 require(q['admission']['sha256']=='75bffeb61a9c03d7868a27dd7e1cb64f3d97d3c44be37007e2b4225c8ee9c28d','actual component admission')
 require(q['final_source_check']['candidate']['sha256']=='915815d0f66da3bd142b3dbbc999696b8a1ad0c4d34eabb48638c843812d833c','exact static source')
 require(len(q['runs'])==12 and len(q['executables'])==6 and len(q['commands'])==36,'all12 runs/6ELFs/36 phases')
 for row in q['commands']:
  require(row['returncode']==0 and not row['owned_group_remaining'] and row['owned_receipt']['failure'] is None,'all closed normal phases/owned cleanup')
 inv=json.loads((HERE/'stage-inventory.json').read_text());require(stage_inventory()==inv['files'],'ALL closed stage files/stat identities unchanged')
 paths=[]
 for prefix,root in [('stages',STAGE),('proofs',FAMILY)]:
  for p in sorted(root.rglob('*')):
   require(not p.is_symlink(),'no proof/source symlinks')
   if p.is_file():paths.append(p)
 paths.extend([WORK/'bp_common/src/v/bp_retained_line_store.sv']+sorted(p for p in HERE.rglob('*')if p.is_file()))
 require(len(set(paths))==len(paths),'no duplicate source paths')
 return q,paths

def main():
 global GUARD
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--admission-sha256',required=True);ap.add_argument('--execute',action='store_true');args=ap.parse_args()
 require(bind(A)['sha256']==args.admission_sha256,'ROOT-reviewed admission bytes');a=json.loads(A.read_text());require(not OUT.exists(),'fresh closed01 archive output')
 require(a['limits']==dict(durable_bytes=CAP,seconds=DEADLINE,HOME_floor_bytes=FLOOR,separate_source_helper_bytes=SOURCE_CAP),'fixed prospective bounds')
 start=time.monotonic();guard_calls=0;peak=0;source_used=size(FAMILY)+size(WORK)+size(HERE)
 require(source_used<=SOURCE_CAP,'complete separate16MiB source/helper family')
 def guard():
  nonlocal guard_calls,peak
  require(time.monotonic()-start<DEADLINE,'fixed600s total deadline')
  used=size(OUT);peak=max(peak,used);require(used<=CAP,'96MiB complete durable allocation')
  require(shutil.disk_usage(BASE).free>=FLOOR+CAP-used+SOURCE_CAP-source_used,'HOME3GiB plus remaining durable AND separate source/helper allocation')
  guard_calls+=1
 def boundary():
  guard();require(size(FAMILY)+size(WORK)+size(HERE)==source_used,'frozen source/helper phase-boundary sizes changed')
  require(stage_inventory()==json.loads((HERE/'stage-inventory.json').read_text())['files'],'frozen stage phase boundary')
 GUARD=guard;archive_api.bind=bind;guard();q,paths=inputs(a);boundary()
 if not args.execute:
  print(json.dumps(dict(state='PREPARED_ONLY fixed small inputs/closed-proof/stat-budget checks; NO archive/raw-stage hashing',admission=bind(A),source_helper_bytes=source_used,stage_files=len(stage_inventory()),stage_bytes=sum(x['bytes']for x in stage_inventory()),archive_members=len(paths))));return
 old_handlers={s:signal.getsignal(s)for s in [signal.SIGTERM,signal.SIGINT,signal.SIGHUP,signal.SIGALRM]}
 def interrupted(sig,frame):raise TimeoutError('archive own process signal '+str(sig))
 for sig in old_handlers:signal.signal(sig,interrupted)
 signal.alarm(DEADLINE)
 OUT.mkdir();report=dict(state='RUNNING archive only',admission=bind(A),component=bind(STAGE/'session.json'),candidate_commit=a['candidate_commit'],deadline_seconds=DEADLINE,durable_allocation_bytes=CAP,HOME_floor_bytes=FLOOR,source_helper_bytes=source_used,original_refusal_preserved=True,no_execution_reader_build_vendor_board_cleanup=True)
 try:
  # Every file, including all12 rawFSTs/sixELFs/generated C++/headers/objects.
  boundary();rows=[bind(p)for p in paths]
  bypath={r['path']:r for r in rows}
  for expected in [r['fst']for r in q['runs']]+list(q['executables'].values()):require(bypath[expected['path']]==expected,'accepted rawFST/ELF exact hash')
  save(OUT/'plan.json',dict(report,members=rows))
  boundary();report['archive']=archive_api.archive_group(OUT/'closed-stages-and-proofs.tar.gz',rows,guard)
  boundary();_,after_paths=inputs(a);require(paths==after_paths,'complete member set changed')
  for row in rows:require(bind(row['path'])==row,'every original member unchanged after roundtrip')
  boundary();report.update(state='PASS lossless ALL static-slice component/source/proof members; original8MiB prelaunch refusal preserved',members_verified=len(rows),raw_FSTs=12,unit_ELFs=6,stage_actual_bytes=85624133,stage_recorded_prefinal_bytes=q['resources']['stage_bytes'],source_endcheck='PASS')
 except BaseException as e:report.update(state='FAIL archive attempt preserved; no cleanup/retry',error=repr(e));raise
 finally:
  signal.alarm(0)
  for sig,h in old_handlers.items():signal.signal(sig,h)
  report.update(elapsed_seconds=time.monotonic()-start,cheap_guard_calls=guard_calls,peak_durable_bytes=peak)
  try:
   guard();save(OUT/'manifest.json',report);guard()
  except BaseException as e:
   report.update(state='FAIL final archive budget/deadline preserved',final_guard_error=repr(e));save(OUT/'manifest.json',report);raise
  print(OUT/'manifest.json',report['state'])
if __name__=='__main__':main()
