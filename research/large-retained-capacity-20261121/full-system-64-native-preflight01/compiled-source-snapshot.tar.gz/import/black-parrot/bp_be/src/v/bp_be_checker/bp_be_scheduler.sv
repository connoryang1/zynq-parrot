/**
 *
 * Name:
 *   bp_be_scheduler.v
 *
 * Description:
 *   Schedules instruction issue from the FE queue to the Calculator.
 *
 * Notes:
 *   It might make sense to use an enum for RISC-V opcodes rather than `defines.
 *   Floating point instruction decoding is not implemented, so we do not predecode.
 */

`include "bp_common_defines.svh"
`include "bp_be_defines.svh"

module bp_be_scheduler
 import bp_common_pkg::*;
 import bp_be_pkg::*;
 #(parameter bp_params_e bp_params_p = e_bp_default_cfg
   `declare_bp_proc_params(bp_params_p)
   `declare_bp_core_if_widths(vaddr_width_p, paddr_width_p, asid_width_p, branch_metadata_fwd_width_p)
   `declare_bp_be_if_widths(vaddr_width_p, paddr_width_p, asid_width_p, branch_metadata_fwd_width_p, fetch_ptr_p, issue_ptr_p)
   )
  (input                                      clk_i
   , input                                    reset_i

   , output logic [issue_pkt_width_lp-1:0]    issue_pkt_o
   , input [vaddr_width_p-1:0]                expected_npc_i
   , input                                    clear_iss_i
   , input                                    suppress_iss_i
   , input                                    resume_i
   , input [decode_info_width_lp-1:0]         decode_info_i
   , input                                    hazard_v_i
   , input                                    irq_pending_i
   , input                                    ispec_v_i
   , input                                    poison_isd_i
   , input                                    ordered_v_i
   , input [trans_info_width_lp-1:0]          trans_info_i
   , input                                    pending_ctxtsw_sent_i
   , input                                    context_cache_active_i

   // Fetch interface
   , input [fe_queue_width_lp-1:0]            fe_queue_i
   , input                                    fe_queue_v_i
   , output logic                             fe_queue_ready_and_o

   // Dispatch interface
   , output logic [dispatch_pkt_width_lp-1:0] dispatch_pkt_o
   , input [commit_pkt_width_lp-1:0]          commit_pkt_i
   , input [wb_pkt_width_lp-1:0]              iwb_pkt_i
   , input [wb_pkt_width_lp-1:0]              fwb_pkt_i

   , input [wb_pkt_width_lp-1:0]              late_wb_pkt_i
   , input                                    late_wb_v_i
   , input                                    late_wb_force_i
   , output logic                             late_wb_yumi_o

   // Current thread ID for register file reads/writes
   , input [thread_id_width_p-1:0]            current_physical_thread_id_i
   , input [context_id_width_p-1:0]           current_virtual_context_id_i
   , input [thread_id_width_p-1:0]            retire_thread_id_i

   // One immutable protected-RPC descriptor: cap 1, context 0 -> context 1.
   // Top-level state supplies whether its protected call/return edge is legal.
   , input                                    legacy_context_user_enable_i
   , input                                    rpc_call_ready_i
   , input                                    rpc_return_ready_i
   , input                                    rpc_install_v_i
   , input [thread_id_width_p-1:0]            rpc_install_thread_id_i
   , input [15:0]                             rpc_install_w_mask_i
   , input [15:0][dpath_width_gp-1:0]         rpc_install_w_data_i
   , output logic [3:0][dpath_width_gp-1:0]   rpc_args_o

   // CSR 0x802 remote register write into another hardware thread context
   , input                                    rpush_w_v_i
   , input                                    rpush_fp_w_v_i
   , input [thread_id_width_p-1:0]            rpush_tid_i
   , input [reg_addr_width_gp-1:0]            rpush_reg_i
   , input [dpath_width_gp-1:0]               rpush_data_i

   , input [1:0]                              context_cache_scan_r_v_i
   , input [1:0]                              context_cache_scan_w_v_i
   , input [thread_id_width_p-1:0]            context_cache_scan_physical_thread_id_i
   , input [1:0][reg_addr_width_gp-1:0]       context_cache_scan_r_addr_i
   , input [1:0][reg_addr_width_gp-1:0]       context_cache_scan_w_addr_i
   , input [1:0][dpath_width_gp-1:0]          context_cache_scan_w_data_i
   , output logic [1:0][dpath_width_gp-1:0]   context_cache_scan_r_data_o
   , input                                    context_cache_bulk_swap_v_i
   , input [thread_id_width_p-1:0]            context_cache_bulk_swap_physical_thread_id_i
   , input [(2**reg_addr_width_gp)-1:0]       context_cache_bulk_swap_w_mask_i
   , input [(2**reg_addr_width_gp)-1:0][dpath_width_gp-1:0] context_cache_bulk_swap_w_data_i
   , output logic [(2**reg_addr_width_gp)-1:0][dpath_width_gp-1:0] context_cache_bulk_swap_r_data_o
   , input                                    context_cache_line_w_v_i
   , input [thread_id_width_p-1:0]            context_cache_line_physical_thread_id_i
   , input [0:0]                              context_cache_line_index_i
   , input [15:0][dpath_width_gp-1:0]         context_cache_line_data_i
   , input [1:0]                              context_cache_fp_scan_r_v_i
   , input [1:0]                              context_cache_fp_scan_w_v_i
   , input [thread_id_width_p-1:0]            context_cache_fp_scan_physical_thread_id_i
   , input [1:0][reg_addr_width_gp-1:0]       context_cache_fp_scan_r_addr_i
   , input [1:0][reg_addr_width_gp-1:0]       context_cache_fp_scan_w_addr_i
   , input [1:0][dpath_width_gp-1:0]          context_cache_fp_scan_w_data_i
   , output logic [1:0][dpath_width_gp-1:0]   context_cache_fp_scan_r_data_o

   , output logic                             context_cache_drain_ready_o
   );

  // Declare parameterizable structures
  `declare_bp_core_if(vaddr_width_p, paddr_width_p, asid_width_p, branch_metadata_fwd_width_p);
  `declare_bp_be_if(vaddr_width_p, paddr_width_p, asid_width_p, branch_metadata_fwd_width_p, fetch_ptr_p, issue_ptr_p);

  `bp_cast_o(bp_be_issue_pkt_s, issue_pkt);
  `bp_cast_o(bp_be_dispatch_pkt_s, dispatch_pkt);
  `bp_cast_i(bp_be_commit_pkt_s, commit_pkt);
  `bp_cast_i(bp_be_wb_pkt_s, iwb_pkt);
  `bp_cast_i(bp_be_wb_pkt_s, fwb_pkt);
  `bp_cast_i(bp_be_wb_pkt_s, late_wb_pkt);
  `bp_cast_i(bp_be_decode_info_s, decode_info);
  `bp_cast_i(bp_be_trans_info_s, trans_info);

`ifndef SYNTHESIS
  initial begin
    assert ($bits(bp_be_dispatch_pkt_s) == dispatch_pkt_width_lp)
      else $fatal(1, "dispatch packet width macro is stale");
  end
`endif

  logic ptw_busy_lo;
  logic ptw_v_lo, ptw_walk_lo, ptw_itlb_fill_lo, ptw_dtlb_fill_lo;
  logic [fetch_ptr_p-1:0] ptw_count_lo;
  logic ptw_instr_page_fault_lo, ptw_load_page_fault_lo, ptw_store_page_fault_lo;
  logic [dword_width_gp-1:0] ptw_addr_lo, ptw_pte_lo;
  logic [thread_id_width_p-1:0] ptw_thread_id_r;
  logic issue_queue_ready_and_lo;
  logic issue_queue_empty_lo;
  wire ptw_v_li = late_wb_yumi_o & late_wb_pkt_cast_i.ptw_w_v;
  wire [dword_width_gp-1:0] ptw_data_li = late_wb_pkt_cast_i.rd_data;
  wire ptw_start_li = ~ptw_busy_lo
                      & (commit_pkt_cast_i.itlb_miss
                         | commit_pkt_cast_i.dtlb_store_miss
                         | commit_pkt_cast_i.dtlb_load_miss);

  always_ff @(posedge clk_i)
    if (reset_i)
      ptw_thread_id_r <= '0;
    else if (ptw_start_li)
      ptw_thread_id_r <= retire_thread_id_i;

  bp_be_ptw
   #(.bp_params_p(bp_params_p)
     ,.pte_width_p(sv39_pte_width_gp)
     ,.page_table_depth_p(sv39_levels_gp)
     ,.pte_size_in_bytes_p(sv39_pte_size_in_bytes_gp)
     ,.page_idx_width_p(sv39_page_idx_width_gp)
     )
   ptw
    (.clk_i(clk_i)
     ,.reset_i(reset_i)

     ,.busy_o(ptw_busy_lo)
     ,.commit_pkt_i(commit_pkt_cast_i)
     ,.trans_info_i(trans_info_cast_i)
     ,.ordered_i(ordered_v_i)

     ,.v_o(ptw_v_lo)
     ,.walk_o(ptw_walk_lo)
     ,.itlb_fill_o(ptw_itlb_fill_lo)
     ,.dtlb_fill_o(ptw_dtlb_fill_lo)
     ,.instr_page_fault_o(ptw_instr_page_fault_lo)
     ,.load_page_fault_o(ptw_load_page_fault_lo)
     ,.store_page_fault_o(ptw_store_page_fault_lo)
     ,.count_o(ptw_count_lo)
     ,.addr_o(ptw_addr_lo)
     ,.pte_o(ptw_pte_lo)

     ,.v_i(ptw_v_li)
     ,.data_i(ptw_data_li)
     );

  // Prioritization is:
  //   1/2) ptw_fill_pkt/writeback pkt, since there is no backpressure
  //   2) resume request
  //   3) interrupt request
  //   4) finally, fe queue
  wire writeback_v =  late_wb_v_i & (late_wb_force_i | ~issue_pkt_cast_o.v);
  wire resume_v    = ~writeback_v & ~ptw_busy_lo &  resume_i;
  wire interrupt_v = ~writeback_v & ~ptw_busy_lo & ~resume_i & irq_pending_i;

  wire be_exc_not_instr_li =  ptw_v_lo | writeback_v | resume_v | interrupt_v;
  wire fe_exc_not_instr_li = ~be_exc_not_instr_li & issue_pkt_cast_o.v & !issue_pkt_cast_o.fetch;
  wire fe_instr_not_exc_li = ~be_exc_not_instr_li & issue_pkt_cast_o.v &  issue_pkt_cast_o.fetch;

  localparam entry_cinstr_gp = 2**fetch_sel_p;
  localparam op_ptr_width_lp = `BSG_WIDTH(entry_cinstr_gp);
  logic ctxtsw_issue_hold_r;
  bp_be_wb_pkt_s ctxtsw_iwb_pkt_r;
  logic ctxtsw_target_settle_r;
  logic ctxtsw_first_target_dispatch_r;
  logic [3:0] ctxtsw_cancel_drain_r;
  wire ctxtsw_issue_hold_clear_li                  = commit_pkt_cast_i.ctxtsw
                                                     | (commit_pkt_cast_i.npc_w_v & ~commit_pkt_cast_i.ctxtsw);
  wire fe_queue_base_en_li                         = ~suppress_iss_i
                                                     & ~ctxtsw_issue_hold_r
                                                     & ~ptw_busy_lo
                                                     & ~hazard_v_i;
  wire fe_queue_en_li                              = fe_queue_base_en_li
                                                     & ~ctxtsw_target_settle_r;
  wire ctxtsw_commit_accept_li                     = commit_pkt_cast_i.ctxtsw & pending_ctxtsw_sent_i & ~clear_iss_i;
  wire pending_ctxtsw_cancel_li                    = commit_pkt_cast_i.npc_w_v
                                                     & ~commit_pkt_cast_i.ctxtsw
                                                     & pending_ctxtsw_sent_i;
  wire ctxtsw_cancel_drain_li                      = pending_ctxtsw_cancel_li | |ctxtsw_cancel_drain_r;
  wire fe_queue_clr_li                             = clear_iss_i
                                                     | commit_pkt_cast_i.ctxtsw
                                                     | ctxtsw_cancel_drain_li;
  wire fe_queue_roll_li                            = commit_pkt_cast_i.npc_w_v
                                                     & ~commit_pkt_cast_i.ctxtsw
                                                     & ~pending_ctxtsw_sent_i;
  wire fe_queue_read_li                            = fe_instr_not_exc_li | fe_exc_not_instr_li;
  wire [op_ptr_width_lp-1:0] fe_queue_read_size_li = issue_pkt_cast_o.size;
  wire [op_ptr_width_lp-1:0] fe_queue_read_cnt_li  = issue_pkt_cast_o.count;
  wire fe_queue_cmt_li                             = commit_pkt_cast_i.instret;
  wire [op_ptr_width_lp-1:0] fe_queue_cmt_size_li  = commit_pkt_cast_i.size;
  wire [op_ptr_width_lp-1:0] fe_queue_cmt_cnt_li   = commit_pkt_cast_i.count;

  // Could more intelligently schedule these late writebacks, based on availability and dependencies
  assign late_wb_yumi_o = writeback_v;

  bp_be_preissue_pkt_s preissue_pkt;
  bp_be_issue_queue
   #(.bp_params_p(bp_params_p))
   issue_queue
    (.clk_i(clk_i)
     ,.reset_i(reset_i)

     ,.en_i(fe_queue_en_li)
     ,.clr_i(fe_queue_clr_li)
     ,.roll_i(fe_queue_roll_li)
     ,.read_i(fe_queue_read_li)
     ,.read_cnt_i(fe_queue_read_cnt_li)
     ,.read_size_i(fe_queue_read_size_li)
     ,.cmt_i(fe_queue_cmt_li)
     ,.cmt_cnt_i(fe_queue_cmt_cnt_li)
     ,.cmt_size_i(fe_queue_cmt_size_li)

     ,.fe_queue_i(fe_queue_i)
     ,.fe_queue_v_i(fe_queue_v_i)
     ,.fe_queue_ready_and_o(issue_queue_ready_and_lo)

     ,.decode_info_i(decode_info_i)
     ,.preissue_pkt_o(preissue_pkt)
     ,.issue_pkt_o(issue_pkt_cast_o)
     ,.empty_o(issue_queue_empty_lo)
     );
  rv64_instr_fmatype_s preissue_instr;
  assign preissue_instr = preissue_pkt.instr;
  wire [thread_id_width_p-1:0] preissue_thread_id_li =
    preissue_pkt.thread_id[0 +: thread_id_width_p];

  logic [1:0] int_rs_r_v_li;
  logic [1:0][thread_id_width_p-1:0] int_rs_thread_id_li;
  logic [1:0][reg_addr_width_gp-1:0] int_rs_addr_li;
  logic int_rpush_w_v_li;
  logic [thread_id_width_p-1:0] int_rpush_tid_li;
  logic [reg_addr_width_gp-1:0] int_rpush_reg_li;
  logic [dpath_width_gp-1:0] int_rpush_data_li;
  logic [dpath_width_gp-1:0] irf_rs1, irf_rs2;
  always_comb begin
    if (|context_cache_scan_r_v_i) begin
      int_rs_r_v_li = context_cache_scan_r_v_i;
      int_rs_thread_id_li[0] = context_cache_scan_physical_thread_id_i;
      int_rs_thread_id_li[1] = context_cache_scan_physical_thread_id_i;
      int_rs_addr_li[0] = context_cache_scan_r_addr_i[0];
      int_rs_addr_li[1] = context_cache_scan_r_addr_i[1];
    end else begin
      int_rs_r_v_li = {preissue_pkt.irs2_v, preissue_pkt.irs1_v};
      int_rs_thread_id_li[0] = preissue_thread_id_li;
      int_rs_thread_id_li[1] = preissue_thread_id_li;
      int_rs_addr_li[0] = preissue_instr.rs1_addr;
      int_rs_addr_li[1] = preissue_instr.rs2_addr;
    end
  end

  assign int_rpush_w_v_li = context_cache_scan_w_v_i[0] | rpush_w_v_i;
  assign int_rpush_tid_li = context_cache_scan_w_v_i[0] ? context_cache_scan_physical_thread_id_i : rpush_tid_i;
  assign int_rpush_reg_li = context_cache_scan_w_v_i[0] ? context_cache_scan_w_addr_i[0] : rpush_reg_i;
  assign int_rpush_data_li = context_cache_scan_w_v_i[0] ? context_cache_scan_w_data_i[0] : rpush_data_i;

`ifndef SYNTHESIS
  // Check CSR802's scalar port ownership, independently of the separately
  // drained context-image restore ports. Integer x0 has no architectural WB;
  // FP register zero is an ordinary architectural destination.
  always_ff @(posedge clk_i)
    if (!reset_i) begin
      if (rpush_w_v_i && iwb_pkt_cast_i.ird_w_v && (iwb_pkt_cast_i.rd_addr != '0))
        $error("%m: CSR802 integer remote write collides with ordinary writeback");
      if (rpush_fp_w_v_i && fwb_pkt_cast_i.frd_w_v)
        $error("%m: CSR802 FP remote write collides with ordinary writeback");
    end
`endif
  assign context_cache_scan_r_data_o = {irf_rs2, irf_rs1};
  logic [15:0][dpath_width_gp-1:0] rpc_line_r_data_lo;
  logic [3:0][dpath_width_gp-1:0] rpc_args_r;
  assign rpc_args_o = rpc_args_r;

  bp_be_regfile_mt
  #(.bp_params_p(bp_params_p)
    ,.read_ports_p(2)
    ,.zero_x0_p(1)
    ,.data_width_p($bits(bp_be_int_reg_s))
    ,.write_ports_p(1)
    ,.context_line_p(1)
    ,.context_regs_per_line_p(16)
    )
   int_regfile
    (.clk_i(clk_i)
     ,.reset_i(reset_i)

     ,.rd_w_v_i(iwb_pkt_cast_i.ird_w_v)
     ,.rd_thread_id_i(iwb_pkt_cast_i.thread_id)
     ,.rd_addr_i(iwb_pkt_cast_i.rd_addr)
     ,.rd_data_i(iwb_pkt_cast_i.rd_data)

     ,.rpush_w_v_i(int_rpush_w_v_li)
     ,.rpush_thread_id_i(int_rpush_tid_li)
     ,.rpush_addr_i(int_rpush_reg_li)
     ,.rpush_data_i(int_rpush_data_li)

     ,.rd_w_v2_i(context_cache_scan_w_v_i[1])
     ,.rd_thread_id2_i(context_cache_scan_physical_thread_id_i)
     ,.rd_addr2_i(context_cache_scan_w_addr_i[1])
     ,.rd_data2_i(context_cache_scan_w_data_i[1])

     ,.context_swap_v_i(context_cache_bulk_swap_v_i)
     ,.context_swap_thread_id_i(context_cache_bulk_swap_physical_thread_id_i)
     ,.context_swap_w_mask_i(context_cache_bulk_swap_w_mask_i)
     ,.context_swap_data_i(context_cache_bulk_swap_w_data_i)
     ,.context_swap_data_o(context_cache_bulk_swap_r_data_o)

     ,.context_line_w_v_i(context_cache_line_w_v_i)
     ,.context_line_thread_id_i(context_cache_line_physical_thread_id_i)
     ,.context_line_index_i(context_cache_line_index_i)
     ,.context_line_data_i(context_cache_line_data_i)
     ,.context_line_r_data_o(rpc_line_r_data_lo)
     ,.rpc_w_v_i(rpc_install_v_i)
     ,.rpc_thread_id_i(rpc_install_thread_id_i)
     ,.rpc_w_mask_i(rpc_install_w_mask_i)
     ,.rpc_w_data_i(rpc_install_w_data_i)

     ,.rs_r_v_i(int_rs_r_v_li)
     ,.rs_thread_id_i(int_rs_thread_id_li)
     ,.rs_addr_i(int_rs_addr_li)
     ,.rs_data_o({irf_rs2, irf_rs1})
     );

  logic [dpath_width_gp-1:0] frf_rs1, frf_rs2, frf_rs3;
  logic [2:0] fp_rs_r_v_li;
  logic [2:0][thread_id_width_p-1:0] fp_rs_thread_id_li;
  logic [2:0][reg_addr_width_gp-1:0] fp_rs_addr_li;
  logic fp_rpush_w_v_li;
  logic [thread_id_width_p-1:0] fp_rpush_tid_li;
  logic [reg_addr_width_gp-1:0] fp_rpush_reg_li;
  logic [dpath_width_gp-1:0] fp_rpush_data_li;
  always_comb begin
    if (|context_cache_fp_scan_r_v_i) begin
      fp_rs_r_v_li[0] = context_cache_fp_scan_r_v_i[0];
      fp_rs_r_v_li[1] = context_cache_fp_scan_r_v_i[1];
      fp_rs_r_v_li[2] = 1'b0;
      fp_rs_thread_id_li[0] = context_cache_fp_scan_physical_thread_id_i;
      fp_rs_thread_id_li[1] = context_cache_fp_scan_physical_thread_id_i;
      fp_rs_thread_id_li[2] = '0;
      fp_rs_addr_li[0] = context_cache_fp_scan_r_addr_i[0];
      fp_rs_addr_li[1] = context_cache_fp_scan_r_addr_i[1];
      fp_rs_addr_li[2] = '0;
    end else begin
      fp_rs_r_v_li = {preissue_pkt.frs3_v, preissue_pkt.frs2_v, preissue_pkt.frs1_v};
      fp_rs_thread_id_li[0] = preissue_thread_id_li;
      fp_rs_thread_id_li[1] = preissue_thread_id_li;
      fp_rs_thread_id_li[2] = preissue_thread_id_li;
      fp_rs_addr_li[0] = preissue_instr.rs1_addr;
      fp_rs_addr_li[1] = preissue_instr.rs2_addr;
      fp_rs_addr_li[2] = preissue_instr.rs3_addr;
    end
  end

  assign fp_rpush_w_v_li = context_cache_fp_scan_w_v_i[0] | rpush_fp_w_v_i;
  assign fp_rpush_tid_li = context_cache_fp_scan_w_v_i[0] ? context_cache_fp_scan_physical_thread_id_i : rpush_tid_i;
  assign fp_rpush_reg_li = context_cache_fp_scan_w_v_i[0] ? context_cache_fp_scan_w_addr_i[0] : rpush_reg_i;
  assign fp_rpush_data_li = context_cache_fp_scan_w_v_i[0] ? context_cache_fp_scan_w_data_i[0] : rpush_data_i;
  assign context_cache_fp_scan_r_data_o = {frf_rs2, frf_rs1};
  bp_be_regfile_mt
  // Nonresident FP copying is disabled in the GPR-only context-cache design.
  // Keep the ordinary FP write/rpush port, but do not pay for the unreachable
  // second restore-only write port on FPGA.
  #(.bp_params_p(bp_params_p), .read_ports_p(3), .zero_x0_p(0), .data_width_p($bits(bp_be_fp_reg_s)), .write_ports_p(1))
   fp_regfile
    (.clk_i(clk_i)
     ,.reset_i(reset_i)

     ,.rd_w_v_i(fwb_pkt_cast_i.frd_w_v)
     ,.rd_thread_id_i(fwb_pkt_cast_i.thread_id)
     ,.rd_addr_i(fwb_pkt_cast_i.rd_addr)
     ,.rd_data_i(fwb_pkt_cast_i.rd_data)

     ,.rpush_w_v_i(fp_rpush_w_v_li)
     ,.rpush_thread_id_i(fp_rpush_tid_li)
     ,.rpush_addr_i(fp_rpush_reg_li)
     ,.rpush_data_i(fp_rpush_data_li)

     ,.rd_w_v2_i(1'b0)
     ,.rd_thread_id2_i('0)
     ,.rd_addr2_i('0)
     ,.rd_data2_i('0)

     ,.context_swap_v_i(1'b0)
     ,.context_swap_thread_id_i('0)
     ,.context_swap_w_mask_i('0)
     ,.context_swap_data_i('0)
     ,.context_swap_data_o()

     ,.context_line_w_v_i(1'b0)
     ,.context_line_thread_id_i('0)
     ,.context_line_index_i('0)
     ,.context_line_data_i('0)
     ,.context_line_r_data_o()
     ,.rpc_w_v_i(1'b0)
     ,.rpc_thread_id_i('0)
     ,.rpc_w_mask_i('0)
     ,.rpc_w_data_i('0)

     ,.rs_r_v_i(fp_rs_r_v_li)
     ,.rs_thread_id_i(fp_rs_thread_id_li)
     ,.rs_addr_i(fp_rs_addr_li)
     ,.rs_data_o({frf_rs3, frf_rs2, frf_rs1})
     );

  bp_be_decode_s fe_exc_decode_li;
  rv64_instr_fmatype_s fe_exc_instr_li;
  wire [vaddr_width_p-1:0] fe_exc_pc_li = issue_pkt_cast_o.pc;
  wire [vaddr_width_p-1:0] fe_exc_vaddr_li = fe_exc_pc_li + (issue_pkt_cast_o.count << 1'b1);
  wire [dpath_width_gp-1:0] fe_exc_data_li = '0;
  wire [dpath_width_gp-1:0] fe_exc_imm_li = '0;
  assign fe_exc_decode_li = '0;
  assign fe_exc_instr_li = issue_pkt_cast_o.instr;
  wire [fetch_ptr_p-1:0] fe_exc_size_li = issue_pkt_cast_o.size;
  wire [fetch_ptr_p-1:0] fe_exc_count_li = issue_pkt_cast_o.count;

  bp_be_decode_s be_exc_decode_li, wb_decode_li, walk_decode_li;
  rv64_instr_fmatype_s be_exc_instr_li, wb_instr_li;
  wire [dpath_width_gp-1:0] be_exc_vaddr_li = ptw_v_lo ? ptw_addr_lo : writeback_v ? '0 : '0;
  wire [dpath_width_gp-1:0] be_exc_data_li = ptw_v_lo ? ptw_pte_lo : writeback_v ? late_wb_pkt_cast_i.rd_data : '0;
  wire [dpath_width_gp-1:0] be_exc_imm_li = ptw_v_lo ? '0 : writeback_v ? late_wb_pkt_cast_i.fflags : '0;
  assign be_exc_decode_li = ptw_v_lo ? walk_decode_li : writeback_v ? wb_decode_li : '0;
  assign be_exc_instr_li = ptw_v_lo ? issue_pkt_cast_o.instr : writeback_v ? wb_instr_li : '0;
  wire [fetch_ptr_p-1:0] be_exc_size_li = '0;
  wire [fetch_ptr_p-1:0] be_exc_count_li = ptw_v_lo ? ptw_count_lo : writeback_v ? '0 : '0;

  wire issue_regular_ctxtsw_candidate_v =
    fe_instr_not_exc_li
    & issue_pkt_cast_o.csrw
    & (issue_pkt_cast_o.instr.t.itype.imm12 == 12'h800);
  wire issue_regular_ctxtsw_v = issue_regular_ctxtsw_candidate_v
                                 & (legacy_context_user_enable_i
                                    | decode_info_cast_i.m_mode);

  wire issue_rpc_call_candidate_v = fe_instr_not_exc_li
    & issue_pkt_cast_o.csrw
    & (issue_pkt_cast_o.instr.t.itype.imm12 == 12'h808);
  wire issue_rpc_return_candidate_v = fe_instr_not_exc_li
    & issue_pkt_cast_o.csrw
    & (issue_pkt_cast_o.instr.t.itype.imm12 == 12'h809);
  wire issue_rpc_call_v = issue_rpc_call_candidate_v
                          & rpc_call_ready_i
                          & (irf_rs1 == dpath_width_gp'(1));
  wire issue_rpc_return_v = issue_rpc_return_candidate_v & rpc_return_ready_i;
  wire issue_ctxtsw_v = issue_regular_ctxtsw_v | issue_rpc_call_v | issue_rpc_return_v;

  wire issue_ctxtsw_imm_v = issue_regular_ctxtsw_v &
    issue_pkt_cast_o.instr inside {`RV64_CSRRWI, `RV64_CSRRSI, `RV64_CSRRCI};

  wire [thread_id_width_p-1:0] issue_thread_id_li =
    issue_pkt_cast_o.thread_id[0 +: thread_id_width_p];

  // The detector holds a dependent CSR800 through its producer's live IWB
  // cycle. Consume that exact writeback on the following cycle rather than
  // relying on FPGA block-RAM read-during-write behavior.
  wire issue_ctxtsw_iwb_bypass_v = issue_ctxtsw_v
                                    & ~issue_ctxtsw_imm_v
                                    & ctxtsw_iwb_pkt_r.ird_w_v
                                    & (ctxtsw_iwb_pkt_r.thread_id == issue_thread_id_li)
                                    & (ctxtsw_iwb_pkt_r.rd_addr
                                       == issue_pkt_cast_o.instr.t.fmatype.rs1_addr)
                                    & (ctxtsw_iwb_pkt_r.rd_addr != '0);
  wire [context_id_width_p-1:0] issue_ctxtsw_register_target_tid =
    issue_ctxtsw_iwb_bypass_v
      ? ctxtsw_iwb_pkt_r.rd_data[0 +: context_id_width_p]
      : irf_rs1[0 +: context_id_width_p];

  wire [context_id_width_p-1:0] issue_ctxtsw_target_tid =
    issue_rpc_call_v ? context_id_width_p'(1)
    : issue_rpc_return_v ? context_id_width_p'(0)
    : issue_ctxtsw_imm_v
      ? context_id_width_p'(issue_pkt_cast_o.instr.t.fmatype.rs1_addr)
      : issue_ctxtsw_register_target_tid;

  wire issue_ctxtsw_switch_v = issue_ctxtsw_v & (issue_ctxtsw_target_tid != current_virtual_context_id_i);
  wire issue_ctxtsw_dispatch_v = fe_queue_read_li
                                  & ~hazard_v_i
                                  & ~poison_isd_i
                                  & ~ctxtsw_cancel_drain_li
                                  & issue_ctxtsw_switch_v;
  wire ctxtsw_queue_hold_li = (ctxtsw_issue_hold_r & ~ctxtsw_commit_accept_li)
                              | issue_ctxtsw_dispatch_v
                              | (fe_queue_clr_li & ~ctxtsw_commit_accept_li);

  assign fe_queue_ready_and_o = (issue_queue_ready_and_lo | ctxtsw_commit_accept_li)
                                & ~ctxtsw_queue_hold_li
                                & ~context_cache_active_i;
  assign context_cache_drain_ready_o = issue_queue_empty_lo
                                        & ~issue_pkt_cast_o.v
                                        & ~dispatch_pkt_cast_o.v
                                        & ~ptw_busy_lo
                                        & ~writeback_v
                                        & ~ctxtsw_issue_hold_r
                                        & ~ctxtsw_cancel_drain_li;

  always_ff @(posedge clk_i)
    if (reset_i)
      ctxtsw_issue_hold_r <= 1'b0;
    else if (ctxtsw_issue_hold_clear_li)
      ctxtsw_issue_hold_r <= 1'b0;
    else if (issue_ctxtsw_dispatch_v)
      ctxtsw_issue_hold_r <= 1'b1;

  // Keep implicit operands beside the scheduler instead of widening every
  // dispatch and reservation stage by four data words. A pending switch token
  // prevents another switch from replacing them before top-level capture.
  always_ff @(posedge clk_i)
    if (reset_i)
      rpc_args_r <= '0;
    else if (issue_ctxtsw_dispatch_v & (issue_rpc_call_v | issue_rpc_return_v)) begin
      rpc_args_r[0] <= rpc_line_r_data_lo[10];
      rpc_args_r[1] <= rpc_line_r_data_lo[11];
      rpc_args_r[2] <= rpc_line_r_data_lo[12];
      rpc_args_r[3] <= rpc_line_r_data_lo[13];
    end

  always_ff @(posedge clk_i)
    if (reset_i)
      ctxtsw_iwb_pkt_r <= '0;
    else
      ctxtsw_iwb_pkt_r <= iwb_pkt_cast_i;

  // Physical testing found that the first target instruction must remain out
  // of dispatch for one edge after a committed switch.  Keep the interlock
  // pending across the ordinary empty redirect gap, then consume it only when
  // the target queue head would otherwise be eligible to issue.  The FE queue
  // may continue to fill while the backend waits.
  always_ff @(posedge clk_i)
    if (reset_i)
      ctxtsw_target_settle_r <= 1'b0;
    else if (commit_pkt_cast_i.ctxtsw)
      ctxtsw_target_settle_r <= 1'b1;
    else if (ctxtsw_target_settle_r & ~issue_queue_empty_lo & fe_queue_base_en_li)
      ctxtsw_target_settle_r <= 1'b0;

  // A context-switch redirect can replace the issue-queue PC/instruction one
  // cycle before the queue's registered branch-metadata thread tag.  Preserve
  // the issue-carried tag for ordinary in-flight hazards, but tag the first
  // target instruction with the authoritative current physical slot.
  wire first_target_dispatch_li = ctxtsw_first_target_dispatch_r
                                  & fe_queue_read_li
                                  & ~poison_isd_i
                                  & ~ctxtsw_cancel_drain_li
                                  & ~be_exc_not_instr_li;
  always_ff @(posedge clk_i)
    if (reset_i)
      ctxtsw_first_target_dispatch_r <= 1'b0;
    else if (commit_pkt_cast_i.ctxtsw)
      ctxtsw_first_target_dispatch_r <= 1'b1;
    else if (first_target_dispatch_li)
      ctxtsw_first_target_dispatch_r <= 1'b0;

  always_ff @(posedge clk_i)
    if (reset_i)
      ctxtsw_cancel_drain_r <= '0;
    else if (pending_ctxtsw_cancel_li)
      ctxtsw_cancel_drain_r <= '1;
    else
      ctxtsw_cancel_drain_r <= {1'b0, ctxtsw_cancel_drain_r[3:1]};

  assign wb_instr_li = '{rd_addr: late_wb_pkt_cast_i.rd_addr, default: '0};
  assign wb_decode_li = '{irf_w_v: late_wb_pkt_cast_i.ird_w_v, frf_w_v: late_wb_pkt_cast_i.frd_w_v, default: '0};
  assign walk_decode_li = '{pipe_mem_final_v: ptw_walk_lo, dcache_mmu_v: ptw_walk_lo, fu_op: e_dcache_op_ptw, default: '0};

  always_comb
    begin
      // Form dispatch packet
      dispatch_pkt_cast_o = '0;
      dispatch_pkt_cast_o.v          = (fe_queue_read_li & ~poison_isd_i & ~ctxtsw_cancel_drain_li) || be_exc_not_instr_li;
      dispatch_pkt_cast_o.queue_v    = (fe_queue_read_li & ~poison_isd_i & ~ctxtsw_cancel_drain_li);
      dispatch_pkt_cast_o.ispec_v    = fe_instr_not_exc_li & ispec_v_i;
      dispatch_pkt_cast_o.nspec_v    = ptw_v_lo | writeback_v;
      dispatch_pkt_cast_o.ctxtsw_v   = issue_ctxtsw_dispatch_v;
      dispatch_pkt_cast_o.ctxtsw_target_tid = issue_ctxtsw_dispatch_v ? issue_ctxtsw_target_tid : '0;
      dispatch_pkt_cast_o.rpc_call_v = issue_ctxtsw_dispatch_v & issue_rpc_call_v;
      dispatch_pkt_cast_o.rpc_return_v = issue_ctxtsw_dispatch_v & issue_rpc_return_v;
      dispatch_pkt_cast_o.pc         = expected_npc_i;
      dispatch_pkt_cast_o.thread_id  = ptw_v_lo
                                       ? ptw_thread_id_r
                                       : writeback_v
                                       ? late_wb_pkt_cast_i.thread_id
                                       : ctxtsw_first_target_dispatch_r
                                       ? current_physical_thread_id_i
                                       : issue_thread_id_li;
      dispatch_pkt_cast_o.instr      = be_exc_not_instr_li ? be_exc_instr_li   : fe_exc_not_instr_li ? fe_exc_instr_li  : issue_pkt_cast_o.instr;
      dispatch_pkt_cast_o.size       = be_exc_not_instr_li ? be_exc_size_li    : fe_exc_not_instr_li ? fe_exc_size_li   : issue_pkt_cast_o.size;
      dispatch_pkt_cast_o.count      = be_exc_not_instr_li ? be_exc_count_li   : fe_exc_not_instr_li ? fe_exc_count_li  : issue_pkt_cast_o.count;
      dispatch_pkt_cast_o.rs1        = be_exc_not_instr_li ? be_exc_vaddr_li   : fe_exc_not_instr_li ? fe_exc_vaddr_li  : issue_pkt_cast_o.decode.frs1_r_v ? frf_rs1 : irf_rs1;
      dispatch_pkt_cast_o.rs2        = be_exc_not_instr_li ? be_exc_data_li    : fe_exc_not_instr_li ? fe_exc_data_li   : issue_pkt_cast_o.decode.frs2_r_v ? frf_rs2 : irf_rs2;
      dispatch_pkt_cast_o.imm        = be_exc_not_instr_li ? be_exc_imm_li     : fe_exc_not_instr_li ? fe_exc_imm_li    : issue_pkt_cast_o.decode.frs3_r_v ? frf_rs3 : issue_pkt_cast_o.imm;
      dispatch_pkt_cast_o.decode     = be_exc_not_instr_li ? be_exc_decode_li  : fe_exc_not_instr_li ? fe_exc_decode_li : issue_pkt_cast_o.decode;

      dispatch_pkt_cast_o.exception.instr_page_fault |= be_exc_not_instr_li & ptw_instr_page_fault_lo;
      dispatch_pkt_cast_o.exception.load_page_fault  |= be_exc_not_instr_li & ptw_load_page_fault_lo;
      dispatch_pkt_cast_o.exception.store_page_fault |= be_exc_not_instr_li & ptw_store_page_fault_lo;
      dispatch_pkt_cast_o.exception.itlb_fill        |= be_exc_not_instr_li & ptw_itlb_fill_lo;
      dispatch_pkt_cast_o.exception.dtlb_fill        |= be_exc_not_instr_li & ptw_dtlb_fill_lo;
      dispatch_pkt_cast_o.exception.resume           |= be_exc_not_instr_li & resume_v;
      dispatch_pkt_cast_o.exception._interrupt       |= be_exc_not_instr_li & interrupt_v;

      dispatch_pkt_cast_o.exception.instr_access_fault |= fe_exc_not_instr_li & issue_pkt_cast_o.instr_access_fault;
      dispatch_pkt_cast_o.exception.instr_page_fault   |= fe_exc_not_instr_li & issue_pkt_cast_o.instr_page_fault;
      dispatch_pkt_cast_o.exception.itlb_miss          |= fe_exc_not_instr_li & issue_pkt_cast_o.itlb_miss;
      dispatch_pkt_cast_o.exception.icache_miss        |= fe_exc_not_instr_li & issue_pkt_cast_o.icache_miss;
      dispatch_pkt_cast_o.exception.illegal_instr      |= fe_exc_not_instr_li & issue_pkt_cast_o.illegal_instr;

      dispatch_pkt_cast_o.exception.ecall_m       |= fe_instr_not_exc_li & issue_pkt_cast_o.ecall_m;
      dispatch_pkt_cast_o.exception.ecall_s       |= fe_instr_not_exc_li & issue_pkt_cast_o.ecall_s;
      dispatch_pkt_cast_o.exception.ecall_u       |= fe_instr_not_exc_li & issue_pkt_cast_o.ecall_u;
      dispatch_pkt_cast_o.exception.ebreak        |= fe_instr_not_exc_li & issue_pkt_cast_o.ebreak;
      dispatch_pkt_cast_o.special.dbreak          |= fe_instr_not_exc_li & issue_pkt_cast_o.dbreak;
      dispatch_pkt_cast_o.special.dret            |= fe_instr_not_exc_li & issue_pkt_cast_o.dret;
      dispatch_pkt_cast_o.special.mret            |= fe_instr_not_exc_li & issue_pkt_cast_o.mret;
      dispatch_pkt_cast_o.special.sret            |= fe_instr_not_exc_li & issue_pkt_cast_o.sret;
      dispatch_pkt_cast_o.special.wfi             |= fe_instr_not_exc_li & issue_pkt_cast_o.wfi;
      dispatch_pkt_cast_o.special.sfence_vma      |= fe_instr_not_exc_li & issue_pkt_cast_o.sfence_vma;
      dispatch_pkt_cast_o.special.fencei          |= fe_instr_not_exc_li & issue_pkt_cast_o.fencei;
      dispatch_pkt_cast_o.special.csrw            |= fe_instr_not_exc_li & issue_pkt_cast_o.csrw;
    end

endmodule
