
`include "bp_common_defines.svh"
`include "bp_be_defines.svh"

module bp_be_csr
 import bp_common_pkg::*;
 import bp_be_pkg::*;
 #(parameter bp_params_e bp_params_p = e_bp_default_cfg
   , parameter bit retained_buffer_p = 1'b0
   `declare_bp_proc_params(bp_params_p)
   `declare_bp_be_if_widths(vaddr_width_p, paddr_width_p, asid_width_p, branch_metadata_fwd_width_p, fetch_ptr_p, issue_ptr_p)
   , localparam cfg_bus_width_lp = `bp_cfg_bus_width(vaddr_width_p, hio_width_p, core_id_width_p, cce_id_width_p, lce_id_width_p, did_width_p)
   , localparam csr_context_csrs_lp = 26
   , localparam csr_context_width_lp = csr_context_csrs_lp*dword_width_gp + rv64_priv_width_gp
   )
  (input                                     clk_i
   , input                                   reset_i

   , input [63:0] retained_control_status_i
   , output logic retained_control_cmd_v_o
   , output logic [3:0] retained_control_o

   , input [cfg_bus_width_lp-1:0]            cfg_bus_i

   // Core-wide physical timebase.  This is never context-saved or restored.
   , input [dword_width_gp-1:0]               global_cycle_i

   // CSR check interface
   , input                                   csr_r_v_i
   , input [rv64_csr_addr_width_gp-1:0]      csr_r_addr_i
   , output logic [dword_width_gp-1:0]       csr_r_data_o
   , output logic                            csr_r_illegal_o

   // Misc interface
   , input [retire_pkt_width_lp-1:0]         retire_pkt_i
   , input                                   retire_ctxtsw_v_i
   , input rv64_fflags_s                     fflags_acc_i
   , input                                   frf_w_v_i

   // Interrupts
   , input                                   debug_irq_i
   , input                                   timer_irq_i
   , input                                   software_irq_i
   , input                                   m_external_irq_i
   , input                                   s_external_irq_i
   , output logic                            irq_pending_o
   , output logic                            irq_waiting_o

   // The final commit packet
   , output logic [commit_pkt_width_lp-1:0]  commit_pkt_o

   // Slow signals
   , output logic [decode_info_width_lp-1:0] decode_info_o
   , output logic [trans_info_width_lp-1:0]  trans_info_o
   , output rv64_frm_e                       frm_dyn_o

   // Context switching control
   , input [thread_id_width_p-1:0]           current_physical_thread_id_i
   , input [context_id_width_p-1:0]          current_virtual_context_id_i
   , input                                   legacy_context_user_enable_i

   // Physical CSR bank save/restore for nonresident virtual contexts.
   , input                                   csr_context_restore_v_i
   , input                                   csr_context_apc_write_v_i
   , input                                   csr_context_restore_reset_i
   , input [csr_context_width_lp-1:0]        csr_context_restore_data_i
   , input [vaddr_width_p-1:0]               csr_context_restore_npc_i
   , output logic [csr_context_width_lp-1:0] csr_context_save_data_o

   // Bootstrap: write a target NPC for a virtual context (CSR 0x801)
   // Write format: upper bits = context_id, lower vaddr_width_p bits = target NPC
   , output logic                            ctx_npc_write_v_o
   , output logic                            ctx_npc_write_rebind_o
   , output logic                            ctx_npc_write_rpc_entry_o
   , output logic [context_id_width_p-1:0]   ctx_npc_write_virtual_context_id_o
   , output logic [vaddr_width_p-1:0]        ctx_npc_write_npc_o

   // CSR 0x802 remote register write into a virtual context
   // Write format: bits[38:0]=value, context_id, reg_addr, fp_sel
   , output logic                            ctx_rpush_v_o
   , output logic                            ctx_rpush_fp_v_o
   , output logic [context_id_width_p-1:0]   ctx_rpush_virtual_context_id_o
   , output logic [reg_addr_width_gp-1:0]    ctx_rpush_reg_o
   , output logic [dpath_width_gp-1:0]       ctx_rpush_data_o

   // Compatibility: keep every project context CSR in the collision-free custom range.
   // Context-cache L1 D$ service: 0x803 data/result, 0x804 command/status.
   , input                                   ctx_l1_ready_i
   , input                                   ctx_l1_resp_v_i
   , input [dword_width_gp-1:0]              ctx_l1_resp_data_i
   , output logic                            ctx_l1_cmd_v_o
   , output logic                            ctx_l1_cmd_w_o
   , output logic [paddr_width_p-1:0]        ctx_l1_cmd_paddr_o
   , output logic [dword_width_gp-1:0]       ctx_l1_cmd_data_o

   // Core-wide accepted cache-miss trace: 0x805 control/status,
   // 0x806 read selector, and 0x807 selected record.
   , input [dword_width_gp-1:0]              miss_trace_status_i
   , input [dword_width_gp-1:0]              miss_trace_data_i
   , output logic                            miss_trace_ctrl_v_o
   , output logic                            miss_trace_arm_o
   , output logic                            miss_trace_clear_o
   , output logic                            miss_trace_read_v_o
   , output logic                            miss_trace_read_source_o
   , output logic [7:0]                      miss_trace_read_index_o

   // Machine-mode physical instruction replay enqueue. The address is
   // advisory; architectural fetch still performs its ordinary translation
   // and execute-permission checks before consuming an installed line.
   , input                                   icache_replay_ready_i
   , output logic                            icache_replay_v_o
   , output logic [paddr_width_p-1:0]        icache_replay_paddr_o

   // Core-wide shared instruction-prefix replay control. Machine mode owns
   // physical table contents and length; supervisor mode may only trigger the
   // already configured table and inspect its aggregate status.
   , input [63:0]                            icache_retention_status_i
   , output logic                            icache_retention_cmd_v_o
   , output logic [1:0]                      icache_retention_mode_o
   , input [dword_width_gp-1:0]              icache_prefix_status_i
   , output logic                            icache_prefix_entry_v_o
   , output logic [7:0]                      icache_prefix_entry_index_o
   , output logic [paddr_width_p-1:0]        icache_prefix_entry_paddr_o
   , output logic                            icache_prefix_count_v_o
   , output logic [8:0]                      icache_prefix_count_o
   , output logic                            icache_prefix_trigger_v_o
   , output logic                            icache_prefix_trigger_range_v_o
   , output logic [7:0]                      icache_prefix_trigger_start_o
   , output logic [8:0]                      icache_prefix_trigger_count_o
   , output logic                            icache_prefix_clear_v_o

   // Supervisor physical data preview. The address becomes visible only
   // when the CSR instruction retires and is validated again by PMA.
   , input                                   physical_preview_idle_i
   , output logic                            physical_preview_v_o
   , output logic [paddr_width_p-1:0]        physical_preview_paddr_o

   // Tagged physical-data footprint configuration and wakeup command.
   , input [dword_width_gp-1:0]              dcache_replay_status_i
   , output logic                            dcache_replay_entry_v_o
   , output logic                            dcache_replay_config_v_o
   , output logic                            dcache_replay_trigger_v_o
   , output logic [dword_width_gp-1:0]       dcache_replay_payload_o
   );

  // Declare parameterizable structs
  `declare_bp_cfg_bus_s(vaddr_width_p, hio_width_p, core_id_width_p, cce_id_width_p, lce_id_width_p, did_width_p);
  `declare_bp_be_if(vaddr_width_p, paddr_width_p, asid_width_p, branch_metadata_fwd_width_p, fetch_ptr_p, issue_ptr_p);

  `declare_csr_structs(vaddr_width_p, paddr_width_p);
  `bp_cast_i(bp_cfg_bus_s, cfg_bus);
  `bp_cast_i(bp_be_retire_pkt_s, retire_pkt);
  `bp_cast_o(bp_be_commit_pkt_s, commit_pkt);
  `bp_cast_o(bp_be_decode_info_s, decode_info);
  `bp_cast_o(bp_be_trans_info_s, trans_info);

  typedef struct packed {
    logic [dword_width_gp-1:0] dcsr;
    logic [dword_width_gp-1:0] dpc;
    logic [dword_width_gp-1:0] dscratch0;
    logic [dword_width_gp-1:0] dscratch1;
    logic [dword_width_gp-1:0] mstatus;
    logic [dword_width_gp-1:0] medeleg;
    logic [dword_width_gp-1:0] mideleg;
    logic [dword_width_gp-1:0] mie;
    logic [dword_width_gp-1:0] mtvec;
    logic [dword_width_gp-1:0] mcounteren;
    logic [dword_width_gp-1:0] mscratch;
    logic [dword_width_gp-1:0] mepc;
    logic [dword_width_gp-1:0] mcause;
    logic [dword_width_gp-1:0] mtval;
    logic [dword_width_gp-1:0] mip;
    logic [dword_width_gp-1:0] mcycle;
    logic [dword_width_gp-1:0] minstret;
    logic [dword_width_gp-1:0] mcountinhibit;
    logic [dword_width_gp-1:0] stvec;
    logic [dword_width_gp-1:0] scounteren;
    logic [dword_width_gp-1:0] sscratch;
    logic [dword_width_gp-1:0] sepc;
    logic [dword_width_gp-1:0] scause;
    logic [dword_width_gp-1:0] stval;
    logic [dword_width_gp-1:0] satp;
    logic [dword_width_gp-1:0] fcsr;
    logic [rv64_priv_width_gp-1:0] priv_mode;
  } bp_be_csr_context_s;

  bp_be_csr_context_s csr_context_restore;
  bp_be_csr_context_s csr_context_save;
  assign csr_context_restore = csr_context_restore_data_i;

  // satp.ASID is WARL.  Keep its architectural readback consistent with the
  // narrower ASID tag carried by the MMU/TLB interfaces.  Linux discovers the
  // implemented ASID width by writing all ones and reading satp back; retaining
  // unsupported bits would make it allocate aliases that the TLB cannot tell
  // apart.
  localparam logic [15:0] satp_asid_mask_lp = {16{1'b1}} >> (16-asid_width_p);

  // The muxed and demuxed CSR outputs
  logic [dword_width_gp-1:0] csr_data_lo;
  logic [dword_width_gp-1:0] ctx_l1_data_r;
  logic exception_v_lo, interrupt_v_lo;

  rv64_mstatus_s sstatus_wmask_li, sstatus_rmask_li;
  rv64_mie_s sie_rwmask_li;
  rv64_mip_s sip_wmask_li, sip_rmask_li, mip_wmask_li;

  logic [rv64_priv_width_gp-1:0] priv_mode_n, priv_mode_r;
  logic debug_mode_n, debug_mode_r;
  logic translation_en_n, translation_en_r;

  wire is_debug_mode = debug_mode_r;
  // Debug Mode grants pseudo M-mode permission
  wire is_m_mode = is_debug_mode | (priv_mode_r == `PRIV_MODE_M);
  wire is_s_mode = (priv_mode_r == `PRIV_MODE_S);
  wire is_u_mode = (priv_mode_r == `PRIV_MODE_U);
  wire legacy_context_access_li = legacy_context_user_enable_i | is_m_mode;

  `declare_csr(dcsr);
  `declare_csr_addr(dpc, vaddr_width_p, paddr_width_p);
  `declare_csr(dscratch0);
  `declare_csr(dscratch1);

  // We have no vendorid currently
  wire [dword_width_gp-1:0] mvendorid_lo = 64'h0;
  // https://github.com/riscv/riscv-isa-manual/blob/master/marchid.md
  //   Lucky 13 (*v*)
  wire [dword_width_gp-1:0] marchid_lo = 13;
  // 0: Tapeout 0, July 2019
  // 1: Tapeout 1, June 2021
  // 2: Tapeout 2, Sept 2022
  // 3: Current
  wire [dword_width_gp-1:0] mimpid_lo  = 64'd3;
  wire [dword_width_gp-1:0] mhartid_lo = cfg_bus_cast_i.core_id;

  `declare_csr(mstatus);
  // MISA is optionally read-write, but all fields are read-only in BlackParrot
  //   64 bit MXLEN, IMACFDSUB extensions
  wire [dword_width_gp-1:0] misa_lo = {2'b10, 36'b0, 26'h14112f};
  `declare_csr(medeleg);
  `declare_csr(mideleg);
  `declare_csr(mie);
  `declare_csr_addr(mtvec, vaddr_width_p, paddr_width_p);
  `declare_csr(mcounteren);

  `declare_csr(mscratch);
  `declare_csr_addr(mepc, vaddr_width_p, paddr_width_p);
  `declare_csr(mcause);
  `declare_csr_addr(mtval, vaddr_width_p, paddr_width_p);
  `declare_csr(mip);

  `declare_csr(mcycle);
  `declare_csr(minstret);
  // Preserve the physically qualified pre-6a behavior for absent privileged
  // facilities: OpenSBI discovers them through illegal-instruction traps.
  // Returning zero for these unimplemented CSRs advertises extensions whose
  // execution paths this core cannot actually service and prevents Linux boot.
  `declare_csr(mcountinhibit);

  // sstatus subset of mstatus
  wire [dword_width_gp-1:0] sstatus_lo = mstatus_lo & sstatus_rmask_li;
  wire [dword_width_gp-1:0] sedeleg_lo = '0;
  wire [dword_width_gp-1:0] sideleg_lo = '0;
  wire [dword_width_gp-1:0] sie_lo = mie_lo & sie_rwmask_li;
  `declare_csr_addr(stvec, vaddr_width_p, paddr_width_p);
  `declare_csr(scounteren);

  `declare_csr(sscratch);
  `declare_csr_addr(sepc, vaddr_width_p, paddr_width_p);
  `declare_csr(scause);
  `declare_csr_addr(stval, vaddr_width_p, paddr_width_p);
  // sip subset of mip
  wire [dword_width_gp-1:0] sip_lo = mip_lo & sip_rmask_li;

  `declare_csr_addr(satp, vaddr_width_p, paddr_width_p);

  `declare_csr(fcsr);
  wire [dword_width_gp-1:0] fflags_lo = fcsr_lo.fflags;
  wire [dword_width_gp-1:0] frm_lo    = fcsr_lo.frm;

  assign csr_context_save =
    '{dcsr: dword_width_gp'(dcsr_lo)
      ,dpc: dword_width_gp'(dpc_lo)
      ,dscratch0: dword_width_gp'(dscratch0_lo)
      ,dscratch1: dword_width_gp'(dscratch1_lo)
      ,mstatus: dword_width_gp'(mstatus_lo)
      ,medeleg: dword_width_gp'(medeleg_lo)
      ,mideleg: dword_width_gp'(mideleg_lo)
      ,mie: dword_width_gp'(mie_lo)
      ,mtvec: dword_width_gp'(mtvec_lo)
      ,mcounteren: dword_width_gp'(mcounteren_lo)
      ,mscratch: dword_width_gp'(mscratch_lo)
      ,mepc: dword_width_gp'(mepc_lo)
      ,mcause: dword_width_gp'(mcause_lo)
      ,mtval: dword_width_gp'(mtval_lo)
      ,mip: dword_width_gp'(mip_lo)
      ,mcycle: dword_width_gp'(mcycle_lo)
      ,minstret: dword_width_gp'(minstret_lo)
      ,mcountinhibit: dword_width_gp'(mcountinhibit_lo)
      ,stvec: dword_width_gp'(stvec_lo)
      ,scounteren: dword_width_gp'(scounteren_lo)
      ,sscratch: dword_width_gp'(sscratch_lo)
      ,sepc: dword_width_gp'(sepc_lo)
      ,scause: dword_width_gp'(scause_lo)
      ,stval: dword_width_gp'(stval_lo)
      ,satp: dword_width_gp'(satp_lo)
      ,fcsr: dword_width_gp'(fcsr_lo)
      ,priv_mode: priv_mode_r
      };
  assign csr_context_save_data_o = csr_context_save;

  wire dgie = ~is_debug_mode;
  wire mgie = ~is_debug_mode & (mstatus_r.mie & is_m_mode) | is_s_mode | is_u_mode;
  wire sgie = ~is_debug_mode & (mstatus_r.sie & is_s_mode) | is_u_mode;

  wire mti_v = mie_r.mtie & mip_r.mtip;
  wire msi_v = mie_r.msie & mip_r.msip;
  wire mei_v = mie_r.meie & mip_r.meip;

  wire sti_v = mie_r.stie & mip_r.stip;
  wire ssi_v = mie_r.ssie & mip_r.ssip;
  wire sei_v = mie_r.seie & (mip_r.seip | s_external_irq_i);

  // TODO: interrupt priority is non-compliant with the spec.
  wire [15:0] interrupt_icode_dec_li =
    {4'b0

     ,mei_v
     ,1'b0
     ,sei_v
     ,1'b0

     ,mti_v
     ,1'b0 // Reserved
     ,sti_v
     ,1'b0

     ,msi_v
     ,1'b0 // Reserved
     ,ssi_v
     ,1'b0
     };

  assign irq_waiting_o = |interrupt_icode_dec_li;

  rv64_exception_dec_s exception_dec_li;
  assign exception_dec_li =
      '{instr_misaligned    : retire_pkt_cast_i.exception.instr_misaligned
        ,instr_access_fault : retire_pkt_cast_i.exception.instr_access_fault
        ,illegal_instr      : retire_pkt_cast_i.exception.illegal_instr
        ,breakpoint         : retire_pkt_cast_i.exception.ebreak
        ,load_misaligned    : retire_pkt_cast_i.exception.load_misaligned
        ,load_access_fault  : retire_pkt_cast_i.exception.load_access_fault
        ,store_misaligned   : retire_pkt_cast_i.exception.store_misaligned
        ,store_access_fault : retire_pkt_cast_i.exception.store_access_fault
        ,ecall_u_mode       : retire_pkt_cast_i.exception.ecall_u
        ,ecall_s_mode       : retire_pkt_cast_i.exception.ecall_s
        ,ecall_m_mode       : retire_pkt_cast_i.exception.ecall_m
        ,instr_page_fault   : retire_pkt_cast_i.exception.instr_page_fault
        ,load_page_fault    : retire_pkt_cast_i.exception.load_page_fault
        ,store_page_fault   : retire_pkt_cast_i.exception.store_page_fault
        ,default : '0
        };

  logic [3:0] exception_ecode_li;
  logic       exception_ecode_v_li;
  bsg_priority_encode
   #(.width_p($bits(exception_dec_li)), .lo_to_hi_p(1))
   mcause_exception_enc
    (.i(exception_dec_li)
     ,.addr_o(exception_ecode_li)
     ,.v_o(exception_ecode_v_li)
     );

  wire d_interrupt_icode_v_li = debug_irq_i;

  logic [3:0] m_interrupt_icode_li, s_interrupt_icode_li;
  logic       m_interrupt_icode_v_li, s_interrupt_icode_v_li;
  bsg_priority_encode
   #(.width_p($bits(exception_dec_li)), .lo_to_hi_p(1))
   m_interrupt_enc
    (.i(interrupt_icode_dec_li & ~mideleg_lo[0+:$bits(exception_dec_li)])
     ,.addr_o(m_interrupt_icode_li)
     ,.v_o(m_interrupt_icode_v_li)
     );

  bsg_priority_encode
   #(.width_p($bits(exception_dec_li)), .lo_to_hi_p(1))
   s_interrupt_enc
    (.i(interrupt_icode_dec_li & mideleg_lo[0+:$bits(exception_dec_li)])
     ,.addr_o(s_interrupt_icode_li)
     ,.v_o(s_interrupt_icode_v_li)
     );

  wire                               csr_w_v_li = retire_pkt_cast_i.special.csrw & ~retire_ctxtsw_v_i;
  wire [rv64_reg_data_width_gp-1:0] csr_data_li = retire_pkt_cast_i.data;
  wire [rv64_csr_addr_width_gp-1:0] csr_addr_li = retire_pkt_cast_i.instr.t.itype.imm12;
  wire [rv64_funct3_width_gp-1:0]   csr_func_li = retire_pkt_cast_i.instr.t.itype.funct3;

  wire csr_fany_li = csr_addr_li inside {`CSR_ADDR_FCSR, `CSR_ADDR_FFLAGS, `CSR_ADDR_FRM};
  wire instr_fany_li = retire_pkt_cast_i.instr.t.rtype.opcode inside
    {`RV64_FLOAD_OP, `RV64_FMADD_OP, `RV64_FMSUB_OP, `RV64_FNMSUB_OP, `RV64_FP_OP};

  logic enter_debug, exit_debug;
  bsg_dff_reset_set_clear
   #(.width_p(1))
   debug_mode_reg
    (.clk_i(clk_i)
     ,.reset_i(reset_i)
     ,.set_i(enter_debug)
     ,.clear_i(exit_debug)

     ,.data_o(debug_mode_r)
     );

  logic [vaddr_width_p-1:0] apc_n, apc_r, apc_storage_n;
  bsg_dff_reset
   #(.width_p(vaddr_width_p))
   apc_reg
    (.clk_i(clk_i)
     ,.reset_i(reset_i)

     ,.data_i(apc_storage_n)
     ,.data_o(apc_r)
     );

  // Just for timing, could remove and save some regs...
  logic [vaddr_width_p-1:0] cfg_npc_r;
  wire [vaddr_width_p-1:0] cfg_npc_n = cfg_bus_cast_i.npc;
  bsg_dff
   #(.width_p(vaddr_width_p))
   cfg_npc_reg
    (.clk_i(clk_i)
     ,.data_i(cfg_npc_n)
     ,.data_o(cfg_npc_r)
     );
  // This currently depends on specific offsets in the debug module which are
  //   compatible with the pulp-platform debug rom:
  // https://github.com/pulp-platform/riscv-dbg/blob/64f48cd8ef3ed4269ab3dfcc32e8a137a871e3e1/src/dm_pkg.sv#L28
  // For now, assume that debug_halt_pc is 16 byte aligned to avoid another mux
  wire [vaddr_width_p-1:0] debug_halt_pc      = {cfg_npc_r[vaddr_width_p-1:4], 4'b0000};
  wire [vaddr_width_p-1:0] debug_resume_pc    = {cfg_npc_r[vaddr_width_p-1:4], 4'b0100};
  wire [vaddr_width_p-1:0] debug_exception_pc = {cfg_npc_r[vaddr_width_p-1:4], 4'b1000};

  wire ret_v = |{retire_pkt_cast_i.special.dret, retire_pkt_cast_i.special.mret, retire_pkt_cast_i.special.sret};

  wire [vaddr_width_p-1:0] ret_pc =
    retire_pkt_cast_i.special.sret
    ? sepc_lo
    : retire_pkt_cast_i.special.mret
      ? mepc_lo
      : dpc_lo;
  wire [vaddr_width_p-1:0] tvec_pc =
    is_debug_mode ? debug_exception_pc
    : (priv_mode_n == `PRIV_MODE_S)
      ? {stvec_lo.base, 2'b00}
      : {mtvec_lo.base, 2'b00};

  wire [vaddr_width_p-1:0] core_npc =
    (exception_v_lo | interrupt_v_lo)
    ? tvec_pc
    : ret_v
      ? ret_pc
      : retire_pkt_cast_i.instret
        ? retire_pkt_cast_i.npc
        : apc_r;

  // APC is pipeline bookkeeping rather than an architectural CSR, but it is
  // nevertheless context-specific: replay and exception paths use it when no
  // instruction retires.  Restore it alongside the selected physical CSR bank
  // so a newly installed virtual context cannot inherit its victim's PC.
  assign apc_n = (enter_debug | cfg_bus_cast_i.freeze)
                 ? debug_halt_pc
                 : csr_context_restore_v_i ? csr_context_restore_npc_i : core_npc;

  // An inactive resident NPC reseed changes only stored bookkeeping. Keep it
  // out of the live commit NPC path: a pending interrupt after handoff must
  // save the reseeded PC without coupling a remote update to current commit.
  assign apc_storage_n = (csr_context_apc_write_v_i
                         & ~enter_debug & ~cfg_bus_cast_i.freeze
                         & ~csr_context_restore_v_i)
                        ? csr_context_restore_npc_i : apc_n;

  assign translation_en_n = ((priv_mode_n < `PRIV_MODE_M) & (satp_li.mode == 4'd8));
  bsg_dff_reset
   #(.width_p(3), .reset_val_p({1'b0, `PRIV_MODE_M}))
   priv_mode_reg
    (.clk_i(clk_i)
     ,.reset_i(reset_i)

     ,.data_i({translation_en_n, priv_mode_n})
     ,.data_o({translation_en_r, priv_mode_r})
     );

  // sstatus mask
  assign sstatus_wmask_li = '{fs: 2'b11
                              ,mxr: 1'b1, sum: 1'b1
                              ,mpp: 2'b00, spp: 2'b11
                              ,mpie: 1'b0, spie: 1'b1
                              ,mie: 1'b0, sie: 1'b1
                              ,default: '0
                              };
  assign sstatus_rmask_li = '{sd: 1'b1, uxl: 2'b11, fs: 2'b11
                              ,mxr: 1'b1, sum: 1'b1
                              ,mpp: 2'b00, spp: 2'b11
                              ,mpie: 1'b0, spie: 1'b1
                              ,mie: 1'b0, sie: 1'b1
                              ,default: '0
                              };

  // sie mask
  assign sie_rwmask_li    = mideleg_lo;

  // sip mask
  assign sip_rmask_li     = mideleg_lo;
  assign sip_wmask_li     = '{meip: 1'b0, seip: 1'b0
                              ,mtip: 1'b0, stip: 1'b0
                              ,msip: 1'b0, ssip: mideleg_lo.ssi
                              ,default: '0
                              };

  // CSR read
  always_comb
    begin
      csr_r_illegal_o = 1'b0;
      unique casez (csr_r_addr_i)
        {`CSR_ADDR_FFLAGS       }: csr_data_lo = fcsr_lo.fflags;
        {`CSR_ADDR_FRM          }: csr_data_lo = fcsr_lo.frm;
        {`CSR_ADDR_FCSR         }: csr_data_lo = fcsr_lo;
        {`CSR_ADDR_CYCLE        }: csr_data_lo = mcycle_lo;
        {`CSR_ADDR_INSTRET      }: csr_data_lo = minstret_lo;
        {`CSR_ADDR_SSTATUS      }: csr_data_lo = sstatus_lo;
        {`CSR_ADDR_SEDELEG      }: csr_data_lo = sedeleg_lo;
        {`CSR_ADDR_SIDELEG      }: csr_data_lo = sideleg_lo;
        {`CSR_ADDR_SIE          }: csr_data_lo = sie_lo;
        {`CSR_ADDR_STVEC        }: csr_data_lo = stvec_lo;
        {`CSR_ADDR_SCOUNTEREN   }: csr_data_lo = scounteren_lo;
        {`CSR_ADDR_SSCRATCH     }: csr_data_lo = sscratch_lo;
        {`CSR_ADDR_SEPC         }: csr_data_lo = sepc_lo;
        {`CSR_ADDR_SCAUSE       }: csr_data_lo = scause_lo;
        {`CSR_ADDR_STVAL        }: csr_data_lo = stval_lo;
        {`CSR_ADDR_SIP          }: csr_data_lo = sip_lo;
        {`CSR_ADDR_SATP         }: csr_data_lo = satp_lo;
        {`CSR_ADDR_MVENDORID    }: csr_data_lo = mvendorid_lo;
        {`CSR_ADDR_MARCHID      }: csr_data_lo = marchid_lo;
        {`CSR_ADDR_MIMPID       }: csr_data_lo = mimpid_lo;
        {`CSR_ADDR_MHARTID      }: csr_data_lo = mhartid_lo;
        {`CSR_ADDR_MSTATUS      }: csr_data_lo = mstatus_lo;
        {`CSR_ADDR_MISA         }: csr_data_lo = misa_lo;
        {`CSR_ADDR_MEDELEG      }: csr_data_lo = medeleg_lo;
        {`CSR_ADDR_MIDELEG      }: csr_data_lo = mideleg_lo;
        {`CSR_ADDR_MIE          }: csr_data_lo = mie_lo;
        {`CSR_ADDR_MTVEC        }: csr_data_lo = mtvec_lo;
        {`CSR_ADDR_MCOUNTEREN   }: csr_data_lo = mcounteren_lo;
        {`CSR_ADDR_MIP          }: csr_data_lo = mip_lo;
        {`CSR_ADDR_MSCRATCH     }: csr_data_lo = mscratch_lo;
        {`CSR_ADDR_MEPC         }: csr_data_lo = mepc_lo;
        {`CSR_ADDR_MCAUSE       }: csr_data_lo = mcause_lo;
        {`CSR_ADDR_MTVAL        }: csr_data_lo = mtval_lo;
        {`CSR_ADDR_MCYCLE       }: csr_data_lo = mcycle_lo;
        {`CSR_ADDR_MINSTRET     }: csr_data_lo = minstret_lo;
        {`CSR_ADDR_MCOUNTINHIBIT}: csr_data_lo = mcountinhibit_lo;
        {`CSR_ADDR_DCSR         }: csr_data_lo = dcsr_lo;
        {`CSR_ADDR_DPC          }: csr_data_lo = dpc_lo;
        {`CSR_ADDR_DSCRATCH0    }: csr_data_lo = dscratch0_lo;
        {`CSR_ADDR_DSCRATCH1    }: csr_data_lo = dscratch1_lo;
        12'h800:  // CTXT CSR - Current thread/context ID
          csr_data_lo = dword_width_gp'(current_virtual_context_id_i);
        12'h801:  // Thread NPC seed - write-only, reads as 0
          csr_data_lo = '0;
        12'h802:  // Thread register seed / remote register write - write-only, reads as 0
          csr_data_lo = '0;
        12'h803:  // Context-cache L1 service data/result
          csr_data_lo = legacy_context_access_li ? ctx_l1_data_r : '0;
        12'h804:  // Context-cache L1 service status
          csr_data_lo = legacy_context_access_li
                        ? {{(dword_width_gp-2){1'b0}}, ctx_l1_resp_v_i, ctx_l1_ready_i}
                        : '0;
        12'h805:  // Accepted cache-miss trace control/status
          csr_data_lo = legacy_context_access_li ? miss_trace_status_i : '0;
        12'h806:  // Trace read selector - write-only, reads as 0
          csr_data_lo = '0;
        12'h807:  // Selected trace record
          csr_data_lo = legacy_context_access_li ? miss_trace_data_i : '0;
        12'h808:  // Protected call capability operand / status
          csr_data_lo = '0;
        12'h809:  // Protected return result operand / status
          csr_data_lo = '0;
        12'h7c0:  // M-mode physical I-cache replay enqueue/status
          csr_data_lo = {{(dword_width_gp-1){1'b0}}, icache_replay_ready_i};
        12'h7c1:  // M-mode shared-prefix table entry (write-only)
          csr_data_lo = '0;
        12'h7c2:  // M-mode shared-prefix length/control
          csr_data_lo = is_m_mode ? icache_prefix_status_i : '0;
        12'h5c1:  // S-mode global instruction retention policy/status
          csr_data_lo = icache_retention_status_i;
        12'h5c2: begin  // Optional global large I/D retained-store control
          if (retained_buffer_p)
            csr_data_lo = retained_control_status_i;
          else begin
            csr_data_lo = '0;
            csr_r_illegal_o = csr_r_v_i;
          end
        end
        12'h5c0:  // S-mode shared-prefix trigger/status
          csr_data_lo = icache_prefix_status_i;
        12'h9c0:  // S-mode physical data preview / drained status
          csr_data_lo = {{(dword_width_gp-1){1'b0}}, physical_preview_idle_i};
        12'h9c1:  // S-mode physical-data footprint entry (write-only)
          csr_data_lo = '0;
        12'h9c2:  // S-mode physical-data footprint configuration (write-only)
          csr_data_lo = '0;
        12'h9c3:  // S-mode tagged physical-data replay trigger/status
          csr_data_lo = dcache_replay_status_i;
        {`CSR_ADDR_GLOBAL_CYCLE}:  // Read-only, core-wide physical cycle counter
          csr_data_lo = global_cycle_i;
        default:
          begin
            csr_data_lo = '0;
            csr_r_illegal_o = csr_r_v_i;
          end
      endcase
    end

  // CSR update
  always_comb
    begin
      priv_mode_n   = priv_mode_r;

      fcsr_li       = fcsr_lo;

      stvec_li      = stvec_lo;
      scounteren_li = scounteren_lo;

      sscratch_li = sscratch_lo;
      sepc_li     = sepc_lo;
      scause_li   = scause_lo;
      stval_li    = stval_lo;

      satp_li     = satp_lo;

      mstatus_li    = mstatus_lo;
      medeleg_li    = medeleg_lo;
      mideleg_li    = mideleg_lo;
      mie_li        = mie_lo;
      mtvec_li      = mtvec_lo;
      mcounteren_li = mcounteren_lo;

      mscratch_li = mscratch_lo;
      mepc_li     = mepc_lo;
      mcause_li   = mcause_lo;
      mtval_li    = mtval_lo;
      mip_li      = mip_lo;

      mcycle_li        = mcycle_lo;
      minstret_li      = minstret_lo;
      mcountinhibit_li = mcountinhibit_lo;

      dcsr_li     = dcsr_lo;
      dpc_li      = dpc_lo;
      dscratch0_li = dscratch0_lo;
      dscratch1_li = dscratch1_lo;

      enter_debug = '0;
      exit_debug  = '0;
      exception_v_lo    = '0;
      interrupt_v_lo    = '0;

      unique casez ({csr_w_v_li, csr_addr_li})
        {1'b1, `CSR_ADDR_FFLAGS       }: fcsr_li = '{frm: fcsr_lo.frm, fflags: csr_data_li, default: '0};
        {1'b1, `CSR_ADDR_FRM          }: fcsr_li = '{frm: csr_data_li, fflags: fcsr_lo.fflags, default: '0};
        {1'b1, `CSR_ADDR_FCSR         }: fcsr_li = csr_data_li;
        // Time must be done by trapping, since we can't stall at this point
        {1'b1, `CSR_ADDR_INSTRET      }: minstret_li = csr_data_li;
        // SSTATUS subset of MSTATUS
        {1'b1, `CSR_ADDR_SSTATUS      }: mstatus_li = (mstatus_lo & ~sstatus_wmask_li) | (csr_data_li & sstatus_wmask_li);
        // Read-only because we don't support N-extension
        // Read-only because we don't support N-extension
        {1'b1, `CSR_ADDR_SEDELEG      }: begin end
        {1'b1, `CSR_ADDR_SIDELEG      }: begin end
        {1'b1, `CSR_ADDR_SIE          }: mie_li = (mie_lo & ~sie_rwmask_li) | (csr_data_li & sie_rwmask_li);
        {1'b1, `CSR_ADDR_STVEC        }: stvec_li = csr_data_li;
        {1'b1, `CSR_ADDR_SCOUNTEREN   }: scounteren_li = csr_data_li;
        {1'b1, `CSR_ADDR_SSCRATCH     }: sscratch_li = csr_data_li;
        {1'b1, `CSR_ADDR_SEPC         }: sepc_li = csr_data_li;
        {1'b1, `CSR_ADDR_SCAUSE       }: scause_li = csr_data_li;
        {1'b1, `CSR_ADDR_STVAL        }: stval_li = csr_data_li;
        // SIP subset of MIP
        {1'b1, `CSR_ADDR_SIP          }: mip_li = (mip_lo & ~sip_wmask_li) | (csr_data_li & sip_wmask_li);
        {1'b1, `CSR_ADDR_SATP         }: satp_li = csr_data_li;
        {1'b1, `CSR_ADDR_MSTATUS      }: mstatus_li = csr_data_li;
        {1'b1, `CSR_ADDR_MISA         }: begin end
        {1'b1, `CSR_ADDR_MEDELEG      }: medeleg_li = csr_data_li;
        {1'b1, `CSR_ADDR_MIDELEG      }: mideleg_li = csr_data_li;
        {1'b1, `CSR_ADDR_MIE          }: mie_li = csr_data_li;
        {1'b1, `CSR_ADDR_MTVEC        }: mtvec_li = csr_data_li;
        {1'b1, `CSR_ADDR_MCOUNTEREN   }: mcounteren_li = csr_data_li;
        {1'b1, `CSR_ADDR_MIP          }: mip_li = csr_data_li;
        {1'b1, `CSR_ADDR_MSCRATCH     }: mscratch_li = csr_data_li;
        {1'b1, `CSR_ADDR_MEPC         }: mepc_li = csr_data_li;
        {1'b1, `CSR_ADDR_MCAUSE       }: mcause_li = csr_data_li;
        {1'b1, `CSR_ADDR_MTVAL        }: mtval_li = csr_data_li;
        {1'b1, `CSR_ADDR_MCYCLE       }: mcycle_li = csr_data_li;
        {1'b1, `CSR_ADDR_MINSTRET     }: minstret_li = csr_data_li;
        {1'b1, `CSR_ADDR_MCOUNTINHIBIT}: mcountinhibit_li = csr_data_li;
        {1'b1, `CSR_ADDR_DCSR         }: dcsr_li = csr_data_li;
        {1'b1, `CSR_ADDR_DPC          }: dpc_li = csr_data_li;
        {1'b1, `CSR_ADDR_DSCRATCH0    }: dscratch0_li = csr_data_li;
        {1'b1, `CSR_ADDR_DSCRATCH1    }: dscratch1_li = csr_data_li;
        default: begin end
      endcase

      if (retire_pkt_cast_i.exception._interrupt)
        begin
          if (m_interrupt_icode_v_li & mgie)
            begin
              priv_mode_n          = `PRIV_MODE_M;

              mstatus_li.mpp       = priv_mode_r;
              mstatus_li.mpie      = mstatus_lo.mie;
              mstatus_li.mie       = 1'b0;

              mepc_li              = `BSG_SIGN_EXTEND(apc_r, dword_width_gp);
              mtval_li             = '0;
              mcause_li._interrupt = 1'b1;
              mcause_li.ecode      = m_interrupt_icode_li;

              interrupt_v_lo        = 1'b1;
            end
          else if (s_interrupt_icode_v_li & sgie)
            begin
              priv_mode_n          = `PRIV_MODE_S;

              mstatus_li.spp       = priv_mode_r;
              mstatus_li.spie      = mstatus_lo.sie;
              mstatus_li.sie       = 1'b0;

              sepc_li              = `BSG_SIGN_EXTEND(apc_r, dword_width_gp);
              stval_li             = '0;
              scause_li._interrupt = 1'b1;
              scause_li.ecode      = s_interrupt_icode_li;

              interrupt_v_lo        = 1'b1;
            end
        end
      else if (exception_ecode_v_li)
        begin
          if (is_debug_mode)
            begin
              // Trap back into debug mode, don't set any CSRs
              exception_v_lo       = 1'b1;
            end
          else if (medeleg_lo[exception_ecode_li] & ~is_m_mode)
            begin
              priv_mode_n          = `PRIV_MODE_S;

              mstatus_li.spp       = priv_mode_r;
              mstatus_li.spie      = mstatus_lo.sie;
              mstatus_li.sie       = 1'b0;

              sepc_li              = `BSG_SIGN_EXTEND(apc_r, dword_width_gp);
              stval_li             = (exception_ecode_li == 2)
                                    ? retire_pkt_cast_i.instr
                                    : `BSG_SIGN_EXTEND(retire_pkt_cast_i.vaddr, dword_width_gp);

              scause_li._interrupt = 1'b0;
              scause_li.ecode      = exception_ecode_li;

              exception_v_lo        = 1'b1;
            end
          else
            begin
              priv_mode_n          = `PRIV_MODE_M;

              mstatus_li.mpp       = priv_mode_r;
              mstatus_li.mpie      = mstatus_lo.mie;
              mstatus_li.mie       = 1'b0;

              mepc_li              = `BSG_SIGN_EXTEND(apc_r, dword_width_gp);
              mtval_li             = (exception_ecode_li == 2)
                                    ? retire_pkt_cast_i.instr
                                    : `BSG_SIGN_EXTEND(retire_pkt_cast_i.vaddr, dword_width_gp);

              mcause_li._interrupt = 1'b0;
              mcause_li.ecode      = exception_ecode_li;

              exception_v_lo        = 1'b1;
            end
        end

      // Re-enter debug mode if ebreaking during debug sequence
      if (is_debug_mode)
        begin
          enter_debug = retire_pkt_cast_i.special.dbreak;
        end
      else if (retire_pkt_cast_i.exception._interrupt & d_interrupt_icode_v_li & dgie)
        begin
          enter_debug    = 1'b1;
          dpc_li         = `BSG_SIGN_EXTEND(apc_r, dword_width_gp);
          dcsr_li.cause  = 3; // Debugger
          dcsr_li.prv    = priv_mode_r;
        end
      else if (retire_pkt_cast_i.special.dbreak)
        begin
          enter_debug    = 1'b1;
          dpc_li         = `BSG_SIGN_EXTEND(apc_r, dword_width_gp);
          dcsr_li.cause  = 1; // Ebreak
          dcsr_li.prv    = priv_mode_r;
        end
      // Always break in single step mode
      else if (retire_pkt_cast_i.queue_v & dcsr_lo.step)
        begin
          enter_debug    = 1'b1;
          dpc_li         = `BSG_SIGN_EXTEND(core_npc, dword_width_gp);
          dcsr_li.cause  = 4;
          dcsr_li.prv    = priv_mode_r;
        end

      // Only exit debug mode through dret
      if (retire_pkt_cast_i.special.dret)
        begin
          exit_debug     = 1'b1;
          priv_mode_n    = dcsr_lo.prv;
        end

      if (retire_pkt_cast_i.special.mret)
        begin
          priv_mode_n      = mstatus_lo.mpp;

          mstatus_li.mpp   = `PRIV_MODE_U;
          mstatus_li.mpie  = 1'b1;
          mstatus_li.mie   = mstatus_lo.mpie;
          mstatus_li.mprv  = (priv_mode_n < `PRIV_MODE_M) ? '0 : mstatus_li.mprv;
        end

      if (retire_pkt_cast_i.special.sret)
        begin
          priv_mode_n      = {1'b0, mstatus_lo.spp};

          mstatus_li.spp   = `PRIV_MODE_U;
          mstatus_li.spie  = 1'b1;
          mstatus_li.sie   = mstatus_lo.spie;
          mstatus_li.mprv  = (priv_mode_n < `PRIV_MODE_M) ? '0 : mstatus_li.mprv;
        end

      // Accumulate interrupts
      mip_li.mtip = timer_irq_i;
      mip_li.msip = software_irq_i;
      mip_li.meip = m_external_irq_i;

      // Accumulate FFLAGS if we're not writing them this cycle
      if (~(csr_w_v_li & csr_addr_li inside {`CSR_ADDR_FFLAGS, `CSR_ADDR_FCSR}))
        fcsr_li.fflags |= fflags_acc_i;

      // Accumulate counters if we're not writing them
      if (~(csr_w_v_li & csr_addr_li inside {`CSR_ADDR_CYCLE, `CSR_ADDR_MCYCLE}) & ~mcountinhibit_lo.cy)
        mcycle_li = mcycle_lo + 1'b1;
      if (~(csr_w_v_li & csr_addr_li inside {`CSR_ADDR_INSTRET, `CSR_ADDR_MINSTRET}) & ~mcountinhibit_lo.ir)
        minstret_li = minstret_lo + retire_pkt_cast_i.instret;

      // Set FS to dirty if: fflags set, frf written, fcsr written
      mstatus_li.fs |= {2{csr_w_v_li & csr_fany_li}};
      mstatus_li.fs |= {2{retire_pkt_cast_i.instret & instr_fany_li}};

      if (csr_context_restore_v_i) begin
        if (csr_context_restore_reset_i) begin
          priv_mode_n = `PRIV_MODE_M;
          fcsr_li = '0;

          stvec_li = '0;
          scounteren_li = '0;
          sscratch_li = '0;
          sepc_li = '0;
          scause_li = '0;
          stval_li = '0;
          satp_li = '0;

          mstatus_li = '0;
          medeleg_li = '0;
          mideleg_li = '0;
          mie_li = '0;
          mtvec_li = '0;
          mcounteren_li = '0;
          mscratch_li = '0;
          mepc_li = '0;
          mcause_li = '0;
          mtval_li = '0;
          mip_li = '0;
          mcycle_li = '0;
          minstret_li = '0;
          mcountinhibit_li = '0;

          dcsr_li = '0;
          dpc_li = '0;
          dscratch0_li = '0;
          dscratch1_li = '0;
        end else begin
          priv_mode_n = csr_context_restore.priv_mode;
          fcsr_li = csr_context_restore.fcsr;

          stvec_li = csr_context_restore.stvec;
          scounteren_li = csr_context_restore.scounteren;
          sscratch_li = csr_context_restore.sscratch;
          sepc_li = csr_context_restore.sepc;
          scause_li = csr_context_restore.scause;
          stval_li = csr_context_restore.stval;
          satp_li = csr_context_restore.satp;

          mstatus_li = csr_context_restore.mstatus;
          medeleg_li = csr_context_restore.medeleg;
          mideleg_li = csr_context_restore.mideleg;
          mie_li = csr_context_restore.mie;
          mtvec_li = csr_context_restore.mtvec;
          mcounteren_li = csr_context_restore.mcounteren;
          mscratch_li = csr_context_restore.mscratch;
          mepc_li = csr_context_restore.mepc;
          mcause_li = csr_context_restore.mcause;
          mtval_li = csr_context_restore.mtval;
          mip_li = csr_context_restore.mip;
          mcycle_li = csr_context_restore.mcycle;
          minstret_li = csr_context_restore.minstret;
          mcountinhibit_li = csr_context_restore.mcountinhibit;

          dcsr_li = csr_context_restore.dcsr;
          dpc_li = csr_context_restore.dpc;
          dscratch0_li = csr_context_restore.dscratch0;
          dscratch1_li = csr_context_restore.dscratch1;
        end
      end

      satp_li.asid = satp_li.asid & satp_asid_mask_lp;
    end

  assign irq_pending_o = (~dcsr_lo.step | dcsr_lo.stepie)
    & ((d_interrupt_icode_v_li & dgie) | (m_interrupt_icode_v_li & mgie) | (s_interrupt_icode_v_li & sgie));

  // The supervisor external interrupt line does not impact the supervisor software interrupt bit of MIP.
  // However, software read operations return as if it does. bit 9 is supervisor software interrupt
  always_comb
    unique casez (csr_addr_li)
      `CSR_ADDR_SIP   : csr_r_data_o = csr_data_lo | ((s_external_irq_i & sip_rmask_li) << 9);
      `CSR_ADDR_MIP   : csr_r_data_o = csr_data_lo | (s_external_irq_i << 9);
      `CSR_ADDR_FFLAGS
      ,`CSR_ADDR_FCSR : csr_r_data_o = csr_data_lo | fflags_acc_i;
      default: csr_r_data_o = csr_data_lo;
    endcase

  wire ctxt_csr_addr_li = (csr_addr_li == 12'h800)
                           | (csr_addr_li == 12'h801)
                           | (csr_addr_li == 12'h802)
                           | (csr_addr_li == 12'h803)
                           | (csr_addr_li == 12'h804)
                           | (csr_addr_li == 12'h805)
                           | (csr_addr_li == 12'h806)
                           | (csr_addr_li == 12'h807)
                           | (csr_addr_li == 12'h808)
                           | (csr_addr_li == 12'h809)
                           | (csr_addr_li == 12'h9c0)
                           | (csr_addr_li == 12'h9c1)
                           | (csr_addr_li == 12'h9c2)
                           | (csr_addr_li == 12'h9c3);

  assign commit_pkt_cast_o.npc_w_v           = |{retire_pkt_cast_i.special.dcache_miss
                                                 ,retire_pkt_cast_i.special.fencei
                                                 ,retire_pkt_cast_i.special.sfence_vma
                                                 ,retire_pkt_cast_i.special.dbreak
                                                 ,retire_pkt_cast_i.special.dret
                                                 ,retire_pkt_cast_i.special.mret
                                                 ,retire_pkt_cast_i.special.sret
                                                 ,retire_pkt_cast_i.special.wfi
                                                 ,(csr_w_v_li & ~ctxt_csr_addr_li)
                                                 ,retire_pkt_cast_i.exception
                                                 };
  assign commit_pkt_cast_o.queue_v           = retire_pkt_cast_i.queue_v & ~|retire_pkt_cast_i.exception;
  assign commit_pkt_cast_o.instret           = retire_pkt_cast_i.instret;
  assign commit_pkt_cast_o.size              = retire_pkt_cast_i.size;
  assign commit_pkt_cast_o.count             = retire_pkt_cast_i.count;
  assign commit_pkt_cast_o.pc                = apc_r;
  assign commit_pkt_cast_o.npc               = apc_n;
  assign commit_pkt_cast_o.vaddr             = retire_pkt_cast_i.vaddr;
  assign commit_pkt_cast_o.instr             = retire_pkt_cast_i.instr;
  assign commit_pkt_cast_o.pte_leaf          = retire_pkt_cast_i.data;
  assign commit_pkt_cast_o.priv_n            = priv_mode_n;
  assign commit_pkt_cast_o.translation_en_n  = translation_en_n;
  assign commit_pkt_cast_o.exception         = exception_v_lo;
  // Debug mode acts as a pseudo-interrupt
  assign commit_pkt_cast_o._interrupt        = interrupt_v_lo | enter_debug;
  assign commit_pkt_cast_o.fencei            = retire_pkt_cast_i.special.fencei;
  assign commit_pkt_cast_o.sfence            = retire_pkt_cast_i.special.sfence_vma;
  assign commit_pkt_cast_o.wfi               = retire_pkt_cast_i.special.wfi;
  assign commit_pkt_cast_o.eret              = ret_v;
  assign commit_pkt_cast_o.csrw              = csr_w_v_li & ~ctxt_csr_addr_li;
  assign commit_pkt_cast_o.ctxtsw            = retire_pkt_cast_i.instret & retire_ctxtsw_v_i;
  assign commit_pkt_cast_o.resume            = retire_pkt_cast_i.exception.resume;
  assign commit_pkt_cast_o.itlb_miss         = retire_pkt_cast_i.exception.itlb_miss;
  assign commit_pkt_cast_o.icache_miss       = retire_pkt_cast_i.exception.icache_miss;
  assign commit_pkt_cast_o.dtlb_store_miss   = retire_pkt_cast_i.exception.dtlb_store_miss;
  assign commit_pkt_cast_o.dtlb_load_miss    = retire_pkt_cast_i.exception.dtlb_load_miss;
  assign commit_pkt_cast_o.dcache_replay     = retire_pkt_cast_i.exception.dcache_replay;
  assign commit_pkt_cast_o.dcache_miss       = retire_pkt_cast_i.special.dcache_miss;
  assign commit_pkt_cast_o.itlb_fill_v       = retire_pkt_cast_i.exception.itlb_fill;
  assign commit_pkt_cast_o.dtlb_fill_v       = retire_pkt_cast_i.exception.dtlb_fill;
  assign commit_pkt_cast_o.iscore_v          = retire_pkt_cast_i.iscore;
  assign commit_pkt_cast_o.fdirty_v          = (csr_w_v_li & csr_fany_li)
                                               | (retire_pkt_cast_i.instret & instr_fany_li);
  assign commit_pkt_cast_o.fscore_v          = retire_pkt_cast_i.fscore;

  wire mprv_mem_v = (~is_debug_mode | dcsr_lo.mprven)
                    & mstatus_lo.mprv
                    & (mstatus_lo.mpp < `PRIV_MODE_M)
                    & (satp_lo.mode == 4'd8);

  assign trans_info_cast_o.priv_mode      = mprv_mem_v ? mstatus_lo.mpp : priv_mode_r;
  assign trans_info_cast_o.base_ppn       = satp_lo.ppn;
  assign trans_info_cast_o.translation_en = translation_en_r | mprv_mem_v;
  assign trans_info_cast_o.mstatus_sum = mstatus_lo.sum;
  assign trans_info_cast_o.mstatus_mxr = mstatus_lo.mxr;
  assign trans_info_cast_o.asid        = satp_lo.asid;

  assign decode_info_cast_o.m_mode     = is_m_mode;
  assign decode_info_cast_o.s_mode     = is_s_mode;
  assign decode_info_cast_o.u_mode     = is_u_mode;
  assign decode_info_cast_o.debug_mode = debug_mode_r;
  assign decode_info_cast_o.tsr        = mstatus_lo.tsr;
  assign decode_info_cast_o.tw         = mstatus_lo.tw;
  assign decode_info_cast_o.tvm        = mstatus_lo.tvm;
  assign decode_info_cast_o.ebreakm    = dcsr_lo.ebreakm;
  assign decode_info_cast_o.ebreaks    = dcsr_lo.ebreaks;
  assign decode_info_cast_o.ebreaku    = dcsr_lo.ebreaku;
  assign decode_info_cast_o.fpu_en     = (mstatus_lo.fs != 2'b00);
  assign decode_info_cast_o.cycle_en   = is_m_mode | (is_s_mode & mcounteren_lo.cy) | (is_u_mode & scounteren_lo.cy);
  assign decode_info_cast_o.instret_en = is_m_mode | (is_m_mode & mcounteren_lo.ir) | (is_u_mode & mcounteren_lo.ir);

  assign frm_dyn_o = rv64_frm_e'(fcsr_lo.frm);

  // CSR 0x801 write: set the NPC for the virtual context whose ID is in the upper bits.
  // Bit 63 explicitly rebinds the target's privilege/translation CSR image to
  // the caller. Ordinary reseeds preserve the target's private CSR state.
  // Write format: csr_data_li[vaddr_width_p +: context_id_width_p] = context_id
  //               csr_data_li[vaddr_width_p-1:0]                   = target NPC
  assign ctx_npc_write_v_o   = csr_w_v_li & (csr_addr_li == 12'h801)
                               & legacy_context_access_li;
  assign ctx_npc_write_rebind_o = ctx_npc_write_v_o & csr_data_li[dword_width_gp-1];
  // Bit 62 requests installation of the single protected-RPC descriptor entry
  // while using the existing context-id/NPC payload. Top-level commit logic
  // authorizes it from architectural privilege; the CSR-local is_m_mode also
  // includes debug mode and is therefore intentionally not a security gate.
  assign ctx_npc_write_rpc_entry_o = ctx_npc_write_v_o
                                      & csr_data_li[dword_width_gp-2];
  assign ctx_npc_write_virtual_context_id_o = csr_data_li[vaddr_width_p +: context_id_width_p];
  assign ctx_npc_write_npc_o = csr_data_li[0 +: vaddr_width_p];

  // CSR 0x802 write: remote register write into a target virtual context
  // Write format: bits[38:0]                                    = value (39-bit vaddr width)
  //               bits[38+context_id_width_p : 39]              = context_id
  //               bits[38+context_id_width_p+reg_addr_width_gp : 39+context_id_width_p] = reg_addr
  //               next bit                                      = fp_sel (1=FP regfile, 0=INT regfile)
  localparam fp_sel_bit_lp = vaddr_width_p + context_id_width_p + reg_addr_width_gp;
  wire rpush_v = csr_w_v_li & (csr_addr_li == 12'h802)
                 & legacy_context_access_li;
  assign ctx_rpush_v_o    = rpush_v & ~csr_data_li[fp_sel_bit_lp];
  assign ctx_rpush_fp_v_o = rpush_v &  csr_data_li[fp_sel_bit_lp];
  assign ctx_rpush_virtual_context_id_o  = csr_data_li[vaddr_width_p +: context_id_width_p];
  assign ctx_rpush_reg_o  = csr_data_li[vaddr_width_p + context_id_width_p +: reg_addr_width_gp];
  assign ctx_rpush_data_o = {{(dpath_width_gp - vaddr_width_p){1'b0}}, csr_data_li[0 +: vaddr_width_p]};

  wire ctx_l1_data_write_v_li = csr_w_v_li & (csr_addr_li == 12'h803)
                                & legacy_context_access_li;
  wire ctx_l1_cmd_write_v_li = csr_w_v_li & (csr_addr_li == 12'h804)
                               & legacy_context_access_li;
  assign ctx_l1_cmd_v_o = ctx_l1_cmd_write_v_li & ctx_l1_ready_i;
  assign ctx_l1_cmd_w_o = csr_data_li[dword_width_gp-1];
  assign ctx_l1_cmd_paddr_o = csr_data_li[0+:paddr_width_p];
  assign ctx_l1_cmd_data_o = ctx_l1_data_r;

  // A control write sets the desired armed state directly. Bit 1 also clears
  // counts and overflow flags. A selector write initiates the recorder's
  // synchronous BRAM read; bit 8 chooses D (1) or I (0), bits 7:0 select entry.
  assign miss_trace_ctrl_v_o = csr_w_v_li & (csr_addr_li == 12'h805)
                               & legacy_context_access_li;
  assign miss_trace_arm_o = csr_data_li[0];
  assign miss_trace_clear_o = miss_trace_ctrl_v_o & csr_data_li[1];
  assign miss_trace_read_v_o = csr_w_v_li & (csr_addr_li == 12'h806)
                               & legacy_context_access_li;
  assign miss_trace_read_source_o = csr_data_li[8];
  assign miss_trace_read_index_o = csr_data_li[7:0];

  // 0x7c0 is in the standard machine-custom CSR range. Keep an explicit
  // privilege gate in addition to the generic CSR legality check so lower
  // privilege software can never inject physical addresses speculatively.
  // Valid must not depend combinationally on downstream ready. The replay
  // controller's ready depends on request identity for duplicate admission;
  // gating valid with ready forms a loop that FPGA synthesis must break.
  // Software polls the read-only ready bit before issuing this test enqueue.
  assign icache_replay_v_o = csr_w_v_li & (csr_addr_li == 12'h7c0)
                             & is_m_mode;
  assign icache_replay_paddr_o = csr_data_li[0+:paddr_width_p];

  // 0x7c1 payload: physical line address in the low paddr bits and the
  // destination table index in bits 63:56. 0x7c2 programs the number
  // of valid entries (0--256) and bit 63 clears counters. The supervisor-
  // custom 0x5c0 CSR never contains address data. A legacy write requests the
  // complete immutable M-configured prefix. Bit 63 optionally selects a
  // bounded subrange: bits 7:0 are its start and bits 16:8 its count. The
  // controller rejects ranges outside the configured table, so S-mode can
  // choose among preauthorized entries but cannot inject physical addresses.
  assign icache_prefix_entry_v_o = csr_w_v_li & (csr_addr_li == 12'h7c1)
                                    & is_m_mode;
  assign icache_prefix_entry_index_o = csr_data_li[63:56];
  assign icache_prefix_entry_paddr_o = csr_data_li[0+:paddr_width_p];
  assign icache_prefix_count_v_o = csr_w_v_li & (csr_addr_li == 12'h7c2)
                                    & is_m_mode;
  assign icache_prefix_count_o = csr_data_li[8:0];
  assign icache_prefix_clear_v_o = icache_prefix_count_v_o
                                    & csr_data_li[dword_width_gp-1];
  // 0x5c1 is global cache state, deliberately absent from context snapshots.
  // Only retired S/M writes may change policy; generic CSR privilege checks
  // also reject both U-mode reads and writes.
  assign icache_retention_cmd_v_o = csr_w_v_li & retire_pkt_cast_i.instret
    & (csr_addr_li == 12'h5c1) & (is_s_mode | is_m_mode);
  assign icache_retention_mode_o = csr_data_li[1:0];
  assign retained_control_cmd_v_o = retained_buffer_p & csr_w_v_li
    & retire_pkt_cast_i.instret & (csr_addr_li == 12'h5c2)
    & (is_s_mode | is_m_mode);
  assign retained_control_o = csr_data_li[3:0];
  assign icache_prefix_trigger_v_o = csr_w_v_li & (csr_addr_li == 12'h5c0)
                                      & (is_s_mode | is_m_mode);
  assign icache_prefix_trigger_range_v_o = csr_data_li[63];
  assign icache_prefix_trigger_start_o = csr_data_li[7:0];
  assign icache_prefix_trigger_count_o = csr_data_li[16:8];

  // The generic decoder rejects U-mode access to this supervisor-custom CSR.
  // Repeat privilege and physical-width checks before the advisory address
  // leaves the architectural retirement boundary.
  assign physical_preview_v_o = csr_w_v_li & retire_pkt_cast_i.instret
                                & (csr_addr_li == 12'h9c0)
                                & (is_s_mode | is_m_mode)
                                & ~(|csr_data_li[dword_width_gp-1:paddr_width_p]);
  assign physical_preview_paddr_o = csr_data_li[0+:paddr_width_p];

  // The direct 0x9c0 primitive remains available as a matched control. The
  // new interface moves all per-line writes outside the wakeup path: 0x9c1
  // programs a table entry, 0x9c2 programs its count/timing, and 0x9c3 queues
  // one software-assigned slot tag. All remain supervisor-only physical-data
  // operations, matching the privilege boundary of the original primitive.
  assign dcache_replay_entry_v_o = csr_w_v_li & retire_pkt_cast_i.instret
                                    & (csr_addr_li == 12'h9c1)
                                    & (is_s_mode | is_m_mode);
  assign dcache_replay_config_v_o = csr_w_v_li & retire_pkt_cast_i.instret
                                     & (csr_addr_li == 12'h9c2)
                                     & (is_s_mode | is_m_mode);
  assign dcache_replay_trigger_v_o = csr_w_v_li & retire_pkt_cast_i.instret
                                      & (csr_addr_li == 12'h9c3)
                                      & (is_s_mode | is_m_mode);
  assign dcache_replay_payload_o = csr_data_li;

  always_ff @(posedge clk_i)
    if (reset_i)
      ctx_l1_data_r <= '0;
    else if (ctx_l1_resp_v_i)
      ctx_l1_data_r <= ctx_l1_resp_data_i;
    else if (ctx_l1_data_write_v_li)
      ctx_l1_data_r <= csr_data_li;

endmodule
