/**
 *
 * Name:
 *   bp_be_pipe_sys.v
 *
 * Description:
 *
 * Notes:
 *
 */
`include "bp_common_defines.svh"
`include "bp_be_defines.svh"

module bp_be_pipe_sys
 import bp_common_pkg::*;
 import bp_be_pkg::*;
 #(parameter bp_params_e bp_params_p = e_bp_default_cfg
   , parameter bit retained_buffer_p = 1'b0
   `declare_bp_proc_params(bp_params_p)
   `declare_bp_be_if_widths(vaddr_width_p, paddr_width_p, asid_width_p, branch_metadata_fwd_width_p, fetch_ptr_p, issue_ptr_p)

   , localparam cfg_bus_width_lp       = `bp_cfg_bus_width(vaddr_width_p, hio_width_p, core_id_width_p, cce_id_width_p, lce_id_width_p, did_width_p)
   // Generated parameters
   , localparam exception_width_lp    = $bits(bp_be_exception_s)
   , localparam special_width_lp      = $bits(bp_be_special_s)
   , localparam csr_context_csrs_lp   = 26
   , localparam csr_context_width_lp  = csr_context_csrs_lp*dword_width_gp + rv64_priv_width_gp
   )
  (input                                    clk_i
   , input                                   reset_i

   , input [63:0] retained_control_status_i
   , output logic retained_control_cmd_v_o
   , output logic [3:0] retained_control_o

   , input [cfg_bus_width_lp-1:0]            cfg_bus_i

   , input [reservation_width_lp-1:0]        reservation_i
   , input                                   flush_i

   , input                                   retire_v_i
   , input                                   retire_queue_v_i
   , input [dpath_width_gp-1:0]              retire_data_i
   , input [exception_width_lp-1:0]          retire_exception_i
   , input [special_width_lp-1:0]            retire_special_i

   , output logic [dpath_width_gp-1:0]       data_o
   , output logic                            v_o
   , output logic                            illegal_instr_o

   , input [wb_pkt_width_lp-1:0]             iwb_pkt_i
   , input [wb_pkt_width_lp-1:0]             fwb_pkt_i
   , output logic [commit_pkt_width_lp-1:0]  commit_pkt_o

   , input                                   debug_irq_i
   , input                                   timer_irq_i
   , input                                   software_irq_i
   , input                                   m_external_irq_i
   , input                                   s_external_irq_i
   , output logic                            irq_pending_o
   , output logic                            irq_waiting_o

   , output logic [decode_info_width_lp-1:0] decode_info_o
   , output logic [trans_info_width_lp-1:0]  trans_info_o
   , output logic [trans_info_width_lp-1:0]  reservation_trans_info_o
   , output rv64_frm_e                       frm_dyn_o

   // Current thread selects the active per-thread CSR instance.
   , input [thread_id_width_p-1:0]           current_physical_thread_id_i
   // Software-visible virtual context ID returned by CSR 0x800.
   , input [context_id_width_p-1:0]          current_virtual_context_id_i
   , input                                   legacy_context_user_enable_i
   // Retire thread owns the instruction currently committing in the backend.
   , input [thread_id_width_p-1:0]           retire_thread_id_i

   // Save/restore physical CSR state for nonresident virtual contexts.
   , input                                   csr_context_restore_v_i
   , input                                   csr_context_apc_write_v_i
   , input                                   csr_context_restore_reset_i
   , input [thread_id_width_p-1:0]           csr_context_restore_physical_thread_id_i
   , input [csr_context_width_lp-1:0]        csr_context_restore_data_i
   , input [vaddr_width_p-1:0]               csr_context_restore_npc_i
   , input [thread_id_width_p-1:0]           csr_context_save_physical_thread_id_i
   , output logic [csr_context_width_lp-1:0] csr_context_save_data_o

   // Bootstrap: write target NPC for a virtual context (CSR 0x801)
   , output logic                            ctx_npc_write_v_o
   , output logic                            ctx_npc_write_rebind_o
   , output logic                            ctx_npc_write_rpc_entry_o
   , output logic [context_id_width_p-1:0]   ctx_npc_write_virtual_context_id_o
   , output logic [vaddr_width_p-1:0]        ctx_npc_write_npc_o

   // rpush: write arbitrary register of a virtual context (CSR 0x802)
   , output logic                            ctx_rpush_v_o
   , output logic                            ctx_rpush_fp_v_o
   , output logic [context_id_width_p-1:0]   ctx_rpush_virtual_context_id_o
   , output logic [reg_addr_width_gp-1:0]    ctx_rpush_reg_o
   , output logic [dpath_width_gp-1:0]       ctx_rpush_data_o

   // Context-cache L1 D$ service CSR path.
   , input                                   ctx_l1_ready_i
   , input                                   ctx_l1_resp_v_i
   , input [dword_width_gp-1:0]              ctx_l1_resp_data_i
   , output logic                            ctx_l1_cmd_v_o
   , output logic                            ctx_l1_cmd_w_o
   , output logic [paddr_width_p-1:0]        ctx_l1_cmd_paddr_o
   , output logic [dword_width_gp-1:0]       ctx_l1_cmd_data_o

   , input [dword_width_gp-1:0]              miss_trace_status_i
   , input [dword_width_gp-1:0]              miss_trace_data_i
   , output logic                            miss_trace_ctrl_v_o
   , output logic                            miss_trace_arm_o
   , output logic                            miss_trace_clear_o
   , output logic                            miss_trace_read_v_o
   , output logic                            miss_trace_read_source_o
   , output logic [7:0]                      miss_trace_read_index_o

   , input                                   icache_replay_ready_i
   , output logic                            icache_replay_v_o
   , output logic [paddr_width_p-1:0]        icache_replay_paddr_o
   , input [63:0]                            icache_retention_status_i
   , output logic                            icache_retention_cmd_v_o
   , output logic [1:0]                      icache_retention_mode_o
   , input [dword_width_gp-1:0]              icache_prefix_status_i
   , output logic                            icache_prefix_entry_v_o
   , output logic [7:0]                      icache_prefix_entry_index_o
   , output logic [paddr_width_p-1:0]        icache_prefix_entry_paddr_o
   , output logic                            icache_prefix_count_v_o
   , output logic [8:0]                      icache_prefix_count_o
   , output logic                            icache_prefix_trigger_v_o
   , output logic                            icache_prefix_trigger_range_v_o
   , output logic [7:0]                      icache_prefix_trigger_start_o
   , output logic [8:0]                      icache_prefix_trigger_count_o
   , output logic                            icache_prefix_clear_v_o
   , input                                   physical_preview_idle_i
   , output logic                            physical_preview_v_o
   , output logic [paddr_width_p-1:0]        physical_preview_paddr_o
   , input [dword_width_gp-1:0]              dcache_replay_status_i
   , output logic                            dcache_replay_entry_v_o
   , output logic                            dcache_replay_config_v_o
   , output logic                            dcache_replay_trigger_v_o
   , output logic [dword_width_gp-1:0]       dcache_replay_payload_o
   );

  `declare_bp_be_if(vaddr_width_p, paddr_width_p, asid_width_p, branch_metadata_fwd_width_p, fetch_ptr_p, issue_ptr_p);

  bp_be_reservation_s reservation;
  bp_be_decode_s decode;
  rv64_instr_s instr;
  `bp_cast_i(bp_be_wb_pkt_s, iwb_pkt);
  `bp_cast_i(bp_be_wb_pkt_s, fwb_pkt);
  `bp_cast_o(bp_be_commit_pkt_s, commit_pkt);
  `bp_cast_o(bp_be_decode_info_s, decode_info);
  `bp_cast_o(bp_be_trans_info_s, trans_info);
  `bp_cast_o(bp_be_trans_info_s, reservation_trans_info);

  assign reservation = reservation_i;
  assign decode = reservation.decode;
  assign instr  = reservation.instr;
  wire [thread_id_width_p-1:0] reservation_physical_thread_id = reservation.thread_id[0 +: thread_id_width_p];
  wire [vaddr_width_p-1:0] pc  = reservation.pc;
  wire [dword_width_gp-1:0] rs1 = reservation.isrc1;
  wire [dword_width_gp-1:0] rs2 = reservation.isrc2;
  wire [dword_width_gp-1:0] imm = reservation.isrc3;

  wire csr_v_li = (reservation.decode.csr_r_v | reservation.decode.csr_w_v) & ~reservation.ctxtsw_v;
  wire [rv64_csr_addr_width_gp-1:0] csr_addr_li = instr.t.itype.imm12;

  bp_be_retire_pkt_s retire_pkt;
  logic [dword_width_gp-1:0] csr_data_lo;
  wire [4:0] fflags_acc_li = iwb_pkt_cast_i.fflags | fwb_pkt_cast_i.fflags;
  bp_be_csr_wrapper_mt
   #(.bp_params_p(bp_params_p)
     ,.retained_buffer_p(retained_buffer_p))
    csr
    (.clk_i(clk_i)
     ,.reset_i(reset_i)
     ,.retained_control_status_i(retained_control_status_i)
     ,.retained_control_cmd_v_o(retained_control_cmd_v_o)
     ,.retained_control_o(retained_control_o)

     ,.cfg_bus_i(cfg_bus_i)

     ,.csr_r_v_i(csr_v_li)
     ,.csr_r_addr_i(csr_addr_li)
     ,.csr_r_data_o(csr_data_lo)
     ,.csr_r_illegal_o(illegal_instr_o)

     ,.fflags_acc_i(fflags_acc_li)
     ,.frf_w_v_i(fwb_pkt_cast_i.frd_w_v)

     ,.debug_irq_i(debug_irq_i)
     ,.timer_irq_i(timer_irq_i)
     ,.software_irq_i(software_irq_i)
     ,.m_external_irq_i(m_external_irq_i)
     ,.s_external_irq_i(s_external_irq_i)
     ,.irq_pending_o(irq_pending_o)
     ,.irq_waiting_o(irq_waiting_o)

     ,.retire_pkt_i(retire_pkt)
     ,.retire_ctxtsw_v_i(retire_ctxtsw_r)
     ,.commit_pkt_o(commit_pkt_cast_o)
     ,.decode_info_o(decode_info_cast_o)
     ,.trans_info_o(trans_info_cast_o)
     ,.reservation_trans_info_o(reservation_trans_info_cast_o)
     ,.frm_dyn_o(frm_dyn_o)
     // Current selects slow CSR state; reservation thread owns CSR reads
     // and memory translation information.
     ,.current_physical_thread_id_i(current_physical_thread_id_i)
     ,.current_virtual_context_id_i(current_virtual_context_id_i)
     ,.legacy_context_user_enable_i(legacy_context_user_enable_i)
     ,.csr_thread_id_i(reservation_physical_thread_id)
     ,.retire_thread_id_i(retire_thread_id_i)
     ,.csr_context_restore_v_i(csr_context_restore_v_i)
     ,.csr_context_apc_write_v_i(csr_context_apc_write_v_i)
     ,.csr_context_restore_reset_i(csr_context_restore_reset_i)
     ,.csr_context_restore_physical_thread_id_i(csr_context_restore_physical_thread_id_i)
     ,.csr_context_restore_data_i(csr_context_restore_data_i)
     ,.csr_context_restore_npc_i(csr_context_restore_npc_i)
     ,.csr_context_save_physical_thread_id_i(csr_context_save_physical_thread_id_i)
     ,.csr_context_save_data_o(csr_context_save_data_o)
     ,.ctx_npc_write_v_o(ctx_npc_write_v_o)
     ,.ctx_npc_write_rebind_o(ctx_npc_write_rebind_o)
     ,.ctx_npc_write_rpc_entry_o(ctx_npc_write_rpc_entry_o)
     ,.ctx_npc_write_virtual_context_id_o(ctx_npc_write_virtual_context_id_o)
     ,.ctx_npc_write_npc_o(ctx_npc_write_npc_o)
     ,.ctx_rpush_v_o(ctx_rpush_v_o)
     ,.ctx_rpush_fp_v_o(ctx_rpush_fp_v_o)
     ,.ctx_rpush_virtual_context_id_o(ctx_rpush_virtual_context_id_o)
     ,.ctx_rpush_reg_o(ctx_rpush_reg_o)
     ,.ctx_rpush_data_o(ctx_rpush_data_o)
     ,.ctx_l1_ready_i(ctx_l1_ready_i)
     ,.ctx_l1_resp_v_i(ctx_l1_resp_v_i)
     ,.ctx_l1_resp_data_i(ctx_l1_resp_data_i)
     ,.ctx_l1_cmd_v_o(ctx_l1_cmd_v_o)
     ,.ctx_l1_cmd_w_o(ctx_l1_cmd_w_o)
     ,.ctx_l1_cmd_paddr_o(ctx_l1_cmd_paddr_o)
     ,.ctx_l1_cmd_data_o(ctx_l1_cmd_data_o)
     ,.miss_trace_status_i(miss_trace_status_i)
     ,.miss_trace_data_i(miss_trace_data_i)
     ,.miss_trace_ctrl_v_o(miss_trace_ctrl_v_o)
     ,.miss_trace_arm_o(miss_trace_arm_o)
     ,.miss_trace_clear_o(miss_trace_clear_o)
     ,.miss_trace_read_v_o(miss_trace_read_v_o)
     ,.miss_trace_read_source_o(miss_trace_read_source_o)
     ,.miss_trace_read_index_o(miss_trace_read_index_o)
     ,.icache_replay_ready_i(icache_replay_ready_i)
     ,.icache_replay_v_o(icache_replay_v_o)
     ,.icache_replay_paddr_o(icache_replay_paddr_o)
       ,.icache_retention_status_i(icache_retention_status_i)
       ,.icache_retention_cmd_v_o(icache_retention_cmd_v_o)
       ,.icache_retention_mode_o(icache_retention_mode_o)
     ,.icache_prefix_status_i(icache_prefix_status_i)
     ,.icache_prefix_entry_v_o(icache_prefix_entry_v_o)
     ,.icache_prefix_entry_index_o(icache_prefix_entry_index_o)
     ,.icache_prefix_entry_paddr_o(icache_prefix_entry_paddr_o)
     ,.icache_prefix_count_v_o(icache_prefix_count_v_o)
     ,.icache_prefix_count_o(icache_prefix_count_o)
     ,.icache_prefix_trigger_v_o(icache_prefix_trigger_v_o)
     ,.icache_prefix_trigger_range_v_o(icache_prefix_trigger_range_v_o)
     ,.icache_prefix_trigger_start_o(icache_prefix_trigger_start_o)
     ,.icache_prefix_trigger_count_o(icache_prefix_trigger_count_o)
     ,.icache_prefix_clear_v_o(icache_prefix_clear_v_o)
     ,.physical_preview_idle_i(physical_preview_idle_i)
     ,.physical_preview_v_o(physical_preview_v_o)
     ,.physical_preview_paddr_o(physical_preview_paddr_o)
     ,.dcache_replay_status_i(dcache_replay_status_i)
     ,.dcache_replay_entry_v_o(dcache_replay_entry_v_o)
     ,.dcache_replay_config_v_o(dcache_replay_config_v_o)
     ,.dcache_replay_trigger_v_o(dcache_replay_trigger_v_o)
     ,.dcache_replay_payload_o(dcache_replay_payload_o)
     );

  logic [vaddr_width_p-1:0] retire_npc_r;
  logic [dword_width_gp-1:0] retire_nvaddr_r, retire_vaddr_r;
  logic [dword_width_gp-1:0] retire_ndata_r, retire_data_r;
  logic [fetch_ptr_p-1:0] retire_nsize_r, retire_size_r;
  logic [fetch_ptr_p-1:0] retire_ncount_r, retire_count_r;
  rv64_instr_s retire_ninstr_r, retire_instr_r;
  logic retire_niscore_r, retire_iscore_r;
  logic retire_nfscore_r, retire_fscore_r;
  logic retire_nspec_w_r, retire_spec_w_r;
  logic retire_nctxtsw_r, retire_ctxtsw_r;
  always_ff @(posedge clk_i)
    begin
      retire_npc_r <= reservation.pc;

      retire_nvaddr_r <= rs1+imm;
      retire_vaddr_r  <= retire_nvaddr_r;

      retire_ndata_r <= rs2;
      retire_data_r  <= retire_ndata_r;

      retire_nsize_r <= reservation.size;
      retire_size_r <= retire_nsize_r;

      retire_ncount_r <= reservation.count;
      retire_count_r <= retire_ncount_r;

      retire_ninstr_r <= reservation.instr;
      retire_instr_r  <= retire_ninstr_r;

      retire_niscore_r <= reservation.decode.score_v & reservation.decode.irf_w_v;
      retire_iscore_r  <= retire_niscore_r;

      retire_nfscore_r <= reservation.decode.score_v & reservation.decode.frf_w_v;
      retire_fscore_r  <= retire_nfscore_r;

      retire_nspec_w_r <= reservation.decode.score_v & reservation.decode.spec_w_v;
      retire_spec_w_r  <= retire_nspec_w_r;

    end

  always_ff @(posedge clk_i)
    if (reset_i) begin
      retire_nctxtsw_r <= 1'b0;
      retire_ctxtsw_r  <= 1'b0;
    end else begin
      retire_nctxtsw_r <= reservation.v & reservation.ctxtsw_v & ~flush_i;
      retire_ctxtsw_r  <= retire_nctxtsw_r;
    end

  // Compute input CSR data
  logic [dword_width_gp-1:0] retire_data_li;
  wire [dword_width_gp-1:0] retire_imm_li = retire_instr_r.t.fmatype.rs1_addr;
  always_comb
    unique casez ({retire_queue_v_i, retire_instr_r})
      {1'b1, `RV64_CSRRSI}: retire_data_li =  retire_imm_li | retire_data_i;
      {1'b1, `RV64_CSRRCI}: retire_data_li = ~retire_imm_li & retire_data_i;
      {1'b1, `RV64_CSRRWI}: retire_data_li =  retire_imm_li;

      {1'b1, `RV64_CSRRS }: retire_data_li =  retire_vaddr_r | retire_data_i;
      {1'b1, `RV64_CSRRC }: retire_data_li = ~retire_vaddr_r & retire_data_i;
      {1'b1, `RV64_CSRRW }: retire_data_li =  retire_vaddr_r;
      default             : retire_data_li = retire_data_i;
    endcase

  wire instret_li = retire_v_i & retire_queue_v_i & ~|retire_exception_i;
  wire iscore_li =
    (~retire_spec_w_r & retire_iscore_r) | (retire_spec_w_r & retire_iscore_r & |retire_special_i);
  wire fscore_li =
    (~retire_spec_w_r & retire_fscore_r) | (retire_spec_w_r & retire_fscore_r & |retire_special_i);
  assign retire_pkt =
    '{v            : retire_v_i
      ,queue_v     : retire_queue_v_i
      ,instret     : instret_li
      ,size        : retire_size_r
      ,count       : retire_count_r
      ,npc         : retire_npc_r
      ,vaddr       : retire_vaddr_r
      ,data        : retire_data_li
      ,instr       : retire_instr_r
      ,exception   : retire_v_i ? retire_exception_i : '0
      ,special     : instret_li ? retire_special_i   : '0
      ,iscore      : instret_li ? iscore_li : '0
      ,fscore      : instret_li ? fscore_li : '0
      };

  assign v_o = csr_v_li;
  assign data_o = csr_data_lo;

endmodule
