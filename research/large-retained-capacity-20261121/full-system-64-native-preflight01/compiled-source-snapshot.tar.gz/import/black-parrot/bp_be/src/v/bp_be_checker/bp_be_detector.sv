/**
 *
 * Name:
 *   bp_be_detector.v
 *
 * Description:
 *
 *
 * Notes:
 *   We should get rid of the magic numbers here and replace with constants based on pipeline
 *     stages. However, like the calculator, this is a high risk change that should be postponed
 */

`include "bp_common_defines.svh"
`include "bp_be_defines.svh"

module bp_be_detector
 import bp_common_pkg::*;
 import bp_be_pkg::*;
 #(parameter bp_params_e bp_params_p = e_bp_default_cfg
   `declare_bp_proc_params(bp_params_p)
   `declare_bp_be_if_widths(vaddr_width_p, paddr_width_p, asid_width_p, branch_metadata_fwd_width_p, fetch_ptr_p, issue_ptr_p)

   // Generated parameters
   )
  (input                               clk_i
   , input                             reset_i

   // Dependency information
   , input [issue_pkt_width_lp-1:0]    issue_pkt_i
   , input                             cmd_full_i
   , input                             credits_full_i
   , input                             credits_empty_i
   , input                             idiv_busy_i
   , input                             fdiv_busy_i
   , input                             mem_busy_i
   , input                             mem_ordered_i
   , input                             register_seed_ready_i
   , input [thread_id_width_p-1:0]     current_physical_thread_id_i
   , input [thread_id_width_p-1:0]     retire_thread_id_i

   // Pipeline control signals from the checker to the calculator
   , output logic                      hazard_v_o
   , output logic                      ordered_v_o
   , input [dispatch_pkt_width_lp-1:0] dispatch_pkt_i
   , input [commit_pkt_width_lp-1:0]   commit_pkt_i
   , input [wb_pkt_width_lp-1:0]       late_wb_pkt_i
   , input                             late_wb_yumi_i

   , output logic                      ispec_v_o
   );

  `declare_bp_be_if(vaddr_width_p, paddr_width_p, asid_width_p, branch_metadata_fwd_width_p, fetch_ptr_p, issue_ptr_p);

  `bp_cast_i(bp_be_issue_pkt_s, issue_pkt);
  `bp_cast_i(bp_be_dispatch_pkt_s, dispatch_pkt);
  `bp_cast_i(bp_be_commit_pkt_s, commit_pkt);
  `bp_cast_i(bp_be_wb_pkt_s, late_wb_pkt);

  // Integer data hazards
  logic irs1_sb_raw_haz_v, irs2_sb_raw_haz_v;
  logic ird_sb_waw_haz_v;
  logic [2:0] irs1_data_haz_v , irs2_data_haz_v;
  // Floating point data hazards
  logic frs1_sb_raw_haz_v, frs2_sb_raw_haz_v, frs3_sb_raw_haz_v;
  logic frd_sb_waw_haz_v;
  logic [2:0] frs1_data_haz_v, frs2_data_haz_v, frs3_data_haz_v;
  logic [2:0] rs1_match_vector, rs2_match_vector, rs3_match_vector, rd_match_vector;
  logic [2:0] dep_thread_match_vector;
  logic score_rs1_match, score_rs2_match, score_rs3_match, score_rd_match;

  bp_be_decode_s decode;
  rv64_instr_s instr;
  assign decode = issue_pkt_cast_i.decode;
  bp_be_dep_status_s [3:0] dep_status_r;
  logic [3:0][thread_id_width_p-1:0] dep_thread_id_r;
  logic [3:0] dep_irf_w_r;
  logic [3:0] dep_npc_seed_r;
  logic register_seed_active_r;

  logic fence_haz_v, cmd_haz_v, fflags_haz_v, csr_rs1_haz_v, csr_trans_haz_v, iscore_haz_v, fscore_haz_v;
  logic ctxtsw_rs1_haz_v, ctxtsw_seed_haz_v, ctxtsw_order_haz_v, rpc_args_haz_v;
  logic register_seed_haz_v;
  logic data_haz_v, control_haz_v, struct_haz_v;

  wire [reg_addr_width_gp-1:0] score_rd_li  = commit_pkt_cast_i.instr.t.fmatype.rd_addr;
  wire [reg_addr_width_gp-1:0] check_rs1_li = issue_pkt_cast_i.instr.t.fmatype.rs1_addr;
  wire [reg_addr_width_gp-1:0] check_rs2_li = issue_pkt_cast_i.instr.t.fmatype.rs2_addr;
  wire [reg_addr_width_gp-1:0] check_rs3_li = issue_pkt_cast_i.instr.t.fmatype.rs3_addr;
  wire [reg_addr_width_gp-1:0] check_rd_li  = issue_pkt_cast_i.instr.t.fmatype.rd_addr;
  wire [thread_id_width_p-1:0] check_thread_id_li =
    issue_pkt_cast_i.thread_id[0 +: thread_id_width_p];

  wire [reg_addr_width_gp-1:0] clear_rd_li = late_wb_pkt_cast_i.rd_addr;

  wire irs1_ispec_v = decode.irs1_r_v & rs1_match_vector[0]
    & decode.pipe_int_v
    & (dep_status_r[0].aux_iwb_v | dep_status_r[0].emem_iwb_v | dep_status_r[0].fint_iwb_v)
    & integer_support_p[e_catchup];

  wire irs2_ispec_v = decode.irs2_r_v & rs2_match_vector[0]
    & decode.pipe_int_v
    & (dep_status_r[0].aux_iwb_v | dep_status_r[0].emem_iwb_v | dep_status_r[0].fint_iwb_v)
    & integer_support_p[e_catchup];

  wire irs2_store_v = decode.irs2_r_v & rs2_match_vector[0]
    & decode.dcache_w_v
    & (dep_status_r[0].aux_iwb_v | dep_status_r[0].emem_iwb_v | dep_status_r[0].fint_iwb_v)
    & integer_support_p[e_catchup];

  assign ispec_v_o = irs1_ispec_v | irs2_ispec_v;

  logic [1:0] irs_match_lo;
  logic       ird_match_lo;
  wire score_int_v_li = commit_pkt_cast_i.iscore_v;
  wire clear_int_v_li = late_wb_pkt_cast_i.ird_w_v & late_wb_yumi_i;
  bp_be_scoreboard
   #(.bp_params_p(bp_params_p), .num_rs_p(2))
   int_scoreboard
    (.clk_i(clk_i)
     ,.reset_i(reset_i)

     ,.score_v_i(score_int_v_li)
     ,.score_thread_id_i(retire_thread_id_i)
     ,.score_rd_i(score_rd_li)

     ,.clear_v_i(clear_int_v_li)
     ,.clear_thread_id_i(late_wb_pkt_cast_i.thread_id)
     ,.clear_rd_i(clear_rd_li)

     ,.check_thread_id_i(check_thread_id_li)
     ,.check_rs_i({check_rs2_li, check_rs1_li})
     ,.check_rd_i(check_rd_li)
     ,.rs_match_o(irs_match_lo)
     ,.rd_match_o(ird_match_lo)
     );

  logic [2:0] frs_match_lo;
  logic       frd_match_lo;
  wire score_fp_v_li = commit_pkt_cast_i.fscore_v;
  wire clear_fp_v_li = late_wb_pkt_cast_i.frd_w_v & late_wb_yumi_i;
  bp_be_scoreboard
   #(.bp_params_p(bp_params_p), .num_rs_p(3))
   fp_scoreboard
    (.clk_i(clk_i)
     ,.reset_i(reset_i)

     ,.score_v_i(score_fp_v_li)
     ,.score_thread_id_i(retire_thread_id_i)
     ,.score_rd_i(score_rd_li)

     ,.clear_v_i(clear_fp_v_li)
     ,.clear_thread_id_i(late_wb_pkt_cast_i.thread_id)
     ,.clear_rd_i(clear_rd_li)

     ,.check_thread_id_i(check_thread_id_li)
     ,.check_rs_i({check_rs3_li, check_rs2_li, check_rs1_li})
     ,.check_rd_i(check_rd_li)
     ,.rs_match_o(frs_match_lo)
     ,.rd_match_o(frd_match_lo)
     );

  always_comb
    begin
      // Generate matches for rs1, rs2, rs3
      // 3 stages because we only care about ex1, ex2, and iwb dependencies. fwb dependencies
      //   can be handled through forwarding
      for (int i = 0; i < 3; i++)
        begin
          dep_thread_match_vector[i] = (check_thread_id_li == dep_thread_id_r[i]);
          rs1_match_vector[i] = dep_thread_match_vector[i] & (issue_pkt_cast_i.instr.t.fmatype.rs1_addr == dep_status_r[i].rd_addr);
          rs2_match_vector[i] = dep_thread_match_vector[i] & (issue_pkt_cast_i.instr.t.fmatype.rs2_addr == dep_status_r[i].rd_addr);
          rs3_match_vector[i] = dep_thread_match_vector[i] & (issue_pkt_cast_i.instr.t.fmatype.rs3_addr == dep_status_r[i].rd_addr);
          rd_match_vector [i] = dep_thread_match_vector[i] & (issue_pkt_cast_i.instr.t.fmatype.rd_addr  == dep_status_r[i].rd_addr);
        end
      score_rs1_match = (issue_pkt_cast_i.instr.t.fmatype.rs1_addr == score_rd_li);
      score_rs2_match = (issue_pkt_cast_i.instr.t.fmatype.rs2_addr == score_rd_li);
      score_rs3_match = (issue_pkt_cast_i.instr.t.fmatype.rs3_addr == score_rd_li);
      score_rd_match  = (issue_pkt_cast_i.instr.t.fmatype.rd_addr  == score_rd_li);

      // Detect scoreboard hazards
      irs1_sb_raw_haz_v = (decode.irs1_r_v & irs_match_lo[0]);
      irs2_sb_raw_haz_v = (decode.irs2_r_v & irs_match_lo[1]);
      ird_sb_waw_haz_v  = (decode.irf_w_v  & ird_match_lo);

      frs1_sb_raw_haz_v = (decode.frs1_r_v & frs_match_lo[0]);
      frs2_sb_raw_haz_v = (decode.frs2_r_v & frs_match_lo[1]);
      frs3_sb_raw_haz_v = (decode.frs3_r_v & frs_match_lo[2]);
      frd_sb_waw_haz_v  = (decode.frf_w_v  & frd_match_lo);

      iscore_haz_v       = (decode.irf_w_v & dep_status_r[0].long_iwb_v & rd_match_vector[0])
                           | (decode.irf_w_v & dep_status_r[1].long_iwb_v & rd_match_vector[1])
                           | (decode.irf_w_v & dep_status_r[2].long_iwb_v & rd_match_vector[2]);

      fscore_haz_v       = (decode.frf_w_v & dep_status_r[0].long_fwb_v & rd_match_vector[0])
                           | (decode.frf_w_v & dep_status_r[1].long_fwb_v & rd_match_vector[1])
                           | (decode.frf_w_v & dep_status_r[2].long_fwb_v & rd_match_vector[2]);

      // Detect integer and float data hazards for EX1
      irs1_data_haz_v[0] = (decode.irs1_r_v & rs1_match_vector[0])
                           & (dep_status_r[0].fint_iwb_v | dep_status_r[0].aux_iwb_v | dep_status_r[0].mul_iwb_v | dep_status_r[0].emem_iwb_v | dep_status_r[0].fmem_iwb_v | dep_status_r[0].long_iwb_v)
                           & ~irs1_ispec_v;

      irs2_data_haz_v[0] = (decode.irs2_r_v & rs2_match_vector[0])
                           & (dep_status_r[0].fint_iwb_v | dep_status_r[0].aux_iwb_v | dep_status_r[0].mul_iwb_v | dep_status_r[0].emem_iwb_v | dep_status_r[0].fmem_iwb_v | dep_status_r[0].long_iwb_v)
                           & ~irs2_ispec_v
                           & ~irs2_store_v;

      frs1_data_haz_v[0] = (decode.frs1_r_v & rs1_match_vector[0])
                           & (dep_status_r[0].fint_fwb_v | dep_status_r[0].aux_fwb_v | dep_status_r[0].emem_fwb_v | dep_status_r[0].fmem_fwb_v | dep_status_r[0].fma_fwb_v | dep_status_r[0].long_fwb_v);

      frs2_data_haz_v[0] = (decode.frs2_r_v & rs2_match_vector[0])
                           & (dep_status_r[0].fint_fwb_v | dep_status_r[0].aux_fwb_v | dep_status_r[0].emem_fwb_v | dep_status_r[0].fmem_fwb_v | dep_status_r[0].fma_fwb_v | dep_status_r[0].long_fwb_v);

      frs3_data_haz_v[0] = (decode.frs3_r_v & rs3_match_vector[0])
                           & (dep_status_r[0].fint_fwb_v | dep_status_r[0].aux_fwb_v | dep_status_r[0].emem_fwb_v | dep_status_r[0].fmem_fwb_v | dep_status_r[0].fma_fwb_v | dep_status_r[0].long_fwb_v);

      // Detect integer and float data hazards for EX2
      irs1_data_haz_v[1] = (decode.irs1_r_v & rs1_match_vector[1])
                           & (dep_status_r[1].fmem_iwb_v | dep_status_r[1].mul_iwb_v | dep_status_r[1].long_iwb_v);

      irs2_data_haz_v[1] = (decode.irs2_r_v & rs2_match_vector[1])
                           & (dep_status_r[1].fmem_iwb_v | dep_status_r[1].mul_iwb_v | dep_status_r[1].long_iwb_v);

      frs1_data_haz_v[1] = (decode.frs1_r_v & rs1_match_vector[1])
                           & (dep_status_r[1].fmem_fwb_v | dep_status_r[1].fma_fwb_v | dep_status_r[1].long_fwb_v);

      frs2_data_haz_v[1] = (decode.frs2_r_v & rs2_match_vector[1])
                           & (dep_status_r[1].fmem_fwb_v | dep_status_r[1].fma_fwb_v | dep_status_r[1].long_fwb_v);

      frs3_data_haz_v[1] = (decode.frs3_r_v & rs3_match_vector[1])
                           & (dep_status_r[1].fmem_fwb_v | dep_status_r[1].fma_fwb_v | dep_status_r[1].long_fwb_v);

      irs1_data_haz_v[2] = (decode.irs1_r_v & rs1_match_vector[2])
                           & (dep_status_r[2].long_iwb_v);

      irs2_data_haz_v[2] = (decode.irs2_r_v & rs2_match_vector[2])
                           & (dep_status_r[2].long_iwb_v);

      frs1_data_haz_v[2] = (decode.frs1_r_v & rs1_match_vector[2])
                           & (dep_status_r[2].fma_fwb_v | dep_status_r[2].long_fwb_v);

      frs2_data_haz_v[2] = (decode.frs2_r_v & rs2_match_vector[2])
                           & (dep_status_r[2].fma_fwb_v | dep_status_r[2].long_fwb_v);

      frs3_data_haz_v[2] = (decode.frs3_r_v & rs3_match_vector[2])
                           & (dep_status_r[2].fma_fwb_v | dep_status_r[2].long_fwb_v);

      // ordered_o deliberately separates a quiescent memory pipe from the
      // cache's externally visible ordering state.  A fence or architectural
      // context handoff needs both: mem_ordered may already be high while an
      // older store is still crossing the local memory pipe.  Detached hints
      // remain advisory because the UCE excludes their credits from
      // mem_ordered when prefetch_ignore_credits_p is enabled.
      fence_haz_v        = decode.fence_v & (mem_busy_i | ~mem_ordered_i);
      cmd_haz_v          = cmd_full_i;

      fflags_haz_v = (decode.csr_r_v | decode.csr_w_v)
                     & ((dep_status_r[0].fflags_v & (check_thread_id_li == dep_thread_id_r[0]))
                        | (dep_status_r[1].fflags_v & (check_thread_id_li == dep_thread_id_r[1]))
                        | (dep_status_r[2].fflags_v & (check_thread_id_li == dep_thread_id_r[2]))
                        | (dep_status_r[3].fflags_v & (check_thread_id_li == dep_thread_id_r[3]))
                        | fdiv_busy_i
                        );

      /*
       * Register-form CSR writes consume rs1 outside the normal integer
       * forwarding path. In particular, the early context-switch classifier
       * reads the target thread id from the scheduler regfile output, so a
       * csrw 0x800 immediately after a produced rs1 value must wait until the
       * value is architectural.
       */
	      csr_rs1_haz_v = issue_pkt_cast_i.csrw
	                      & (issue_pkt_cast_i.instr inside {`RV64_CSRRW, `RV64_CSRRS, `RV64_CSRRC})
                      & ((rs1_match_vector[0]
                           & (dep_status_r[0].eint_iwb_v
                              | dep_status_r[0].fint_iwb_v
                              | dep_status_r[0].aux_iwb_v
                              | dep_status_r[0].mul_iwb_v
                              | dep_status_r[0].emem_iwb_v
                              | dep_status_r[0].fmem_iwb_v
                              | dep_status_r[0].long_iwb_v))
                         | (rs1_match_vector[1]
                            & (dep_status_r[1].fmem_iwb_v
                               | dep_status_r[1].mul_iwb_v
                               | dep_status_r[1].long_iwb_v))
                         | (rs1_match_vector[2]
	                            & dep_status_r[2].long_iwb_v));

      // Unlike ordinary execution operands, the early context target is not
      // repaired by calculator forwarding. Wait through architectural GPR
      // writeback, including injected load/divide completions with no pipe flag.
      // Do not gate on issue.v: it depends on queue enable and hence hazard_v_o.
      ctxtsw_rs1_haz_v = 1'b0;
      for (int i = 0; i < 4; i++)
        ctxtsw_rs1_haz_v |= dep_irf_w_r[i]
                           & (check_thread_id_li == dep_thread_id_r[i])
                           & (check_rs1_li == dep_status_r[i].rd_addr);
      ctxtsw_rs1_haz_v &= issue_pkt_cast_i.csrw
                         & (issue_pkt_cast_i.instr.t.itype.imm12 inside {12'h800, 12'h808})
                         & (issue_pkt_cast_i.instr inside {`RV64_CSRRW, `RV64_CSRRS, `RV64_CSRRC})
                         & (check_rs1_li != '0);

      // The early switch captures NPC and translation state before retirement.
      // Wait for older NPC seeds to commit rather than capturing an uninitialized
      // target bundle. Seeds name logical targets, so this dependency is global,
      // and applies to both register and immediate forms of the switch CSR.
      // As above, issue.v depends on hazard_v_o and must not gate this check.
      ctxtsw_seed_haz_v = issue_pkt_cast_i.csrw
                         & (issue_pkt_cast_i.instr.t.itype.imm12 inside {12'h800, 12'h808, 12'h809})
                         & (|dep_npc_seed_r);

      // Do not change register-bank ownership while an older demand or store
      // still has local pipeline state.  In particular, a fast resident
      // switch has no context-cache drain phase to repair this race later.
      ctxtsw_order_haz_v = issue_pkt_cast_i.csrw
                           & (issue_pkt_cast_i.instr.t.itype.imm12 inside {12'h800, 12'h808, 12'h809})
                           & (mem_busy_i | ~mem_ordered_i);

      // pcall implicitly reads a0-a3 and preturn implicitly reads a0. The
      // line-bank tap is outside the calculator bypass network, so wait until
      // every implicit source has reached architectural writeback.
      rpc_args_haz_v = 1'b0;
      for (int i = 0; i < 4; i++) begin
        rpc_args_haz_v |= dep_irf_w_r[i]
                          & (check_thread_id_li == dep_thread_id_r[i])
                          & (((issue_pkt_cast_i.instr.t.itype.imm12 == 12'h808)
                              & (dep_status_r[i].rd_addr inside {5'd10, 5'd11, 5'd12, 5'd13}))
                             | ((issue_pkt_cast_i.instr.t.itype.imm12 == 12'h809)
                                & (dep_status_r[i].rd_addr == 5'd10)));
      end
      rpc_args_haz_v &= issue_pkt_cast_i.csrw;

      // CSR802 shares each scalar register-file write port with ordinary WB.
      // Drain older work before admitting a seed, then hold younger issue until
      // the seed's own rd writeback has drained. Injected completions remain
      // enabled by the scheduler while FE issue is held. No seed means no hold
      // on the steady-state context-switch path.
      register_seed_haz_v = register_seed_active_r
                           | (issue_pkt_cast_i.csrw
                              & (issue_pkt_cast_i.instr.t.itype.imm12 == 12'h802)
                              & ~register_seed_ready_i);

	      /*
	       * Memory operations consume trans_info_i directly from the CSR block.
	       * Translation-affecting CSR writes must retire before a following
	       * load/store can sample mstatus/satp-derived privilege, MPRV, ASID, or
	       * page-table base state.
	       */
	      csr_trans_haz_v = (decode.pipe_mem_early_v | decode.pipe_mem_final_v)
	                        & ((dep_status_r[0].trans_info_v & (check_thread_id_li == dep_thread_id_r[0]))
	                           | (dep_status_r[1].trans_info_v & (check_thread_id_li == dep_thread_id_r[1]))
	                           | (dep_status_r[2].trans_info_v & (check_thread_id_li == dep_thread_id_r[2]))
	                           | (dep_status_r[3].trans_info_v & (check_thread_id_li == dep_thread_id_r[3])));

      control_haz_v = fence_haz_v | fflags_haz_v | csr_rs1_haz_v | csr_trans_haz_v
                          | ctxtsw_rs1_haz_v | ctxtsw_seed_haz_v | ctxtsw_order_haz_v
                          | rpc_args_haz_v | register_seed_haz_v;

      // Combine all data hazard information
      // TODO: Parameterize away floating point data hazards without hardware support
      data_haz_v = (|irs1_data_haz_v)
                   | (|irs2_data_haz_v)
                   | (|frs1_data_haz_v)
                   | (|frs2_data_haz_v)
                   | (|frs3_data_haz_v)
                   | (irs1_sb_raw_haz_v | irs2_sb_raw_haz_v | ird_sb_waw_haz_v)
                   | (frs1_sb_raw_haz_v | frs2_sb_raw_haz_v | frs3_sb_raw_haz_v | frd_sb_waw_haz_v);

      // Combine all structural hazard information
      struct_haz_v = cmd_haz_v
                     | fscore_haz_v | iscore_haz_v
                     // Keep a hint at dispatch while the memory pipe is busy.
                     // The hint is advisory after acceptance, but silently
                     // retiring it here destroys sustained prefetch coverage.
                     | (mem_busy_i & decode.pipe_mem_early_v)
                     | (mem_busy_i & decode.pipe_mem_final_v)
                     | (fdiv_busy_i & decode.pipe_long_v)
                     | (idiv_busy_i & decode.pipe_long_v);
    end

  assign hazard_v_o = struct_haz_v | control_haz_v | data_haz_v;
  assign ordered_v_o = ~(mem_busy_i | fdiv_busy_i | idiv_busy_i) & mem_ordered_i;

  bp_be_decode_s dep_decode;
  bp_be_dep_status_s dep_status_n;
  assign dep_decode = dispatch_pkt_cast_i.decode;
  always_comb
    begin
      dep_status_n.v           = dispatch_pkt_cast_i.v;
      // nspec == writeback, could reduce to only fflags setting
      dep_status_n.fflags_v    = dispatch_pkt_cast_i.nspec_v | dep_decode.pipe_aux_v | dep_decode.pipe_fma_v;
      dep_status_n.eint_iwb_v  = dep_decode.pipe_int_v       & dep_decode.irf_w_v  & ~ispec_v_o;
      dep_status_n.eint_fwb_v  = dep_decode.pipe_int_v       & dep_decode.frf_w_v;
      dep_status_n.fint_iwb_v  = dep_decode.pipe_int_v       & dep_decode.irf_w_v  &  ispec_v_o;
      dep_status_n.fint_fwb_v  = dep_decode.pipe_int_v       & dep_decode.frf_w_v;
      dep_status_n.aux_iwb_v   = dep_decode.pipe_aux_v       & dep_decode.irf_w_v;
      dep_status_n.aux_fwb_v   = dep_decode.pipe_aux_v       & dep_decode.frf_w_v;
      dep_status_n.emem_iwb_v  = dep_decode.pipe_mem_early_v & dep_decode.irf_w_v;
      dep_status_n.emem_fwb_v  = dep_decode.pipe_mem_early_v & dep_decode.frf_w_v;
      dep_status_n.fmem_iwb_v  = dep_decode.pipe_mem_final_v & dep_decode.irf_w_v;
      dep_status_n.fmem_fwb_v  = dep_decode.pipe_mem_final_v & dep_decode.frf_w_v;
      dep_status_n.mul_iwb_v   = dep_decode.pipe_mul_v       & dep_decode.irf_w_v;
      dep_status_n.mul_fwb_v   = dep_decode.pipe_mul_v       & dep_decode.frf_w_v;
      dep_status_n.fma_iwb_v   = dep_decode.pipe_fma_v       & dep_decode.irf_w_v;
      dep_status_n.fma_fwb_v   = dep_decode.pipe_fma_v       & dep_decode.frf_w_v;
	      dep_status_n.long_iwb_v  = dep_decode.pipe_long_v      & dep_decode.irf_w_v;
	      dep_status_n.long_fwb_v  = dep_decode.pipe_long_v      & dep_decode.frf_w_v;
	      dep_status_n.trans_info_v = dispatch_pkt_cast_i.special.csrw
	                                  & (dispatch_pkt_cast_i.instr.t.itype.imm12
	                                     inside {`CSR_ADDR_MSTATUS, `CSR_ADDR_SSTATUS, `CSR_ADDR_SATP});
	      dep_status_n.rd_addr     = dispatch_pkt_cast_i.instr.t.rtype.rd_addr;
	    end

  // Set on actual dispatch, not the issue candidate. A squashed seed releases
  // the hold when the pipeline empties, without performing a remote write.
  always_ff @(posedge clk_i)
    if (reset_i)
      register_seed_active_r <= 1'b0;
    else if (dispatch_pkt_cast_i.v & dispatch_pkt_cast_i.special.csrw
             & (dispatch_pkt_cast_i.instr.t.itype.imm12 == 12'h802))
      register_seed_active_r <= 1'b1;
    else if (register_seed_ready_i)
      register_seed_active_r <= 1'b0;

  always_ff @(posedge clk_i)
    if (reset_i)
      begin
        dep_irf_w_r <= '0;
        dep_npc_seed_r <= '0;
      end
    else
      begin
        // Age with the existing destination/thread tags even while issue stalls.
        // Squashed producers may conservatively delay only this CSR, then expire.
        dep_irf_w_r <= {dep_irf_w_r[2:0], dispatch_pkt_cast_i.v & dep_decode.irf_w_v};
        dep_npc_seed_r <= {dep_npc_seed_r[2:0], dispatch_pkt_cast_i.v
                          & dispatch_pkt_cast_i.special.csrw
                          & (dispatch_pkt_cast_i.instr.t.itype.imm12 == 12'h801)};
      end

  always_ff @(posedge clk_i)
    begin
      dep_status_r[0]   <= dispatch_pkt_cast_i.v ? dep_status_n : '0;
      dep_status_r[3:1] <= dep_status_r[2:0];
      dep_thread_id_r[0]   <= dispatch_pkt_cast_i.thread_id[0 +: thread_id_width_p];
      dep_thread_id_r[3:1] <= dep_thread_id_r[2:0];
    end

endmodule
