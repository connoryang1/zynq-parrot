This is preparation for ONE clean canonical1792 N200 fullcore correctness gate, following the closed matched native/N40 controls. It builds no target during preparation. All sealed N40 inputs/proofs remain unchanged. No N200 model, HP0 result, effect, physical calibration or route result is claimed.

Exact source remains ROOT TOPeb7d390134a0025331a2366a979a774263b146d5 / BP8dfdbdeec84cb47f902bc1426d69ecb3efd91c7c, static two-bank16KiB L2, ordinary32KiB L1I/D,1792 full64B retained lines/side,256sets/epoch8/observe1,20MHz,2resident4logical. The model command changes response delay40→200 only; eight workers and explicit OBJCACHE= stay unchanged. Same integrity6dc1/f856 and cold08 3fe0/6276 ELF/NBF/CRT/source identities are required. Existing software/source validators, scoped assertions, precise postPASS teardown allowance, strict512bit/eight-real-L1-writes/I retirement, actual GP0 counters and16 geometry fields are preserved.

Six sealed N40 anchors now gate preparation and execution: fullcore manifest/root independent closure, HP0 admission/root receipt/positive107 proof and full512 target-to-ELF-to-winning-L1-write join. Their exact hashes are in N40-anchors.json and run_full.py. This accepts N40 as a measured control but does not transfer201/208, publication509 or any other N200 endpoint. N200 positive107 audit and independent payload join will follow fullcore closure separately. Existing postprocessing tools remain bound to their maintained HOME paths and nativeROOT16534 hashes, not assumed inside old sparseeb7d.

ROOT prepare command (actual host namespace only; no agent privateRAM):

    python3 -B /home/coyang/fpga-artifacts/context-resume/retained-canonical-latency200-8workers-preparation01-20261121/run_full.py --out /dev/shm/zp-canonical-latency200-8workers-20261121-01/prepared01 --prepare-only

After ROOT reviews the actual prepared record and separately admits execution:

    python3 -B /home/coyang/fpga-artifacts/context-resume/retained-canonical-latency200-8workers-preparation01-20261121/run_full.py --out /dev/shm/zp-canonical-latency200-8workers-20261121-01/full01 --execute --prepared /dev/shm/zp-canonical-latency200-8workers-20261121-01/prepared01/session.json

Then, after fullcore PASS, preserve with:

    python3 -B /home/coyang/fpga-artifacts/context-resume/retained-canonical-latency200-8workers-preparation01-20261121/close_full.py --external /dev/shm/zp-canonical-latency200-8workers-20261121-01/full01 --out /home/coyang/fpga-artifacts/context-resume/retained-canonical-latency200-8workers-preparation01-20261121/closed-full01

Limits unchanged: combined actual shared sparse source plus fresh stage640MiB and1GiB free RAM plus remaining allocation; total fresh HOME128MiB (including later HP0 audit) and3GiB reserve plus remaining;150MiB per runtimeFST; build3600s; integrity600s/cold08180s native with780/240s host guards;3GiB HOME floor. Owned process-group stop on any error/resource breach; no retry, budget extension or new software/RTL. No RAM stage is created here. Source paths, actual command/stamp and ingested source inode/time/hash records must pass ROOT preparation/build;12 lightweight host tests pass including incorrect workers/delay/source/stamp/cache/tool hash/N40 anchors/geometry/EOF/budget rejection. This helper inherits the already closed source/tool path guard corrections.

Only the observed N40 canonical control is known: external AR first/full1/8, BP41/48, contiguous eight64b beats; target admission→AR/publication I81/189,D52.5/160. These are simulation/fixture endpoints, not N200 assumptions or physical timing. N200 is an added response-age control shared by demand I/D and prefetch traffic, with R/B bandwidth/backpressure/concurrency audited; ACK is not CPU ready and overlapping intervals cannot be summed as exclusive stalls. No whole-application/FPGA/max-fit claim follows this functional gate.
