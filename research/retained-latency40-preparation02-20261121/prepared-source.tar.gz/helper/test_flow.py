"""Offline admission/geometry tests; no build or target subprocess is invoked."""
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest import mock

HERE=Path(__file__).resolve().parent

def load(name):
    spec=importlib.util.spec_from_file_location('metadata_'+name,HERE/(name+'.py'))
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

flow=load('run_full');geometry=load('geometry')

class FlowTests(unittest.TestCase):
    def command(self):
        macro=' '.join('-D'+n+'='+str(v) for n,v in [('ACLK_MHZ',20),('BP_RETAINED_BUFFER',1),
            ('BP_RETAINED_I_LINES',1792),('BP_RETAINED_D_LINES',1792),('BP_RETAINED_SETS',256),
            ('BP_RETAINED_OBSERVE',1),('BP_AXI_RESPONSE_DELAY',40)])
        return '--assert --trace-fst --build-jobs 8 -DBSG_HIDE_FROM_SYNTHESIS '+macro+' '+ ' '.join(str(flow.ROOT/'import/black-parrot'/p) for p in ('bp_common/src/v/bp_retained_line_store.sv','bp_me/src/v/cce/bp_uce.sv'))

    def test_exact_command_and_wrong_path_macro_assert(self):
        c=self.command();flow.validate_actual_command(c)
        for bad in (c.replace('ACLK_MHZ=20','ACLK_MHZ=18'),c.replace('--assert',''),c.replace('--build-jobs 8','--build-jobs 3'),c.replace('--build-jobs 8','--build-jobs 12'),c.replace('--build-jobs 8','--build-jobs 80'),c+' --build-jobs 8',c.replace('BP_AXI_RESPONSE_DELAY=40','BP_AXI_RESPONSE_DELAY=0'),
                    c.replace('BP_RETAINED_I_LINES=1792','BP_RETAINED_I_LINES=64'),
                    c+' -DBP_RETAINED_METADATA_VERIFY',c+' -DBP_CUSTOM_BASE_CFG=x',
                    c.replace(str(flow.ROOT/'import/black-parrot'),'wrong')):
            with self.assertRaises(ValueError):flow.validate_actual_command(bad)

    def test_future_command_only_changes_workers_and_disables_cache(self):
        original=['make','VERILATOR_BUILD_JOBS=3','BP_AXI_RESPONSE_DELAY=40','TRACE=1']
        self.assertEqual(flow.configure_build_command(original),['make','VERILATOR_BUILD_JOBS=8','BP_AXI_RESPONSE_DELAY=40','TRACE=1','OBJCACHE='])
        for bad in (['make'],original+['VERILATOR_BUILD_JOBS=8'],original+['OBJCACHE=/tmp/ccache'],original+['OBJCACHE=','OBJCACHE=']):
            with self.assertRaises(ValueError):flow.configure_build_command(bad)

    def test_coordinator_equivalence_provenance(self):
        flow.validate_coordinator()

    def test_postprocessing_tool_path_and_hash_are_native_bound(self):
        records=flow.postprocess_tool_bindings()
        self.assertEqual({Path(r['path']).name for r in records},{'admission.DRAFT.json','root-session.json','run.py','audit.py'})
        with self.assertRaisesRegex(ValueError,'postprocessing tool path'):
            flow.postprocess_tool_bindings(flow.ROOT/'testing/rtl/hp0-closed-trace')
        original=flow.bind
        def wrong_hash(path):
            row=original(path)
            if Path(path).name=='run.py':row['sha256']='0'*64
            return row
        with mock.patch.object(flow,'bind',side_effect=wrong_hash):
            with self.assertRaisesRegex(ValueError,'path/hash'):
                flow.postprocess_tool_bindings()

    def test_later_HP0_tools_not_assumed_inside_frozen_RTL(self):
        import inspect
        source=inspect.getsource(flow.input_bindings)
        self.assertNotIn("ROOT/'testing/rtl/hp0-closed-trace",source)
        self.assertIn('postprocess_tool_bindings()',source)

    def test_static_stamp_cannot_be_custom_or_different_geometry(self):
        good='.build_config-nt-nc-cfge_bp_unicore_zynqparrot_prefetch16k_cfg-trace1-BP_AXI_RESPONSE_DELAY_40-BP_RETAINED_BUFFER_1-BP_RETAINED_I_LINES_1792-BP_RETAINED_D_LINES_1792-BP_RETAINED_SETS_256-BP_RETAINED_OBSERVE_1-assert-bsgsimhidden-support'
        flow.validate_stamp(good)
        for old,new in [('prefetch16k_cfg','custom_cfg'),('trace1','trace0'),('SETS_256','SETS_64'),('BP_AXI_RESPONSE_DELAY_40','BP_AXI_RESPONSE_DELAY_0')]:
            with self.assertRaises(ValueError):flow.validate_stamp(good.replace(old,new))

    def test_output_scope(self):
        with self.assertRaises(ValueError):flow.validate_output(Path('/tmp/outside-metadata'))

    def test_reserve_and_allocation(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t);(p/'data').write_bytes(b'x')
            enough=mock.Mock(free=flow.RESERVE+flow.ALLOCATION)
            with mock.patch.object(flow.shutil,'disk_usage',return_value=enough):flow.resource_check(p)
            with mock.patch.object(flow.shutil,'disk_usage',return_value=mock.Mock(free=flow.RESERVE)):
                with self.assertRaises(ValueError):flow.resource_check(p)
            with mock.patch.object(flow,'directory_bytes',return_value=flow.ALLOCATION+1):
                with self.assertRaises(ValueError):flow.resource_check(p)

    def events(self):
        lines=['#FST\t0\t100\t-12\n']
        for n,k in enumerate(geometry.EXPECTED,1):lines.append(f'#SIGNAL\t{k}\t32\t{n}\tTOP.dut.unicore_lite.{k}\n')
        for n,(k,v) in enumerate(geometry.EXPECTED.items(),1):lines.append(f'0\t{n}\t{v:032b}\n')
        return lines+['#END\n']

    def test_actual_parameters_full_eof(self):
        result=geometry.parse(self.events());self.assertTrue(result['clean_eof'])
        for lines in (self.events()[:-1],self.events()+['100\t1\t'+32*'0'+'\n']):
            with self.assertRaises(ValueError):geometry.parse(lines)

    def test_old1280_retained_geometry_rejected(self):
        lines=self.events();index=list(geometry.EXPECTED).index('retained_store.storage.i_lines_p')
        lines[1+len(geometry.EXPECTED)+index]=f'0\t{index+1}\t{1280:032b}\n'
        with self.assertRaises(ValueError):geometry.parse(lines)

    def test_wrong_thread_or_unknown_param(self):
        for bits in (f'{4:032b}',32*'x'):
            lines=self.events();lines[-17]='0\t1\t'+bits+'\n'
            with self.assertRaises(ValueError):geometry.parse(lines)

if __name__=='__main__':unittest.main()
