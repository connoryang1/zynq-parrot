This records the actual SP whole-device implementation failure and the completed read-only resource-attribution query. It preserves the candidate's source, compile settings, resource reports, DRC failure and exact synthesis DCP identity. It does not establish a fitted capacity, routed timing, bitstream or physical acceptance.

Job `20261121T140517Z-11ca59a27` terminated FAIL after synthesis and implementation resource DRC. Actual TOP11ca/BPd766 and backend SHA `aa365818…` match the admitted source. Child Tcl and consumer XPR carry all six required defines: retained1, I/D1280/1280, sets256, observe1, native delay0. Ordinary L1I/L1D32KiB, L216KiB,2/4 contexts and comparison clock remain fixed. No `Synth8-326` warning was found in the captured complete synthesis/terminal logs; no feedback-cut waiver was used.

The actual synthesis report uses57,373/53,200 LUT sites:53,776 logic plus3,441 LUTRAM and156 SRL, with33,699 FF. BRAM is exactly140/140 tiles:139 RAMB36 plus two RAMB18. Implementation's `UTLZ-1` then reports53,344 logic cells against53,200 compatible sites and stops. Its144-cell excess is a different endpoint from synthesis's4,173 total-LUT-site excess; removing144 alone is not shown sufficient. No placement/slice-packing or routed timing result exists.

One approved read-only batch opened synthesis DCP SHA `3514bf6f…`, emitted flat/hierarchical/focused utilization and a bounded named primitive census, and exited0 in81.73seconds. It performed no synthesis, optimization, placement, routing, fixup or bitstream write. A final independent process/hash check confirms all Vivado processes are gone and the82,388,975-byte input DCP remains byte-identical. No further tool launch occurred.

| Actual source hierarchy | LUT sites | FF | BRAM tiles |
|---|---:|---:|---:|
| CPU core, including ordinary L1 caches |38,549|17,867|76|
| Ordinary L1D, already included in core |5,371|1,808|10|
| Ordinary L1I, already included in core |2,196|1,044|11|
| D UCE |2,460|2,483|8|
| I UCE |2,703|2,327|8|
| Retained store |3,756|5,841|41|
| Retained-use observer |42|96|0|
| L2 slice |4,187|1,899|6|

The retained store has zero LUTRAM: all3,756 LUT sites are logic. Its exact named census contains2,048 epoch FF and1,536 replacement-pointer FF, versus2,048 line-buffer FF and209 other FF. Epoch/replacement names account for1,114 raw LUT primitives, with additional metadata access/selection logic under optimized controller/`empty_found` names. The complete store census has4,052 raw LUT primitives versus3,756 site-adjusted LUTs; these are distinct measures and cannot be subtracted interchangeably. Named attribution does not establish that removing one source array saves all associated logic or that metadata alone resolves the full-device deficit.

This evidence supports a metadata reset/storage/read-mux prototype preserving payload and coherence. The observer's42 LUT sites cannot explain the4,173-site synthesis excess. The CPU is the largest absolute module, but no matched feature-off report establishes an incremental CPU cost, and cache subtotals must not be added again. Retained41 + core76 + UCE16 + L2slice6 + wrapper1 accounts for all140 BRAM tiles; UCE protocol/staging memory is not retained payload capacity. No larger-capacity guess, required-feature removal or ordinary-geometry change is justified by these reports. Root owns the next source or inference decision.

`closed-terminal01/manifest.json` binds the terminal reports, source/define evidence, read-job inputs/outputs and lossless snapshots. Original job, DCP and query outputs remain unchanged at their recorded durable paths. The monitor and read-only query have both exited; there is no active process owned by this work.
