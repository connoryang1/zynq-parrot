#!/usr/bin/env python3
"""One bounded read-only netlist query, with only its own child-group cleanup."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

OUT=Path('/tmp/linux-retained-sp-hierarchy-20261121-01')
WRAPPER='/home/coyang/zynq-parrot/codex-skills/bp-fpga-synthesis/scripts/run_vivado_2024_2.sh'
DCP=Path('/tmp/zynq-parrot-fpga-20261121T140517Z-11ca59a27/cosim/black-parrot-example/vivado/black_parrot_bd_proj.runs/synth_1/black_parrot_bd_1_wrapper.dcp')
EXPECTED='3514bf6fd563fae17e6b8c4829810b7d60b706b85c79995f05a501361e247663'


def bind(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())


def group(pgid):
    try:os.killpg(pgid,0);return True
    except ProcessLookupError:return False


def reap(pgid):
    while True:
        try:
            pid,_=os.waitpid(-pgid,os.WNOHANG)
            if not pid:return
        except ChildProcessError:return


def stop(p):
    for sig in (signal.SIGTERM,signal.SIGKILL):
        if group(p.pid):os.killpg(p.pid,sig)
        try:p.wait(timeout=5)
        except subprocess.TimeoutExpired:continue
        until=time.monotonic()+5
        while time.monotonic()<until:
            reap(p.pid)
            if not group(p.pid):return
            time.sleep(.05)
    p.wait(timeout=5);reap(p.pid)
    assert not group(p.pid),'own query process group remains'


def main():
    assert subprocess.run(['pgrep','-x','vivado'],stdout=subprocess.PIPE).returncode==1,'builder is not idle'
    assert bind(DCP)['sha256']==EXPECTED
    assert ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0
    argv=[WRAPPER,'-mode','batch','-source','query.tcl','-log','vivado.log','-journal','vivado.jou']
    r=dict(state='RUNNING read-only query',argv=argv,timeout_seconds=300,input_DCP=bind(DCP),
        query=bind(OUT/'query.tcl'),physical_operations=0,synthesis_operations=0)
    p=None;started=time.monotonic()
    def interrupted(*_):raise RuntimeError('read-only query interrupted')
    signal.signal(signal.SIGTERM,interrupted)
    try:
        with (OUT/'console.log').open('wb') as f:
            p=subprocess.Popen(argv,cwd=OUT,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
            r['pid']=p.pid
            while p.poll() is None:
                if time.monotonic()-started>=300:raise RuntimeError('fixed300s query limit')
                # This query writes small reports only; refuse unexpected output growth.
                assert sum(x.stat().st_size for x in OUT.iterdir() if x.is_file())<64*1024**2,'query outputs exceed64MiB'
                time.sleep(.25)
            r['returncode']=p.wait();reap(p.pid)
            assert not group(p.pid),'query left descendants'
        assert r['returncode']==0
        assert 'READ_ONLY_HIERARCHY_QUERY_COMPLETE_NO_SYNTH_OPT_PLACE_ROUTE' in (OUT/'console.log').read_text()
        assert bind(DCP)['sha256']==EXPECTED
        assert subprocess.run(['pgrep','-x','vivado'],stdout=subprocess.PIPE).returncode==1,'Vivado remains after query'
        r.update(state='PASS one read-only DCP hierarchy query; no reimplementation',outputs=[bind(x) for x in sorted(OUT.iterdir()) if x.is_file()])
    except BaseException as e:r.update(state='FAIL preserved read-only query',error=repr(e));raise
    finally:
        if p is not None:
            if p.poll() is None or group(p.pid):stop(p)
            r['returncode']=p.returncode
        r['elapsed_seconds']=time.monotonic()-started
        (OUT/'session.json').write_text(json.dumps(r,indent=2)+'\n')
        print(r['state'])


if __name__=='__main__':main()
