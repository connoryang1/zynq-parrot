#!/usr/bin/env python3
"""Analyze already collected reports; performs no tool or target execution."""
from collections import Counter,defaultdict
import csv
import hashlib
import json
from pathlib import Path
import re

HERE=Path(__file__).resolve().parent


def bind(p):
    p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def main():
    remote=HERE/'remote';session=json.loads((remote/'session.json').read_text())
    assert session['returncode']==0 and session['state'].startswith('PASS one read-only')
    for r in session['outputs']:
        p=remote/Path(r['path']).name;b=bind(p);assert (b['bytes'],b['sha256'])==(r['bytes'],r['sha256'])
    for name in ('query.tcl','run_remote.py'):assert (remote/name).read_bytes()==(HERE/name).read_bytes()
    names=['CPU_core_including_L1','ordinary_L1D','L1D_writebuffer_included','ordinary_L1I','D_UCE','I_UCE','retained_store','observer'];modules={}
    for index,name in enumerate(names):
        p=remote/f'focused-{index:02d}.rpt';text=p.read_text()
        def used(label):
            m=re.search(r'^\|\s*'+re.escape(label)+r'\s*\|\s*(\d+(?:\.\d+)?)\s*\|',text,re.M);assert m,label
            return float(m[1]) if '.' in m[1] else int(m[1])
        modules[name]=dict(total_LUT=used('Slice LUTs*'),logic_LUT=used('LUT as Logic'),memory_LUT=used('LUT as Memory'),FF=used('Slice Registers'),BRAM_tiles=used('Block RAM Tile'),report=bind(p))
    counts=defaultdict(Counter)
    for r in csv.DictReader((remote/'primitive-counts.tsv').read_text().splitlines(),delimiter=chr(9)):
        if r['component']=='retained_store':counts[r['name_group']][r['ref_name']]+=int(r['primitive_count'])
    groups={g:dict(FF=sum(v for k,v in c.items() if k.startswith('FD')),raw_LUT_primitives=sum(v for k,v in c.items() if re.fullmatch('LUT[1-6]',k)),MUXF7=c['MUXF7'],MUXF8=c['MUXF8'],refs=dict(c)) for g,c in counts.items()}
    assert sum(g['FF'] for g in groups.values())==5841
    assert sum(g['raw_LUT_primitives'] for g in groups.values())==4052
    assert modules['retained_store']['total_LUT']==3756 and modules['retained_store']['memory_LUT']==0
    report=dict(state='TERMINAL FPGA implementation FAIL; successful read-only source/DCP attribution query',
        synth_total=dict(LUT=57373,logic_LUT=53776,LUTRAM=3441,SRL=156,FF=33699,BRAM_tiles=140,RAMB36=139,RAMB18=2),
        opted_DRC=dict(rule='UTLZ-1',required_logic_cells=53344,compatible_sites=53200,excess_at_this_check=144,
            report=bind(HERE.parent/'terminal-drc-exact.rpt'),qualification='Not a full post-opt utilization/packing result; removing144 alone is not proven sufficient. Synth total excess4173 is a distinct endpoint.'),
        input_DCP=session['input_DCP'],query_state=session['state'],query_actual_exit=0,query_elapsed_seconds=session['elapsed_seconds'],query_session=bind(remote/'session.json'),
        source_manifest=bind(HERE/'source-manifest.json'),modules=modules,retained_named_primitive_groups=groups,
        observations=['Store authoritative cost3756 site-adjustedLUT/5841FF/41BRAM, all logic and zeroLUTRAM. Named epoch/RR metadata3584FF, linebuffers2048FF, other209FF.',
            'Epochs+RR have1114 named rawLUT primitives. Additional access/mux/control logic has other optimized names. RawstoreLUT4052 differs from3756 site-adjustedLUT; do not equate rawcounts to removable sites.',
            'Unattributed store samples include empty_found selection/mux logic. This supports metadata-path investigation but is not a complete functional ownership partition.',
            'CPUcore38549LUT is largest absolute module and includes ordinaryL1 caches. Dcache5371/Icache2196/wbuf223 must not be added again. No matched feature-off source establishes incrementalCPUcost.',
            'Observer42LUT/96FF cannot explain4173 synthesis-site excess. Named cache-miss trace is small, but no arbitrary debug subtraction or feature removal is justified.',
            'Retained41 + core76 + UCE16 + L2slice6 + wrapperBRAM1 accounts for actual140tiles. UCE8BRAM each is protocol/transient storage, not retained payload capacity.',
            'Investigate metadata reset/storage/read muxes while preserving actual payload, coherence and controls. Neither this diagnosis nor a prototype establishes a fitted saving.'],
        limitations=['No placement/slice packing/routed timing/bitstream or physical acceptance.',
            'No capacity guess, ordinarygeometry/context/clock change, required-feature removal or further launch.',
            'Census uses named IS_PRIMITIVE objects and may include vendorRAMmacro/leaf views. Authoritative module reports use site-adjusted utilization; named subclasses are partial source attribution.'],
        hierarchy=bind(remote/'utilization_hierarchical.rpt'),primitive_census=bind(remote/'primitive-counts.tsv'),name_samples=bind(remote/'primitive-name-samples.tsv'))
    (HERE/'analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(bind(HERE/'analysis.json'))


if __name__=='__main__':main()
