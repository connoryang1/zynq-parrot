set_param general.maxThreads 2
set input /tmp/zynq-parrot-fpga-20261121T140517Z-11ca59a27/cosim/black-parrot-example/vivado/black_parrot_bd_proj.runs/synth_1/black_parrot_bd_1_wrapper.dcp
set expected 3514bf6fd563fae17e6b8c4829810b7d60b706b85c79995f05a501361e247663
if {[lindex [exec sha256sum $input] 0] ne $expected} {error "input DCP identity mismatch"}
open_checkpoint $input
report_utilization -file utilization_flat.rpt
report_utilization -hierarchical -file utilization_hierarchical.rpt
set f [open focused-hierarchy.tsv w]
puts $f "index\tname\tref_name\treport"
set index 0
foreach c [lsort [get_cells -hierarchical -filter {IS_PRIMITIVE == 0}]] {
  set ref [get_property REF_NAME $c]
  if {[regexp {^(bp_retained_line_store|bp_uce|bp_be_dcache|bp_fe_icache|bp_core_minimal|bp_retained_use_counters)} $ref]} {
    set filename [format focused-%02d.rpt $index]
    report_utilization -cells [list $c] -file $filename
    puts $f [join [list $index $c $ref $filename] "\t"]
    incr index
    if {$index > 20} {error "unexpectedly many focused hierarchy roots"}
  }
}
close $f
set counts [dict create]
set samples [dict create]
foreach c [get_cells -hierarchical -filter {IS_PRIMITIVE == 1}] {
  set name [get_property NAME $c]
  set ref [get_property REF_NAME $c]
  set component other_wrapper_uncore
  set function all
  if {[string match *retained_observe* $name]} {
    set component observer
  } elseif {[string match *retained_store* $name]} {
    set component retained_store
    set function unattributed_named_store_logic
    if {[string match *epochs_r* $name]} {set function epochs_storage_or_access_named}
    if {[string match *rr_r* $name]} {set function RR_storage_or_access_named}
    if {[string match *payload_mem* $name]} {set function payload_RAM_or_interface_named}
    if {[string match *tag_mem* $name]} {set function tag_RAM_or_interface_named}
    if {[regexp {(insert_data_r|resp_data_r)} $name]} {set function line_register_buffers_named}
    if {[regexp {(state_r|slot_r|clear_slot_r|word_r)} $name]} {set function controller_named}
  } elseif {[string match *cache_miss_trace* $name] || [string match *tracer* $name]} {
    set component trace_named
  } elseif {[string match *icache_uce* $name]} {set component I_UCE
  } elseif {[string match *dcache_uce* $name]} {set component D_UCE
  } elseif {[string match *core_minimal*icache* $name]} {set component ordinary_L1I
  } elseif {[string match *pipe_mem*dcache* $name]} {set component ordinary_L1D
  } elseif {[string match *l2s* $name]} {set component L2
  } elseif {[string match *context_cache* $name]} {set component context_cache_named
  } elseif {[string match *core_minimal* $name]} {set component CPU_core_other}
  set key [list $component $function $ref]
  dict incr counts $key
  if {![dict exists $samples $key] || [llength [dict get $samples $key]] < 4} {
    dict lappend samples $key $name
  }
}
set f [open primitive-counts.tsv w]
puts $f "component\tname_group\tref_name\tprimitive_count"
foreach key [lsort [dict keys $counts]] {puts $f [join [concat $key [list [dict get $counts $key]]] "\t"]}
close $f
set f [open primitive-name-samples.tsv w]
puts $f "component\tname_group\tref_name\tname"
foreach key [lsort [dict keys $samples]] {
  foreach name [dict get $samples $key] {puts $f [join [concat $key [list $name]] "\t"]}
}
close $f
if {[lindex [exec sha256sum $input] 0] ne $expected} {error "DCP changed during read query"}
puts "READ_ONLY_HIERARCHY_QUERY_COMPLETE_NO_SYNTH_OPT_PLACE_ROUTE"
