#!/usr/bin/env python3
"""Close already captured terminal/query evidence without remote/tool execution."""
import gzip
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent


def bind(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())


def main():
    terminal=json.loads((HERE/'poll-027.json').read_text())
    end=json.loads((HERE/'read-hierarchy01/end-check.json').read_text())
    query=json.loads((HERE/'read-hierarchy01/remote/session.json').read_text())
    assert terminal['status']=='FAIL' and not terminal['processes']
    assert end['no_Vivado_processes'] and end['input_DCP_unchanged'] and end['query_actual_exit']==0
    assert query['input_DCP']['sha256']==end['input_DCP_sha256']=='3514bf6fd563fae17e6b8c4829810b7d60b706b85c79995f05a501361e247663'
    out=HERE/'closed-terminal01';out.mkdir(exist_ok=False)
    selected=[p for p in HERE.rglob('*') if p.is_file() and not out in p.parents]
    copies=[]
    for source in sorted(selected):
        target=out/(str(source.relative_to(HERE))+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
        raw=source.read_bytes();target.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(target.read_bytes())==raw
        copies.append(dict(original=bind(source),snapshot=bind(target)))
    # The closed local console is archived only if it exactly matches terminal capture.
    console=Path('/home/coyang/fpga-logs-linux-retained-native1280-sp-r4/20261121T140517Z-11ca59a27/console.log')
    expected=terminal['files'][str(console)]
    assert bind(console)['sha256']==expected['sha256']
    target=out/'original-job-console.log.gz';raw=console.read_bytes();target.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(target.read_bytes())==raw
    copies.append(dict(original=bind(console),snapshot=bind(target)))
    result=dict(state='TERMINAL FAIL implementation LUT-overutilization; successful single read-only attribution query',
        job='20261121T140517Z-11ca59a27',source=terminal['source'],actual_define_evidence=[r for r in terminal['definitions'] if r['path'].endswith(('black_parrot_bd_1_wrapper.tcl','black_parrot_bd_proj.xpr'))],
        feedback_cut_warnings=terminal['feedback_warnings'],synth=dict(total_LUT=57373,available_LUT=53200,logic_LUT=53776,memory_LUT=3597,FF=33699,BRAM_tiles=140,available_BRAM_tiles=140),
        opted_DRC=dict(rule='UTLZ-1',required_logic_cells=53344,compatible_sites=53200),
        synthesis_DCP=query['input_DCP'],read_job_elapsed_seconds=query['elapsed_seconds'],read_job_actual_exit=0,
        final_process_DCP_check=bind(HERE/'read-hierarchy01/end-check.json'),attribution=bind(HERE/'read-hierarchy01/analysis.json'),
        no_routed_timing_or_placement=True,no_capacity_recommendation=True,no_further_launch=True,
        snapshots=copies,limitations='Synthesis and optDRC resource endpoints differ; no fit/bit/physical acceptance. Read-only DCP reports do not establish savings from a prototype or justify removing required functionality.')
    (out/'manifest.json').write_text(json.dumps(result,indent=2)+'\n');print(bind(out/'manifest.json'));print('snapshots',len(copies))


if __name__=='__main__':main()
