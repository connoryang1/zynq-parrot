#!/usr/bin/env python3
"""Poll only the existing job; journal every90s and announce substantive changes."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

HERE=Path(__file__).resolve().parent


def main():
    prior=json.loads((HERE/'poll-003.json').read_text());index=3
    while True:
        time.sleep(90)
        index+=1;target=HERE/f'poll-{index:03d}.json'
        command=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-p','30041',
                 'coyang@haight.chillysky.com','python3','-B','-']
        result=subprocess.run(command,input=(HERE/'remote_probe.py').read_bytes(),
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40)
        if result.returncode:
            (HERE/f'poll-{index:03d}-SSH-error.log').write_bytes(result.stderr)
            raise RuntimeError('read-only SSH poll failed; job left untouched')
        current=json.loads(result.stdout);target.write_bytes(result.stdout)
        assert current['epoch']-prior['epoch']>=60,'remote poll interval'
        cpu=[];old={p['pid']:p for p in prior['processes']}
        for p in current['processes']:
            q=old.get(p['pid'])
            if q and q['startticks']==p['startticks'] and '/unwrapped/' in p['argv']:
                delta=((p['utime_ticks']+p['stime_ticks'])-(q['utime_ticks']+q['stime_ticks']))/current['ticks_per_second']
                if delta>1:cpu.append(dict(pid=p['pid'],CPU_seconds=delta))
        report_names=[r['binding']['path'] for r in current['reports']]
        old_names=[r['binding']['path'] for r in prior['reports']]
        changed=(current['status']!=prior['status'] or report_names!=old_names
                 or bool(current['feedback_warnings'])!=bool(prior['feedback_warnings']))
        record=dict(state=current['status'],utc=current['utc'],poll=str(target),
            poll_sha256=hashlib.sha256(result.stdout).hexdigest(),reports=report_names,
            CPU_advancement=cpu,feedback_warnings=current['feedback_warnings'],source=current['source'])
        temp=HERE/'live-status.tmp';temp.write_text(json.dumps(record,indent=2)+'\n');temp.replace(HERE/'live-status.json')
        if changed:print(json.dumps(record),flush=True)
        if current['status']!='RUNNING':
            print('MONITOR_TERMINAL job status='+current['status'],flush=True);return
        prior=current


if __name__=='__main__':main()
