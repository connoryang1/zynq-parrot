#!/usr/bin/env python3
"""Read-only snapshot of the single already admitted SP synthesis job."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

JOB='20261121T140517Z-11ca59a27'
LOGS=Path('/home/coyang/fpga-logs-linux-retained-native1280-sp-r4')/JOB
WORK=Path('/tmp/zynq-parrot-fpga-'+JOB)
DESIGN=WORK/'cosim/black-parrot-example/vivado'
RUN=DESIGN/'black_parrot_bd_proj.runs/synth_1'


def capture(path):
    raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),
                mtime_ns=path.stat().st_mtime_ns),raw.decode(errors='replace')


def main():
    result=dict(utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),epoch=time.time(),
        job=JOB,status=(LOGS/'status').read_text().strip(),ticks_per_second=os.sysconf('SC_CLK_TCK'),
        uptime_seconds=float(Path('/proc/uptime').read_text().split()[0]),processes=[],files={},
        definitions=[],feedback_warnings=[],retained_mapping_lines=[],reports=[],source={})
    result['host_memory_kB']={k:int(v.split()[0]) for k,v in
        (line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines())
        if k in ('MemTotal','MemAvailable','SwapTotal','SwapFree')}
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            if (proc/'comm').read_text().strip()!='vivado':continue
            fields=(proc/'stat').read_text().rsplit(') ',1)[1].split()
            result['processes'].append(dict(pid=int(proc.name),state=fields[0],ppid=int(fields[1]),
                utime_ticks=int(fields[11]),stime_ticks=int(fields[12]),startticks=int(fields[19]),
                minor_faults=int(fields[7]),major_faults=int(fields[9]),threads=int(fields[17]),
                resident_bytes=int(fields[21])*os.sysconf('SC_PAGE_SIZE'),
                argv=(proc/'cmdline').read_bytes().replace(bytes([0]),b' ').decode(errors='replace')))
        except (FileNotFoundError,ProcessLookupError,PermissionError):pass
    paths=[LOGS/'revisions.txt',LOGS/'console.log',LOGS/'summary.txt',RUN/'runme.log',
           RUN/'vivado.tcl',RUN/'black_parrot_bd_1_wrapper.tcl',DESIGN/'black_parrot_bd_proj.xpr']
    for path in paths:
        if not path.exists():continue
        record,text=capture(path);result['files'][str(path)]=record
        lines=text.splitlines()
        for index,line in enumerate(lines):
            if ('BP_RETAINED_' in line or 'BP_AXI_RESPONSE_DELAY' in line) and len(line)<20000:
                result['definitions'].append(dict(path=str(path),line=index+1,text=line))
            if 'Synth 8-326' in line:
                result['feedback_warnings'].append(dict(path=str(path),line=index+1,text=line))
            if 'payload_mem' in line or ('tag_mem' in line and ('lane_fsm' in line or 'retained' in line)):
                result['retained_mapping_lines'].append(dict(path=str(path),line=index+1,
                    context=lines[max(0,index-2):index+6]))
        if path.name in ('console.log','runme.log','summary.txt'):
            result.setdefault('tails',{})[str(path)]=lines[-12:]
    candidates=set(LOGS.glob('*.rpt'))
    for folder in (RUN,DESIGN/'black_parrot_bd_proj.runs/impl_1'):
        if folder.is_dir():candidates.update(folder.glob('*.rpt'))
    for path in sorted(candidates):
        record,text=capture(path);result['reports'].append(dict(binding=record,text=text))
    bp=WORK/'import/black-parrot'
    if (bp/'.git').is_file():
        result['source']['BP_head']=subprocess.check_output(['git','-C',str(bp),'rev-parse','HEAD'],text=True).strip()
        result['source']['backend']=capture(bp/'bp_common/src/v/bp_retained_line_store.sv')[0]
    result['synth_run_files']=[dict(name=p.name,bytes=p.stat().st_size) for p in RUN.iterdir()] if RUN.exists() else []
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
