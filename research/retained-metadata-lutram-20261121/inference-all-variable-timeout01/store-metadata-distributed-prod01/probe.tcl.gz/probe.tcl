set_param general.maxThreads 8
create_project -in_memory -part xc7z020clg400-1
read_verilog -sv source.sv
synth_design -top bp_retained_line_store -part xc7z020clg400-1 -directive AreaOptimized_high -global_retiming on -control_set_opt_threshold 1 -generic i_lines_p=1280 -generic d_lines_p=1280 -generic sets_p=256
report_utilization -hierarchical -file utilization.rpt
set f [open primitives.tsv w]
foreach c [lsort [get_cells -hier -filter {REF_NAME =~ RAMB*}]] {
  puts $f [join [list $c [get_property REF_NAME $c] [get_property RAM_MODE $c] [get_property READ_WIDTH_A $c] [get_property WRITE_WIDTH_A $c] [get_property READ_WIDTH_B $c] [get_property WRITE_WIDTH_B $c]] "\t"]
}
close $f
set f [open distributed-primitives.tsv w]
foreach c [lsort [get_cells -hier -filter {REF_NAME =~ RAM* && REF_NAME !~ RAMB*}]] {
  puts $f [join [list $c [get_property REF_NAME $c] [get_property IS_PRIMITIVE $c]] [format %c 9]]
}
close $f
write_checkpoint -force synthesized.dcp
