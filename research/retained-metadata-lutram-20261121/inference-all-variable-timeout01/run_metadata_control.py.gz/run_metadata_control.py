#!/usr/bin/env python3
"""Source-bound frozen metadata prototype under production synthesis options; prepare by default."""
from pathlib import Path
import argparse
import hashlib
import json
import shlex
import re
from collections import Counter
import subprocess
from datetime import datetime, timezone

HERE=Path(__file__).resolve().parent
BP=Path('/home/coyang/zynq-parrot-retained-metadata/import/black-parrot')
HOST='coyang@haight.chillysky.com'
WRAPPER='/home/coyang/zynq-parrot/codex-skills/bp-fpga-synthesis/scripts/run_vivado_2024_2.sh'
CASES={'store-metadata-distributed-prod':('19bd0da2afa835230a19669ecb06e40498373a4b',8)}
EXPECTED_SOURCE='bd4cd65c92bdaf8af80c9c6f4643383c8bfa7fd335ca131319d44c2e45ee2e24'
BASELINE=Path('/home/coyang/zynq-parrot-linux-capacity/research/retained-ram-inference-20261121/sp-closed01/verification.json')
BASELINE_SHA='6c3e8df9c1b72651b8c8cfa1d44a0c0010478b0eea355a2d64ee7c1b32670364'


def bind(p):
    p=Path(p);raw=p.read_bytes()
    return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('case',choices=CASES);ap.add_argument('--execute',action='store_true');a=ap.parse_args()
    commit,threads=CASES[a.case]
    source=subprocess.check_output(['git','-C',str(BP),'show',commit+':bp_common/src/v/bp_retained_line_store.sv'])
    if len(source)!=18690 or hashlib.sha256(source).hexdigest()!=EXPECTED_SOURCE:
        raise RuntimeError('exact frozen metadata source required')
    if bind(BASELINE)['sha256']!=BASELINE_SHA:
        raise RuntimeError('exact accepted SP baseline proof required')
    baseline=json.loads(BASELINE.read_text())
    if baseline['resources']!={'LUT':6259,'FF':7903,'RAMB36':40,'RAMB18':2,'tile_equivalents':41}:
        raise RuntimeError('wrong accepted standalone baseline')
    state=dict(state='PREPARED source-bound metadata inference only',case=a.case,bp=commit,threads=threads,
               source_sha256=hashlib.sha256(source).hexdigest(),physical_operations=0,baseline=bind(BASELINE),baseline_resources=baseline['resources'],baseline_LUTRAM=0,verification_macro='BP_RETAINED_METADATA_VERIFY undefined',scope='All-variable standalone ports; resource delta only, no additive fullCPU fit forecast or benefit claim')
    if not a.execute:print(json.dumps(state,indent=2));return
    out=HERE/(a.case+'01');out.mkdir();remote='/tmp/linux-retained-'+a.case+'-20261121-01'
    (out/'source.sv').write_bytes(source)
    tcl='''set_param general.maxThreads THREADS
create_project -in_memory -part xc7z020clg400-1
read_verilog -sv source.sv
synth_design -top bp_retained_line_store -part xc7z020clg400-1 -directive AreaOptimized_high -global_retiming on -control_set_opt_threshold 1 -generic i_lines_p=1280 -generic d_lines_p=1280 -generic sets_p=256
report_utilization -hierarchical -file utilization.rpt
set f [open primitives.tsv w]
foreach c [lsort [get_cells -hier -filter {REF_NAME =~ RAMB*}]] {
  puts $f [join [list $c [get_property REF_NAME $c] [get_property RAM_MODE $c] [get_property READ_WIDTH_A $c] [get_property WRITE_WIDTH_A $c] [get_property READ_WIDTH_B $c] [get_property WRITE_WIDTH_B $c]] "\\t"]
}
close $f
set f [open distributed-primitives.tsv w]
foreach c [lsort [get_cells -hier -filter {REF_NAME =~ RAM* && REF_NAME !~ RAMB*}]] {
  puts $f [join [list $c [get_property REF_NAME $c] [get_property IS_PRIMITIVE $c]] [format %c 9]]
}
close $f
write_checkpoint -force synthesized.dcp
'''.replace('THREADS',str(threads))
    (out/'probe.tcl').write_text(tcl)
    state.update(started_utc=datetime.now(timezone.utc).isoformat(),inputs=[bind(out/'source.sv'),bind(out/'probe.tcl'),bind(__file__)],commands=[])
    def save():(out/'session.json').write_text(json.dumps(state,indent=2)+'\n')
    def run(label,argv,seconds,required=True):
        row=dict(label=label,argv=argv,timeout=seconds);state['commands'].append(row);save()
        try:
            with (out/(label+'.log')).open('wb') as log:r=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,timeout=seconds)
            row['returncode']=r.returncode
            if required and r.returncode:raise RuntimeError(label+' failed; source/partial evidence retained')
            return r.returncode
        finally:
            if (out/(label+'.log')).exists():row['log']=bind(out/(label+'.log'))
            save()
    ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-p','30041',HOST]
    try:
        run('admission',ssh+['test -x '+shlex.quote(WRAPPER)+' && ! pgrep -x vivado && test ! -e '+shlex.quote(remote)+' && mkdir '+shlex.quote(remote)],30)
        run('upload',['scp','-q','-P','30041',str(out/'source.sv'),str(out/'probe.tcl'),HOST+':'+remote+'/'],30)
        rc=run('synthesis',ssh+['cd '+shlex.quote(remote)+' && timeout --kill-after=15s 580s '+shlex.quote(WRAPPER)+' -mode batch -source probe.tcl -log vivado.log -journal vivado.jou'],620,False)
        collected=run('collect',['scp','-q','-r','-P','30041',HOST+':'+remote,str(out/'remote')],40,False)
        run('no-orphans',ssh+['! pgrep -x vivado'],20)
        if collected:raise RuntimeError('partial source/log collection failed')
        if rc:raise RuntimeError('compiler isolation arm failed; inspect preserved crash evidence')
        for n in ('utilization.rpt','primitives.tsv','distributed-primitives.tsv','synthesized.dcp'):
            if not (out/'remote'/n).is_file():raise RuntimeError('missing actual synthesis output')
        table=(out/'remote/utilization.rpt').read_text()
        row=re.search(r'^\| bp_retained_line_store\s*\|\s*\(top\)\s*\|([^\n]+)\|$',table,re.M)
        if row is None:raise RuntimeError('missing exact standalone utilization row')
        values=list(map(int,[part.strip() for part in row[1].split('|')]))
        if len(values)!=8:raise RuntimeError('unknown utilization schema')
        resources=dict(LUT=values[0],logic_LUT=values[1],LUTRAM=values[2],SRL=values[3],FF=values[4],RAMB36=values[5],RAMB18=values[6],DSP=values[7],tile_equivalents=values[5]+values[6]/2)
        distributed=Counter()
        for line in (out/'remote/distributed-primitives.tsv').read_text().splitlines():
            fields=line.split(chr(9))
            if len(fields)!=3 or not fields[1].startswith('RAM') or fields[1].startswith('RAMB'):
                raise RuntimeError('bad distributed primitive census schema')
            distributed[fields[1]]+=1
        comparison=dict(resources=resources,baseline=state['baseline'],baseline_resources=baseline['resources'],baseline_LUTRAM=0,
            deltas_vs_SP={key:resources[key]-baseline['resources'][key] for key in baseline['resources']},
            distributed_primitive_objects_by_REF_NAME=dict(distributed),
            limits='Standalone all-variable same1280/1280/256 production options. RawRAMmacro/leaf object counts are not summed as physicalLUTRAMsites; authoritative LUTRAM count is utilization column. No matched wholeCPU saving/fit/route projection. No gain threshold or automatic followup.')
        (out/'comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
        state['comparison']=bind(out/'comparison.json')
        if bind(BASELINE)['sha256']!=BASELINE_SHA:raise RuntimeError('SP baseline drift')
        if hashlib.sha256(subprocess.check_output(['git','-C',str(BP),'show',commit+':bp_common/src/v/bp_retained_line_store.sv'])).hexdigest()!=EXPECTED_SOURCE:
            raise RuntimeError('frozen source drift')
        state.update(state='PASS standalone metadata production-option synthesis and resource reporting only; no routed-fit claim',
                     outputs={n:bind(out/'remote'/n) for n in ('utilization.rpt','primitives.tsv','distributed-primitives.tsv','synthesized.dcp')})
    except BaseException as e:
        state.update(state='FAIL preserved compiler isolation only; no fit conclusion',error=repr(e));raise
    finally:state['closed_utc']=datetime.now(timezone.utc).isoformat();save()
    print(state['state'],a.case)

if __name__=='__main__':main()
