#!/usr/bin/env python3
"""Run one next fixed1280 case, only after complete previous raw/counter audits."""
import argparse
import fcntl
import importlib.util
import json
import os
from pathlib import Path
import re
import resource
import shutil
import subprocess

from build import ROOT, bind, require, verify_coverage
from run_case import primary_counts
from audit1280 import source_bindings

ORDER = ('d-enabled', 'd-off', 'i-enabled')


def previous_gate(cohort, role):
    for previous in ORDER[:ORDER.index(role)]:
        case = cohort / previous
        audit = cohort / (previous + '-audit')
        run = json.loads((case / 'verification.json').read_text())
        proof = json.loads((audit / 'verification.json').read_text())
        counters = json.loads((audit / 'counter-words.json').read_text())
        require(run['role'] == previous and run['state'].startswith('PASS') and proof['state'].startswith('PASS'), 'complete fixed prior case')
        require(proof['lines'] == 1280 and proof['sets'] == 256 and len(proof['targets']) == 1280, 'all prior actual targets')
        require(counters['state'] == 'PASS final FST counter words equal actual GP0 reads' and
                counters['audit'] == bind(audit / 'verification.json') and counters['values'] == run['counters'], 'prior actual counter corroboration')
        for record in run['files'] + [run['admission']] + list(proof['bindings'].values()) + [counters['auditor']]:
            require(bind(record['path']) == record, 'prior closed source/raw proof drift')


def check_inputs(preparation):
    for key in ('model', 'model_stamp', 'compiled_sources', 'compiled_metadata', 'host_dependency', 'program', 'preparer', 'root_session'):
        record = preparation[key]
        require(bind(record['path']) == record, 'frozen preparation changed: ' + key)
    for record in preparation['critical_sources']:
        require(bind(record['path'])['sha256'] == record['sha256'], 'critical host/RTL source drift')
    compiled = json.loads(Path(preparation['compiled_sources']['path']).read_text())
    source_bindings(Path(preparation['compiled_sources']['path']))
    for path, record in compiled['sources'].items():
        require(bind(path)['sha256'] == record['sha256'], 'actual compiled RTL input drift')
    program = json.loads(Path(preparation['program']['path']).read_text())
    for record in program['sources'] + [program['elf'], program['compiler'], program['converter']]:
        require(bind(record['path']) == record, 'program/compiler input drift')
    return program


def check_budget(cohort, preparation):
    require(shutil.disk_usage(cohort).free >= preparation['minimum_free_bytes'], 'fixed minimum8GiB free space')
    total = sum(path.stat().st_size for path in cohort.glob('*/trace.fst'))
    require(total <= preparation['raw_cohort_cap_bytes'], 'fixed raw cohort budget exceeded')
    require(preparation['per_trace_cap_bytes'] == 2*1024**3 and preparation['raw_cohort_cap_bytes'] == 6*1024**3 and
            preparation['minimum_free_bytes'] == 8*1024**3 and preparation['native_runtime_ms'] == 1800000 and
            preparation['outer_timeout_s'] == 1980, 'fixed reviewed budgets')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--preparation', required=True, type=Path)
    parser.add_argument('--role', choices=ORDER, required=True)
    args = parser.parse_args()
    cohort = args.preparation.resolve().parent
    with (cohort / 'acquisition.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        preparation = json.loads(args.preparation.read_text())
        require(preparation['schema'] == 'retained-capacity1280-preparation-v1' and preparation['schedule'] == list(ORDER), 'fixed prepared cohort')
        program = check_inputs(preparation)
        previous_gate(cohort, args.role)
        check_budget(cohort, preparation)
        here = Path(__file__).resolve().parent
        source_paths = sorted(here.glob('*.py')) + sorted(here.glob('*.c')) + sorted(here.glob('*.S'))
        sources = [bind(path) for path in source_paths]
        frozen = cohort / 'runtime-sources.json'
        if frozen.exists():
            require(json.loads(frozen.read_text()) == sources, 'runtime sources frozen across cohort')
        else:
            require(args.role == ORDER[0], 'first source freeze only before first case')
            frozen.write_text(json.dumps(sources, indent=2) + '\n')
        output = Path(preparation['case_paths'][args.role])
        require(output == cohort / args.role, 'exact admitted path')
        output.mkdir(exist_ok=False)
        case = program['cases'][args.role]
        require(bind(case['nbf']['path']) == case['nbf'], 'exact selected NBF')
        shutil.copyfile(program['elf']['path'], output / 'prog.riscv')
        shutil.copyfile(case['nbf']['path'], output / 'prog.nbf')
        coverage = verify_coverage(output / 'prog.riscv', output / 'prog.nbf', program['symbols']['retained_capacity_config']['address'], int(case['input_word'], 16))
        command = [preparation['model']['path'], '+c_args=prog.nbf 1800000', '+bsg_trace=' + str(output / 'trace.fst')]
        admission = dict(schema='retained-capacity-correctness1280-v1', role=args.role,
                         preparation=bind(args.preparation), runtime_sources=bind(frozen),
                         program=preparation['program'], model=preparation['model'], compiled_sources=preparation['compiled_sources'],
                         elf=bind(output / 'prog.riscv'), nbf=bind(output / 'prog.nbf'), coverage=coverage, command=command,
                         native_runtime_ms=1800000, outer_timeout_s=1980, fst_cap_bytes=2*1024**3, negative_control=args.role == 'd-off')
        (output / 'admission.json').write_text(json.dumps(admission, indent=2) + '\n')
        env = os.environ.copy()
        for name in ('BSG_RUNTIME_PATCH_ADDR', 'BSG_RUNTIME_PATCH_VALUE', 'BSG_TRACE_TIMEOUT_S'):
            env.pop(name, None)
        env['LD_LIBRARY_PATH'] = '/home/coyang/zynq-parrot-linux-research/install/lib' + (':' + env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
        def limits():
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
            resource.setrlimit(resource.RLIMIT_FSIZE, (2*1024**3, 2*1024**3))
        try:
            with (output / 'run.log').open('w') as log:
                process = subprocess.run(command, cwd=output, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=1980, preexec_fn=limits)
            (output / 'process.json').write_text(json.dumps(dict(returncode=process.returncode)) + '\n')
            checker_path = ROOT / 'testing/check_run.py'
            spec = importlib.util.spec_from_file_location('checker1280', checker_path)
            checker = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(checker)
            text = (output / 'run.log').read_text(errors='replace')
            checker.check_transcript(text, process.returncode)
            marker = '[BSG-PASS] retained capacity checked all full64B payloads completed'
            require(text.count(marker) == 1 and text.index(marker) < checker.CORE_PASS.search(text).start(), 'complete payload/CORE marker')
            rows = re.findall(r'RETAINED_CAPACITY_CONFIG ([^\r\n]+)', text)
            require(len(rows) == 1, 'one exact config')
            config = dict(word.split('=') for word in rows[0].split())
            lane, active = args.role[0], args.role.endswith('enabled')
            expected = dict(version='1', lane=lane, active=str(int(active)), lines='1280', sets='256', max_lines='1280', line_bytes='64',
                            data_base='0x%016x' % program['data_base'], code_base='0x%016x' % program['code_base'], code_stride='192', copy='0')
            require(config == expected and len(rows[0].split()) == len(expected), 'exact actual geometry/role/config')
            fields = re.findall(r'RETAINED_USE_COUNTERS version=1 i_hits=(\d+) d_hits=(\d+) i_published=(\d+) d_published=(\d+) i_write_beats=(\d+) d_write_beats=(\d+) saturating_bits=16 reset=axi_only', text)
            require(len(fields) == 1, 'one exact actual GP0 row')
            values = tuple(map(int, fields[0]))
            rejected = False
            if active:
                primary_counts(lane, 1280, values)
            else:
                require(values == (0, 0, 0, 0, 0, 0), 'negative zero retained events')
                try:
                    primary_counts(lane, 1280, values)
                except ValueError:
                    rejected = True
                require(rejected, 'negative primary gate rejected')
            check_inputs(preparation)
            require([bind(path) for path in source_paths] == sources, 'source drift during execution')
            require(sum(path.stat().st_size for path in cohort.glob('*/trace.fst')) <= 6*1024**3, 'raw cohort cap')
            report = dict(state='PASS primary functional/counter gate; per-address closed trace pending' if active else 'PASS negative checked execution with primary retained-use gate rejected; closed trace pending',
                          role=args.role, config=config, counters=values, primary_use_gate_rejected=rejected, actual_returncode=process.returncode,
                          admission=bind(output / 'admission.json'), files=[bind(output / name) for name in ('prog.riscv', 'prog.nbf', 'run.log', 'process.json', 'trace.fst')],
                          limits='No FPGA/fit/performance result. Per-address full-payload audit and counter corroboration required before next case.')
            (output / 'verification.json').write_text(json.dumps(report, indent=2) + '\n')
        except BaseException as error:
            (output / 'FAIL.json').write_text(json.dumps(dict(state='FAIL STOP cohort; no retry/limit raise/next case', error=repr(error))) + '\n')
            raise
        print(output / 'verification.json')


if __name__ == '__main__':
    main()
