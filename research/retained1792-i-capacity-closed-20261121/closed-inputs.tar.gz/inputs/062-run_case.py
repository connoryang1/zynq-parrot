#!/usr/bin/env python3
"""One bounded fresh-process correctness case on the exact closed observer model."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import resource
import shutil
import subprocess

from build import ROOT,bind,require,verify_coverage


def primary_counts(lane,lines,values):
    expected=(lines,0,lines,0,8*lines,0) if lane=='i' else (0,lines,0,lines,0,8*lines)
    require(tuple(values)==expected,'primary retained-use counter gate: '+repr(values)+' expected '+repr(expected))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--program',required=True,type=Path);parser.add_argument('--model-build',required=True,type=Path)
    parser.add_argument('--role',required=True,choices=('d-enabled','d-off','i-enabled','i-off'));parser.add_argument('--out',required=True,type=Path)
    a=parser.parse_args();manifest=json.loads((a.program/'manifest.json').read_text())
    require(manifest['state'].startswith('PASS crosscompile'),'closed program')
    case=manifest['cases'][a.role]
    for record in manifest['sources']+[manifest['elf'],manifest['converter'],case['nbf']]:require(bind(record['path'])==record,'program/source/input drift')
    build=json.loads((a.model_build/'build-accepted.json').read_text());require(build['state']=='PASS clean actual-fulltop build; runtime pending','closed model')
    model=Path(build['model']['path']);require(bind(model)['sha256']==build['model']['sha256'],'model identity')
    compiled=json.loads((a.model_build/'actual-source-list.json').read_text())
    for path,record in compiled['sources'].items():require(bind(path)['sha256']==record['sha256'],'compiled source drift')
    require(manifest['max_lines']==manifest['max_sets']==64,'first admission is fixed64 only')
    output=a.out.resolve();output.mkdir(parents=True,exist_ok=False)
    shutil.copyfile(manifest['elf']['path'],output/'prog.riscv');shutil.copyfile(case['nbf']['path'],output/'prog.nbf')
    coverage=verify_coverage(output/'prog.riscv',output/'prog.nbf',manifest['symbols']['retained_capacity_config']['address'],int(case['input_word'],16))
    command=[str(model),'+c_args=prog.nbf 600000','+bsg_trace='+str(output/'trace.fst')]
    admission=dict(schema='retained-capacity-correctness-v1',role=a.role,program=bind(a.program/'manifest.json'),model=build['model'],
        model_build=bind(a.model_build/'build-accepted.json'),compiled_sources=bind(a.model_build/'actual-source-list.json'),
        elf=bind(output/'prog.riscv'),nbf=bind(output/'prog.nbf'),coverage=coverage,command=command,
        native_runtime_ms=600000,outer_timeout_s=660,fst_cap_bytes=512*1024*1024,negative_control=a.role.endswith('-off'))
    (output/'admission.json').write_text(json.dumps(admission,indent=2)+'\n')
    env=os.environ.copy()
    for name in ('BSG_RUNTIME_PATCH_ADDR','BSG_RUNTIME_PATCH_VALUE','BSG_TRACE_TIMEOUT_S'):env.pop(name,None)
    env['LD_LIBRARY_PATH']='/home/coyang/zynq-parrot-linux-research/install/lib'+(':'+env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
    def limits():
        resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_FSIZE,(512*1024*1024,512*1024*1024))
    with (output/'run.log').open('w') as log:
        process=subprocess.run(command,cwd=output,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=660,preexec_fn=limits)
    (output/'process.json').write_text(json.dumps(dict(returncode=process.returncode))+'\n')
    checker_path=ROOT/'testing/check_run.py';spec=importlib.util.spec_from_file_location('checker',checker_path)
    checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)
    text=(output/'run.log').read_text(errors='replace');checker.check_transcript(text,process.returncode)
    marker='[BSG-PASS] retained capacity checked all full64B payloads completed'
    require(text.count(marker)==1 and text.index(marker)<checker.CORE_PASS.search(text).start(),'complete payload check marker')
    rows=re.findall(r'RETAINED_CAPACITY_CONFIG ([^\r\n]+)',text);require(len(rows)==1,'one exact config')
    config={}
    for word in rows[0].split():
        key,value=word.split('=');require(key not in config,'duplicate config');config[key]=value
    lane=a.role[0];active=a.role.endswith('enabled')
    expected=dict(version='1',lane=lane,active=str(int(active)),lines='64',sets='64',max_lines='64',line_bytes='64',
                  data_base='0x%016x'%manifest['data_base'],code_base='0x%016x'%manifest['code_base'],code_stride='192',copy='0')
    require(config==expected,'exact geometry/role/source config')
    counters=re.findall(r'RETAINED_USE_COUNTERS version=1 i_hits=(\d+) d_hits=(\d+) i_published=(\d+) d_published=(\d+) i_write_beats=(\d+) d_write_beats=(\d+) saturating_bits=16 reset=axi_only',text)
    require(len(counters)==1,'one actual GP0 counter row');values=tuple(map(int,counters[0]));require(all(v<65535 for v in values),'unsaturated')
    rejected=False
    if active:primary_counts(lane,64,values)
    else:
        require(values==(0,0,0,0,0,0),'negative source0 has no retained activity')
        try:primary_counts(lane,64,values)
        except ValueError:rejected=True
        require(rejected,'negative must fail primary use gate')
    report=dict(state='PASS primary functional/counter gate; per-address closed trace pending' if active else 'PASS negative checked execution with primary retained-use gate rejected; closed trace pending',
        role=a.role,config=config,counters=values,primary_use_gate_rejected=rejected,actual_returncode=process.returncode,
        admission=bind(output/'admission.json'),files=[bind(output/name) for name in ('prog.riscv','prog.nbf','run.log','process.json','trace.fst')],
        limits='No board/synth/performance result. Aggregates alone do not establish unique physical capacity; complete per-address audit still required.')
    (output/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(output/'verification.json')


if __name__=='__main__':main()
