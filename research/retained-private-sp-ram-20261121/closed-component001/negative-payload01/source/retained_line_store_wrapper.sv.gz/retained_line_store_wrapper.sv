module retained_line_store_wrapper
 #(parameter int I_LINES = 93, parameter int D_LINES = 131)
  (input logic [1:0] clk_i, reset_i, clear_i, invalidate_v_i
   , input logic [33:0] invalidate_addr0_i, invalidate_addr1_i
   , input logic [1:0] lookup_v_i
   , output logic [1:0] lookup_ready_o
   , input logic [33:0] lookup_addr0_i, lookup_addr1_i
   , output logic [1:0] resp_v_o
   , input logic [1:0] resp_ready_i
   , output logic [1:0] resp_hit_o
   , output logic [511:0] resp_data0_o, resp_data1_o
   , input logic [1:0] insert_v_i
   , output logic [1:0] insert_ready_o
   , input logic [33:0] insert_addr0_i, insert_addr1_i
   , input logic [511:0] insert_data0_i, insert_data1_i
   , input logic [1:0] insert_replace_i, insert_cancel_i
   , output logic [1:0] insert_done_o, insert_published_o, busy_o, epoch_wrap_o
   , output logic [1:0] debug_data_v_o, debug_data_w_o
   , output logic [2:0] debug_word0_o, debug_word1_o
   , output logic [31:0] i_lines_o, d_lines_o
   , output logic equivalence_mismatch_o
   );
  assign i_lines_o = I_LINES;
  assign d_lines_o = D_LINES;
  bp_retained_line_store
   #(.paddr_width_p(34), .sets_p(64), .i_lines_p(I_LINES), .d_lines_p(D_LINES), .epoch_width_p(2)) dut
   (.clk_i(clk_i), .reset_i(reset_i), .clear_i(clear_i)
    ,.invalidate_v_i(invalidate_v_i), .invalidate_addr_i({invalidate_addr1_i,invalidate_addr0_i})
    ,.lookup_v_i(lookup_v_i), .lookup_ready_o(lookup_ready_o), .lookup_addr_i({lookup_addr1_i,lookup_addr0_i})
    ,.resp_v_o(resp_v_o), .resp_ready_i(resp_ready_i), .resp_hit_o(resp_hit_o), .resp_data_o({resp_data1_o,resp_data0_o})
    ,.insert_v_i(insert_v_i), .insert_ready_o(insert_ready_o), .insert_addr_i({insert_addr1_i,insert_addr0_i})
    ,.insert_data_i({insert_data1_i,insert_data0_i}), .insert_replace_i(insert_replace_i), .insert_cancel_i(insert_cancel_i)
    ,.insert_done_o(insert_done_o), .insert_published_o(insert_published_o), .busy_o(busy_o), .epoch_wrap_o(epoch_wrap_o));
  assign debug_data_v_o = dut.data_v;
  assign debug_data_w_o = dut.data_w;
  assign debug_word0_o = dut.data_addr[0][2:0];
  assign debug_word1_o = dut.data_addr[1][2:0];
  logic [1:0] ref_lookup_ready_o;
  logic [1:0] ref_resp_v_o;
  logic [1:0] ref_resp_hit_o;
  logic [511:0] ref_resp_data0_o;
  logic [511:0] ref_resp_data1_o;
  logic [1:0] ref_insert_ready_o;
  logic [1:0] ref_insert_done_o;
  logic [1:0] ref_insert_published_o;
  logic [1:0] ref_busy_o;
  logic [1:0] ref_epoch_wrap_o;
  bp_retained_line_store_before
   #(.paddr_width_p(34), .sets_p(64), .i_lines_p(I_LINES), .d_lines_p(D_LINES), .epoch_width_p(2)) reference
   (.clk_i(clk_i), .reset_i(reset_i), .clear_i(clear_i)
    ,.invalidate_v_i(invalidate_v_i), .invalidate_addr_i({invalidate_addr1_i,invalidate_addr0_i})
    ,.lookup_v_i(lookup_v_i), .lookup_ready_o(ref_lookup_ready_o), .lookup_addr_i({lookup_addr1_i,lookup_addr0_i})
    ,.resp_v_o(ref_resp_v_o), .resp_ready_i(resp_ready_i), .resp_hit_o(ref_resp_hit_o), .resp_data_o({ref_resp_data1_o,ref_resp_data0_o})
    ,.insert_v_i(insert_v_i), .insert_ready_o(ref_insert_ready_o), .insert_addr_i({insert_addr1_i,insert_addr0_i})
    ,.insert_data_i({insert_data1_i,insert_data0_i}), .insert_replace_i(insert_replace_i), .insert_cancel_i(insert_cancel_i)
    ,.insert_done_o(ref_insert_done_o), .insert_published_o(ref_insert_published_o), .busy_o(ref_busy_o), .epoch_wrap_o(ref_epoch_wrap_o));
  assign equivalence_mismatch_o =
    (lookup_ready_o != ref_lookup_ready_o)
    | (resp_v_o != ref_resp_v_o)
    | (resp_hit_o != ref_resp_hit_o)
    | (insert_ready_o != ref_insert_ready_o)
    | (insert_done_o != ref_insert_done_o)
    | (insert_published_o != ref_insert_published_o)
    | (busy_o != ref_busy_o)
    | (epoch_wrap_o != ref_epoch_wrap_o)
    | (resp_v_o[0] && resp_hit_o[0] && (resp_data0_o != ref_resp_data0_o))
    | (resp_v_o[1] && resp_hit_o[1] && (resp_data1_o != ref_resp_data1_o))
    | (dut.tag_v != reference.tag_v)
    | (dut.tag_w != reference.tag_w)
    | (dut.data_v != reference.data_v)
    | (dut.data_w != reference.data_w)
    | (dut.tag_v[0] && (dut.tag_addr[0] != reference.tag_addr[0]))
    | (dut.tag_v[0] && dut.tag_w[0] && (dut.tag_wdata[0] != reference.tag_wdata[0]))
    | (dut.data_v[0] && (dut.data_addr[0] != reference.data_addr[0]))
    | (dut.data_v[0] && dut.data_w[0] && (dut.data_wdata[0] != reference.data_wdata[0]))
    | (dut.tag_v[1] && (dut.tag_addr[1] != reference.tag_addr[1]))
    | (dut.tag_v[1] && dut.tag_w[1] && (dut.tag_wdata[1] != reference.tag_wdata[1]))
    | (dut.data_v[1] && (dut.data_addr[1] != reference.data_addr[1]))
    | (dut.data_v[1] && dut.data_w[1] && (dut.data_wdata[1] != reference.data_wdata[1]));
endmodule
