#!/usr/bin/env python3
"""Finite source-bound SP N40/N200 correctness acquisition; defaults to dry run."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import sys
import time
import resource

sys.dont_write_bytecode=True
GIB=1024**3
ROOT=Path('/home/coyang/zynq-parrot-retained-sp')
NATIVE=Path('/home/coyang/fpga-artifacts/context-resume/retained-private-sp-ram-20261121/full01')
BASE=Path('/home/coyang/fpga-artifacts/context-resume/retained-sp-latency-preparation-20261121')
HERE=Path(__file__).resolve().parent


def bind(path,metadata=False):
    path=Path(path).resolve();h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    s=path.stat();r=dict(path=str(path),bytes=s.st_size,sha256=h.hexdigest())
    if metadata:r.update(inode=s.st_ino,ctime_ns=s.st_ctime_ns,mtime_ns=s.st_mtime_ns)
    return r


def write(path,value):
    temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(path)


def git(path,*args):return subprocess.check_output(['git','-C',str(path),*args],text=True,timeout=20).strip()


def require(ok,message):
    if not ok:raise ValueError(message)


def stage_bytes(roots):
    total=0
    for root in roots:
        if not root.exists():continue
        for folder,dirs,files in os.walk(root,followlinks=False):
            for p in [Path(folder)]+[Path(folder)/n for n in files+dirs]:
                s=p.lstat()
                # Directory blocks are included once, when visited below.
                if p!=Path(folder) and stat.S_ISDIR(s.st_mode):continue
                total+=max(s.st_size,s.st_blocks*512)
    return total


def validate(admission):
    for expected in admission['bindings']:
        require(bind(expected['path'],'inode' in expected)==expected,'pinned input changed: '+expected['path'])
    for repo in admission['repositories']:
        path=Path(repo['path'])
        require((path/'.git').is_file() and git(path,'rev-parse','--show-toplevel')==str(path),'real source worktree')
        require(git(path,'rev-parse','HEAD')==repo['head'] and not git(path,'status','--porcelain'),'source repository changed '+str(path))


class Acquisition:
    def __init__(self,a,admission_hash):
        self.a=a;self.journal=Path(a['journal']);self.roots=[self.journal]+[Path(c['output']) for c in a['cases']]
        require(all(not p.exists() for p in self.roots),'fresh outputs required; no resume or retry')
        self.record=dict(state='PREPARED',admission=bind(HERE/'launch-admission.json'),admission_sha256=admission_hash,
            budget=a['budget'],commands=[],phases=[],models={},physical_operations=0)
        require(self.record['admission']['sha256']==admission_hash,'admission changed during entry')
        self.active=None

    def guard(self,label):
        used=stage_bytes(self.roots);free=shutil.disk_usage(BASE).free
        remaining=self.a['budget']['stage_bytes']-used
        snap=dict(label=label,used_bytes=used,free_bytes=free,remaining_stage_bytes=remaining,
                  reserve_headroom_bytes=free-remaining-self.a['budget']['reserve_bytes'])
        self.record['last_resource_check']=snap
        require(remaining>=0,'3GiB added-stage cap exceeded')
        require(free>=self.a['budget']['reserve_bytes'],'less than3GiB free reserve')
        require(snap['reserve_headroom_bytes']>=0,'remaining stage allocation would consume3GiB reserve')
        return snap

    def save(self):write(self.journal/'session.json',self.record)

    def phase(self,label):
        require(bind(HERE/'launch-admission.json')==self.record['admission'],'admission changed during acquisition')
        validate(self.a)
        snap=self.guard(label);self.record['phases'].append(snap);self.record['state']=label;self.save()

    @staticmethod
    def group_exists(pgid):
        try:os.killpg(pgid,0);return True
        except ProcessLookupError:return False

    @staticmethod
    def reap_adopted(pgid):
        while True:
            try:
                pid,_=os.waitpid(-pgid,os.WNOHANG)
                if pid==0:return
            except ChildProcessError:return

    def stop_owned(self,p):
        # Never signal another session or any board/farm process.
        for sig in (signal.SIGTERM,signal.SIGKILL):
            if self.group_exists(p.pid):
                try:os.killpg(p.pid,sig)
                except ProcessLookupError:pass
            try:p.wait(timeout=5)
            except subprocess.TimeoutExpired:continue
            until=time.monotonic()+5
            while time.monotonic()<until:
                self.reap_adopted(p.pid)
                if not self.group_exists(p.pid):return
                time.sleep(.05)
        p.wait(timeout=5);self.reap_adopted(p.pid)
        require(not self.group_exists(p.pid),'owned process group did not terminate/reap')

    def run(self,label,argv,cwd,timeout,allow_nonzero=False,file_cap=2*GIB):
        self.phase(label)
        entry=dict(label=label,argv=list(map(str,argv)),cwd=str(cwd),timeout_seconds=timeout,file_cap_bytes=file_cap)
        self.record['commands'].append(entry);self.save()
        log=self.journal/(label+'.log');start=time.monotonic();p=None
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',LD_LIBRARY_PATH=self.a['LD_LIBRARY_PATH'],TMPDIR=str(self.journal/'tmp'))
        for key in list(env):
            if key.startswith(('BP_RETAINED_','BP_AXI_RESPONSE_DELAY')):env.pop(key)
        def limits():
            resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_FSIZE,(file_cap,file_cap))
        try:
            with log.open('wb') as stream:
                p=subprocess.Popen(entry['argv'],cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,
                    start_new_session=True,preexec_fn=limits)
                self.active=p;entry['pid']=p.pid
                while p.poll() is None:
                    snap=self.guard(label+' monitor')
                    entry['max_stage_bytes']=max(entry.get('max_stage_bytes',0),snap['used_bytes'])
                    entry['min_free_bytes']=min(entry.get('min_free_bytes',snap['free_bytes']),snap['free_bytes'])
                    entry['min_reserve_headroom_bytes']=min(entry.get('min_reserve_headroom_bytes',snap['reserve_headroom_bytes']),snap['reserve_headroom_bytes'])
                    require(time.monotonic()-start<timeout,label+' fixed outer timeout')
                    time.sleep(.25)
                entry['returncode']=p.wait()
                self.reap_adopted(p.pid)
                require(not self.group_exists(p.pid),'child exited with live/zombie descendants: '+label)
            self.guard(label+' completed')
            require(allow_nonzero or entry['returncode']==0,label+' command failed')
            return entry['returncode'],log
        finally:
            if p is not None:
                if p.poll() is None or self.group_exists(p.pid):self.stop_owned(p)
                if p.returncode is not None:entry['returncode']=p.returncode
            self.active=None;entry['elapsed_seconds']=time.monotonic()-start
            if log.exists():entry['log']=bind(log)
            self.save()

    def build(self,case):
        n=case['delay'];out=Path(case['output']);self.phase(f'N{n} create fresh model paths')
        out.mkdir();runtime=out/'verilator';runtime.mkdir()
        (out/'Makefile.design').symlink_to(ROOT/'cosim/black-parrot-example/Makefile.design')
        prefix=case['command_prefix']
        _,log=self.run(f'N{n}-make-preflight',prefix+['-n','build'],runtime,120)
        dry=log.read_text()
        for k,v in case['flags'].items():require(k+'='+str(v) in dry,'actual flag missing '+k)
        self.run(f'N{n}-clean',prefix+['clean'],runtime,120)
        self.run(f'N{n}-build',prefix+['build'],runtime,3600)
        self.phase(f'N{n} verify actual source ingestion and model stamp')
        metadata=runtime/'obj_dir/Vbsg_nonsynth_zynq_testbench__verFiles.dat';actual={}
        for line in metadata.read_text().splitlines():
            m=re.fullmatch(r'S\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+"([^"]+)"',line)
            if not m:continue
            size,inode,cs,cn,ms,mn=map(int,m.groups()[:6]);p=Path(m[7]);p=p if p.is_absolute() else runtime/p
            b=bind(p,True)
            require((b['bytes'],b['inode'],b['ctime_ns'],b['mtime_ns'])==(size,inode,cs*10**9+cn,ms*10**9+mn),'ingestion metadata mismatch '+str(p))
            actual[str(p.resolve())]=b
        for r in self.a['critical_RTL']:
            require(r['path'] in actual and actual[r['path']]['sha256']==r['sha256'],'critical RTL not consumed unchanged')
        stamps=list((runtime/'obj_dir').glob('.build_config-*'))
        wanted=self.a['native_model_stamp_name'].replace('BP_AXI_RESPONSE_DELAY_0',f'BP_AXI_RESPONSE_DELAY_{n}')
        require(len(stamps)==1 and stamps[0].name==wanted,'wrong exact model configuration stamp')
        write(out/'actual-source-list.json',dict(sources=actual,metadata=bind(metadata)))
        model=runtime/'obj_dir/Vbsg_nonsynth_zynq_testbench'
        self.record['models'][str(n)]=dict(model=bind(model,True),stamp=bind(stamps[0]),source_list=bind(out/'actual-source-list.json'))
        _,log=self.run(f'N{n}-loader',['ldd',model],out,30)
        require('not found' not in log.read_text(),'unresolved loader dependency')
        return out,model

    def program(self,n,out,model,name):
        self.phase(f'N{n} {name} prepare unchanged file-backed program')
        require(bind(model,True)==self.record['models'][str(n)]['model'],'model changed before runtime')
        target=out/name;target.mkdir()
        for key,suffix in [('elf','riscv'),('nbf','nbf')]:
            r=self.a['programs'][name][key];require(bind(r['path'])==r,'program drift')
            shutil.copyfile(r['path'],target/('prog.'+suffix))
        native,outer=(600000,780) if name=='integrity' else (180000,240)
        argv=[model,'+c_args=prog.nbf '+str(native),'+bsg_trace='+str(target/'trace.fst')]
        write(target/'admission.json',dict(model=self.record['models'][str(n)]['model'],native_host_runtime_ms_after_loader=native,
            outer_seconds_including_loader=outer,FST_cap_bytes=256*1024**2,argv=list(map(str,argv)),programs=self.a['programs'][name],delay=n))
        rc,log=self.run(f'N{n}-{name}-run',argv,target,outer,True,256*1024**2)
        require(bind(model,True)==self.record['models'][str(n)]['model'],'model changed during runtime')
        shutil.copyfile(log,target/'run.log');write(target/'process.json',dict(returncode=rc))
        check=['python3','-B',ROOT/'testing/check_run.py',target/'run.log','--exit-code',str(rc)]
        if name=='integrity':check+=['--test','mt_large_retained_system_test']
        self.run(f'N{n}-{name}-checker',check,out,60)
        text=log.read_text();require(text.count('Verilator assertion setting restored to 1')==1,'runtime assertion scope missing')
        rows=None
        if name=='advisory':
            marker='[BSG-PASS] retained advisory full-line I/D checked all words completed'
            require(text.count(marker)==1 and text.index(marker)<text.index('CORE PASS'),'advisory completion missing')
            rows=re.findall(r'RETAINED_USE_COUNTERS version=1 i_hits=(\d+) d_hits=(\d+) i_published=(\d+) d_published=(\d+) i_write_beats=(\d+) d_write_beats=(\d+) saturating_bits=16 reset=axi_only',text)
            require(len(rows)==1 and tuple(map(int,rows[0]))==(1,1,1,1,8,8),'GP0 actual counters')
        state='PASS complete scoped wholecore and actual GP0 1hit/1publish/8writes per lane; strict closed trace audit pending' if name=='advisory' else 'PASS-complete-checked-system-1280-scoped-assertions'
        write(target/'verification.json',dict(state=state,actual_returncode=rc,known_postPASS_GPIO_exception=rc!=0,
            counter_values=rows[0] if rows else None,trace=bind(target/'trace.fst'),
            files=[bind(target/p,True) for p in ('admission.json','process.json','run.log','prog.riscv','prog.nbf','trace.fst')]))
        return rc

    def hp0(self,n,out,name,proof=None):
        source=out/'actual-source-list.json';target=out/name;rc=json.loads((target/'process.json').read_text())['returncode']
        dest=self.journal/f'N{n}-{name}-HP0'
        argv=['python3','-B',self.a['HP0_auditor'],'--fst',target/'trace.fst','--model-source-list',source,
            '--log',target/'run.log','--exit-code',str(rc),'--delay',str(n),'--out',dest]
        if proof:argv+=['--proof',proof]
        self.run(f'N{n}-{name}-HP0',argv,self.journal,900)
        result=json.loads((dest/'verification.json').read_text())
        require(result['accepted'] and result['static_response_beat_minimum_age_cycles']==n,'same-run HP0 audit rejected')

    def audits(self,n,out):
        strict=out/'advisory-strict01';counter=out/'advisory-counter01';target=out/'advisory'
        rc=json.loads((target/'process.json').read_text())['returncode']
        self.run(f'N{n}-strict',['python3','-B',ROOT/'testing/rtl/retained-advisory-trace/validate.py',
            '--fst',target/'trace.fst','--reader',self.a['reader'],'--model-source-list',out/'actual-source-list.json',
            '--fixture-manifest',self.a['fixture_manifest'],'--log',target/'run.log','--exit-code',str(rc),'--out',strict],out,780)
        require(json.loads((strict/'verification.json').read_text())['accepted'],'strict payload proof rejected')
        self.run(f'N{n}-counter',['python3','-B',ROOT/'research/retained-use-observation-20261121/verify_counters.py',
            '--fst',target/'trace.fst','--reader',self.a['reader'],'--strict-proof',strict/'verification.json',
            '--run-proof',target/'verification.json','--out',counter],out,240)
        require(json.loads((counter/'verification.json').read_text())['firsttouch_counts']=={'i':[1,1,8],'d':[1,1,8]},'counter audit rejected')
        self.phase(f'N{n} actual generated L2 geometry')
        # Reuse unchanged source-bound elaboration inspection, without its CLI.
        import importlib.util
        path=ROOT/'research/retained-maintenance-acyclic-20261121/bind_geometry.py'
        spec=importlib.util.spec_from_file_location('geometry',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        # The inspector accepts the native recipe's session schema.
        write(out/'session.json',dict(model=self.record['models'][str(n)]['model'],actual_source_list=bind(out/'actual-source-list.json')))
        facts,headers=module.inspect(out,self.record['models'][str(n)]['model']['sha256'])
        require(facts['l2']==dict(slices=1,banks=2,sets_per_bank=64,ways=2,line_bytes=64,data_bytes_per_bank=8192,total_bytes=16384),'actual L2 geometry differs')
        obj=out/'verilator/obj_dir';root_header=obj/'Vbsg_nonsynth_zynq_testbench___024root.h';text=root_header.read_text()
        i_mem=re.findall(r'VlUnpacked<QData/\*63:0\*/, 512> [^\n]*__DOT__icache__DOT__data_mems__BRA__(\d+)__KET____DOT__data_mem__DOT__synth__DOT__nz__DOT__mem;',text)
        require(sorted(map(int,i_mem))==list(range(8)),'actual I32KiB payload geometry')
        d_mem=re.findall(r'^\s*(\w+)\* [^\n]*__DOT__dcache__DOT__d__BRA__(\d+)__KET____DOT__data_mem__DOT__synth__DOT__nz__DOT__bk__BRA__(\d+)__KET____DOT__mem_1rw_sync;',text,re.M)
        require(len(d_mem)==64 and {(int(i),int(j)) for _,i,j in d_mem}=={(i,j) for i in range(8) for j in range(8)} and len({kind for kind,_,_ in d_mem})==1,'actual D64 byte RAMs')
        d_header=obj/(d_mem[0][0]+'.h')
        require('VlUnpacked<CData/*7:0*/, 512> __PVT__synth__DOT__nz__DOT__mem;' in d_header.read_text(),'actual D32KiB payload geometry')
        for lane in ('icache','dcache'):
            require(len(re.findall(r'VlUnpacked<[^\n]*, 64> [^\n]*__DOT__'+lane+r'__DOT__tag_mem__DOT__synth__DOT__nz__DOT__mem;',text))==1,'actual64-set L1 tag RAM '+lane)
        write(out/'geometry.json',dict(state='PASS actual generated static16KiB L2 and ordinary32KiB L1I/D',facts=facts,
            L1_payload_bytes=dict(i=8*512*8,d=64*512),L1_sets=64,headers=[bind(p) for p in headers+[d_header]]))
        self.hp0(n,out,'integrity');self.hp0(n,out,'advisory',strict/'verification.json')

    def execute(self):
        self.guard('launch allocation admission');self.journal.mkdir()
        (self.journal/'tmp').mkdir()
        self.save()
        try:
            libc=ctypes.CDLL(None,use_errno=True)
            require(libc.prctl(36,1,0,0,0)==0,'cannot become own-child subreaper')
            for case in self.a['cases']:
                n=case['delay'];out,model=self.build(case)
                self.program(n,out,model,'integrity');self.program(n,out,model,'advisory');self.audits(n,out)
                require(bind(model,True)==self.record['models'][str(n)]['model'],'model changed during acquisition')
                self.record.setdefault('completed_delays',[]).append(n);self.save()
            self.hp0(0,NATIVE,'integrity')
            self.hp0(0,NATIVE,'advisory',NATIVE/'advisory-strict01/verification.json')
            self.phase('PASS all fixed N40/N200 execution and same-run transport/correctness gates')
            self.record['state']='PASS fixed SP N40/N200 correctness only; no application/FPGA claim'
        except BaseException as e:
            self.record.update(state='FAIL preserved; no retry or continuation',error=repr(e));raise
        finally:
            if self.active is not None:self.stop_owned(self.active)
            self.save()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--admission-sha256',required=True)
    p.add_argument('--execute',action='store_true',help='requires separate root launch instruction; absent means static dry run')
    args=p.parse_args();path=HERE/'launch-admission.json'
    require(bind(path)['sha256']==args.admission_sha256,'exact reviewed admission SHA required')
    a=json.loads(path.read_text());validate(a)
    require(a['budget']==dict(stage_bytes=3*GIB,reserve_bytes=3*GIB,runtime_FST_bytes=256*1024**2,monitor_period_seconds=.25),'fixed chosen budget')
    acq=Acquisition(a,args.admission_sha256);sample=acq.guard('static dry run allocation check')
    if not args.execute:
        print(json.dumps(dict(state='STATIC DRY RUN PASS; no output paths created, Make or target commands run',resource_check=sample,
            commands=a['cases'],admission=bind(path),source_worktree_clean=True),indent=2));return
    signal.signal(signal.SIGTERM,lambda *_:(_ for _ in ()).throw(RuntimeError('acquisition SIGTERM; stop own child only')))
    acq.execute()


if __name__=='__main__':main()
