This completes only the three remaining maintained checkers for one already-completed b912 observation-clone target. It does not rerun or rebuild a model. Original attempt01 remains FAIL: the old script location resolved a different compiled-source root. All five literal domains and native guest/CORE/counter/terminal checks had completed before that infrastructure failure.

complete_host.py inherits exact31300 admission, failed supervision/source receipt, untouched b912 relink, only Syms archive mutation, all414 registration calls, exact model/source archives, closed758542B FST and five byte-identical complete event streams. It requires the correct newROOT strict/counter/geometry scripts to be byte-identical to the maintained scripts. Source, old build/native/literal records and original failure stay immutable.

Root prepare (read-only inheritance/source/archive checks, no checkers):
PYTHONDONTWRITEBYTECODE=1 python3 -B /home/coyang/fpga-artifacts/context-resume/retained-canonical-scoped-completion-20261121/complete_host.py --prepare-only

After reviewing the generated admission hash, root execute:
PYTHONDONTWRITEBYTECODE=1 python3 -B /home/coyang/fpga-artifacts/context-resume/retained-canonical-scoped-completion-20261121/complete_host.py --execute --approval-sha ADMISSION_SHA

Only strict, observer and geometry commands exist in this driver. They use the same closed raw FST/runtime proof, fresh RAM completion outputs, and the source scripts under /dev/shm/zp-linux-canonical-fulltop-20261121-01. The fixed combined old+new artifact limits remain512MiB RAM/64MiB HOME,1GiB RAM/3GiB HOME reserve plus remaining allocation, strict720s (reader600), observer300s, geometry660s. A single owned worker group is terminated/reaped on failure/exit. No retry or extension. No compiler, linker, target, vendor, board or network action is available. Final PASS is composite and keeps the original failed attempt explicit.
