#!/usr/bin/env python3
"""Complete only the three remaining checkers on one preserved observation trace.

No model, compiler, linker, elaborator, vendor tool, network or board command.
"""
import argparse
import hashlib
import gzip
import tarfile
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
OLD=Path('/home/coyang/fpga-artifacts/context-resume/retained-canonical-scoped-20261121')
sys.path.insert(0,str(OLD/'helper'))
import host_flow as h
from canonical import equivalent
from common import bind,verify,require,save,MODEL_SHA,ORIGINAL,ARTIFACT_ALLOCATION,RESERVE
STAGE=Path('/dev/shm/zp-retained-canonical-scoped-completion-20261121-02')
ADMISSION=ROOT/'admission.json'
TOP=Path('/dev/shm/zp-linux-canonical-fulltop-20261121-01')
SCRIPTS={'strict':TOP/'testing/rtl/retained-advisory-trace/validate.py',
 'observer':TOP/'research/retained-use-observation-20261121/verify_counters.py',
 'geometry':TOP/'research/retained-dense-fullcore-20261121/geometry.py'}
OLD_SCRIPTS={key:h.SP/path.relative_to(TOP) for key,path in SCRIPTS.items()}


def used(path):return sum(p.stat().st_size for p in path.rglob('*') if p.is_file()) if path.exists() else 0

def guard():
    ram=used(h.STAGE)+used(STAGE);home=used(OLD)+used(ROOT)
    require(ram<=ARTIFACT_ALLOCATION and shutil.disk_usage('/dev/shm').free>=RESERVE+ARTIFACT_ALLOCATION-ram,'combined512MiB RAM/1GiB remaining reserve')
    require(home<=h.HOME_CAP and shutil.disk_usage(ROOT).free>=3*1024**3+h.HOME_CAP-home,'combined64MiB HOME/3GiB remaining reserve')


def inherit():
    require(bind(OLD/'admission.json')['sha256']=='31300f4846bba35676c1579398242d39643544710d6c137d737a28a8b6e31f5c','exact failed attempt admission')
    a=json.loads((OLD/'admission.json').read_text());p=h.validate(a)
    supervisor=json.loads((OLD/'host-supervision.json').read_text())
    require(supervisor['state']=='FAIL-preserved-no-retry','preserve actual failed attempt')
    q=json.loads((h.STAGE/'qualification01/qualification.json').read_text())
    build=json.loads((h.STAGE/'build/evidence/build.json').read_text())
    require(q['state']=='COMPLETE-cold08-awaiting-five-domain-and-maintained-checkers','native complete prerequisite')
    require(q['admission']==bind(OLD/'admission.json') and q['guest']==a['reference']['guest'],'same complete guest/CORE/counter/terminal record')
    require(set(q['domains'])==set(p['domains'])==set(a['original_canonical']) and len(q['domains'])==5,'all five literal domains required')
    verify(q['trace']);require(q['trace']['bytes']==758542,'exact closed failed-attempt trace')
    for name,row in q['domains'].items():
        require(row['literal_bytes_equal'] is True and row['reference']==a['original_canonical'][name],'immutable literal reference')
        verify(row['reference']['canonical_file']);verify(row['clone']['canonical_file']);equivalent(row['reference'],row['clone'])
    require(build['baseline_relink']['sha256']==build['original_model']['sha256']==MODEL_SHA,'untouched b912 relink')
    require(build['original_members']==p['archive_members'] and list(build['original_members'])==list(build['final_members']),'archive inventory')
    require([n for n in build['original_members'] if build['original_members'][n]!=build['final_members'][n]]==[h.SYMS+'.o'],'only copied Syms archive member changed')
    initial,final=build['initial_copy'],build['final_copy']
    require(set(initial)==set(final)==set(p['required_copy']),'copied inventory names')
    changes=[n for n in initial if (initial[n]['bytes'],initial[n]['sha256'])!=(final[n]['bytes'],final[n]['sha256'])]
    require(set(changes)==set(build['changed_files']) and set(changes)<={h.PREFIX,h.PREFIX+'__ALL.a',h.SYMS+'.cpp',h.SYMS+'.o',h.SYMS+'.d'},'only permitted copied files changed')
    for name in initial:
        require(all(initial[name][k]==p['required_copy'][name][k] for k in ('bytes','sha256')),'initial copied identity')
    for record in final.values():verify(record)
    expected,_=h.filtered_source(Path(p['required_copy'][h.SYMS+'.cpp']['path']).read_text(),p['writer_leaves'])
    require(Path(final[h.SYMS+'.cpp']['path']).read_text()==expected,'exact414 registration-only source change')
    archived=json.loads((OLD/'closed01/archive.json').read_text())
    for key in ('gzip','copied_source_archive','qualified_rawFST'):verify(archived[key])
    require(hashlib.sha256(gzip.decompress(Path(archived['gzip']['path']).read_bytes())).hexdigest()==build['binary']['sha256'],'durable modelgzip identity')
    require(archived['qualified_rawFST']['sha256']==q['trace']['sha256'],'durable closed rawFST identity')
    expected_members={'obj/'+name:record for name,record in initial.items() if name.endswith('.h')}
    expected_members['obj/'+h.SYMS+'.cpp']=final[h.SYMS+'.cpp']
    with tarfile.open(archived['copied_source_archive']['path'],'r:gz') as tar:
        require({m.name for m in tar.getmembers()}==set(expected_members) and len(tar.getmembers())==len(expected_members),'durable copied-source member inventory')
        for name,record in expected_members.items():
            raw=tar.extractfile(name).read()
            require(len(raw)==record['bytes'] and hashlib.sha256(raw).hexdigest()==record['sha256'],'durable copied-source identity')
    runtime=h.STAGE/'qualification01/runtime'
    proof=json.loads((runtime/'verification.json').read_text())
    for record in proof['files']:
        require(all(bind(record['path'])[k]==record[k] for k in ('bytes','sha256')),'closed runtime file drift')
    require(proof['actual_returncode']==a['reference']['returncode'],'actual native return scope')
    for key,path in SCRIPTS.items():
        require(path.is_file() and bind(path)['sha256']==bind(OLD_SCRIPTS[key])['sha256'],'byte-identical maintained checker with correct newROOT')
    require(bind(TOP/'research/retained-use-observation-20261121/build_full.py')['sha256']==bind(h.SP/'research/retained-use-observation-20261121/build_full.py')['sha256'],'counter transitive binding helper identity')
    require((h.STAGE/'qualification01/strict.log').read_text().find('compiled/source mismatch')>=0,'original checker-root failure provenance')
    return a,p,q,build


def records():
    a,p,q,b=inherit()
    paths=[Path(__file__),OLD/'admission.json',OLD/'host-supervision.json',h.STAGE/'flow.json',
      h.STAGE/'build/evidence/build.json',h.STAGE/'qualification01/qualification.json',h.STAGE/'qualification01/strict.log',
      h.STAGE/'qualification01/runtime/verification.json',Path(q['trace']['path']),*SCRIPTS.values(),
      TOP/'research/retained-use-observation-20261121/build_full.py',OLD/'helper/host_flow.py',OLD/'closed01/archive.json',OLD/'failed01/preservation.json']
    return [bind(path) for path in paths]


def check_admission(a,sha):
    require(bind(ADMISSION)['sha256']==sha,'frozen completion admission')
    require(a['stage']==str(STAGE) and a['schema']=='b912-trace-postprocess-completion-v1','fixed completion stage/schema')
    require(a['budget']==dict(combined_RAM_bytes=512*1024**2,combined_HOME_bytes=64*1024**2,RAM_reserve_bytes=1024**3,HOME_reserve_bytes=3*1024**3,strict_seconds=720,observer_seconds=300,geometry_seconds=660,reader_seconds=600,attempts=1),'fixed postprocess budget')
    require(a['inputs']==records(),'completion input/source/receipt drift')
    guard()


def worker(a):
    original,p,q,build=inherit();out=STAGE/'checks';out.mkdir()
    state=dict(state='RUNNING-three-checkers-only',admission=bind(ADMISSION),inherited_qualification=bind(h.STAGE/'qualification01/qualification.json'),commands=[])
    save(STAGE/'completion.json',state)
    def command(label,argv,seconds):
        guard();entry=dict(label=label,argv=list(map(str,argv)),timeout_seconds=seconds);state['commands'].append(entry);save(STAGE/'completion.json',state)
        h.command(entry['argv'],out,out/(label+'.log'),seconds);entry['returncode']=0;entry['log']=bind(out/(label+'.log'));guard()
    fst=q['trace']['path'];runtime=h.STAGE/'qualification01/runtime';rc=original['reference']['returncode']
    try:
        command('strict',[sys.executable,'-B',SCRIPTS['strict'],'--fst',fst,'--reader',p['reader']['path'],'--model-source-list',ORIGINAL/'actual-source-list.json',
          '--fixture-manifest',original['fixture_manifest']['path'],'--log',runtime/'run.log','--exit-code',str(rc),'--out',out/'strict','--reader-timeout','600'],720)
        require(json.loads((out/'strict/verification.json').read_text())['accepted'] is True,'strict full512/eight real writes/Iretire')
        command('observer',[sys.executable,'-B',SCRIPTS['observer'],'--fst',fst,'--reader',p['reader']['path'],'--strict-proof',out/'strict/verification.json',
          '--run-proof',runtime/'verification.json','--out',out/'observer'],300)
        obs=json.loads((out/'observer/verification.json').read_text());require(obs['state'].startswith('PASS actual counter transitions') and obs['firsttouch_counts']==dict(i=[1,1,8],d=[1,1,8]),'actual observer transitions')
        command('geometry',[sys.executable,'-B',SCRIPTS['geometry'],'--fst',fst,'--reader',p['reader']['path'],'--out',out/'geometry'],660)
        geo=json.loads((out/'geometry/verification.json').read_text());require(geo['facts']['clean_eof'] is True and geo['facts']['values']==original['reference']['actual_geometry'],'actual16 parameters/EOF')
        require(a['inputs']==records(),'final frozen source/native/literal receipt drift')
        state.update(state='PASS-composite-b912-native-five-literal-domains-plus-three-maintained-checkers',
          original_failure=bind(OLD/'host-supervision.json'),build=bind(h.STAGE/'build/evidence/build.json'),native_and_literals=bind(h.STAGE/'qualification01/qualification.json'),
          model=build['binary'],trace=q['trace'],strict=bind(out/'strict/verification.json'),observer=bind(out/'observer/verification.json'),geometry=bind(out/'geometry/verification.json'))
        save(STAGE/'completion.json',state)
        closed=ROOT/'closed01';closed.mkdir();shutil.copytree(out,closed/'checks');shutil.copyfile(STAGE/'completion.json',closed/'completion.json');guard()
    except BaseException as error:
        state.update(state='FAIL-preserved-postprocess-only-no-retry',error=repr(error));raise
    finally:save(STAGE/'completion.json',state)


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--prepare-only',action='store_true');ap.add_argument('--execute',action='store_true');ap.add_argument('--worker',action='store_true');ap.add_argument('--approval-sha');args=ap.parse_args()
    require(sum([args.prepare_only,args.execute,args.worker])==1,'one explicit action')
    if args.prepare_only:
        require(not ADMISSION.exists(),'fresh admission only');guard();inputs=records()
        save(ADMISSION,dict(schema='b912-trace-postprocess-completion-v1',state='PREPARED-HOLD-root-command-review',stage=str(STAGE),inputs=inputs,
          budget=dict(combined_RAM_bytes=512*1024**2,combined_HOME_bytes=64*1024**2,RAM_reserve_bytes=1024**3,HOME_reserve_bytes=3*1024**3,strict_seconds=720,observer_seconds=300,geometry_seconds=660,reader_seconds=600,attempts=1),
          scope='Only remaining strict/counter/geometry, newROOT byte-identical checker scripts. No build/relink/target repeat; failedattempt01 remains failed.'))
        print(bind(ADMISSION));return
    a=json.loads(ADMISSION.read_text());check_admission(a,args.approval_sha)
    if args.worker:
        require(os.getpgrp()==os.getpid(),'owned worker PG');worker(a);return
    require(not STAGE.exists() and not (ROOT/'host-supervision.json').exists(),'fresh one-shot completion')
    STAGE.mkdir();state=dict(state='RUNNING-owned-three-checker-completion-only',admission=bind(ADMISSION),stage=str(STAGE));proc=None
    try:
        with (STAGE/'worker.log').open('wb') as log:
            proc=subprocess.Popen([sys.executable,'-B',str(Path(__file__).resolve()),'--worker','--approval-sha',args.approval_sha],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            state.update(owned_pid=proc.pid,owned_process_group=proc.pid);save(ROOT/'host-supervision.json',state)
            while proc.poll() is None:guard();time.sleep(1)
        require(proc.returncode==0,'postprocess worker failed')
        check_admission(a,args.approval_sha);state.update(state='PASS-owned-postprocess-only-completion',returncode=0,completion=bind(STAGE/'completion.json'));guard()
    except BaseException as error:state.update(state='FAIL-preserved-postprocess-only-no-retry',error=repr(error));raise
    finally:
        if proc is not None:h.terminate_owned_group(proc)
        save(ROOT/'host-supervision.json',state);print(state['state'],flush=True)

if __name__=='__main__':
    def interrupted(signum,frame):raise KeyboardInterrupt('postprocess supervisor interrupted')
    signal.signal(signal.SIGTERM,interrupted);main()
