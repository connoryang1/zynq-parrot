#!/usr/bin/env python3
"""Read-only verification of compact returned dense scoped qualification artifacts.

No model/reader/board launch. RAM bindings are mapped to their exact archived
relative names; raw FST is intentionally unavailable and is not reparsed here.
"""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import tarfile

BASE=Path('/home/coyang/fpga-artifacts/context-resume/retained-canonical-scoped-20261121')
STAGE=Path('/dev/shm/zp-retained-canonical-scoped-20261121-01')
POST=Path('/home/coyang/fpga-artifacts/context-resume/retained-canonical-scoped-completion-20261121')
POST_STAGE=Path('/dev/shm/zp-retained-canonical-scoped-completion-20261121-02')
SOURCE=Path('/dev/shm/zp-linux-canonical-fulltop-20261121-01')
OLD_SOURCE=Path('/home/coyang/zynq-parrot-retained-dense')
POST_ADMISSION='04a3b0adc71e8a87eab61734f403852b2ce4785da4444331ca2fc7b3e385db89'
MODEL='Vbsg_nonsynth_zynq_testbench';SYMS=MODEL+'__Syms'
ADMISSION='31300f4846bba35676c1579398242d39643544710d6c137d737a28a8b6e31f5c'
ORIGINAL='b912913adc5fa98a0675bd323e7b37da7cbaecdabbb787ca3f466edcc4851de9'
DRIVER='2f9570c46783c934e478faed4801cbffd050406b2057f94290c6e919214200b6'


def require(ok,message):
    if not ok:raise ValueError(message)


def digest(stream):
    sha=hashlib.sha256();size=0
    for block in iter(lambda:stream.read(1024**2),b''):sha.update(block);size+=len(block)
    return dict(bytes=size,sha256=sha.hexdigest())


def identity(record):return {k:record[k] for k in ('bytes','sha256')}


def bind(path):
    with Path(path).open('rb') as stream:result=digest(stream)
    return dict(path=str(Path(path).resolve()),**result)


def returned(record,base):
    path=Path(record['path'])
    require(path.is_absolute() and '..' not in path.parts,'noncanonical binding path')
    if SOURCE in path.parents:return OLD_SOURCE/path.relative_to(SOURCE)
    if POST_STAGE in path.parents:return POST/'closed01'/path.relative_to(POST_STAGE)
    try:relative=path.relative_to(STAGE)
    except ValueError:return path
    if str(relative)=='qualification01/runtime/trace.fst':return base/'closed01/qualification-trace.fst'
    return base/'closed01'/relative


def verify_binding(record,base):
    path=returned(record,base)
    require(identity(bind(path))==identity(record),'returned binding differs: '+str(path));return path


def json_file(path):return json.loads(Path(path).read_text())


def literal(reference,selected,base):
    for key in ('sha256','events','changes_by_index','first_tick','final_tick','timescale','clean_EOF'):
        require(reference[key]==selected[key],'canonical stats differ: '+key)
    require(reference['clean_EOF'] is True,'no clean canonical EOF')
    a=verify_binding(reference['canonical_file'],base);b=verify_binding(selected['canonical_file'],base)
    sha=hashlib.sha256();size=0
    with gzip.open(a,'rb') as left,gzip.open(b,'rb') as right:
        while True:
            first,second=left.read(1024**2),right.read(1024**2)
            require(first==second,'literal selected bytes differ')
            if not first:break
            sha.update(first);size+=len(first)
    require(sha.hexdigest()==reference['sha256'],'canonical content digest differs from record')
    return dict(events=reference['events'],literal_bytes=size,sha256=sha.hexdigest(),clean_EOF=True)


def source_archive(path,initial,filtered_record):
    expected={'obj/'+name:identity(r) for name,r in initial.items() if name.endswith('.h')}
    expected['obj/'+SYMS+'.cpp']=identity(filtered_record)
    with tarfile.open(path,'r:gz') as archive:
        members=archive.getmembers()
        require(len(members)==len(expected) and len({m.name for m in members})==len(members),'source archive duplicate/extra/missing member')
        require({m.name for m in members}==set(expected),'source archive names differ')
        for member in members:
            require(member.isfile(),'source archive link/directory not permitted')
            with archive.extractfile(member) as stream:
                require(digest(stream)==expected[member.name],'source archive bytes differ: '+member.name)
    return len(expected)


def capacity_contract(p,listing,base):
    require(len(p['writer_leaves'])==414 and len(p['domains'])==5 and len(p['domains']['capacity167'])==167,'414/five/167 domain counts differ')
    raw_rows=[r for r in p['writer_leaves'] if r['path'].endswith('.unicore_lite.dcache_retained_maintenance_v')]
    require(len(raw_rows)==1,'exact raw maintenance leaf')
    raw=raw_rows[0]
    require(raw['width']==1 and raw['path'].endswith('.unicore_lite.dcache_retained_maintenance_v'),'raw maintenance binding differs')
    schema=json_file(verify_binding(p['capacity_schema'],base))
    require(p['capacity_schema']['sha256']=='60127818144df33e34bf3dc998ca317fac67cbefaf53784123836af8ba08c78e','capacity167 schema differs')
    for row in schema['leaves']:
        matches=[r for r in p['domains']['capacity167'] if r['path'].endswith('.'+row['suffix'])]
        require(len(matches)==1 and matches[0]['width']==row['width'],'capacity167 exact suffix/width differs')
    require(listing.rstrip().endswith('#END'),'returned hierarchy not cleanEOF')
    declarations=[(r[3],int(r[1])) for r in (line.split('\t') for line in listing.splitlines()) if r[0]=='#VAR']
    require(len(declarations)==414 and len(set(declarations))==414 and set(declarations)=={(r['path'],r['width']) for r in p['writer_leaves']},'returned414 exact leaf hierarchy differs')
    require((raw['path'],1) in declarations,'raw maintenance missing from returned trace declarations')


def verify(base):
    admission_record=bind(base/'admission.json');require(admission_record['sha256']==ADMISSION,'final frozen admission differs')
    a=json_file(base/'admission.json');p=json_file(verify_binding(a['proposal'],base))
    require(bind(base/'helper/host_flow.py')['sha256']==DRIVER,'frozen host driver differs')
    for record in a['inputs'].values():verify_binding(record,base)
    # OriginalPCH files live only in the root host namespace. The frozen
    # driver checked them before/after; this returned-proof verifier cannot
    # independently reread those private live files and does not claim to.
    require(len(a['PCH_inventory'])==2,'two originalPCH identities required')
    supervisor=json_file(base/'host-supervision.json')
    require(supervisor['state']=='FAIL-preserved-no-retry','original failed attempt must remain explicit')
    require(supervisor['admission']==admission_record and supervisor['stage']==str(STAGE),'original admission/stage differs')
    flow=json_file(base/'closed01/flow.json')
    require(flow['state']=='FAIL-preserved-no-retry' and 'strict.log' in flow['error'],'exact original checker-root failure')
    post_record=bind(POST/'admission.json');require(post_record['sha256']==POST_ADMISSION,'frozen postprocess admission')
    post_admission=json_file(POST/'admission.json')
    for record in post_admission['inputs']:verify_binding(record,base)
    post_supervisor=json_file(POST/'host-supervision.json')
    require(post_supervisor['state']=='PASS-owned-postprocess-only-completion' and post_supervisor['returncode']==0,'postprocess actual complete PASS')
    require(post_supervisor['admission']==post_record and post_supervisor['owned_pid']==post_supervisor['owned_process_group'],'owned postprocess admission/group')
    composite=json_file(verify_binding(post_supervisor['completion'],base))
    require(composite['state']=='PASS-composite-b912-native-five-literal-domains-plus-three-maintained-checkers' and composite['admission']==post_record,'composite PASS missing')
    require(composite['original_failure']==bind(base/'host-supervision.json'),'original failure not preserved')
    require([row['label'] for row in composite['commands']]==['strict','observer','geometry'],'exact three remaining checkers only')
    for row in composite['commands']:
        require(row['returncode']==0 and str(SOURCE)+'/' in row['argv'][2],'correct new source root and successful checker')
        verify_binding(row['log'],base)
    build_path=verify_binding(composite['build'],base);build=json_file(build_path)
    require(build['state']=='BUILT-only-copied-Syms-awaiting-one-cold08' and build['admission']==admission_record,'wrong build evidence')
    require(build['baseline_relink']['sha256']==build['original_model']['sha256']==ORIGINAL,'untouched relink/original model differs')
    require(build['original_members']==p['archive_members'],'original archive inventory differs')
    initial,final=build['initial_copy'],build['final_copy']
    require(set(initial)==set(final)==set(p['required_copy']),'copy inventory names differ')
    for name in initial:require(identity(initial[name])==identity(p['required_copy'][name]),'initial copied file differs: '+name)
    changed=[name for name in initial if identity(initial[name])!=identity(final[name])]
    allowed={MODEL,MODEL+'__ALL.a',SYMS+'.cpp',SYMS+'.o',SYMS+'.d'}
    require(set(changed)==set(build['changed_files']) and set(changed)<=allowed and {SYMS+'.cpp',SYMS+'.o'}<=set(changed),'non-writer copied file changed')
    require(list(build['original_members'])==list(build['final_members']) and
        [n for n in build['original_members'] if build['original_members'][n]!=build['final_members'][n]]==[SYMS+'.o'],'archive changed beyond Syms')
    require(identity(build['binary'])==identity(final[MODEL]),'final binary metadata differs')
    with gzip.open(base/'closed01/model.gz','rb') as stream:
        require(digest(stream)==identity(build['binary']),'gzip model not identical to qualified binary')
    with gzip.open(base/'closed01/filtered-Syms.cpp.gz','rb') as stream:filtered=stream.read()
    require(dict(bytes=len(filtered),sha256=hashlib.sha256(filtered).hexdigest())==identity(final[SYMS+'.cpp']),'filtered source gzip differs')
    extra=(base/'closed01/build/evidence/inserted-filter.txt').read_bytes()
    require(filtered.count(extra)==1,'filter insertion not unique')
    original=filtered.replace(extra,b'')
    require(dict(bytes=len(original),sha256=hashlib.sha256(original).hexdigest())==identity(initial[SYMS+'.cpp']),'change outside inserted tracewriter calls')
    require(extra.count(b'__Vm_dumperp->dumpvars(1, ')==414,'wrong writer call count')
    for row in p['writer_leaves']:require(('dumpvars(1, '+json.dumps(row['path'])+');').encode() in extra,'writer leaf missing')
    archive=json_file(base/'closed01/archive.json')
    require(archive['state']=='compact-proof-plus-exact-qualified-rawFST','exact qualified rawFST must be durable')
    raw_fst=verify_binding(archive['qualified_rawFST'],base)
    verify_binding(archive['gzip'],base);verify_binding(archive['copied_source_archive'],base)
    source_count=source_archive(base/'closed01/copied-model-sources.tar.gz',initial,final[SYMS+'.cpp'])
    qualifier=json_file(verify_binding(composite['native_and_literals'],base))
    require(composite['inherited_qualification']==composite['native_and_literals'],'same inherited native/literal record')
    require(identity(archive['qualified_rawFST'])==identity(qualifier['trace']),'durable raw FST not qualified trace')
    require(qualifier['state']=='COMPLETE-cold08-awaiting-five-domain-and-maintained-checkers','preserved pre-checker qualification state')
    require(qualifier['admission']==admission_record and qualifier['guest']==a['reference']['guest'],'complete guest/CORE/host protocol differs')
    require(set(qualifier['domains'])==set(p['domains'])==set(a['original_canonical']),'domain union differs')
    capacity_contract(p,(base/'closed01/qualification01/hierarchy.tsv').read_text(),base)
    results={}
    for name,row in qualifier['domains'].items():
        require(row['literal_bytes_equal'] is True and row['reference']==a['original_canonical'][name],'wrong immutable canonical reference')
        results[name]=literal(row['reference'],row['clone'],base)
    strict=json_file(verify_binding(composite['strict'],base));observer=json_file(verify_binding(composite['observer'],base));geo=json_file(verify_binding(composite['geometry'],base))
    require(strict['accepted'] is True,'strict payload proof not accepted')
    for lane in ('i','d'):
        facts=strict['lanes'][lane]
        require(len(facts['publications'])==len(facts['hits'])==len(facts['bursts'])==1 and len(facts['bursts'][0]['beats'])==8,'strict real lane event counts differ')
    require(observer['state'].startswith('PASS actual counter transitions') and observer['firsttouch_counts']==dict(i=[1,1,8],d=[1,1,8]),'observer real counters differ')
    require(geo['facts']['clean_eof'] is True and geo['facts']['values']==a['reference']['actual_geometry'],'16 actual geometry values/EOF differ')
    for proof in (strict,observer,geo):
        require(identity(proof['bindings']['fst'])==identity(qualifier['trace']),'maintained proof not same FST')
    run=json_file(base/'closed01/qualification01/runtime/verification.json')
    require(run['actual_returncode']==a['reference']['returncode'] and run['counter_values']==a['reference']['guest']['counter_values'],'terminal exception/counter scope differs')
    for record in run['files']:
        if Path(record['path']).suffix=='.fst':require(identity(record)==identity(qualifier['trace']),'run trace differs')
        else:verify_binding(record,base)
    claim=json_file(base/'target-one-shot-claim.json')
    require(claim['state']=='ONE-cold08-no-retry' and claim['admission']==admission_record and claim['stage']==str(STAGE),'one-shot claim differs')
    return dict(state='PASS-composite-returned-b912-observation-model-five-literal-domains-plus-three-checkers',
                admission=admission_record,original_failed_supervision=bind(base/'host-supervision.json'),postprocess_admission=post_record,postprocess_supervision=bind(POST/'host-supervision.json'),composite_completion=bind(POST/'closed01/completion.json'),build=bind(build_path),
                qualified_model=build['binary'],original_model=p['original_model'],trace=qualifier['trace'],
                domains=results,source_archive_members=source_count,verifier=bind(__file__),source_proposal=bind(base/'proposal.json'),original_TOP=p['original_TOP'],original_BP=p['original_BP'],compiled_source_inventory=p['compiled_sources'],model_stamp=p['model_stamp'],environment=p['environment'],linked_libraries=p['linked_libraries'],model_gzip=bind(base/'closed01/model.gz'),copied_source_archive=bind(base/'closed01/copied-model-sources.tar.gz'),strict=composite['strict'],observer=composite['observer'],geometry=composite['geometry'],
                original_PCH_live_recheck='Unavailable in agent namespace; frozen driver validated before/after. This verifier checks returned evidence, not live original objects.',
                durable_raw_FST=bind(raw_fst),scope='Read-only returned-artifact verification. Exact qualified raw FST is hashed durably, not reparsed here. Literal selected bytes, model/source archives and strict/counter/geometry predicates are independently rebound. No application, FPGA, fit or performance claim.')


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--base',type=Path,default=BASE);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    require(not args.output.exists(),'preserve prior closure report')
    result=verify(args.base);args.output.write_text(json.dumps(result,indent=2)+'\n');print(result['state'])
