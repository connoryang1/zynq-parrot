"""Frozen dense1792 static16KiB model and observation-only helper primitives."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
PROPOSAL=ROOT/'proposal.json'
MODEL_SHA='b912913adc5fa98a0675bd323e7b37da7cbaecdabbb787ca3f466edcc4851de9'
PREFIX='Vbsg_nonsynth_zynq_testbench';SYMS=PREFIX+'__Syms'
CAP=150*1024*1024;NATIVE_SECONDS=180;HOST_SECONDS=360
RESERVE=1024**3;ARTIFACT_ALLOCATION=512*1024**2
SP=Path('/home/coyang/zynq-parrot-retained-dense')
ORIGINAL=Path('/dev/shm/zp-linux-canonical-fullcore-20261121-01/full01')


def require(value,message):
    if not value:raise ValueError(message)


def bind(path):
    p=Path(path).resolve();h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())


def verify(record):require(bind(record['path'])==record,'frozen file changed: '+record['path'])


def save(path,value):Path(path).write_text(json.dumps(value,indent=2)+'\n')


def identities(records):return {k:(v['bytes'],v['sha256']) for k,v in records.items()}


def tree(path):
    result={}
    for p in sorted(Path(path).rglob('*')):
        require(not p.is_symlink(),'generated tree contains symlink')
        if p.is_file() and p.suffix!='.gch':result[str(p.relative_to(path))]=bind(p)
    return result


def fresh_home(path):
    p=Path(path).absolute();require(not p.exists() and not p.is_symlink(),'output must be fresh')
    p=p.resolve();require(str(p).startswith('/home/coyang/'),'output must be HOME');return p


