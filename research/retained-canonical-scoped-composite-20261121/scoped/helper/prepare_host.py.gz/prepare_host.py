#!/usr/bin/env python3
"""Root-host READ-ONLY model/source collector and five-domain original-FST preflight.

No RAM allocation, compiler/linker, model execution, vendor or board calls.
"""
import argparse
import copy
import gzip
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
sys.dont_write_bytecode=True
from common import *
from canonical import extract
from protocol import parse
from host_flow import members,ADMISSION,STAGE,validate,HOME_CAP

OLD=Path('/home/coyang/fpga-artifacts/context-resume/retained-dense-scoped-20261121-02')
CLOSED=Path('/home/coyang/fpga-artifacts/context-resume/retained-canonical-fullcore-20261121/closed-full01')
TOP='eb7d390134a0025331a2366a979a774263b146d5'
BP='8dfdbdeec84cb47f902bc1426d69ecb3efd91c7c'
SENTINEL=Path('/dev/shm/zp-linux-canonical-fulltop-20261121-01')


def home_guard():
    used=sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())
    require(used<=HOME_CAP,'64MiB totalHOME prep cap')
    require(shutil.disk_usage(ROOT).free>=3*1024**3+HOME_CAP-used,'3GiB HOME plus remaining64MiB allocation')


def read_gz_json(path):
    return json.loads(gzip.decompress(path.read_bytes()))


def unique(commands,predicate,label):
    found=[a for a in commands if predicate(a)]
    require(len(found)==1,'exact original compiler/link '+label)
    return found[0]


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--prepare-only',action='store_true',required=True);ap.parse_args()
    # These reads prove the root host namespace before any preparation writes.
    require(SENTINEL.is_dir() and (ORIGINAL/'verilator/obj_dir'/PREFIX).is_file(),'root host source/model absent; no privateRAM use')
    obj=ORIGINAL/'verilator/obj_dir';model=bind(obj/PREFIX)
    require(model['sha256']==MODEL_SHA,'newb912 original model only')
    require(not ADMISSION.exists() and not PROPOSAL.exists(),'fresh preparation only; preserve failures')
    home_guard()
    template=json.loads((OLD/'proposal.json').read_text());old_a=json.loads((OLD/'admission.json').read_text())
    require(bind(OLD/'admission.json')['sha256']=='7cf3575d85d19d457f14cd8296e57019a0ec0fcae9497a3221613a46eb19dd92','accepted414 lineage')
    closure=json.loads((CLOSED/'manifest.json').read_text())
    require(closure['model']['sha256']==MODEL_SHA and closure['executed_top']['head']==TOP and closure['executed_bp']['head']==BP,'closed canonical source/model identity')
    session=json.loads((ORIGINAL/'session.json').read_text())
    require(session['state'].startswith('PASS canonical1792 fullcore integrity/cold08'),'whole original fullcore incomplete')
    require(session['source_bp']==BP and session['source_repositories'][0]['head']==TOP,'original actual source commits')
    for row in closure['durable_copies']:
        verify(row['snapshot'])
    inventory=tree(obj)
    sources=json.loads((ORIGINAL/'actual-source-list.json').read_text())['sources']
    compiled={name:bind(name) for name in sources}
    for name,row in sources.items():
        require(all(compiled[name][k]==row[k] for k in ('bytes','sha256')),'actual consumed source changed')
    backend=SENTINEL/'import/black-parrot/bp_common/src/v/bp_retained_line_store.sv'
    require(bind(backend)['sha256']=='68d1dd0c7df7e56ffe76317f9bae5a3ca3e09d13cb44d1167c0f737acefcbea6','actual integrated epoch source')
    log=(ORIGINAL/'build.log').read_text()
    commands=[shlex.split(line) for line in log.splitlines() if line.startswith('g++ ')]
    original_compile=unique(commands,lambda a:a[-1]==SYMS+'.cpp','Syms')
    pch=unique(commands,lambda a:a[-1]==PREFIX+'__pch.h.slow.gch','slowPCH')
    link=unique(commands,lambda a:'-o' in a and a[a.index('-o')+1]==PREFIX,'link')
    require(original_compile[-6:]==['-include',PREFIX+'__pch.h.slow','-c','-o',SYMS+'.o',SYMS+'.cpp'],'original Syms compile shape')
    require(pch[:-5]==original_compile[:-6] and pch[-5:]==['-x','c++-header',PREFIX+'__pch.h','-o',PREFIX+'__pch.h.slow.gch'],'textual PCH include/flags identity')
    mapped=original_compile.copy();mapped[-5]=PREFIX+'__pch.h'
    host=['ps.o','main.o','bsg_nonsynth_dpi_clock_gen.o','verilated.o','verilated_dpi.o','verilated_fst_c.o','verilated_threads.o']
    require([x for x in link if x.endswith(('.o','.a'))]==host+[PREFIX+'__ALL.a'],'exact seven-host-object order')
    names=set(host+[PREFIX,PREFIX+'__ALL.a',SYMS+'.cpp',SYMS+'.o',SYMS+'.d'])
    names.update(p.name for p in obj.glob('*.h'))
    required={name:bind(obj/name) for name in sorted(names)}
    require(not any(name.endswith('.gch') for name in required),'no PCH copy')
    stamp=list(obj.glob('.build_config-*'));require(len(stamp)==1,'one actual build stamp')
    env=session['environment'];ldenv=dict(os.environ,**env)
    ld=subprocess.run(['ldd',str(obj/PREFIX)],env=ldenv,text=True,capture_output=True,timeout=10)
    require(ld.returncode==0 and 'not found' not in ld.stdout,'original loader preflight')
    libraries=[bind(x) for line in ld.stdout.splitlines() for x in line.split() if x.startswith('/') and Path(x).is_file()]
    reader=template['reader'];verify(reader)
    trace=CLOSED/'durable/advisory-trace.fst'
    require(bind(trace)['sha256']=='35da7b2088acc410d6bf6bfd9853134c9d57223cbb6c6746dac00ec7f5a184ab','new original cold08 FST')
    listing=subprocess.check_output([reader['path'],str(trace),'--list'],text=True,timeout=60)
    require(listing.rstrip().endswith('#END'),'actual original hierarchy cleanEOF')
    declared={}
    for line in listing.splitlines():
        if line.startswith('#VAR\t'):
            _,width,handle,name=line.split('\t');require(name not in declared,'duplicate original leaf');declared[name]=int(width)
    domains=copy.deepcopy(template['domains'])
    for part in domains.values():
        for leaf in part:require(declared.get(leaf['path'])==leaf['width'],'new original exact leaf/width: '+leaf['path'])
    union={leaf['path']:leaf for part in domains.values() for leaf in part}
    require(len(union)==414 and any(k.endswith('.unicore_lite.dcache_retained_maintenance_v') and v['width']==1 for k,v in union.items()),'414 union/raw maintenance')
    # The only original-model operations above were metadata readers (ldd/ar/FST).
    (ROOT/'original-hierarchy.tsv.gz').write_bytes(gzip.compress(listing.encode(),mtime=0))
    (ROOT/'original-loader.log').write_text(ld.stdout)
    stat=SENTINEL.stat()
    p=dict(state='PREPARED-b912-host-observation-clone-NO-build-target',original_model=model,original_root=str(obj),original_inventory=inventory,
      required_copy=required,copy_bytes=sum(r['bytes'] for r in required.values()),compiled_sources=compiled,archive_members=members(obj/(PREFIX+'__ALL.a')),
      compile_argv=mapped,original_compile_argv=original_compile,PCH_creation_argv=pch,link_argv=link,domains=domains,
      writer_leaves=[union[k] for k in sorted(union)],reader=reader,environment=env,linked_libraries=libraries,model_stamp=bind(stamp[0]),
      runtime_sources=template['runtime_sources'],original_session=bind(ORIGINAL/'session.json'),original_build_log=bind(ORIGINAL/'build.log'),
      previous_accepted_plan=bind(OLD/'admission.json'),namespace_sentinel=str(SENTINEL),namespace_identity=dict(device=stat.st_dev,inode=stat.st_ino),
      original_TOP=TOP,original_BP=BP,fullcore_closure=bind(CLOSED/'manifest.json'),original_hierarchy=bind(ROOT/'original-hierarchy.tsv.gz'),
      capacity_schema=template['capacity_schema'],capacity_sources=template['capacity_sources'],scope='Trace registration only on NEWb912. No old876/a5d substitution, target/RTL change, performance/FPGA claim.')
    for r in [*p['runtime_sources'].values(),p['capacity_schema'],*p['capacity_sources']]:verify(r)
    save(PROPOSAL,p)
    (ROOT/'required-leaves.tsv').write_text(''.join(str(r['width'])+'\t'+r['path']+'\n' for r in p['writer_leaves']))
    canonical={}
    for name,part in domains.items():
        home_guard();canonical[name]=extract(reader['path'],trace,part,ROOT/('preflight-original-'+name),False);home_guard()
    save(ROOT/'real-preflight.json',dict(state='PASS-newb912-414leaves-five-literal-domains-init-to-cleanEOF',domains=canonical,proposal=bind(PROPOSAL)))
    refdir=ROOT/'original-reference';refdir.mkdir()
    reference={}
    for kind,suffix in [('elf','riscv'),('nbf','nbf')]:
        data=gzip.decompress((CLOSED/'durable'/('advisory-prog.'+suffix+'.gz')).read_bytes())
        dest=refdir/('prog.'+suffix);dest.write_bytes(data);reference[kind]=bind(dest)
    require(reference['elf']['sha256']=='3fe096173e3a63b2656c1fadf0a058a328fb5f1ee375be652176408856f897b8' and reference['nbf']['sha256']=='627662f775f9c2645e5b5687a9df3bfaed25d42265e125a0386047ebe1daad4b','unchanged cold08 program')
    process=read_gz_json(CLOSED/'advisory/process.json.gz')
    text=gzip.decompress((CLOSED/'advisory/run.log.gz').read_bytes()).decode()
    reference.update(trace=bind(trace),returncode=process['returncode'],guest=parse(text,process['returncode']),actual_geometry=read_gz_json(CLOSED/'actual-parameters01/verification.json.gz')['facts']['values'])
    inputs={str(x):bind(x) for x in [*HERE.glob('*.py'),ROOT/'README.md',ROOT/'host-tests.log',ROOT/'required-leaves.tsv',ROOT/'real-preflight.json',PROPOSAL,OLD/'admission.json',OLD/'proposal.json',CLOSED/'manifest.json']}
    maintained=[SP/'testing/check_run.py',SP/'testing/rtl/retained-advisory-trace/validate.py',
        SP/'research/retained-use-observation-20261121/build_full.py',
        SP/'research/retained-use-observation-20261121/verify_counters.py',
        SP/'research/retained-dense-fullcore-20261121/geometry.py',Path(old_a['fixture_manifest']['path'])]
    fixture=json.loads(Path(old_a['fixture_manifest']['path']).read_text())
    maintained.extend(Path(fixture[k]['path']) for k in ('source','elf'))
    for path in maintained:inputs[str(path)]=bind(path)
    for record in [*reference.values(),p['capacity_schema'],*p['capacity_sources'],*(r['canonical_file'] for r in canonical.values())]:
        if isinstance(record,dict) and {'path','bytes','sha256'}<=set(record):inputs[record['path']]=record
    a=dict(schema='canonical1792-observation-only-host-admission-v1',state='FROZEN-PREPARED-HOLD-root-build-target-review',proposal=bind(PROPOSAL),stage=str(STAGE),inputs=inputs,
      PCH_inventory={x.name:bind(x) for x in obj.glob('*.gch')},budget=dict(stage_bytes=ARTIFACT_ALLOCATION,minimum_free_plus_remaining=RESERVE,home_bytes=HOME_CAP,native_seconds=180,host_seconds=360,FST_bytes=CAP,reader_seconds_per_domain=600,canonical_bytes_per_file=50*1024**2,attempts=1),
      fixture_manifest=old_a['fixture_manifest'],reference=reference,original_canonical=canonical,scope=p['scope'])
    save(ADMISSION,a);validate(a);home_guard()
    command='PYTHONDONTWRITEBYTECODE=1 python3 -B '+str(HERE/'host_flow.py')+' --approval-sha '+bind(ADMISSION)['sha256']
    (ROOT/'HOST_COMMAND.txt').write_text(command+'\n')
    save(ROOT/'prepared-handoff.json',dict(state='PREPARED-NO-build-or-target-executed',admission=bind(ADMISSION),proposal=bind(PROPOSAL),host_command=command,copy_bytes=p['copy_bytes'],original_model=model))
    print(ROOT/'prepared-handoff.json',bind(ADMISSION)['sha256'],flush=True)

if __name__=='__main__':main()
