#!/usr/bin/env python3
"""Host namespace only: one source-bound tracewriter clone and cold08 qualification.

The outer supervisor owns only its worker process group. No FPGA commands, RTL
elaboration, make invocation, evaluation recompilation or original-tree writes.
"""
import argparse
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import tarfile
import time
sys.dont_write_bytecode=True
from common import *
from canonical import extract,declarations,equivalent
from framing import framing
from protocol import parse

ADMISSION=ROOT/'admission.json'
STAGE=Path('/dev/shm/zp-retained-canonical-scoped-20261121-01')
HOME_CAP=64*1024**2


def used(path):
    return sum(p.stat().st_size for p in Path(path).rglob('*') if p.is_file()) if Path(path).exists() else 0


def resource_guard(free,consumed,home_consumed):
    require(0<=consumed<=ARTIFACT_ALLOCATION,'512MiB stage allocation exceeded')
    require(free>=RESERVE+ARTIFACT_ALLOCATION-consumed,'host RAM minimum1GiB+remaining-stage reserve breached')
    require(home_consumed<=HOME_CAP,'64MiB durable HOME allocation exceeded')


def validate(a):
    require(a['schema']=='canonical1792-observation-only-host-admission-v1','wrong admission')
    require(a['stage']==str(STAGE) and a['proposal']['path']==str(PROPOSAL),'changed fixed output/inputs')
    require(a['budget']==dict(stage_bytes=ARTIFACT_ALLOCATION,minimum_free_plus_remaining=RESERVE,
            home_bytes=HOME_CAP,native_seconds=180,host_seconds=360,FST_bytes=CAP,
            reader_seconds_per_domain=600,canonical_bytes_per_file=50*1024**2,attempts=1),'changed budget')
    for r in a['inputs'].values():verify(r)
    verify(a['proposal']);p=json.loads(PROPOSAL.read_text())
    require(p['original_model']['sha256']==MODEL_SHA,'wrong originalb912 model')
    require(p['original_BP']=='8dfdbdeec84cb47f902bc1426d69ecb3efd91c7c' and p['original_TOP']=='eb7d390134a0025331a2366a979a774263b146d5','new canonical original source identity')
    verify(p['fullcore_closure'])
    require({n:len(rows) for n,rows in p['domains'].items()}==dict(core252=252,observer_and_geometry=45,SP_strict162=162,actual_geometry16=16,capacity167=167),'wrong domains')
    union={r['path']:r['width'] for rows in p['domains'].values() for r in rows}
    require(union=={r['path']:r['width'] for r in p['writer_leaves']} and len(union)==414,'414-leaf union gap')
    for r in [p['original_model'],p['original_session'],p['original_build_log'],p['model_stamp'],p['reader'],
              *p['runtime_sources'].values(),*p['linked_libraries'],*p['compiled_sources'].values()]:verify(r)
    require(identities(tree(p['original_root']))==identities(p['original_inventory']),'original generated inventory changed')
    for r in a['PCH_inventory'].values():verify(r)
    return p


def filtered_source(text,leaves):
    needle='        __Vm_modelp->trace(__Vm_dumperp, 0, 0);\n'
    require(text.count(needle)==1 and text.index(needle)<text.index('__Vm_dumperp->open('),'ambiguous trace registration/open')
    require(len(leaves)==len({r['path'] for r in leaves}),'duplicate filter leaf')
    extra='        // Observation-only whole-callback selection; evaluation is unchanged.\n'
    extra+=''.join('        __Vm_dumperp->dumpvars(1, '+json.dumps(r['path'])+');\n' for r in leaves)
    return text.replace(needle,needle+extra),extra


def members(archive):
    names=subprocess.check_output(['ar','t',str(archive)],text=True,timeout=30).splitlines()
    require(len(names)==len(set(names)),'duplicate archive members')
    return {n:hashlib.sha256(subprocess.check_output(['ar','p',str(archive),n],timeout=30)).hexdigest() for n in names}


def command(argv,cwd,output,timeout):
    save(str(output)+'.argv.json',argv)
    with Path(output).open('wb') as log:
        proc=subprocess.Popen(argv,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
        try:rc=proc.wait(timeout=timeout)
        finally:
            if proc.poll() is None:proc.kill();proc.wait()
    require(rc==0,'command failed: '+str(output))


def loader(binary,p):
    env=dict(os.environ);env.update(p['environment'])
    ld=subprocess.run(['ldd',str(binary)],env=env,text=True,capture_output=True,timeout=10)
    require(ld.returncode==0 and 'not found' not in ld.stdout,'loader unresolved')
    libs=[bind(x) for line in ld.stdout.splitlines() for x in line.split() if x.startswith('/') and Path(x).is_file()]
    require(libs==p['linked_libraries'],'loader/library identity differs')
    return ld.stdout


def build(a,p):
    out=STAGE/'build';out.mkdir();obj=out/'obj';obj.mkdir();ev=out/'evidence';ev.mkdir()
    state=dict(state='BUILDING-only-copied-Syms-no-target',admission=bind(ADMISSION),original_model=p['original_model'])
    save(ev/'build.json',state)
    for name,r in p['required_copy'].items():
        verify(r);shutil.copy2(r['path'],obj/name)
        require(bind(obj/name)['sha256']==r['sha256'],'copied byte mismatch')
    before=tree(obj);archive=obj/(PREFIX+'__ALL.a');oldmembers=members(archive)
    require(oldmembers==p['archive_members'],'copied archive differs')
    original_compile=p['original_compile_argv'];pch=p['PCH_creation_argv']
    require(original_compile[-6:]==['-include',PREFIX+'__pch.h.slow','-c','-o',SYMS+'.o',SYMS+'.cpp'],'compile argv guard')
    require(pch[:-5]==original_compile[:-6] and pch[-5:]==['-x','c++-header',PREFIX+'__pch.h','-o',PREFIX+'__pch.h.slow.gch'],'PCH exact textual header/flags guard')
    mapped=original_compile.copy();mapped[-5]=PREFIX+'__pch.h'
    require(mapped==p['compile_argv'],'textual include mapping differs')
    expected=['ps.o','main.o','bsg_nonsynth_dpi_clock_gen.o','verilated.o','verilated_dpi.o','verilated_fst_c.o','verilated_threads.o',PREFIX+'__ALL.a']
    require([x for x in p['link_argv'] if x.endswith(('.o','.a'))]==expected,'host object order differs')
    command(p['link_argv'],obj,ev/'untouched-link.log',600)
    require(bind(obj/PREFIX)['sha256']==MODEL_SHA,'untouched relink did not reproduceb912: no filter/target allowed')
    state['baseline_relink']=bind(obj/PREFIX);save(ev/'build.json',state)
    source=obj/(SYMS+'.cpp');modified,extra=filtered_source(source.read_text(),p['writer_leaves']);source.write_text(modified)
    (ev/'inserted-filter.txt').write_text(extra)
    command(mapped,obj,ev/'compile-Syms.log',600)
    command(['ar','rcs',archive.name,SYMS+'.o'],obj,ev/'replace-Syms.log',60)
    newmembers=members(archive)
    require(list(oldmembers)==list(newmembers) and [n for n in oldmembers if oldmembers[n]!=newmembers[n]]==[SYMS+'.o'],'archive mutation beyond single Syms object')
    command(p['link_argv'],obj,ev/'filtered-link.log',600)
    after=tree(obj);require(set(before)==set(after),'unexpected copied file created/deleted')
    changes=[n for n in before if identities(before)[n]!=identities(after)[n]]
    require(set(changes)<={SYMS+'.cpp',SYMS+'.o',SYMS+'.d',PREFIX+'__ALL.a',PREFIX} and {SYMS+'.cpp',SYMS+'.o'}<=set(changes),'copied evaluation/host object changed')
    (ev/'loader.log').write_text(loader(obj/PREFIX,p));validate(a)
    state.update(state='BUILT-only-copied-Syms-awaiting-one-cold08',binary=bind(obj/PREFIX),changed_files=changes,
                 initial_copy=before,final_copy=after,original_members=oldmembers,final_members=newmembers,
                 compiler=bind(shutil.which('g++')))
    save(ev/'build.json',state);return obj/PREFIX


def limits():
    resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_FSIZE,(CAP,CAP))


def run_target(binary,runtime,env):
    argv=[str(binary),'+c_args=prog.nbf 180000','+bsg_trace='+str(runtime/'trace.fst')]
    save(runtime/'admission.json',dict(admission=bind(ADMISSION),model=bind(binary),command=argv))
    with (runtime/'run.log').open('wb') as log:
        proc=subprocess.Popen(argv,cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT,preexec_fn=limits)
        start=time.monotonic()
        try:rc=proc.wait(timeout=HOST_SECONDS)
        finally:
            if proc.poll() is None:proc.kill();proc.wait()
    save(runtime/'process.json',dict(returncode=rc,elapsed_seconds=time.monotonic()-start));return rc


def qualify(a,p,binary):
    out=STAGE/'qualification01';out.mkdir();runtime=out/'runtime';runtime.mkdir()
    with (ROOT/'target-one-shot-claim.json').open('x') as f:
        json.dump(dict(state='ONE-cold08-no-retry',admission=bind(ADMISSION),pid=os.getpid(),stage=str(STAGE)),f);f.flush();os.fsync(f.fileno())
    journal=out/'qualification.json';state=dict(state='RUNNING-one-cold08',admission=bind(ADMISSION),domains={});save(journal,state)
    for name,dest in (('elf','prog.riscv'),('nbf','prog.nbf')):
        shutil.copy2(a['reference'][name]['path'],runtime/dest)
        require(bind(runtime/dest)['sha256']==a['reference'][name]['sha256'],'cold08 image byte mismatch')
    env={k:v for k,v in os.environ.items() if not k.startswith(('BSG_RUNTIME_PATCH_','BSG_TRACE_'))};env.update(p['environment'])
    (runtime/'loader.log').write_text(loader(binary,p));validate(a)
    rc=run_target(binary,runtime,env);guest=parse((runtime/'run.log').read_text(),rc)
    require(rc==a['reference']['returncode'] and guest==a['reference']['guest'],'whole cold08/CORE/GP0/retired-count/terminal protocol differs')
    fst=runtime/'trace.fst';require(0<fst.stat().st_size<CAP,'FST absent/at cap')
    frame=framing(fst);old=framing(Path(a['reference']['trace']['path']))
    require((frame['header_start_tick'],frame['header_end_tick'])==(old['header_start_tick'],old['header_end_tick']),'full initialization-to-EOF clock endpoints differ')
    listing=subprocess.check_output([p['reader']['path'],str(fst),'--list'],text=True,timeout=60)
    declarations(listing,p['writer_leaves']);(out/'hierarchy.tsv').write_text(listing)
    spec=importlib.util.spec_from_file_location('unchanged_dense_binding',SP/'research/retained-use-observation-20261121/build_full.py')
    producer=importlib.util.module_from_spec(spec);spec.loader.exec_module(producer)
    proof=dict(state='PASS complete scoped wholecore and actual GP0 1hit/1publish/8writes per lane; strict closed trace audit pending',
        actual_returncode=rc,known_postPASS_GPIO_exception=rc!=0,counter_values=guest['counter_values'],
        sources=producer.binding(ORIGINAL/'actual-source-list.json'),trace=bind(fst),
        files=[producer.binding(runtime/n) for n in ('admission.json','process.json','run.log','prog.riscv','prog.nbf','trace.fst')])
    save(runtime/'verification.json',proof)
    state.update(state='COMPLETE-cold08-awaiting-five-domain-and-maintained-checkers',guest=guest,framing=frame,trace=bind(fst));save(journal,state)
    for name,leaves in p['domains'].items():
        reference=a['original_canonical'][name]
        verify(reference['canonical_file'])
        selected=extract(p['reader']['path'],fst,leaves,out/('clone-'+name),False)
        equivalent(reference,selected);state['domains'][name]=dict(reference=reference,clone=selected,literal_bytes_equal=True);save(journal,state)
    strict=SP/'testing/rtl/retained-advisory-trace/validate.py'
    command([sys.executable,'-B',str(strict),'--fst',str(fst),'--reader',p['reader']['path'],'--model-source-list',str(ORIGINAL/'actual-source-list.json'),
        '--fixture-manifest',a['fixture_manifest']['path'],'--log',str(runtime/'run.log'),'--exit-code',str(rc),'--out',str(out/'strict'),'--reader-timeout','600'],out,out/'strict.log',720)
    require(json.loads((out/'strict/verification.json').read_text())['accepted'] is True,'strict512b/eight-real-writes/Iretire not accepted')
    command([sys.executable,'-B',str(SP/'research/retained-use-observation-20261121/verify_counters.py'),'--fst',str(fst),'--reader',p['reader']['path'],
        '--strict-proof',str(out/'strict/verification.json'),'--run-proof',str(runtime/'verification.json'),'--out',str(out/'observer')],out,out/'observer.log',300)
    obs=json.loads((out/'observer/verification.json').read_text());require(obs['state'].startswith('PASS actual counter transitions') and obs['firsttouch_counts']==dict(i=[1,1,8],d=[1,1,8]),'counter transitions/GP0 differ')
    command([sys.executable,'-B',str(SP/'research/retained-dense-fullcore-20261121/geometry.py'),'--fst',str(fst),'--reader',p['reader']['path'],'--out',str(out/'geometry')],out,out/'geometry.log',660)
    geo=json.loads((out/'geometry/verification.json').read_text());require(geo['facts']['values']==a['reference']['actual_geometry'],'all16 actual geometry fields differ')
    validate(a);state.update(state='PASS-dense1792-cold08-five-domain-literal-equivalence-strict-counter-geometry',strict=bind(out/'strict/verification.json'),observer=bind(out/'observer/verification.json'),geometry=bind(out/'geometry/verification.json'))
    save(journal,state);return out


def archive_small(stage):
    # No FST, RAM archive or raw generated model copies in HOME. Keep a small
    # gzip executable and complete small proof/source inventory only.
    dst=ROOT/'closed01';dst.mkdir()
    for p in stage.rglob('*'):
        if not p.is_file() or p.suffix in ('.fst','.a','.o','.h','.d') or p.name==PREFIX:continue
        if 'obj' in p.relative_to(stage).parts:continue
        target=dst/p.relative_to(stage);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
    for p,name in ((stage/'build/obj'/PREFIX,'model.gz'),(stage/'build/obj'/(SYMS+'.cpp'),'filtered-Syms.cpp.gz')):
        with p.open('rb') as src,gzip.open(dst/name,'wb') as dest:shutil.copyfileobj(src,dest)
    with tarfile.open(dst/'copied-model-sources.tar.gz','w:gz') as archive:
        for source in sorted((stage/'build/obj').glob('*.h')):
            archive.add(source,arcname='obj/'+source.name,recursive=False)
        archive.add(stage/'build/obj'/(SYMS+'.cpp'),arcname='obj/'+SYMS+'.cpp',recursive=False)
    raw=stage/'qualification01/runtime/trace.fst';raw_copy=dst/'qualification-trace.fst'
    require(used(ROOT)+raw.stat().st_size<=HOME_CAP,'qualified rawFST exceeds64MiB durable total')
    shutil.copy2(raw,raw_copy);require(bind(raw)['sha256']==bind(raw_copy)['sha256'],'qualified rawFST copy drift')
    require(used(ROOT)<=HOME_CAP,'durable64MiB cap');save(dst/'archive.json',dict(state='compact-proof-plus-exact-qualified-rawFST',qualified_rawFST=bind(raw_copy),model=bind(stage/'build/obj'/PREFIX),gzip=bind(dst/'model.gz'),copied_source_archive=bind(dst/'copied-model-sources.tar.gz'),stage=str(stage)))


def worker(a):
    journal=STAGE/'flow.json';state=dict(state='STARTED',admission=bind(ADMISSION));save(journal,state)
    try:
        p=validate(a);binary=build(a,p);out=qualify(a,p,binary)
        state.update(state='PASS-one-dense1792-observation-qualification',build=bind(STAGE/'build/evidence/build.json'),qualification=bind(out/'qualification.json'))
        save(journal,state);archive_small(STAGE)
    except BaseException as error:
        state.update(state='FAIL-preserved-no-retry',error=repr(error));raise
    finally:save(journal,state)


def terminate_owned_group(proc):
    # Even if the worker exits at a deadline, its group may retain a reader or
    # compiler. Never target a PID/group not created by this invocation.
    for sig,delay in ((signal.SIGTERM,2),(signal.SIGKILL,0)):
        try:os.killpg(proc.pid,sig)
        except ProcessLookupError:pass
        if delay:time.sleep(delay)
    proc.wait()


def supervise(approval):
    require(bind(ADMISSION)['sha256']==approval,'frozen admission SHA differs')
    a=json.loads(ADMISSION.read_text());p=validate(a)
    require(Path(p['namespace_sentinel']).is_dir(),'wrong/private RAM namespace: host source sentinel absent')
    stat=Path(p['namespace_sentinel']).stat()
    require(dict(device=stat.st_dev,inode=stat.st_ino)==p['namespace_identity'],'root-host source sentinel identity changed')
    require(not STAGE.exists() and not STAGE.is_symlink(),'stage must be fresh; no retries')
    require(not (ROOT/'target-one-shot-claim.json').exists(),'target claim already exists')
    resource_guard(shutil.disk_usage('/dev/shm').free,0,used(ROOT));STAGE.mkdir()
    journal=ROOT/'host-supervision.json';state=dict(state='RUNNING-owned-host-flow',admission=bind(ADMISSION),stage=str(STAGE),supervisor_pid=os.getpid());save(journal,state)
    proc=None
    try:
        with (STAGE/'worker.log').open('wb') as log:
            proc=subprocess.Popen([sys.executable,'-B',str(Path(__file__).resolve()),'--worker','--approval-sha',approval],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            state['owned_worker_pid']=proc.pid;state['owned_process_group']=proc.pid;save(journal,state)
            while proc.poll() is None:
                resource_guard(shutil.disk_usage('/dev/shm').free,used(STAGE),used(ROOT));time.sleep(1)
            resource_guard(shutil.disk_usage('/dev/shm').free,used(STAGE),used(ROOT))
            require(proc.returncode==0,'owned flow failed; preserve stage and stop')
        validate(a);state.update(state='PASS-one-owned-host-flow',returncode=proc.returncode,flow=bind(STAGE/'flow.json'),RAM_bytes=used(STAGE),HOME_bytes=used(ROOT))
    except BaseException as error:
        state.update(state='FAIL-preserved-no-retry',error=repr(error));raise
    finally:
        if proc is not None:terminate_owned_group(proc)
        save(journal,state);print(journal,state['state'],flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--approval-sha',required=True);ap.add_argument('--worker',action='store_true');args=ap.parse_args()
    if args.worker:
        require(os.getpgrp()==os.getpid(),'worker must own its session/group')
        require(bind(ADMISSION)['sha256']==args.approval_sha,'worker admission differs')
        worker(json.loads(ADMISSION.read_text()))
    else:
        def interrupted(signum,frame):raise KeyboardInterrupt('supervisor interrupted: '+str(signum))
        signal.signal(signal.SIGTERM,interrupted)
        supervise(args.approval_sha)
