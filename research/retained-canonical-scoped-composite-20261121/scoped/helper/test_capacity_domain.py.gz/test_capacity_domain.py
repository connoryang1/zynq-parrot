"""Preparation-only negative gates: no model/compiler/reader launches."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import host_flow as h


class CapacityDomainTests(unittest.TestCase):
    def fixture(self):
        p=json.loads(Path('/home/coyang/fpga-artifacts/context-resume/retained-dense-scoped-20261121-02/proposal.json').read_text())
        p.update(original_BP='8dfdbdeec84cb47f902bc1426d69ecb3efd91c7c',original_TOP='eb7d390134a0025331a2366a979a774263b146d5',fullcore_closure={})
        p['original_model']['sha256']=h.MODEL_SHA
        return p
    def rejected(self,plan,message):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'proposal.json';path.write_text(json.dumps(plan))
            admission=dict(schema='canonical1792-observation-only-host-admission-v1',stage=str(h.STAGE),proposal={'path':str(path)},inputs={},
                budget=dict(stage_bytes=h.ARTIFACT_ALLOCATION,minimum_free_plus_remaining=h.RESERVE,home_bytes=h.HOME_CAP,native_seconds=180,host_seconds=360,FST_bytes=h.CAP,reader_seconds_per_domain=600,canonical_bytes_per_file=50*1024**2,attempts=1))
            with patch.object(h,'PROPOSAL',path),patch.object(h,'verify'):
                with self.assertRaisesRegex(ValueError,message):h.validate(admission)
    def test_missing_raw_maintenance_rejected(self):
        p=self.fixture();p['writer_leaves']=[r for r in p['writer_leaves'] if not r['path'].endswith('.unicore_lite.dcache_retained_maintenance_v')]
        self.rejected(p,'414-leaf union gap')
    def test_thin_capacity_domain_rejected(self):
        p=self.fixture();p['domains']['capacity167'].pop()
        self.rejected(p,'wrong domains')


if __name__=='__main__':unittest.main()
