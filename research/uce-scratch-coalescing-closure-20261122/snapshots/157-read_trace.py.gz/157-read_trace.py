import subprocess,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent
F=R.parent/'attempt01/I64-BedRock64/uce-retained.fst'
p=subprocess.Popen(['/usr/bin/fst2vcd',str(F)],stdout=subprocess.PIPE,text=True)
scopes=[];names={};values={};selected={};params={};events=[];now=0;header=True
wanted={'clk_i','req_addr_i','req_v_i','req_yumi_o','rev_v_i','rev_ready_o','rev_addr_i','rev_word_i','data_v_o','data_word_o','data_fill_o','arrays_accept_i','capture_cancel_i','clear_i','metadata_v_i','req_type_i','instruction_p','fill_lp','cache_data_lp','assoc_lp','block_lp','bedrock_fill_width_p','icache_data_width_p','icache_fill_width_p','data_width_p','bank_width_lp','byte_offset_width_lp','bank_offset_width_lp','block_offset_width_lp','fill_index_shift','fsm_rev_addr_li','fsm_rev_data_li','fsm_rev_v_li','load_resp_yumi_lo','retained_hit_r','retained_capture_beat','retained_demand_cancel_r','state_r','retained_capture_mask_r','fsm_rev_new_li','fsm_rev_last_li'}
def flush():
 if now>=9600:events.append(dict(time=now,signals={n:values.get(k)for k,ns in selected.items() for n in ns if n.rsplit('.',1)[-1] not in params}))
for line in p.stdout:
 s=line.strip()
 if header:
  if s.startswith('$scope'):scopes.append(s.split()[2])
  elif s.startswith('$upscope'):scopes.pop()
  elif s.startswith('$var'):
   a=s.split();name='.'.join(scopes+[a[4]]);key=a[3];names.setdefault(key,[]).append(name)
   if a[4] in wanted and len(scopes)<=3:selected.setdefault(key,[]).append(name)
  elif s.startswith('$enddefinitions'):header=False
  continue
 if s.startswith('#'):flush();now=int(s[1:]);continue
 if not s or s[0]=='$':continue
 if s[0] in 'bBrR':a=s[1:].split();v,k=a[0],a[1]
 else:v,k=s[0],s[1:]
 if k in selected:
  try:values[k]=int(v,2)
  except ValueError:values[k]=v
  for n in selected[k]:
   if n not in params:params[n]=values[k]
flush();assert p.wait()==0
out=dict(input=dict(path=str(F),bytes=F.stat().st_size,sha256=hashlib.sha256(F.read_bytes()).hexdigest()),reader='/usr/bin/fst2vcd',returncode=0,initial_selected= params,events=events)
(R/'trace-frame.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({n:v for n,v in params.items() if any(k in n for k in ('width','fill_lp','cache_data','assoc_lp','block_lp','instruction_p'))},indent=2))
print('last events',len(events))
