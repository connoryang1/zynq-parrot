#!/usr/bin/env python3
"""Prepared, source-bound real UCE/backend D64 then I64 gate. Default never compiles/runs."""
import argparse,hashlib,json,os,re,resource,shutil,signal,subprocess,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
BP=Path('/home/coyang/bp-retained-canonical-epochs-20261121')
DEPS=Path('/home/coyang/zynq-parrot-retained-dense/import/black-parrot/external')
CAND=Path('/home/coyang/bp-retained-scratch-coalesced-20261122/bp_me/src/v/cce/bp_uce.sv')
V=Path('/home/coyang/zynq-parrot/install/bin/verilator')
M=1024**2;CAP=128*M;TRACE_CAP=4*M;RAM_FLOOR=512*M;HOME_FLOOR=3*1024**3;HOME_CAP=8*M
PIN='c565fce280c3559066a1ebfaf1e0385b2320df67f89a3d12ed52c7852544c688'
GIT='8dfdbdeec84cb47f902bc1426d69ecb3efd91c7c'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def usage(p):return sum(q.stat().st_blocks*512 for q in p.rglob('*') if q.is_file())
def run_main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--stage',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--execute',action='store_true');ap.add_argument('--admission-sha256');a=ap.parse_args()
 stage=a.stage.resolve();out=a.out.resolve();admission=HERE/'admission.json';d=json.loads(admission.read_text())
 if a.execute and bind(admission)['sha256']!=a.admission_sha256:raise ValueError('explicit exact admission hash required')
 for row in d['bindings']:
  if bind(Path(row['path']))!=row:raise ValueError('bound input drift '+row['path'])
 if bind(CAND)['sha256']!=PIN:raise ValueError('candidate source pin')
 if subprocess.check_output(['git','-C',str(BP),'rev-parse','HEAD'],text=True).strip()!=GIT:raise ValueError('reference package/backend HEAD')
 for name,pin in d['nested_dependencies'].items():
  p=DEPS/name
  if not (p/'.git').is_file() or subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip()!=pin:raise ValueError('real nested dependency pin '+name)
 if stage.exists() or out.exists() or stage.parent!=Path('/dev/shm') or not stage.name.startswith('zp-uce-scratch-20261122-') or out.parent!=HERE.parent:raise ValueError('fresh owned stage/out paths')
 if shutil.disk_usage('/dev/shm').free<CAP+RAM_FLOOR or shutil.disk_usage(HERE).free<HOME_FLOOR+HOME_CAP:raise ValueError('prelaunch complete remaining allocation plus floor')
 if sum(q.stat().st_size for q in HERE.parent.rglob('*') if q.is_file())>HOME_CAP:raise ValueError('8MiB source/helper/evidence family cap')
 commands=[];peak=0;tracepeak=0;state='FAIL preserved unit attempt'
 if not a.execute:
  print(json.dumps(dict(state='PREPARED ONLY source/budget/default gate PASS; no compiler/model execution',source=bind(CAND),sequence=['D64','I64-BedRock64'],workers=4,PCH=False,compiler_cache=False,stage_cap=CAP,trace_cap=TRACE_CAP,ram_floor=RAM_FLOOR,home_floor=HOME_FLOOR,admission_sha256=bind(admission)['sha256']),indent=2));return
 stage.mkdir();out.mkdir();(stage/'source').mkdir()
 own=[CAND,BP/'bp_common/src/v/bp_retained_line_store.sv',HERE/'uce_retained_tb.sv',HERE/'uce_retained_driver.cpp',HERE/'no-pch.mk']
 for p in own:shutil.copyfile(p,stage/'source'/p.name)
 before=[bind(Path(row['path'])) for row in d['bindings']]
 def guard():
  nonlocal peak,tracepeak
  family=[p for p in stage.parent.glob('zp-uce-scratch-20261122-*') if p.is_dir()];used=sum(usage(p) for p in family);peak=max(peak,used)
  traces=sum(p.stat().st_size for r in family for p in r.rglob('*.fst'));tracepeak=max(tracepeak,traces)
  if used>CAP or traces>TRACE_CAP:raise ValueError('aggregate stage/trace cap')
  if shutil.disk_usage(stage.parent).free<RAM_FLOOR+max(0,CAP-used):raise ValueError('RAM floor plus remaining aggregate allocation')
  homeused=usage(HERE.parent)
  if homeused>HOME_CAP or shutil.disk_usage(HERE).free<HOME_FLOOR+max(0,HOME_CAP-homeused):raise ValueError('HOME source/helper/evidence cap/reserve')
 def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_FSIZE,(TRACE_CAP,TRACE_CAP))
 def run(argv,cwd,log,deadline,expected_failure=None):
  guard();start=time.monotonic();p=None;failure=None
  with log.open('wb') as stream:
   try:
    p=subprocess.Popen(argv,cwd=cwd,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=limits)
    while p.poll() is None:
     guard()
     if time.monotonic()-start>deadline:raise ValueError('fixed phase timeout')
     time.sleep(.1)
    guard();raw=log.read_text(errors='replace')
    if expected_failure:
     if p.returncode==0 or expected_failure not in raw:raise ValueError('specific ownership assertion negative absent')
    elif p.returncode:raise ValueError('phase failed '+str(p.returncode))
   except BaseException as e:failure=repr(e);raise
   finally:
    if p is not None:
     try:os.killpg(p.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     p.wait(timeout=5)
     try:os.killpg(p.pid,0);left=True
     except ProcessLookupError:left=False
     row=dict(argv=argv,cwd=str(cwd),returncode=p.returncode,expected_failure=expected_failure,failure=failure,elapsed_s=time.monotonic()-start,deadline_s=deadline,owned_group_remaining=left);commands.append(row);(log.parent/(log.name+'.owned.json')).write_text(json.dumps(row,indent=2)+'\n')
     if left:raise ValueError('owned process group remains')
 try:
  for label,icache in [('D64',False),('I64-BedRock64',True)]:
   case=stage/label;case.mkdir();e=out/label;e.mkdir();src=stage/'source';bsg=DEPS/'basejump_stl'
   includes=[bsg/n for n in ('bsg_misc','bsg_cache','bsg_mem','bsg_dataflow','bsg_noc')]+[BP/n/'src/include' for n in ('bp_common','bp_me')]
   libraries=[bsg/n for n in ('bsg_misc','bsg_dataflow','bsg_mem')]+[BP/'bp_me/src/v/network',BP/'bp_me/src/v/cce',BP/'bp_common/src/v']
   argv=[str(V),'--cc','--exe','--assert','--trace-fst','--top-module','uce_retained_tb','--prefix','Vuce_retained','--Mdir',str(case/'obj'),'-Wno-fatal','-DBP_CUSTOM_BASE_CFG=bp_default_cfg_p','-DBP_DCACHE_FILL_WIDTH=64','-DBP_BEDROCK_FILL_WIDTH=64','-Gretained_lines_p=64']
   if icache:argv+=['-Ginstruction_p=1','-DBP_ICACHE_FILL_WIDTH=64']
   argv+=['+incdir+'+str(p) for p in includes]
   for p in libraries:argv+=['-y',str(p)]
   argv+=list(map(str,[BP/'bp_common/src/include/bp_common_pkg.sv',BP/'bp_me/src/include/bp_me_pkg.sv',src/'bp_retained_line_store.sv',src/'bp_uce.sv',src/'uce_retained_tb.sv',src/'uce_retained_driver.cpp']))
   run(argv,case,e/'generate.log',60)
   dat=case/'obj/Vuce_retained__verFiles.dat';ingested=[]
   for line in dat.read_text().splitlines():
    if not line.startswith('S '):continue
    fields=line.split('"')[0].split();path=Path(re.search(r'"(.*)"$',line)[1]);stat=path.stat()
    actual=(stat.st_size,stat.st_ino,stat.st_ctime_ns//10**9,stat.st_ctime_ns%10**9,stat.st_mtime_ns//10**9,stat.st_mtime_ns%10**9)
    if tuple(map(int,fields[1:7]))!=actual:raise ValueError('parsed source metadata changed '+str(path))
    ingested.append(bind(path))
   if not any(x['path']==str(src/'bp_uce.sv') and x['sha256']==PIN for x in ingested):raise ValueError('candidate not actually parsed')
   if not any(x['path']==str(src/'bp_retained_line_store.sv') for x in ingested):raise ValueError('real backend not actually parsed')
   (e/'actual-source-ingestion.json').write_text(json.dumps(ingested,indent=2)+'\n')
   run(['make','-C',str(case/'obj'),'-f','Vuce_retained.mk','-f',str(src/'no-pch.mk'),'-j4','OBJCACHE='],case,e/'compile.log',240)
   if list(case.rglob('*.gch')):raise ValueError('PCH artifact despite no-PCH overlay')
   binary=case/'obj/Vuce_retained';run([str(binary)],case,e/'unit.log',60)
   raw=(e/'unit.log').read_text();marker='[UCE-RETAINED-I] PASS:' if icache else '[UCE-RETAINED] PASS:'
   if marker not in raw or '[UCE-SCRATCH-TURNOVER] PASS:' not in raw:raise ValueError('old and new full512 scoreboards required')
   for sub,args,negative in [('short-response',['--short-response'],'UCE prefetch response has no live slot'),('short-response-drain',['--short-response-drain'],None)]:
    c=case/sub;c.mkdir();run([str(binary)]+args,c,e/(sub+'.log'),30,negative)
    if sub=='short-response-drain' and '[UCE-SHORT-DRAIN] PASS:' not in (e/(sub+'.log')).read_text():raise ValueError('legacy partial-packet drain guard missing')
   for p in case.rglob('*.fst'):q=e/p.relative_to(case);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
   shutil.copyfile(case/'obj/Vuce_retained__verFiles.dat',e/'source-ingestion.dat')
  if before!=[bind(Path(row['path'])) for row in d['bindings']]:raise ValueError('bound source/helper drift')
  state='PASS real UCE/backend D64+I64 scratch lifetime/turnover; no fullcore/area/FPGA claim'
 finally:
  # Preserve closed or partial failure traces too; no retry overwrites RAM/output.
  for p in stage.rglob('*.fst'):
   q=out/p.relative_to(stage);q.parent.mkdir(parents=True,exist_ok=True)
   if not q.exists():shutil.copyfile(p,q)
  proof=dict(state=state,admission=bind(admission),candidate=bind(CAND),commands=commands,source_before=before,source_after=[bind(Path(row['path'])) for row in d['bindings']],aggregate_stage_peak_allocated_bytes=peak,aggregate_trace_peak_bytes=tracepeak,stage_cap_bytes=CAP,trace_cap_bytes=TRACE_CAP,stage=str(stage),PCH=False,compiler_cache=False,compiler_workers=4,artifacts=[bind(p) for p in sorted(out.rglob('*')) if p.is_file()]);(out/'manifest.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(state=state,manifest=bind(out/'manifest.json'))))
if __name__=='__main__':run_main()
