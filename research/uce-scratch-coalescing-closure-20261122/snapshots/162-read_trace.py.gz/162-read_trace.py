import subprocess,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;F=R.parent/'matched-attempt01/baseline-I128-mixed/uce-retained.fst'
p=subprocess.Popen(['/usr/bin/fst2vcd',str(F)],stdout=subprocess.PIPE,text=True);sc=[];selected={};vals={};initial={};events=[];header=True;now=0;previous=None
names={'instruction_p','icache_fill_width_p','dcache_fill_width_p','bedrock_fill_width_p','fill_lp','cache_data_lp','arrays_accept_i','rev_v_i','rev_ready_o','rev_word_i','data_v_o','state_r','load_resp_v_li','load_resp_yumi_lo','fsm_rev_v_li','fsm_rev_yumi_lo','retained_hit_r','retained_capture_beat','in_data_width_p','out_data_width_p','msg_v_li','msg_ready_and_lo','msg_v_o','msg_ready_param_i','count_r','last_word','ready_and_o','ready_and_i','v_i','v_o','receiving','sending','len_i','sipop_len_li','bits_r','head_r','tail_r','empty_r','full_r'}
def flush():
 global previous
 row={n:vals.get(k) for k,ns in selected.items() for n in ns}
 if row!=previous:events.append(dict(time=now,signals=row));previous=row
for line in p.stdout:
 s=line.strip()
 if header:
  if s.startswith('$scope'):sc.append(s.split()[2])
  elif s.startswith('$upscope'):sc.pop()
  elif s.startswith('$var'):
   a=s.split();name='.'.join(sc+[a[4]])
   if a[4] in names and (len(sc)<=3 or '.rev_pump_in' in name):selected.setdefault(a[3],[]).append(name)
  elif s.startswith('$enddefinitions'):header=False
  continue
 if s.startswith('#'):flush();now=int(s[1:]);continue
 if not s or s[0]=='$':continue
 if s[0] in 'bBrR':a=s[1:].split();v,k=a[0],a[1]
 else:v,k=s[0],s[1:]
 if k in selected:
  try:vals[k]=int(v,2)
  except ValueError:vals[k]=v
  for n in selected[k]:initial.setdefault(n,vals[k])
flush();assert p.wait()==0
out=dict(input=dict(path=str(F),bytes=F.stat().st_size,sha256=hashlib.sha256(F.read_bytes()).hexdigest()),reader_returncode=0,initial=initial,state_changes=events,last_trace_time=now,last_state=previous)
(R/'frame.json').write_text(json.dumps(out,indent=2)+'\n')
print('state changes',len(events),'last',now)
for n,v in previous.items():
 if any(x in n for x in ('widen.sipop','gearbox.msg_v_li','gearbox.msg_ready_and_lo','load_resp','rev_ready_o','arrays_accept','data_v_o','retained_hit_r')):print(n,v)
