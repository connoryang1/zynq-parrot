# PREPARE ONLY: one future600s batch, five fixed geometries, no retry.
set_param general.maxThreads 8
puts "ACTUAL_TOOL_VERSION [version -short]"
puts "ACTUAL_MAX_THREADS [get_param general.maxThreads]"
if {![string match 2024.2* [version -short]] || [get_param general.maxThreads]!=8} {error "wrong tool/thread configuration"}
foreach lines {1280 1536 1792 1856 1920} {
  set label lines${lines}
  if {[llength [glob -nocomplain ${label}-*]]} {error "fresh case outputs required"}
  create_project -in_memory -part xc7z020clg400-1
  read_verilog -sv ram_probe.sv
  synth_design -top retained_private_ram_probe -part xc7z020clg400-1 -directive Default -global_retiming on -control_set_opt_threshold 1 -generic paddr_width_p=34 -generic sets_p=256 -generic epoch_width_p=8 -generic i_lines_p=$lines -generic d_lines_p=$lines
  create_clock -name lane0 -period 50 [get_ports {clk_i[0]}]
  create_clock -name lane1 -period 50 [get_ports {clk_i[1]}]
  set_clock_groups -asynchronous -group lane0 -group lane1
  report_utilization -hierarchical -file ${label}-utilization.rpt
  set f [open ${label}-primitives.tsv w]
  puts $f "cell\tprimitive\tram_mode\tread_a\twrite_a\tread_b\twrite_b\twrite_mode_a\twrite_mode_b\tdoa_reg\tdob_reg\tclock_a\tclock_b"
  foreach c [lsort [get_cells -hier -filter {REF_NAME =~ RAMB*}]] {
    set row [list $c [get_property REF_NAME $c]]
    foreach prop {RAM_MODE READ_WIDTH_A WRITE_WIDTH_A READ_WIDTH_B WRITE_WIDTH_B WRITE_MODE_A WRITE_MODE_B DOA_REG DOB_REG} {
      if {[lsearch -exact [list_property $c] $prop]>=0} {lappend row [get_property $prop $c]} else {lappend row "-"}
    }
    foreach pin {CLKARDCLK CLKBWRCLK} {lappend row [join [lsort [get_clocks -quiet -of_objects [get_pins -quiet $c/$pin]]] ,]}
    puts $f [join $row [format %c 9]]
  }
  close $f
  set f [open ${label}-all-primitives.tsv w]
  foreach c [lsort [get_cells -hier -filter {IS_PRIMITIVE == 1}]] {puts $f [join [list $c [get_property REF_NAME $c]] [format %c 9]]}
  close $f
  write_checkpoint ${label}-synthesized.dcp
  close_project
}
