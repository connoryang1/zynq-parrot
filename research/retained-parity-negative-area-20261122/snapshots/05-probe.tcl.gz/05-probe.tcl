# Fixed production-options RAM/controller probe; no implementation or fit.
set cases [dict create baseline1792 {backend-baseline.sv 1792} parity1792 {backend-parity.sv 1792}]
if {[llength $argv]!=1 || ![dict exists $cases [lindex $argv 0]]} {error "one fixed arm required"}
set arm [lindex $argv 0]
lassign [dict get $cases $arm] backend lines
set base [file dirname [file normalize [info script]]]
set_param general.maxThreads 8
create_project -in_memory -part xc7z020clg400-1
puts "ACTUAL_TOOL_VERSION [version -short]"
puts "ACTUAL_MAX_THREADS [get_param general.maxThreads]"
puts "FIXED_ARM $arm I=$lines D=$lines sets=256 epoch=8 PA=34"
if {![string match 2024.2* [version -short]] || [get_param general.maxThreads]!=8} {error "tool/thread identity"}
# Combined production files each contain their exact helper definitions once.
read_verilog -sv [file join $base $backend]
read_verilog -sv [file join $base wrapper.sv]
read_xdc [file join $base clock.xdc]
synth_design -top retained_production_controls -part xc7z020clg400-1 -directive AreaOptimized_high -global_retiming on -control_set_opt_threshold 1 -generic i_lines_p=$lines -generic d_lines_p=$lines -generic sets_p=256 -generic paddr_width_p=34 -generic epoch_width_p=8
foreach pin {{clk_i[0]} {clk_i[1]}} {if {[llength [get_ports -quiet $pin]]!=1} {error "owning clock port not resolved"}}
set bb [get_cells -quiet -hier -filter {IS_BLACKBOX == 1}]
set f [open blackboxes.txt w]; puts $f $bb; close $f
if {[llength $bb]!=0} {error "unresolved blackbox cells"}
set f [open clocks.tsv w]
foreach c [get_clocks] {puts $f [join [list $c [get_property PERIOD $c] [get_property WAVEFORM $c]] "\t"]}
close $f
report_utilization -hierarchical -file utilization.rpt
set f [open primitives.tsv w]
puts $f "name\tREF_NAME\tIS_PRIMITIVE"
foreach c [lsort [get_cells -hier]] {puts $f [join [list $c [get_property REF_NAME $c] [get_property IS_PRIMITIVE $c]] "\t"]}
close $f
set f [open block-ports.tsv w]
puts $f "name\tREF_NAME\tRAM_MODE\tREAD_WIDTH_A\tWRITE_WIDTH_A\tREAD_WIDTH_B\tWRITE_WIDTH_B\tWRITE_MODE_A\tWRITE_MODE_B\tDOA_REG\tDOB_REG"
set clocks [open block-clocks.tsv w];puts $clocks "cell\tclock_pin\tnets\tclocks"
foreach c [lsort [get_cells -hier -filter {REF_NAME =~ RAMB*}]] {
  set row [list $c [get_property REF_NAME $c]]
  foreach prop {RAM_MODE READ_WIDTH_A WRITE_WIDTH_A READ_WIDTH_B WRITE_WIDTH_B WRITE_MODE_A WRITE_MODE_B DOA_REG DOB_REG} {lappend row [get_property $prop $c]}
  puts $f [join $row "\t"]
  foreach p [get_pins -of_objects $c -filter {REF_PIN_NAME == CLKARDCLK || REF_PIN_NAME == CLKBWRCLK || REF_PIN_NAME == CLKA || REF_PIN_NAME == CLKB}] {
    puts $clocks [join [list $c $p [get_nets -of_objects $p] [get_clocks -of_objects $p]] "\t"]
  }
}
close $f;close $clocks
set f [open metadata-cells.tsv w]
puts $f "group\tname\tREF_NAME\tIS_PRIMITIVE"
foreach c [lsort [get_cells -hier]] {
 set name $c;set group ""
 if {[string match {*distributed_epochs*epoch_ram*} $name]} {set group "D_epoch"}
 if {[string match {*packed_storage*validity*} $name]} {set group "validity_broad"}
 if {$group!=""} {puts $f [join [list $group $c [get_property REF_NAME $c] [get_property IS_PRIMITIVE $c]] "\t"]}
}
close $f
write_checkpoint -force synthesized.dcp
write_verilog -mode funcsim functional.v
puts "CELL36_PRODUCTION_INFERENCE_COMPLETE $arm"
