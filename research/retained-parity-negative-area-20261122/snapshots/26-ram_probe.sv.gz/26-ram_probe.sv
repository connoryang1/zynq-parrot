// Exact frozen SP owning-clock RAM fragment, isolated from FSM/metadata.
module retained_private_ram_probe
 #(parameter int unsigned paddr_width_p=34
   ,parameter int unsigned sets_p=256
   ,parameter int unsigned i_lines_p=1280
   ,parameter int unsigned d_lines_p=1280
   ,parameter int unsigned epoch_width_p=8)
 (clk_i,tag_v,tag_w,data_v,data_w,tag_addr,data_addr,tag_wdata,data_wdata,tag_rdata,data_rdata);
  localparam int set_width_lp = (sets_p > 1) ? $clog2(sets_p) : 1;
  localparam int set_bits_lp = $clog2(sets_p);
  localparam int tag_width_lp = paddr_width_p - 6 - set_bits_lp;
  localparam int total_lines_lp = i_lines_p + d_lines_p;
  localparam int ram_lines_lp = (total_lines_lp > 0) ? total_lines_lp : 1;
  localparam int tag_addr_width_lp = (ram_lines_lp > 1) ? $clog2(ram_lines_lp) : 1;
  localparam int data_addr_width_lp = $clog2(ram_lines_lp * 8);
  typedef struct packed {
    logic valid;
    logic [epoch_width_p-1:0] epoch;
    logic [tag_width_lp-1:0] tag;
  } tag_info_s;
  localparam int tag_bits_lp = $bits(tag_info_s);

  input logic [1:0] clk_i;
  input logic [1:0] tag_v,tag_w,data_v,data_w;
  input logic [1:0][tag_addr_width_lp-1:0] tag_addr;
  input logic [1:0][data_addr_width_lp-1:0] data_addr;
  input logic [1:0][tag_bits_lp-1:0] tag_wdata;
  input logic [1:0][63:0] data_wdata;
  output wire [1:0][tag_bits_lp-1:0] tag_rdata;
  output wire [1:0][63:0] data_rdata;
  for (genvar lane = 0; lane < 2; lane++) begin : lane_fsm
    localparam int lines_lp = (lane == 0) ? i_lines_p : d_lines_p;
    localparam int base_lp = (lane == 0) ? 0 : i_lines_p;
    localparam int local_addr_width_lp = (lines_lp > 1) ? $clog2(lines_lp) : 1;
    localparam int lane_ram_lines_lp = (lines_lp > 0) ? lines_lp : 1;
    localparam int lane_data_addr_width_lp = $clog2(lane_ram_lines_lp * 8);
    // Static lane ownership needs only one synchronous read/write port.
    // Preserve read-first behavior, enables and read latency; only physical
    // storage/indexing changes. Existing global-address assertions below still
    // bound every access. Disabled lanes never access their placeholder arrays.
    /* verilator tracing_off */
    (* ram_style = "block", ram_decomp = "area" *) logic [tag_bits_lp-1:0] tag_mem [lane_ram_lines_lp];
    (* ram_style = "block", ram_decomp = "area" *) logic [63:0] payload_mem [lane_ram_lines_lp * 8];
    /* verilator tracing_on */
    logic [tag_bits_lp-1:0] tag_q;
    logic [63:0] data_q;
    wire [local_addr_width_lp-1:0] local_tag_addr
      = local_addr_width_lp'(tag_addr[lane] - tag_addr_width_lp'(base_lp));
    wire [lane_data_addr_width_lp-1:0] local_data_addr
      = lane_data_addr_width_lp'(data_addr[lane] - data_addr_width_lp'(base_lp * 8));
    assign tag_rdata[lane] = tag_q;
    assign data_rdata[lane] = data_q;
    always @(posedge clk_i[lane]) begin
      if (tag_v[lane]) begin
        if (tag_w[lane]) tag_mem[local_tag_addr] <= tag_wdata[lane];
        tag_q <= tag_mem[local_tag_addr];
      end
      if (data_v[lane]) begin
        if (data_w[lane]) payload_mem[local_data_addr] <= data_wdata[lane];
        data_q <= payload_mem[local_data_addr];
      end
    end
  end
endmodule
