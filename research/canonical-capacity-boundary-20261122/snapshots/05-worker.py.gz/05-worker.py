#!/usr/bin/env python3
"""ROOT per-VM one-job CAD worker, never an atomic/global lock or board owner."""
import argparse,collections,datetime,hashlib,json,os,re,resource,shutil,signal,socket,sys,time,uuid
from pathlib import Path
sys.dont_write_bytecode=True
import software_owned_v2 as owned
HERE=Path(__file__).resolve().parent
OUT=HERE/'run01'
A=HERE/'admission.json'
WRAPPER=Path('/home/coyang/zynq-parrot/codex-skills/bp-fpga-synthesis/scripts/run_vivado_2024_2.sh')
CAP=64*1024**2
FLOOR=3*1024**3
CASES=['canonical1793','canonical1824']
SETTINGS={'top': 'retained_production_controls', 'device': 'xc7z020clg400-1', 'Vivado': '2024.2', 'max_threads': 8, 'paddr_width': 34, 'sets': 256, 'epoch_width': 8, 'I_invalidate': 0, 'I_invalidate_address': 0, 'D_invalidate': 'variable', 'all_other_client_ports': 'live', 'clock_period_ns': 50, 'I_waveform_ns': [0, 25], 'D_waveform_ns': [25, 50], 'synthesis_directive': 'AreaOptimized_high', 'global_retiming': 'on', 'control_set_opt_threshold': 1, 'KEEP_attributes_added': False, 'implementation_or_route': False}
VENDOR_NAMES={'vivado','vivado_lab','xelab','xsim','xsimk','xsimk.exe','xvlog','xsc','vitis_hls','v++','planahead'}
VENDOR_LAUNCHERS={'run_vivado_2024_2.sh','launch_synthesis.sh'}
class ForeignJob(RuntimeError):pass
class Deferred(RuntimeError):pass

def require(ok,msg):
 if not ok:raise ValueError(msg)
def bind(p):
 p=Path(p);raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def save(p,o):
 tmp=p.with_name(p.name+'.tmp');tmp.write_text(json.dumps(o,indent=2)+'\n');tmp.replace(p)
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def usage(p):return sum(f.stat().st_size for f in p.rglob('*') if f.is_file()) if p.exists() else 0
def stat_row(pid):
 p=Path('/proc')/str(pid);text=(p/'stat').read_text();end=text.rfind(')');fields=text[end+2:].split()
 return dict(pid=int(pid),comm=text[text.find('(')+1:end],ppid=int(fields[1]),pgid=int(fields[2]),state=fields[0],startticks=int(fields[19]))
def process_rows():
 rows=[]
 for p in Path('/proc').glob('[0-9]*'):
  try:
   rec=stat_row(p.name);cmd=(p/'cmdline').read_bytes().split(b'\0');rec['argv']=[x.decode(errors='replace') for x in cmd if x]
   if stat_row(p.name)['startticks']!=rec['startticks']:continue
   rows.append(rec)
  except (FileNotFoundError,ProcessLookupError):continue
  except PermissionError:
   # Kernel process identity remains the basic global vendor check. Never
   # expose unrelated inaccessible command lines or search credentials.
   try:rec=stat_row(p.name);rec['argv']=[];rec['cmdline_unreadable']=True;rows.append(rec)
   except (FileNotFoundError,ProcessLookupError):continue
 return rows

def is_vendor(row):
 if row['comm'].lower() in VENDOR_NAMES:return True
 if row['comm'].lower() in ('pgrep','ps','grep'):return False
 return any(str(arg).split('/')[-1].lower() in VENDOR_NAMES|VENDOR_LAUNCHERS for arg in row.get('argv',[]))
def vendor_inventory(rows,allowed_pgid=None):
 result=[]
 for r in rows:
  if not is_vendor(r) or (allowed_pgid is not None and r['pgid']==allowed_pgid):continue
  item={k:r[k] for k in ('pid','comm','ppid','pgid','state','startticks')}
  item['executable']=r.get('argv',[''])[0] if r.get('argv') else None
  item['argv_sha256']=hashlib.sha256('\0'.join(r.get('argv',[])).encode()).hexdigest();result.append(item)
 return result
def empty_inventory():
 rows=vendor_inventory(process_rows());
 if rows:raise Deferred('global vendor/launcher inventory busy: '+json.dumps(rows,sort_keys=True))
 return dict(utc=utc(),vendor_processes=[])
def validate_ack(record,identity,admission_sha,claim=None):
 for k in ('hostname','pid','startticks','pgid','nonce'):
  require(record.get(k)==identity[k],'ROOT ownership receipt identity changed '+k)
 require(record.get('admission_sha256')==admission_sha and record.get('linux_claim_state')=='ACK','ROOT Linux CAD claim revoked/changed')
 if claim is not None:require(record.get('linux_claim')==claim,'current ACK Linux claim changed')
 require(record.get('basis')=='coordinator conditional release + ROOT perVM onejobprotocol','ownership basis changed')

def analyze(folder,arm):
 require(not (folder/'blackboxes.txt').read_text().strip(),'unresolved synthesized blackbox')
 clocks={}
 for line in (folder/'clocks.tsv').read_text().splitlines():
  n,p,w=line.split('\t');clocks[n]=[float(p),[float(x) for x in w.strip('{}').split()]]
 require(clocks=={'I_owning_clock':[50.0,[0.0,25.0]],'D_owning_clock':[50.0,[25.0,50.0]]},'actual clocks/waveforms')
 for name in ['clocks.tsv','utilization.rpt','primitives.tsv','block-ports.tsv','block-clocks.tsv','metadata-cells.tsv','synthesized.dcp','functional.v']:
  require((folder/name).is_file() and (folder/name).stat().st_size>0,'required artifact '+name)
 text=(folder/'utilization.rpt').read_text();match=re.search(r'^\| retained_production_controls\s*\|\s*\(top\)\s*\|([^\n]+)\|$',text,re.M);require(match is not None,'exact top utilization row')
 values=[int(x.strip().replace(',','')) for x in match[1].split('|')];require(len(values)==8,'eight actual resource columns')
 resources=dict(zip(['LUT','logic_LUT','LUTRAM','SRL','FF','RAMB36','RAMB18','DSP'],values));resources['BRAM36_tiles']=resources['RAMB36']+resources['RAMB18']/2
 blocks=(folder/'block-ports.tsv').read_text().splitlines();require(blocks and blocks[0].startswith('name\tREF_NAME\tRAM_MODE'),'RAM pin report schema')
 rows=[]
 for line in blocks[1:]:
  fields=line.split('\t');require(len(fields)==11,'all actual RAM port properties');rows.append(dict(zip(blocks[0].split('\t'),fields)))
 meta=collections.defaultdict(collections.Counter)
 for line in (folder/'metadata-cells.tsv').read_text().splitlines()[1:]:
  group,name,ref,primitive=line.split('\t');meta[group][ref]+=1
 log=(folder/'console.log').read_text();require(log.count('CANONICAL_BOUNDARY_INFERENCE_COMPLETE '+arm)==1,'complete fixed arm marker')
 require('ACTUAL_TOOL_VERSION 2024.2' in log and 'ACTUAL_MAX_THREADS 8' in log,'actual tool/thread provenance')
 return dict(resources=resources,block_ports=rows,metadata_raw_named_refs={k:dict(v) for k,v in meta.items()},actual_clocks=clocks,
             scope='Actual outcome retained even if storage/width/FF goals fail. Macro/leaf counts overlap, not additive sites. Standalone synthesized component, not mapped functional/fullCPU/fit/application proof.')

def validate_inputs(a,sha,allow_pending=False):
 require(bind(A)['sha256']==sha,'exact ROOT-reviewed admission SHA')
 require(a['schema']=='canonical-boundary-root-pervm-mapping-v1','new fixed two-arm schema')
 require(a['launchable'] is True and a['resource_only'] is True and a['functional_claim'] is False,'ROOT-reviewed resource-only admission, no new-depth functional claim')
 require(a['canonical_source']['commit']=='8dfdbdeec84cb47f902bc1426d69ecb3efd91c7c' and a['canonical_source']['sha256']=='68d1dd0c7df7e56ffe76317f9bae5a3ca3e09d13cb44d1167c0f737acefcbea6','exact canonical source')
 require(bind(HERE/'backend-canonical.sv')['sha256']==a['canonical_source']['sha256'],'canonical uploaded bytes')
 require(a['ownership']['basis']=='coordinator conditional release + ROOT perVM onejobprotocol','fixed ownership basis')
 require(a['cases']==[dict(name='canonical1793',source='backend-canonical.sv',i_lines=1793,d_lines=1793),dict(name='canonical1824',source='backend-canonical.sv',i_lines=1824,d_lines=1824)],'fixed2arm order/geometry')
 require(a['settings']==SETTINGS,'fixed matched production settings')
 for row in a['sources']:
  got=bind(HERE/row['name']);require(all(got[k]==row[k] for k in ('bytes','sha256')),'uploaded source drift '+row['name'])
 require(a['limits']==dict(per_arm_native_seconds=580,per_arm_parent_seconds=620,batch_seconds=1300,remote_total_artifact_bytes=CAP,local_total_artifact_bytes=CAP,source_preparation_bytes=8*1024**2,HOME_floor_bytes=FLOOR,owned_cleanup_seconds=5,attempts_per_arm=1,retries=0,extensions=0),'fixed limits')

def vendor_command(arm):
 require(arm in CASES,'fixed vendor arm')
 # -tclargs consumes all following arguments, so it must be LAST.
 return [str(WRAPPER),'-mode','batch','-source',str(HERE/'probe.tcl'),'-log','vivado.log','-journal','vivado.jou','-tclargs',arm]

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true');parser.add_argument('--inventory',action='store_true');parser.add_argument('--admission-sha256');args=parser.parse_args()
 require(args.execute!=args.inventory,'one explicit action')
 a=json.loads(A.read_text());sha=bind(A)['sha256'];validate_inputs(a,args.admission_sha256 or sha)
 if args.inventory:
  print(json.dumps(dict(hostname=socket.gethostname(),utc=utc(),vendor_inventory=vendor_inventory(process_rows()),basis=a['ownership']['basis']),indent=2));return
 require(args.admission_sha256==sha,'execute needs exact reviewed SHA')
 require(socket.gethostname()==a['target_hostname'],'wrong actual VM hostname')
 require(bind(WRAPPER)['sha256']==a['tool_wrapper']['sha256'],'actual tool wrapper source')
 require(not OUT.exists(),'fresh one-shot remote output')
 # This read/publish protocol is deliberately not described as an atomic lock.
 # A concurrent appearance is detected while running and aborts only our PG.
 try:initial=empty_inventory()
 except Deferred as e:
  print(json.dumps(dict(state='DEFER before any vendor launch',hostname=socket.gethostname(),admission_sha256=sha,reason=str(e),vendor_attempts=0),sort_keys=True),flush=True);raise SystemExit(75)
 require(shutil.disk_usage(HERE).free>=FLOOR+CAP-usage(HERE) and shutil.disk_usage('/home/coyang').free>=FLOOR+CAP-usage(HERE),'3GiB disk floor plus remaining64MiB')
 OUT.mkdir();identity=stat_row(os.getpid());identity=dict(hostname=socket.gethostname(),pid=os.getpid(),startticks=identity['startticks'],pgid=os.getpgrp(),nonce=uuid.uuid4().hex)
 receipt=dict(schema='bp1-root-pervm-cad-ownership-receipt-v1',**identity,utc=utc(),admission_sha256=sha,linux_claim_state='ACK',linux_claim=a['ownership']['linux_claim'],basis=a['ownership']['basis'],all_vendor_inventory_empty=initial,atomic_global_lock=False)
 receipt_path=OUT/'ROOT-ownership.json';save(receipt_path,receipt);save(OUT/'ROOT-ownership-initial.json',receipt);print('ROOT_CAD_ACK '+json.dumps(receipt,sort_keys=True),flush=True)
 state=dict(state='RUNNING ROOT perVM mapping protocol',admission=bind(A),ownership_receipt=bind(OUT/'ROOT-ownership-initial.json'),ownership_current_path=str(receipt_path),ownership_identity=identity,arms=[],foreign_inventory_events=[],no_board_operations=True)
 started=time.monotonic();active=None;arm_armed=False
 def interrupted(sig,frame):raise RuntimeError('ROOT worker signal '+str(sig))
 for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGHUP]:signal.signal(sig,interrupted)
 def guard():
  nonlocal active
  require(time.monotonic()-started<1300,'fixed batch1300s deadline')
  used=usage(HERE);require(used<=CAP,'64MiB complete remote artifact cap');require(shutil.disk_usage(HERE).free>=FLOOR+CAP-used and shutil.disk_usage('/home/coyang').free>=FLOOR+CAP-used,'3GiB floor plus remaining output')
  require(bind(A)['sha256']==sha,'reviewed admission changed during acquisition')
  validate_ack(json.loads(receipt_path.read_text()),identity,sha,a['ownership']['linux_claim'])
  rows=process_rows()
  if arm_armed and active is None:
   children=[r for r in rows if r['ppid']==os.getpid() and r['pgid']==r['pid']]
   require(len(children)<=1,'unexpected simultaneous ROOT child groups')
   if children:active={k:children[0][k] for k in ('pid','pgid','startticks')}
  leader=next((r for r in rows if active and r['pid']==active['pid'] and r['startticks']==active['startticks']),None)
  allowed=active['pgid'] if leader else None
  foreign=vendor_inventory(rows,allowed)
  if foreign:
   state['foreign_inventory_events'].append(dict(utc=utc(),rows=foreign))
   if active is None:raise Deferred('foreign owner/job before owned vendor group creation; no new launch')
   raise ForeignJob('foreign vendor/launcher appeared; stop only ownedPG')
 try:
  for arm in CASES:
   validate_inputs(a,sha);guard();idle=empty_inventory()
   folder=OUT/arm;folder.mkdir();row=dict(arm=arm,prelaunch_global_idle=idle,argv=vendor_command(arm));state['arms'].append(row);save(OUT/'session.json',state)
   active=None;arm_armed=True
   def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_FSIZE,(CAP,CAP))
   with (folder/'console.log').open('wb') as log:
    try:row['owned_receipt']=owned.run(row['argv'],folder,dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),log,580,guard,limits)
    except BaseException as e:row['owned_receipt']=getattr(e,'owned_receipt',dict(owned_pgid=None,returncode=None,failure=repr(e),owned_group_remaining=False,scope='prePopen refusal'));raise
   arm_armed=False
   require(row['owned_receipt']['returncode']==0,'native Vivado arm failed')
   if active:require(row['owned_receipt']['owned_pgid']==active['pgid'],'discovered owner group differs from actual lifecycle')
   active=None;guard();empty_inventory();row['analysis']=analyze(folder,arm)
   row['artifacts']=[bind(p) for p in sorted(folder.rglob('*')) if p.is_file()];save(OUT/'session.json',state)
  validate_inputs(a,sha);guard();state['state']='PASS two unmeasured-depth canonical resource acquisitions; no functional/fit claim'
 except BaseException as e:
  state.update(state='DEFERRED/ABORTED preserved; no retries or foreign signaling',error=repr(e));raise
 finally:
  for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGHUP]:signal.signal(sig,signal.SIG_IGN)
  arm_armed=False
  try:
   validate_inputs(a,sha);require(bind(WRAPPER)['sha256']==a['tool_wrapper']['sha256'],'tool wrapper drift');state['source_endcheck']='PASS'
  except BaseException as e:state.update(state='FAIL source-endcheck, preserved',source_endcheck_error=repr(e))
  remaining=any(r.get('owned_receipt',{}).get('owned_group_remaining',False) for r in state['arms'])
  if active and owned.group_state(active['pgid']):remaining=True
  final=dict(receipt,linux_claim_state='HELD_OWNED_GROUP_REMAINS' if remaining else 'RELEASED',release_utc=utc(),outcome=state['state'],owned_group_remaining=remaining)
  # Never replace a receipt that someone else revoked or reassigned.
  try:
   current=json.loads(receipt_path.read_text())
   if all(current.get(k)==identity[k] for k in identity) and current.get('linux_claim_state')=='ACK':save(receipt_path,final)
   else:save(OUT/'ROOT-ownership-final.json',final)
  except BaseException as e:state['ownership_release_error']=repr(e)
  if remaining:state['state']='FAIL owned group remains; CAD claim HELD, not released'
  state.update(elapsed_seconds=time.monotonic()-started,ownership_final=final)
  save(OUT/'session.json',state);print(state['state'],flush=True)
if __name__=='__main__':main()
