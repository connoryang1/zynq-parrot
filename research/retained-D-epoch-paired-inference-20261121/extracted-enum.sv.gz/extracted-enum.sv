    typedef enum logic [3:0] {
      e_clear, e_idle, e_lookup_tag, e_lookup_compare, e_lookup_data,
      e_lookup_collect, e_insert_tag, e_insert_compare, e_insert_invalidate,
      e_insert_data
    } state_e;
