// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.2 (lin64) Build 5239630 Fri Nov 08 22:34:34 MST 2024
// Date        : Sat Nov 21 15:40:34 2026
// Host        : blackparrot1 running 64-bit Ubuntu 20.04.6 LTS
// Command     : write_verilog -mode funcsim -rename_top epoch_current current-functional.v
// Design      : epoch_probe
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z020clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* epoch_width_p = "8" *) (* lane = "1" *) (* lines_lp = "1792" *) 
(* paddr_width_p = "34" *) (* set_width_lp = "8" *) (* sets_p = "256" *) 
(* NotValidForBitStream *)
module epoch_current
   (clk_d_i,
    reset_d_i,
    clear_d_i,
    inv_v_i,
    inv_addr_i,
    insert_paddr_i,
    state_i,
    set_i,
    clear_slot_i,
    tag_valid_i,
    tag_epoch_i,
    line_epoch_o,
    inv_epoch_o,
    wrap_o,
    clear_now_o,
    set_kill_o,
    valid_tag_o);
  input clk_d_i;
  input reset_d_i;
  input clear_d_i;
  input inv_v_i;
  input [33:0]inv_addr_i;
  input [33:0]insert_paddr_i;
  input [3:0]state_i;
  input [7:0]set_i;
  input [10:0]clear_slot_i;
  input tag_valid_i;
  input [7:0]tag_epoch_i;
  output [7:0]line_epoch_o;
  output [7:0]inv_epoch_o;
  output wrap_o;
  output clear_now_o;
  output set_kill_o;
  output valid_tag_o;

  wire clear_d_i;
  wire clear_d_i_IBUF;
  wire clear_now_o;
  wire clear_now_o_OBUF;
  wire [10:0]clear_slot_i;
  wire [7:0]clear_slot_i_IBUF;
  wire clk_d_i;
  wire clk_d_i_IBUF;
  wire clk_d_i_IBUF_BUFG;
  wire [7:0]epoch_read_set;
  wire epochs_r_reg_r1_0_63_0_2_i_11_n_0;
  wire epochs_r_reg_r1_0_63_0_2_i_12_n_0;
  wire epochs_r_reg_r1_0_63_0_2_i_13_n_0;
  wire epochs_r_reg_r1_0_63_0_2_i_4_n_0;
  wire epochs_r_reg_r1_0_63_0_2_n_0;
  wire epochs_r_reg_r1_0_63_0_2_n_1;
  wire epochs_r_reg_r1_0_63_0_2_n_2;
  wire epochs_r_reg_r1_0_63_3_5_i_4_n_0;
  wire epochs_r_reg_r1_0_63_3_5_i_5_n_0;
  wire epochs_r_reg_r1_0_63_3_5_i_6_n_0;
  wire epochs_r_reg_r1_0_63_3_5_n_0;
  wire epochs_r_reg_r1_0_63_3_5_n_1;
  wire epochs_r_reg_r1_0_63_3_5_n_2;
  wire epochs_r_reg_r1_0_63_6_7_n_0;
  wire epochs_r_reg_r1_0_63_6_7_n_1;
  wire epochs_r_reg_r1_128_191_0_2_i_1_n_0;
  wire epochs_r_reg_r1_128_191_0_2_n_0;
  wire epochs_r_reg_r1_128_191_0_2_n_1;
  wire epochs_r_reg_r1_128_191_0_2_n_2;
  wire epochs_r_reg_r1_128_191_3_5_n_0;
  wire epochs_r_reg_r1_128_191_3_5_n_1;
  wire epochs_r_reg_r1_128_191_3_5_n_2;
  wire epochs_r_reg_r1_128_191_6_7_n_0;
  wire epochs_r_reg_r1_128_191_6_7_n_1;
  wire epochs_r_reg_r1_192_255_0_2_i_1_n_0;
  wire epochs_r_reg_r1_192_255_0_2_n_0;
  wire epochs_r_reg_r1_192_255_0_2_n_1;
  wire epochs_r_reg_r1_192_255_0_2_n_2;
  wire epochs_r_reg_r1_192_255_3_5_n_0;
  wire epochs_r_reg_r1_192_255_3_5_n_1;
  wire epochs_r_reg_r1_192_255_3_5_n_2;
  wire epochs_r_reg_r1_192_255_6_7_n_0;
  wire epochs_r_reg_r1_192_255_6_7_n_1;
  wire epochs_r_reg_r1_64_127_0_2_i_1_n_0;
  wire epochs_r_reg_r1_64_127_0_2_n_0;
  wire epochs_r_reg_r1_64_127_0_2_n_1;
  wire epochs_r_reg_r1_64_127_0_2_n_2;
  wire epochs_r_reg_r1_64_127_3_5_n_0;
  wire epochs_r_reg_r1_64_127_3_5_n_1;
  wire epochs_r_reg_r1_64_127_3_5_n_2;
  wire epochs_r_reg_r1_64_127_6_7_n_0;
  wire epochs_r_reg_r1_64_127_6_7_n_1;
  wire epochs_r_reg_r2_0_63_0_2_n_0;
  wire epochs_r_reg_r2_0_63_0_2_n_1;
  wire epochs_r_reg_r2_0_63_0_2_n_2;
  wire epochs_r_reg_r2_0_63_3_5_n_0;
  wire epochs_r_reg_r2_0_63_3_5_n_1;
  wire epochs_r_reg_r2_0_63_3_5_n_2;
  wire epochs_r_reg_r2_0_63_6_7_n_0;
  wire epochs_r_reg_r2_0_63_6_7_n_1;
  wire epochs_r_reg_r2_128_191_0_2_n_0;
  wire epochs_r_reg_r2_128_191_0_2_n_1;
  wire epochs_r_reg_r2_128_191_0_2_n_2;
  wire epochs_r_reg_r2_128_191_3_5_n_0;
  wire epochs_r_reg_r2_128_191_3_5_n_1;
  wire epochs_r_reg_r2_128_191_3_5_n_2;
  wire epochs_r_reg_r2_128_191_6_7_n_0;
  wire epochs_r_reg_r2_128_191_6_7_n_1;
  wire epochs_r_reg_r2_192_255_0_2_n_0;
  wire epochs_r_reg_r2_192_255_0_2_n_1;
  wire epochs_r_reg_r2_192_255_0_2_n_2;
  wire epochs_r_reg_r2_192_255_3_5_n_0;
  wire epochs_r_reg_r2_192_255_3_5_n_1;
  wire epochs_r_reg_r2_192_255_3_5_n_2;
  wire epochs_r_reg_r2_192_255_6_7_n_0;
  wire epochs_r_reg_r2_192_255_6_7_n_1;
  wire epochs_r_reg_r2_64_127_0_2_n_0;
  wire epochs_r_reg_r2_64_127_0_2_n_1;
  wire epochs_r_reg_r2_64_127_0_2_n_2;
  wire epochs_r_reg_r2_64_127_3_5_n_0;
  wire epochs_r_reg_r2_64_127_3_5_n_1;
  wire epochs_r_reg_r2_64_127_3_5_n_2;
  wire epochs_r_reg_r2_64_127_6_7_n_0;
  wire epochs_r_reg_r2_64_127_6_7_n_1;
  wire [33:0]insert_paddr_i;
  wire [13:6]insert_paddr_i_IBUF;
  wire [33:0]inv_addr_i;
  wire [13:6]inv_addr_i_IBUF;
  wire [7:0]inv_epoch_o;
  wire [7:0]inv_epoch_o_OBUF;
  wire inv_v_i;
  wire inv_v_i_IBUF;
  wire [7:0]line_epoch_o;
  wire [7:0]line_epoch_o_OBUF;
  wire [5:0]p_1_in;
  wire [7:0]p_2_in;
  wire reset_d_i;
  wire reset_d_i_IBUF;
  wire [7:0]set_i;
  wire [7:0]set_i_IBUF;
  wire set_kill_o;
  wire set_kill_o_OBUF;
  wire set_kill_o_OBUF_inst_i_2_n_0;
  wire set_kill_o_OBUF_inst_i_3_n_0;
  wire set_kill_o_OBUF_inst_i_4_n_0;
  wire [3:0]state_i;
  wire [3:0]state_i_IBUF;
  wire [7:0]tag_epoch_i;
  wire [7:0]tag_epoch_i_IBUF;
  wire tag_valid_i;
  wire tag_valid_i_IBUF;
  wire valid_tag_o;
  wire valid_tag_o_OBUF;
  wire valid_tag_o_OBUF_inst_i_2_n_0;
  wire valid_tag_o_OBUF_inst_i_3_n_0;
  wire valid_tag_o_OBUF_inst_i_4_n_0;
  wire wrap_o;
  wire wrap_o_OBUF;
  wire wrap_o_OBUF_inst_i_2_n_0;
  wire wrap_o_OBUF_inst_i_3_n_0;
  wire NLW_epochs_r_reg_r1_0_63_0_2_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r1_0_63_3_5_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r1_0_63_6_7_DOC_UNCONNECTED;
  wire NLW_epochs_r_reg_r1_0_63_6_7_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r1_128_191_0_2_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r1_128_191_3_5_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r1_128_191_6_7_DOC_UNCONNECTED;
  wire NLW_epochs_r_reg_r1_128_191_6_7_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r1_192_255_0_2_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r1_192_255_3_5_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r1_192_255_6_7_DOC_UNCONNECTED;
  wire NLW_epochs_r_reg_r1_192_255_6_7_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r1_64_127_0_2_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r1_64_127_3_5_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r1_64_127_6_7_DOC_UNCONNECTED;
  wire NLW_epochs_r_reg_r1_64_127_6_7_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r2_0_63_0_2_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r2_0_63_3_5_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r2_0_63_6_7_DOC_UNCONNECTED;
  wire NLW_epochs_r_reg_r2_0_63_6_7_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r2_128_191_0_2_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r2_128_191_3_5_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r2_128_191_6_7_DOC_UNCONNECTED;
  wire NLW_epochs_r_reg_r2_128_191_6_7_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r2_192_255_0_2_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r2_192_255_3_5_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r2_192_255_6_7_DOC_UNCONNECTED;
  wire NLW_epochs_r_reg_r2_192_255_6_7_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r2_64_127_0_2_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r2_64_127_3_5_DOD_UNCONNECTED;
  wire NLW_epochs_r_reg_r2_64_127_6_7_DOC_UNCONNECTED;
  wire NLW_epochs_r_reg_r2_64_127_6_7_DOD_UNCONNECTED;

  IBUF clear_d_i_IBUF_inst
       (.I(clear_d_i),
        .O(clear_d_i_IBUF));
  OBUF clear_now_o_OBUF_inst
       (.I(clear_now_o_OBUF),
        .O(clear_now_o));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'hFF80)) 
    clear_now_o_OBUF_inst_i_1
       (.I0(inv_v_i_IBUF),
        .I1(inv_epoch_o_OBUF[0]),
        .I2(wrap_o_OBUF_inst_i_2_n_0),
        .I3(clear_d_i_IBUF),
        .O(clear_now_o_OBUF));
  IBUF \clear_slot_i_IBUF[0]_inst 
       (.I(clear_slot_i[0]),
        .O(clear_slot_i_IBUF[0]));
  IBUF \clear_slot_i_IBUF[1]_inst 
       (.I(clear_slot_i[1]),
        .O(clear_slot_i_IBUF[1]));
  IBUF \clear_slot_i_IBUF[2]_inst 
       (.I(clear_slot_i[2]),
        .O(clear_slot_i_IBUF[2]));
  IBUF \clear_slot_i_IBUF[3]_inst 
       (.I(clear_slot_i[3]),
        .O(clear_slot_i_IBUF[3]));
  IBUF \clear_slot_i_IBUF[4]_inst 
       (.I(clear_slot_i[4]),
        .O(clear_slot_i_IBUF[4]));
  IBUF \clear_slot_i_IBUF[5]_inst 
       (.I(clear_slot_i[5]),
        .O(clear_slot_i_IBUF[5]));
  IBUF \clear_slot_i_IBUF[6]_inst 
       (.I(clear_slot_i[6]),
        .O(clear_slot_i_IBUF[6]));
  IBUF \clear_slot_i_IBUF[7]_inst 
       (.I(clear_slot_i[7]),
        .O(clear_slot_i_IBUF[7]));
  BUFG clk_d_i_IBUF_BUFG_inst
       (.I(clk_d_i_IBUF),
        .O(clk_d_i_IBUF_BUFG));
  IBUF clk_d_i_IBUF_inst
       (.I(clk_d_i),
        .O(clk_d_i_IBUF));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "2" *) 
  RAM64M epochs_r_reg_r1_0_63_0_2
       (.ADDRA(inv_addr_i_IBUF[11:6]),
        .ADDRB(inv_addr_i_IBUF[11:6]),
        .ADDRC(inv_addr_i_IBUF[11:6]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[0]),
        .DIB(p_2_in[1]),
        .DIC(p_2_in[2]),
        .DID(1'b0),
        .DOA(epochs_r_reg_r1_0_63_0_2_n_0),
        .DOB(epochs_r_reg_r1_0_63_0_2_n_1),
        .DOC(epochs_r_reg_r1_0_63_0_2_n_2),
        .DOD(NLW_epochs_r_reg_r1_0_63_0_2_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_0_63_0_2_i_4_n_0));
  LUT5 #(
    .INIT(32'hFF40B040)) 
    epochs_r_reg_r1_0_63_0_2_i_1
       (.I0(clear_d_i_IBUF),
        .I1(inv_v_i_IBUF),
        .I2(epochs_r_reg_r1_0_63_0_2_i_11_n_0),
        .I3(inv_epoch_o_OBUF[0]),
        .I4(wrap_o_OBUF_inst_i_2_n_0),
        .O(p_2_in[0]));
  LUT3 #(
    .INIT(8'hB8)) 
    epochs_r_reg_r1_0_63_0_2_i_10
       (.I0(inv_addr_i_IBUF[6]),
        .I1(epochs_r_reg_r1_0_63_0_2_i_11_n_0),
        .I2(clear_slot_i_IBUF[0]),
        .O(p_1_in[0]));
  LUT4 #(
    .INIT(16'hFFFE)) 
    epochs_r_reg_r1_0_63_0_2_i_11
       (.I0(state_i_IBUF[1]),
        .I1(state_i_IBUF[2]),
        .I2(state_i_IBUF[3]),
        .I3(state_i_IBUF[0]),
        .O(epochs_r_reg_r1_0_63_0_2_i_11_n_0));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'hDFFF)) 
    epochs_r_reg_r1_0_63_0_2_i_12
       (.I0(inv_epoch_o_OBUF[0]),
        .I1(clear_d_i_IBUF),
        .I2(inv_v_i_IBUF),
        .I3(inv_epoch_o_OBUF[1]),
        .O(epochs_r_reg_r1_0_63_0_2_i_12_n_0));
  LUT4 #(
    .INIT(16'h8000)) 
    epochs_r_reg_r1_0_63_0_2_i_13
       (.I0(inv_epoch_o_OBUF[5]),
        .I1(epochs_r_reg_r1_0_63_0_2_i_11_n_0),
        .I2(inv_epoch_o_OBUF[6]),
        .I3(inv_epoch_o_OBUF[7]),
        .O(epochs_r_reg_r1_0_63_0_2_i_13_n_0));
  LUT6 #(
    .INIT(64'hEEAEEEEEAAEAAAAA)) 
    epochs_r_reg_r1_0_63_0_2_i_2
       (.I0(wrap_o_OBUF_inst_i_2_n_0),
        .I1(epochs_r_reg_r1_0_63_0_2_i_11_n_0),
        .I2(inv_epoch_o_OBUF[0]),
        .I3(clear_d_i_IBUF),
        .I4(inv_v_i_IBUF),
        .I5(inv_epoch_o_OBUF[1]),
        .O(p_2_in[1]));
  LUT6 #(
    .INIT(64'hF888888822222222)) 
    epochs_r_reg_r1_0_63_0_2_i_3
       (.I0(epochs_r_reg_r1_0_63_0_2_i_11_n_0),
        .I1(epochs_r_reg_r1_0_63_0_2_i_12_n_0),
        .I2(epochs_r_reg_r1_0_63_0_2_i_13_n_0),
        .I3(inv_epoch_o_OBUF[4]),
        .I4(inv_epoch_o_OBUF[3]),
        .I5(inv_epoch_o_OBUF[2]),
        .O(p_2_in[2]));
  LUT6 #(
    .INIT(64'h0000000000440347)) 
    epochs_r_reg_r1_0_63_0_2_i_4
       (.I0(inv_addr_i_IBUF[12]),
        .I1(epochs_r_reg_r1_0_63_0_2_i_11_n_0),
        .I2(clear_slot_i_IBUF[6]),
        .I3(inv_addr_i_IBUF[13]),
        .I4(clear_slot_i_IBUF[7]),
        .I5(reset_d_i_IBUF),
        .O(epochs_r_reg_r1_0_63_0_2_i_4_n_0));
  LUT3 #(
    .INIT(8'hB8)) 
    epochs_r_reg_r1_0_63_0_2_i_5
       (.I0(inv_addr_i_IBUF[11]),
        .I1(epochs_r_reg_r1_0_63_0_2_i_11_n_0),
        .I2(clear_slot_i_IBUF[5]),
        .O(p_1_in[5]));
  LUT3 #(
    .INIT(8'hB8)) 
    epochs_r_reg_r1_0_63_0_2_i_6
       (.I0(inv_addr_i_IBUF[10]),
        .I1(epochs_r_reg_r1_0_63_0_2_i_11_n_0),
        .I2(clear_slot_i_IBUF[4]),
        .O(p_1_in[4]));
  LUT3 #(
    .INIT(8'hB8)) 
    epochs_r_reg_r1_0_63_0_2_i_7
       (.I0(inv_addr_i_IBUF[9]),
        .I1(epochs_r_reg_r1_0_63_0_2_i_11_n_0),
        .I2(clear_slot_i_IBUF[3]),
        .O(p_1_in[3]));
  LUT3 #(
    .INIT(8'hB8)) 
    epochs_r_reg_r1_0_63_0_2_i_8
       (.I0(inv_addr_i_IBUF[8]),
        .I1(epochs_r_reg_r1_0_63_0_2_i_11_n_0),
        .I2(clear_slot_i_IBUF[2]),
        .O(p_1_in[2]));
  LUT3 #(
    .INIT(8'hB8)) 
    epochs_r_reg_r1_0_63_0_2_i_9
       (.I0(inv_addr_i_IBUF[7]),
        .I1(epochs_r_reg_r1_0_63_0_2_i_11_n_0),
        .I2(clear_slot_i_IBUF[1]),
        .O(p_1_in[1]));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "3" *) 
  (* ram_slice_end = "5" *) 
  RAM64M epochs_r_reg_r1_0_63_3_5
       (.ADDRA(inv_addr_i_IBUF[11:6]),
        .ADDRB(inv_addr_i_IBUF[11:6]),
        .ADDRC(inv_addr_i_IBUF[11:6]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[3]),
        .DIB(p_2_in[4]),
        .DIC(p_2_in[5]),
        .DID(1'b0),
        .DOA(epochs_r_reg_r1_0_63_3_5_n_0),
        .DOB(epochs_r_reg_r1_0_63_3_5_n_1),
        .DOC(epochs_r_reg_r1_0_63_3_5_n_2),
        .DOD(NLW_epochs_r_reg_r1_0_63_3_5_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_0_63_0_2_i_4_n_0));
  LUT5 #(
    .INIT(32'hF8228822)) 
    epochs_r_reg_r1_0_63_3_5_i_1
       (.I0(epochs_r_reg_r1_0_63_0_2_i_11_n_0),
        .I1(epochs_r_reg_r1_0_63_3_5_i_4_n_0),
        .I2(epochs_r_reg_r1_0_63_0_2_i_13_n_0),
        .I3(inv_epoch_o_OBUF[3]),
        .I4(inv_epoch_o_OBUF[4]),
        .O(p_2_in[3]));
  LUT4 #(
    .INIT(16'hF282)) 
    epochs_r_reg_r1_0_63_3_5_i_2
       (.I0(epochs_r_reg_r1_0_63_0_2_i_11_n_0),
        .I1(epochs_r_reg_r1_0_63_3_5_i_5_n_0),
        .I2(inv_epoch_o_OBUF[4]),
        .I3(epochs_r_reg_r1_0_63_0_2_i_13_n_0),
        .O(p_2_in[4]));
  LUT4 #(
    .INIT(16'hEABA)) 
    epochs_r_reg_r1_0_63_3_5_i_3
       (.I0(epochs_r_reg_r1_0_63_0_2_i_13_n_0),
        .I1(epochs_r_reg_r1_0_63_3_5_i_6_n_0),
        .I2(epochs_r_reg_r1_0_63_0_2_i_11_n_0),
        .I3(inv_epoch_o_OBUF[5]),
        .O(p_2_in[5]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hFF7FFFFF)) 
    epochs_r_reg_r1_0_63_3_5_i_4
       (.I0(inv_epoch_o_OBUF[2]),
        .I1(inv_epoch_o_OBUF[1]),
        .I2(inv_epoch_o_OBUF[0]),
        .I3(clear_d_i_IBUF),
        .I4(inv_v_i_IBUF),
        .O(epochs_r_reg_r1_0_63_3_5_i_4_n_0));
  LUT6 #(
    .INIT(64'hFFFF7FFFFFFFFFFF)) 
    epochs_r_reg_r1_0_63_3_5_i_5
       (.I0(inv_epoch_o_OBUF[3]),
        .I1(inv_epoch_o_OBUF[1]),
        .I2(inv_epoch_o_OBUF[2]),
        .I3(inv_epoch_o_OBUF[0]),
        .I4(clear_d_i_IBUF),
        .I5(inv_v_i_IBUF),
        .O(epochs_r_reg_r1_0_63_3_5_i_5_n_0));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'hFBFF)) 
    epochs_r_reg_r1_0_63_3_5_i_6
       (.I0(wrap_o_OBUF_inst_i_3_n_0),
        .I1(inv_epoch_o_OBUF[0]),
        .I2(clear_d_i_IBUF),
        .I3(inv_v_i_IBUF),
        .O(epochs_r_reg_r1_0_63_3_5_i_6_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "6" *) 
  (* ram_slice_end = "7" *) 
  RAM64M epochs_r_reg_r1_0_63_6_7
       (.ADDRA(inv_addr_i_IBUF[11:6]),
        .ADDRB(inv_addr_i_IBUF[11:6]),
        .ADDRC(inv_addr_i_IBUF[11:6]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[6]),
        .DIB(p_2_in[7]),
        .DIC(1'b0),
        .DID(1'b0),
        .DOA(epochs_r_reg_r1_0_63_6_7_n_0),
        .DOB(epochs_r_reg_r1_0_63_6_7_n_1),
        .DOC(NLW_epochs_r_reg_r1_0_63_6_7_DOC_UNCONNECTED),
        .DOD(NLW_epochs_r_reg_r1_0_63_6_7_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_0_63_0_2_i_4_n_0));
  LUT5 #(
    .INIT(32'hC08CC0C0)) 
    epochs_r_reg_r1_0_63_6_7_i_1
       (.I0(inv_epoch_o_OBUF[7]),
        .I1(epochs_r_reg_r1_0_63_0_2_i_11_n_0),
        .I2(inv_epoch_o_OBUF[6]),
        .I3(epochs_r_reg_r1_0_63_3_5_i_6_n_0),
        .I4(inv_epoch_o_OBUF[5]),
        .O(p_2_in[6]));
  LUT5 #(
    .INIT(32'hBA00AA00)) 
    epochs_r_reg_r1_0_63_6_7_i_2
       (.I0(inv_epoch_o_OBUF[7]),
        .I1(epochs_r_reg_r1_0_63_3_5_i_6_n_0),
        .I2(inv_epoch_o_OBUF[6]),
        .I3(epochs_r_reg_r1_0_63_0_2_i_11_n_0),
        .I4(inv_epoch_o_OBUF[5]),
        .O(p_2_in[7]));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "128" *) 
  (* ram_addr_end = "191" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "2" *) 
  RAM64M epochs_r_reg_r1_128_191_0_2
       (.ADDRA(inv_addr_i_IBUF[11:6]),
        .ADDRB(inv_addr_i_IBUF[11:6]),
        .ADDRC(inv_addr_i_IBUF[11:6]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[0]),
        .DIB(p_2_in[1]),
        .DIC(p_2_in[2]),
        .DID(1'b0),
        .DOA(epochs_r_reg_r1_128_191_0_2_n_0),
        .DOB(epochs_r_reg_r1_128_191_0_2_n_1),
        .DOC(epochs_r_reg_r1_128_191_0_2_n_2),
        .DOD(NLW_epochs_r_reg_r1_128_191_0_2_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_128_191_0_2_i_1_n_0));
  LUT6 #(
    .INIT(64'h0000000030553000)) 
    epochs_r_reg_r1_128_191_0_2_i_1
       (.I0(clear_slot_i_IBUF[6]),
        .I1(inv_addr_i_IBUF[12]),
        .I2(inv_addr_i_IBUF[13]),
        .I3(epochs_r_reg_r1_0_63_0_2_i_11_n_0),
        .I4(clear_slot_i_IBUF[7]),
        .I5(reset_d_i_IBUF),
        .O(epochs_r_reg_r1_128_191_0_2_i_1_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "128" *) 
  (* ram_addr_end = "191" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "3" *) 
  (* ram_slice_end = "5" *) 
  RAM64M epochs_r_reg_r1_128_191_3_5
       (.ADDRA(inv_addr_i_IBUF[11:6]),
        .ADDRB(inv_addr_i_IBUF[11:6]),
        .ADDRC(inv_addr_i_IBUF[11:6]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[3]),
        .DIB(p_2_in[4]),
        .DIC(p_2_in[5]),
        .DID(1'b0),
        .DOA(epochs_r_reg_r1_128_191_3_5_n_0),
        .DOB(epochs_r_reg_r1_128_191_3_5_n_1),
        .DOC(epochs_r_reg_r1_128_191_3_5_n_2),
        .DOD(NLW_epochs_r_reg_r1_128_191_3_5_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_128_191_0_2_i_1_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "128" *) 
  (* ram_addr_end = "191" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "6" *) 
  (* ram_slice_end = "7" *) 
  RAM64M epochs_r_reg_r1_128_191_6_7
       (.ADDRA(inv_addr_i_IBUF[11:6]),
        .ADDRB(inv_addr_i_IBUF[11:6]),
        .ADDRC(inv_addr_i_IBUF[11:6]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[6]),
        .DIB(p_2_in[7]),
        .DIC(1'b0),
        .DID(1'b0),
        .DOA(epochs_r_reg_r1_128_191_6_7_n_0),
        .DOB(epochs_r_reg_r1_128_191_6_7_n_1),
        .DOC(NLW_epochs_r_reg_r1_128_191_6_7_DOC_UNCONNECTED),
        .DOD(NLW_epochs_r_reg_r1_128_191_6_7_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_128_191_0_2_i_1_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "192" *) 
  (* ram_addr_end = "255" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "2" *) 
  RAM64M epochs_r_reg_r1_192_255_0_2
       (.ADDRA(inv_addr_i_IBUF[11:6]),
        .ADDRB(inv_addr_i_IBUF[11:6]),
        .ADDRC(inv_addr_i_IBUF[11:6]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[0]),
        .DIB(p_2_in[1]),
        .DIC(p_2_in[2]),
        .DID(1'b0),
        .DOA(epochs_r_reg_r1_192_255_0_2_n_0),
        .DOB(epochs_r_reg_r1_192_255_0_2_n_1),
        .DOC(epochs_r_reg_r1_192_255_0_2_n_2),
        .DOD(NLW_epochs_r_reg_r1_192_255_0_2_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_192_255_0_2_i_1_n_0));
  LUT6 #(
    .INIT(64'h00000000B8308800)) 
    epochs_r_reg_r1_192_255_0_2_i_1
       (.I0(inv_addr_i_IBUF[12]),
        .I1(epochs_r_reg_r1_0_63_0_2_i_11_n_0),
        .I2(clear_slot_i_IBUF[6]),
        .I3(inv_addr_i_IBUF[13]),
        .I4(clear_slot_i_IBUF[7]),
        .I5(reset_d_i_IBUF),
        .O(epochs_r_reg_r1_192_255_0_2_i_1_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "192" *) 
  (* ram_addr_end = "255" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "3" *) 
  (* ram_slice_end = "5" *) 
  RAM64M epochs_r_reg_r1_192_255_3_5
       (.ADDRA(inv_addr_i_IBUF[11:6]),
        .ADDRB(inv_addr_i_IBUF[11:6]),
        .ADDRC(inv_addr_i_IBUF[11:6]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[3]),
        .DIB(p_2_in[4]),
        .DIC(p_2_in[5]),
        .DID(1'b0),
        .DOA(epochs_r_reg_r1_192_255_3_5_n_0),
        .DOB(epochs_r_reg_r1_192_255_3_5_n_1),
        .DOC(epochs_r_reg_r1_192_255_3_5_n_2),
        .DOD(NLW_epochs_r_reg_r1_192_255_3_5_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_192_255_0_2_i_1_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "192" *) 
  (* ram_addr_end = "255" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "6" *) 
  (* ram_slice_end = "7" *) 
  RAM64M epochs_r_reg_r1_192_255_6_7
       (.ADDRA(inv_addr_i_IBUF[11:6]),
        .ADDRB(inv_addr_i_IBUF[11:6]),
        .ADDRC(inv_addr_i_IBUF[11:6]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[6]),
        .DIB(p_2_in[7]),
        .DIC(1'b0),
        .DID(1'b0),
        .DOA(epochs_r_reg_r1_192_255_6_7_n_0),
        .DOB(epochs_r_reg_r1_192_255_6_7_n_1),
        .DOC(NLW_epochs_r_reg_r1_192_255_6_7_DOC_UNCONNECTED),
        .DOD(NLW_epochs_r_reg_r1_192_255_6_7_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_192_255_0_2_i_1_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "64" *) 
  (* ram_addr_end = "127" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "2" *) 
  RAM64M epochs_r_reg_r1_64_127_0_2
       (.ADDRA(inv_addr_i_IBUF[11:6]),
        .ADDRB(inv_addr_i_IBUF[11:6]),
        .ADDRC(inv_addr_i_IBUF[11:6]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[0]),
        .DIB(p_2_in[1]),
        .DIC(p_2_in[2]),
        .DID(1'b0),
        .DOA(epochs_r_reg_r1_64_127_0_2_n_0),
        .DOB(epochs_r_reg_r1_64_127_0_2_n_1),
        .DOC(epochs_r_reg_r1_64_127_0_2_n_2),
        .DOD(NLW_epochs_r_reg_r1_64_127_0_2_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_64_127_0_2_i_1_n_0));
  LUT6 #(
    .INIT(64'h0000000030553000)) 
    epochs_r_reg_r1_64_127_0_2_i_1
       (.I0(clear_slot_i_IBUF[7]),
        .I1(inv_addr_i_IBUF[13]),
        .I2(inv_addr_i_IBUF[12]),
        .I3(epochs_r_reg_r1_0_63_0_2_i_11_n_0),
        .I4(clear_slot_i_IBUF[6]),
        .I5(reset_d_i_IBUF),
        .O(epochs_r_reg_r1_64_127_0_2_i_1_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "64" *) 
  (* ram_addr_end = "127" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "3" *) 
  (* ram_slice_end = "5" *) 
  RAM64M epochs_r_reg_r1_64_127_3_5
       (.ADDRA(inv_addr_i_IBUF[11:6]),
        .ADDRB(inv_addr_i_IBUF[11:6]),
        .ADDRC(inv_addr_i_IBUF[11:6]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[3]),
        .DIB(p_2_in[4]),
        .DIC(p_2_in[5]),
        .DID(1'b0),
        .DOA(epochs_r_reg_r1_64_127_3_5_n_0),
        .DOB(epochs_r_reg_r1_64_127_3_5_n_1),
        .DOC(epochs_r_reg_r1_64_127_3_5_n_2),
        .DOD(NLW_epochs_r_reg_r1_64_127_3_5_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_64_127_0_2_i_1_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "64" *) 
  (* ram_addr_end = "127" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "6" *) 
  (* ram_slice_end = "7" *) 
  RAM64M epochs_r_reg_r1_64_127_6_7
       (.ADDRA(inv_addr_i_IBUF[11:6]),
        .ADDRB(inv_addr_i_IBUF[11:6]),
        .ADDRC(inv_addr_i_IBUF[11:6]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[6]),
        .DIB(p_2_in[7]),
        .DIC(1'b0),
        .DID(1'b0),
        .DOA(epochs_r_reg_r1_64_127_6_7_n_0),
        .DOB(epochs_r_reg_r1_64_127_6_7_n_1),
        .DOC(NLW_epochs_r_reg_r1_64_127_6_7_DOC_UNCONNECTED),
        .DOD(NLW_epochs_r_reg_r1_64_127_6_7_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_64_127_0_2_i_1_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "2" *) 
  RAM64M epochs_r_reg_r2_0_63_0_2
       (.ADDRA(epoch_read_set[5:0]),
        .ADDRB(epoch_read_set[5:0]),
        .ADDRC(epoch_read_set[5:0]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[0]),
        .DIB(p_2_in[1]),
        .DIC(p_2_in[2]),
        .DID(1'b0),
        .DOA(epochs_r_reg_r2_0_63_0_2_n_0),
        .DOB(epochs_r_reg_r2_0_63_0_2_n_1),
        .DOC(epochs_r_reg_r2_0_63_0_2_n_2),
        .DOD(NLW_epochs_r_reg_r2_0_63_0_2_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_0_63_0_2_i_4_n_0));
  LUT6 #(
    .INIT(64'hAAABAAAAAAA8AAAA)) 
    epochs_r_reg_r2_0_63_0_2_i_1
       (.I0(set_i_IBUF[5]),
        .I1(state_i_IBUF[1]),
        .I2(state_i_IBUF[2]),
        .I3(state_i_IBUF[3]),
        .I4(state_i_IBUF[0]),
        .I5(insert_paddr_i_IBUF[11]),
        .O(epoch_read_set[5]));
  LUT6 #(
    .INIT(64'hAAABAAAAAAA8AAAA)) 
    epochs_r_reg_r2_0_63_0_2_i_2
       (.I0(set_i_IBUF[4]),
        .I1(state_i_IBUF[1]),
        .I2(state_i_IBUF[2]),
        .I3(state_i_IBUF[3]),
        .I4(state_i_IBUF[0]),
        .I5(insert_paddr_i_IBUF[10]),
        .O(epoch_read_set[4]));
  LUT6 #(
    .INIT(64'hAAABAAAAAAA8AAAA)) 
    epochs_r_reg_r2_0_63_0_2_i_3
       (.I0(set_i_IBUF[3]),
        .I1(state_i_IBUF[1]),
        .I2(state_i_IBUF[2]),
        .I3(state_i_IBUF[3]),
        .I4(state_i_IBUF[0]),
        .I5(insert_paddr_i_IBUF[9]),
        .O(epoch_read_set[3]));
  LUT6 #(
    .INIT(64'hAAABAAAAAAA8AAAA)) 
    epochs_r_reg_r2_0_63_0_2_i_4
       (.I0(set_i_IBUF[2]),
        .I1(state_i_IBUF[1]),
        .I2(state_i_IBUF[2]),
        .I3(state_i_IBUF[3]),
        .I4(state_i_IBUF[0]),
        .I5(insert_paddr_i_IBUF[8]),
        .O(epoch_read_set[2]));
  LUT6 #(
    .INIT(64'hAAABAAAAAAA8AAAA)) 
    epochs_r_reg_r2_0_63_0_2_i_5
       (.I0(set_i_IBUF[1]),
        .I1(state_i_IBUF[1]),
        .I2(state_i_IBUF[2]),
        .I3(state_i_IBUF[3]),
        .I4(state_i_IBUF[0]),
        .I5(insert_paddr_i_IBUF[7]),
        .O(epoch_read_set[1]));
  LUT6 #(
    .INIT(64'hAAABAAAAAAA8AAAA)) 
    epochs_r_reg_r2_0_63_0_2_i_6
       (.I0(set_i_IBUF[0]),
        .I1(state_i_IBUF[1]),
        .I2(state_i_IBUF[2]),
        .I3(state_i_IBUF[3]),
        .I4(state_i_IBUF[0]),
        .I5(insert_paddr_i_IBUF[6]),
        .O(epoch_read_set[0]));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "3" *) 
  (* ram_slice_end = "5" *) 
  RAM64M epochs_r_reg_r2_0_63_3_5
       (.ADDRA(epoch_read_set[5:0]),
        .ADDRB(epoch_read_set[5:0]),
        .ADDRC(epoch_read_set[5:0]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[3]),
        .DIB(p_2_in[4]),
        .DIC(p_2_in[5]),
        .DID(1'b0),
        .DOA(epochs_r_reg_r2_0_63_3_5_n_0),
        .DOB(epochs_r_reg_r2_0_63_3_5_n_1),
        .DOC(epochs_r_reg_r2_0_63_3_5_n_2),
        .DOD(NLW_epochs_r_reg_r2_0_63_3_5_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_0_63_0_2_i_4_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "63" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "6" *) 
  (* ram_slice_end = "7" *) 
  RAM64M epochs_r_reg_r2_0_63_6_7
       (.ADDRA(epoch_read_set[5:0]),
        .ADDRB(epoch_read_set[5:0]),
        .ADDRC(epoch_read_set[5:0]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[6]),
        .DIB(p_2_in[7]),
        .DIC(1'b0),
        .DID(1'b0),
        .DOA(epochs_r_reg_r2_0_63_6_7_n_0),
        .DOB(epochs_r_reg_r2_0_63_6_7_n_1),
        .DOC(NLW_epochs_r_reg_r2_0_63_6_7_DOC_UNCONNECTED),
        .DOD(NLW_epochs_r_reg_r2_0_63_6_7_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_0_63_0_2_i_4_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "128" *) 
  (* ram_addr_end = "191" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "2" *) 
  RAM64M epochs_r_reg_r2_128_191_0_2
       (.ADDRA(epoch_read_set[5:0]),
        .ADDRB(epoch_read_set[5:0]),
        .ADDRC(epoch_read_set[5:0]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[0]),
        .DIB(p_2_in[1]),
        .DIC(p_2_in[2]),
        .DID(1'b0),
        .DOA(epochs_r_reg_r2_128_191_0_2_n_0),
        .DOB(epochs_r_reg_r2_128_191_0_2_n_1),
        .DOC(epochs_r_reg_r2_128_191_0_2_n_2),
        .DOD(NLW_epochs_r_reg_r2_128_191_0_2_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_128_191_0_2_i_1_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "128" *) 
  (* ram_addr_end = "191" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "3" *) 
  (* ram_slice_end = "5" *) 
  RAM64M epochs_r_reg_r2_128_191_3_5
       (.ADDRA(epoch_read_set[5:0]),
        .ADDRB(epoch_read_set[5:0]),
        .ADDRC(epoch_read_set[5:0]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[3]),
        .DIB(p_2_in[4]),
        .DIC(p_2_in[5]),
        .DID(1'b0),
        .DOA(epochs_r_reg_r2_128_191_3_5_n_0),
        .DOB(epochs_r_reg_r2_128_191_3_5_n_1),
        .DOC(epochs_r_reg_r2_128_191_3_5_n_2),
        .DOD(NLW_epochs_r_reg_r2_128_191_3_5_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_128_191_0_2_i_1_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "128" *) 
  (* ram_addr_end = "191" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "6" *) 
  (* ram_slice_end = "7" *) 
  RAM64M epochs_r_reg_r2_128_191_6_7
       (.ADDRA(epoch_read_set[5:0]),
        .ADDRB(epoch_read_set[5:0]),
        .ADDRC(epoch_read_set[5:0]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[6]),
        .DIB(p_2_in[7]),
        .DIC(1'b0),
        .DID(1'b0),
        .DOA(epochs_r_reg_r2_128_191_6_7_n_0),
        .DOB(epochs_r_reg_r2_128_191_6_7_n_1),
        .DOC(NLW_epochs_r_reg_r2_128_191_6_7_DOC_UNCONNECTED),
        .DOD(NLW_epochs_r_reg_r2_128_191_6_7_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_128_191_0_2_i_1_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "192" *) 
  (* ram_addr_end = "255" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "2" *) 
  RAM64M epochs_r_reg_r2_192_255_0_2
       (.ADDRA(epoch_read_set[5:0]),
        .ADDRB(epoch_read_set[5:0]),
        .ADDRC(epoch_read_set[5:0]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[0]),
        .DIB(p_2_in[1]),
        .DIC(p_2_in[2]),
        .DID(1'b0),
        .DOA(epochs_r_reg_r2_192_255_0_2_n_0),
        .DOB(epochs_r_reg_r2_192_255_0_2_n_1),
        .DOC(epochs_r_reg_r2_192_255_0_2_n_2),
        .DOD(NLW_epochs_r_reg_r2_192_255_0_2_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_192_255_0_2_i_1_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "192" *) 
  (* ram_addr_end = "255" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "3" *) 
  (* ram_slice_end = "5" *) 
  RAM64M epochs_r_reg_r2_192_255_3_5
       (.ADDRA(epoch_read_set[5:0]),
        .ADDRB(epoch_read_set[5:0]),
        .ADDRC(epoch_read_set[5:0]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[3]),
        .DIB(p_2_in[4]),
        .DIC(p_2_in[5]),
        .DID(1'b0),
        .DOA(epochs_r_reg_r2_192_255_3_5_n_0),
        .DOB(epochs_r_reg_r2_192_255_3_5_n_1),
        .DOC(epochs_r_reg_r2_192_255_3_5_n_2),
        .DOD(NLW_epochs_r_reg_r2_192_255_3_5_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_192_255_0_2_i_1_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "192" *) 
  (* ram_addr_end = "255" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "6" *) 
  (* ram_slice_end = "7" *) 
  RAM64M epochs_r_reg_r2_192_255_6_7
       (.ADDRA(epoch_read_set[5:0]),
        .ADDRB(epoch_read_set[5:0]),
        .ADDRC(epoch_read_set[5:0]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[6]),
        .DIB(p_2_in[7]),
        .DIC(1'b0),
        .DID(1'b0),
        .DOA(epochs_r_reg_r2_192_255_6_7_n_0),
        .DOB(epochs_r_reg_r2_192_255_6_7_n_1),
        .DOC(NLW_epochs_r_reg_r2_192_255_6_7_DOC_UNCONNECTED),
        .DOD(NLW_epochs_r_reg_r2_192_255_6_7_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_192_255_0_2_i_1_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "64" *) 
  (* ram_addr_end = "127" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "2" *) 
  RAM64M epochs_r_reg_r2_64_127_0_2
       (.ADDRA(epoch_read_set[5:0]),
        .ADDRB(epoch_read_set[5:0]),
        .ADDRC(epoch_read_set[5:0]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[0]),
        .DIB(p_2_in[1]),
        .DIC(p_2_in[2]),
        .DID(1'b0),
        .DOA(epochs_r_reg_r2_64_127_0_2_n_0),
        .DOB(epochs_r_reg_r2_64_127_0_2_n_1),
        .DOC(epochs_r_reg_r2_64_127_0_2_n_2),
        .DOD(NLW_epochs_r_reg_r2_64_127_0_2_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_64_127_0_2_i_1_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "64" *) 
  (* ram_addr_end = "127" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "3" *) 
  (* ram_slice_end = "5" *) 
  RAM64M epochs_r_reg_r2_64_127_3_5
       (.ADDRA(epoch_read_set[5:0]),
        .ADDRB(epoch_read_set[5:0]),
        .ADDRC(epoch_read_set[5:0]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[3]),
        .DIB(p_2_in[4]),
        .DIC(p_2_in[5]),
        .DID(1'b0),
        .DOA(epochs_r_reg_r2_64_127_3_5_n_0),
        .DOB(epochs_r_reg_r2_64_127_3_5_n_1),
        .DOC(epochs_r_reg_r2_64_127_3_5_n_2),
        .DOD(NLW_epochs_r_reg_r2_64_127_3_5_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_64_127_0_2_i_1_n_0));
  (* METHODOLOGY_DRC_VIOS = "" *) 
  (* RTL_RAM_BITS = "2048" *) 
  (* RTL_RAM_NAME = "epoch_probe/epochs_r_reg" *) 
  (* RTL_RAM_STYLE = "distributed" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "64" *) 
  (* ram_addr_end = "127" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "6" *) 
  (* ram_slice_end = "7" *) 
  RAM64M epochs_r_reg_r2_64_127_6_7
       (.ADDRA(epoch_read_set[5:0]),
        .ADDRB(epoch_read_set[5:0]),
        .ADDRC(epoch_read_set[5:0]),
        .ADDRD(p_1_in),
        .DIA(p_2_in[6]),
        .DIB(p_2_in[7]),
        .DIC(1'b0),
        .DID(1'b0),
        .DOA(epochs_r_reg_r2_64_127_6_7_n_0),
        .DOB(epochs_r_reg_r2_64_127_6_7_n_1),
        .DOC(NLW_epochs_r_reg_r2_64_127_6_7_DOC_UNCONNECTED),
        .DOD(NLW_epochs_r_reg_r2_64_127_6_7_DOD_UNCONNECTED),
        .WCLK(clk_d_i_IBUF_BUFG),
        .WE(epochs_r_reg_r1_64_127_0_2_i_1_n_0));
  IBUF \insert_paddr_i_IBUF[10]_inst 
       (.I(insert_paddr_i[10]),
        .O(insert_paddr_i_IBUF[10]));
  IBUF \insert_paddr_i_IBUF[11]_inst 
       (.I(insert_paddr_i[11]),
        .O(insert_paddr_i_IBUF[11]));
  IBUF \insert_paddr_i_IBUF[12]_inst 
       (.I(insert_paddr_i[12]),
        .O(insert_paddr_i_IBUF[12]));
  IBUF \insert_paddr_i_IBUF[13]_inst 
       (.I(insert_paddr_i[13]),
        .O(insert_paddr_i_IBUF[13]));
  IBUF \insert_paddr_i_IBUF[6]_inst 
       (.I(insert_paddr_i[6]),
        .O(insert_paddr_i_IBUF[6]));
  IBUF \insert_paddr_i_IBUF[7]_inst 
       (.I(insert_paddr_i[7]),
        .O(insert_paddr_i_IBUF[7]));
  IBUF \insert_paddr_i_IBUF[8]_inst 
       (.I(insert_paddr_i[8]),
        .O(insert_paddr_i_IBUF[8]));
  IBUF \insert_paddr_i_IBUF[9]_inst 
       (.I(insert_paddr_i[9]),
        .O(insert_paddr_i_IBUF[9]));
  IBUF \inv_addr_i_IBUF[10]_inst 
       (.I(inv_addr_i[10]),
        .O(inv_addr_i_IBUF[10]));
  IBUF \inv_addr_i_IBUF[11]_inst 
       (.I(inv_addr_i[11]),
        .O(inv_addr_i_IBUF[11]));
  IBUF \inv_addr_i_IBUF[12]_inst 
       (.I(inv_addr_i[12]),
        .O(inv_addr_i_IBUF[12]));
  IBUF \inv_addr_i_IBUF[13]_inst 
       (.I(inv_addr_i[13]),
        .O(inv_addr_i_IBUF[13]));
  IBUF \inv_addr_i_IBUF[6]_inst 
       (.I(inv_addr_i[6]),
        .O(inv_addr_i_IBUF[6]));
  IBUF \inv_addr_i_IBUF[7]_inst 
       (.I(inv_addr_i[7]),
        .O(inv_addr_i_IBUF[7]));
  IBUF \inv_addr_i_IBUF[8]_inst 
       (.I(inv_addr_i[8]),
        .O(inv_addr_i_IBUF[8]));
  IBUF \inv_addr_i_IBUF[9]_inst 
       (.I(inv_addr_i[9]),
        .O(inv_addr_i_IBUF[9]));
  OBUF \inv_epoch_o_OBUF[0]_inst 
       (.I(inv_epoch_o_OBUF[0]),
        .O(inv_epoch_o[0]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \inv_epoch_o_OBUF[0]_inst_i_1 
       (.I0(epochs_r_reg_r1_192_255_0_2_n_0),
        .I1(epochs_r_reg_r1_128_191_0_2_n_0),
        .I2(inv_addr_i_IBUF[13]),
        .I3(epochs_r_reg_r1_64_127_0_2_n_0),
        .I4(inv_addr_i_IBUF[12]),
        .I5(epochs_r_reg_r1_0_63_0_2_n_0),
        .O(inv_epoch_o_OBUF[0]));
  OBUF \inv_epoch_o_OBUF[1]_inst 
       (.I(inv_epoch_o_OBUF[1]),
        .O(inv_epoch_o[1]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \inv_epoch_o_OBUF[1]_inst_i_1 
       (.I0(epochs_r_reg_r1_192_255_0_2_n_1),
        .I1(epochs_r_reg_r1_128_191_0_2_n_1),
        .I2(inv_addr_i_IBUF[13]),
        .I3(epochs_r_reg_r1_64_127_0_2_n_1),
        .I4(inv_addr_i_IBUF[12]),
        .I5(epochs_r_reg_r1_0_63_0_2_n_1),
        .O(inv_epoch_o_OBUF[1]));
  OBUF \inv_epoch_o_OBUF[2]_inst 
       (.I(inv_epoch_o_OBUF[2]),
        .O(inv_epoch_o[2]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \inv_epoch_o_OBUF[2]_inst_i_1 
       (.I0(epochs_r_reg_r1_192_255_0_2_n_2),
        .I1(epochs_r_reg_r1_128_191_0_2_n_2),
        .I2(inv_addr_i_IBUF[13]),
        .I3(epochs_r_reg_r1_64_127_0_2_n_2),
        .I4(inv_addr_i_IBUF[12]),
        .I5(epochs_r_reg_r1_0_63_0_2_n_2),
        .O(inv_epoch_o_OBUF[2]));
  OBUF \inv_epoch_o_OBUF[3]_inst 
       (.I(inv_epoch_o_OBUF[3]),
        .O(inv_epoch_o[3]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \inv_epoch_o_OBUF[3]_inst_i_1 
       (.I0(epochs_r_reg_r1_192_255_3_5_n_0),
        .I1(epochs_r_reg_r1_128_191_3_5_n_0),
        .I2(inv_addr_i_IBUF[13]),
        .I3(epochs_r_reg_r1_64_127_3_5_n_0),
        .I4(inv_addr_i_IBUF[12]),
        .I5(epochs_r_reg_r1_0_63_3_5_n_0),
        .O(inv_epoch_o_OBUF[3]));
  OBUF \inv_epoch_o_OBUF[4]_inst 
       (.I(inv_epoch_o_OBUF[4]),
        .O(inv_epoch_o[4]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \inv_epoch_o_OBUF[4]_inst_i_1 
       (.I0(epochs_r_reg_r1_192_255_3_5_n_1),
        .I1(epochs_r_reg_r1_128_191_3_5_n_1),
        .I2(inv_addr_i_IBUF[13]),
        .I3(epochs_r_reg_r1_64_127_3_5_n_1),
        .I4(inv_addr_i_IBUF[12]),
        .I5(epochs_r_reg_r1_0_63_3_5_n_1),
        .O(inv_epoch_o_OBUF[4]));
  OBUF \inv_epoch_o_OBUF[5]_inst 
       (.I(inv_epoch_o_OBUF[5]),
        .O(inv_epoch_o[5]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \inv_epoch_o_OBUF[5]_inst_i_1 
       (.I0(epochs_r_reg_r1_192_255_3_5_n_2),
        .I1(epochs_r_reg_r1_128_191_3_5_n_2),
        .I2(inv_addr_i_IBUF[13]),
        .I3(epochs_r_reg_r1_64_127_3_5_n_2),
        .I4(inv_addr_i_IBUF[12]),
        .I5(epochs_r_reg_r1_0_63_3_5_n_2),
        .O(inv_epoch_o_OBUF[5]));
  OBUF \inv_epoch_o_OBUF[6]_inst 
       (.I(inv_epoch_o_OBUF[6]),
        .O(inv_epoch_o[6]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \inv_epoch_o_OBUF[6]_inst_i_1 
       (.I0(epochs_r_reg_r1_192_255_6_7_n_0),
        .I1(epochs_r_reg_r1_128_191_6_7_n_0),
        .I2(inv_addr_i_IBUF[13]),
        .I3(epochs_r_reg_r1_64_127_6_7_n_0),
        .I4(inv_addr_i_IBUF[12]),
        .I5(epochs_r_reg_r1_0_63_6_7_n_0),
        .O(inv_epoch_o_OBUF[6]));
  OBUF \inv_epoch_o_OBUF[7]_inst 
       (.I(inv_epoch_o_OBUF[7]),
        .O(inv_epoch_o[7]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \inv_epoch_o_OBUF[7]_inst_i_1 
       (.I0(epochs_r_reg_r1_192_255_6_7_n_1),
        .I1(epochs_r_reg_r1_128_191_6_7_n_1),
        .I2(inv_addr_i_IBUF[13]),
        .I3(epochs_r_reg_r1_64_127_6_7_n_1),
        .I4(inv_addr_i_IBUF[12]),
        .I5(epochs_r_reg_r1_0_63_6_7_n_1),
        .O(inv_epoch_o_OBUF[7]));
  IBUF inv_v_i_IBUF_inst
       (.I(inv_v_i),
        .O(inv_v_i_IBUF));
  OBUF \line_epoch_o_OBUF[0]_inst 
       (.I(line_epoch_o_OBUF[0]),
        .O(line_epoch_o[0]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \line_epoch_o_OBUF[0]_inst_i_1 
       (.I0(epochs_r_reg_r2_192_255_0_2_n_0),
        .I1(epochs_r_reg_r2_128_191_0_2_n_0),
        .I2(epoch_read_set[7]),
        .I3(epochs_r_reg_r2_64_127_0_2_n_0),
        .I4(epoch_read_set[6]),
        .I5(epochs_r_reg_r2_0_63_0_2_n_0),
        .O(line_epoch_o_OBUF[0]));
  OBUF \line_epoch_o_OBUF[1]_inst 
       (.I(line_epoch_o_OBUF[1]),
        .O(line_epoch_o[1]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \line_epoch_o_OBUF[1]_inst_i_1 
       (.I0(epochs_r_reg_r2_192_255_0_2_n_1),
        .I1(epochs_r_reg_r2_128_191_0_2_n_1),
        .I2(epoch_read_set[7]),
        .I3(epochs_r_reg_r2_64_127_0_2_n_1),
        .I4(epoch_read_set[6]),
        .I5(epochs_r_reg_r2_0_63_0_2_n_1),
        .O(line_epoch_o_OBUF[1]));
  OBUF \line_epoch_o_OBUF[2]_inst 
       (.I(line_epoch_o_OBUF[2]),
        .O(line_epoch_o[2]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \line_epoch_o_OBUF[2]_inst_i_1 
       (.I0(epochs_r_reg_r2_192_255_0_2_n_2),
        .I1(epochs_r_reg_r2_128_191_0_2_n_2),
        .I2(epoch_read_set[7]),
        .I3(epochs_r_reg_r2_64_127_0_2_n_2),
        .I4(epoch_read_set[6]),
        .I5(epochs_r_reg_r2_0_63_0_2_n_2),
        .O(line_epoch_o_OBUF[2]));
  OBUF \line_epoch_o_OBUF[3]_inst 
       (.I(line_epoch_o_OBUF[3]),
        .O(line_epoch_o[3]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \line_epoch_o_OBUF[3]_inst_i_1 
       (.I0(epochs_r_reg_r2_192_255_3_5_n_0),
        .I1(epochs_r_reg_r2_128_191_3_5_n_0),
        .I2(epoch_read_set[7]),
        .I3(epochs_r_reg_r2_64_127_3_5_n_0),
        .I4(epoch_read_set[6]),
        .I5(epochs_r_reg_r2_0_63_3_5_n_0),
        .O(line_epoch_o_OBUF[3]));
  OBUF \line_epoch_o_OBUF[4]_inst 
       (.I(line_epoch_o_OBUF[4]),
        .O(line_epoch_o[4]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \line_epoch_o_OBUF[4]_inst_i_1 
       (.I0(epochs_r_reg_r2_192_255_3_5_n_1),
        .I1(epochs_r_reg_r2_128_191_3_5_n_1),
        .I2(epoch_read_set[7]),
        .I3(epochs_r_reg_r2_64_127_3_5_n_1),
        .I4(epoch_read_set[6]),
        .I5(epochs_r_reg_r2_0_63_3_5_n_1),
        .O(line_epoch_o_OBUF[4]));
  OBUF \line_epoch_o_OBUF[5]_inst 
       (.I(line_epoch_o_OBUF[5]),
        .O(line_epoch_o[5]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \line_epoch_o_OBUF[5]_inst_i_1 
       (.I0(epochs_r_reg_r2_192_255_3_5_n_2),
        .I1(epochs_r_reg_r2_128_191_3_5_n_2),
        .I2(epoch_read_set[7]),
        .I3(epochs_r_reg_r2_64_127_3_5_n_2),
        .I4(epoch_read_set[6]),
        .I5(epochs_r_reg_r2_0_63_3_5_n_2),
        .O(line_epoch_o_OBUF[5]));
  OBUF \line_epoch_o_OBUF[6]_inst 
       (.I(line_epoch_o_OBUF[6]),
        .O(line_epoch_o[6]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \line_epoch_o_OBUF[6]_inst_i_1 
       (.I0(epochs_r_reg_r2_192_255_6_7_n_0),
        .I1(epochs_r_reg_r2_128_191_6_7_n_0),
        .I2(epoch_read_set[7]),
        .I3(epochs_r_reg_r2_64_127_6_7_n_0),
        .I4(epoch_read_set[6]),
        .I5(epochs_r_reg_r2_0_63_6_7_n_0),
        .O(line_epoch_o_OBUF[6]));
  OBUF \line_epoch_o_OBUF[7]_inst 
       (.I(line_epoch_o_OBUF[7]),
        .O(line_epoch_o[7]));
  LUT6 #(
    .INIT(64'hAFA0CFCFAFA0C0C0)) 
    \line_epoch_o_OBUF[7]_inst_i_1 
       (.I0(epochs_r_reg_r2_192_255_6_7_n_1),
        .I1(epochs_r_reg_r2_128_191_6_7_n_1),
        .I2(epoch_read_set[7]),
        .I3(epochs_r_reg_r2_64_127_6_7_n_1),
        .I4(epoch_read_set[6]),
        .I5(epochs_r_reg_r2_0_63_6_7_n_1),
        .O(line_epoch_o_OBUF[7]));
  LUT6 #(
    .INIT(64'hAAABAAAAAAA8AAAA)) 
    \line_epoch_o_OBUF[7]_inst_i_2 
       (.I0(set_i_IBUF[7]),
        .I1(state_i_IBUF[1]),
        .I2(state_i_IBUF[2]),
        .I3(state_i_IBUF[3]),
        .I4(state_i_IBUF[0]),
        .I5(insert_paddr_i_IBUF[13]),
        .O(epoch_read_set[7]));
  LUT6 #(
    .INIT(64'hAAABAAAAAAA8AAAA)) 
    \line_epoch_o_OBUF[7]_inst_i_3 
       (.I0(set_i_IBUF[6]),
        .I1(state_i_IBUF[1]),
        .I2(state_i_IBUF[2]),
        .I3(state_i_IBUF[3]),
        .I4(state_i_IBUF[0]),
        .I5(insert_paddr_i_IBUF[12]),
        .O(epoch_read_set[6]));
  IBUF reset_d_i_IBUF_inst
       (.I(reset_d_i),
        .O(reset_d_i_IBUF));
  IBUF \set_i_IBUF[0]_inst 
       (.I(set_i[0]),
        .O(set_i_IBUF[0]));
  IBUF \set_i_IBUF[1]_inst 
       (.I(set_i[1]),
        .O(set_i_IBUF[1]));
  IBUF \set_i_IBUF[2]_inst 
       (.I(set_i[2]),
        .O(set_i_IBUF[2]));
  IBUF \set_i_IBUF[3]_inst 
       (.I(set_i[3]),
        .O(set_i_IBUF[3]));
  IBUF \set_i_IBUF[4]_inst 
       (.I(set_i[4]),
        .O(set_i_IBUF[4]));
  IBUF \set_i_IBUF[5]_inst 
       (.I(set_i[5]),
        .O(set_i_IBUF[5]));
  IBUF \set_i_IBUF[6]_inst 
       (.I(set_i[6]),
        .O(set_i_IBUF[6]));
  IBUF \set_i_IBUF[7]_inst 
       (.I(set_i[7]),
        .O(set_i_IBUF[7]));
  OBUF set_kill_o_OBUF_inst
       (.I(set_kill_o_OBUF),
        .O(set_kill_o));
  LUT6 #(
    .INIT(64'h8200000000000000)) 
    set_kill_o_OBUF_inst_i_1
       (.I0(set_kill_o_OBUF_inst_i_2_n_0),
        .I1(set_i_IBUF[7]),
        .I2(inv_addr_i_IBUF[13]),
        .I3(inv_v_i_IBUF),
        .I4(set_kill_o_OBUF_inst_i_3_n_0),
        .I5(set_kill_o_OBUF_inst_i_4_n_0),
        .O(set_kill_o_OBUF));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    set_kill_o_OBUF_inst_i_2
       (.I0(inv_addr_i_IBUF[8]),
        .I1(set_i_IBUF[2]),
        .I2(inv_addr_i_IBUF[7]),
        .I3(set_i_IBUF[1]),
        .I4(set_i_IBUF[0]),
        .I5(inv_addr_i_IBUF[6]),
        .O(set_kill_o_OBUF_inst_i_2_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    set_kill_o_OBUF_inst_i_3
       (.I0(set_i_IBUF[3]),
        .I1(inv_addr_i_IBUF[9]),
        .I2(set_i_IBUF[4]),
        .I3(inv_addr_i_IBUF[10]),
        .O(set_kill_o_OBUF_inst_i_3_n_0));
  LUT4 #(
    .INIT(16'h9009)) 
    set_kill_o_OBUF_inst_i_4
       (.I0(set_i_IBUF[5]),
        .I1(inv_addr_i_IBUF[11]),
        .I2(set_i_IBUF[6]),
        .I3(inv_addr_i_IBUF[12]),
        .O(set_kill_o_OBUF_inst_i_4_n_0));
  IBUF \state_i_IBUF[0]_inst 
       (.I(state_i[0]),
        .O(state_i_IBUF[0]));
  IBUF \state_i_IBUF[1]_inst 
       (.I(state_i[1]),
        .O(state_i_IBUF[1]));
  IBUF \state_i_IBUF[2]_inst 
       (.I(state_i[2]),
        .O(state_i_IBUF[2]));
  IBUF \state_i_IBUF[3]_inst 
       (.I(state_i[3]),
        .O(state_i_IBUF[3]));
  IBUF \tag_epoch_i_IBUF[0]_inst 
       (.I(tag_epoch_i[0]),
        .O(tag_epoch_i_IBUF[0]));
  IBUF \tag_epoch_i_IBUF[1]_inst 
       (.I(tag_epoch_i[1]),
        .O(tag_epoch_i_IBUF[1]));
  IBUF \tag_epoch_i_IBUF[2]_inst 
       (.I(tag_epoch_i[2]),
        .O(tag_epoch_i_IBUF[2]));
  IBUF \tag_epoch_i_IBUF[3]_inst 
       (.I(tag_epoch_i[3]),
        .O(tag_epoch_i_IBUF[3]));
  IBUF \tag_epoch_i_IBUF[4]_inst 
       (.I(tag_epoch_i[4]),
        .O(tag_epoch_i_IBUF[4]));
  IBUF \tag_epoch_i_IBUF[5]_inst 
       (.I(tag_epoch_i[5]),
        .O(tag_epoch_i_IBUF[5]));
  IBUF \tag_epoch_i_IBUF[6]_inst 
       (.I(tag_epoch_i[6]),
        .O(tag_epoch_i_IBUF[6]));
  IBUF \tag_epoch_i_IBUF[7]_inst 
       (.I(tag_epoch_i[7]),
        .O(tag_epoch_i_IBUF[7]));
  IBUF tag_valid_i_IBUF_inst
       (.I(tag_valid_i),
        .O(tag_valid_i_IBUF));
  OBUF valid_tag_o_OBUF_inst
       (.I(valid_tag_o_OBUF),
        .O(valid_tag_o));
  LUT4 #(
    .INIT(16'h0080)) 
    valid_tag_o_OBUF_inst_i_1
       (.I0(tag_valid_i_IBUF),
        .I1(valid_tag_o_OBUF_inst_i_2_n_0),
        .I2(valid_tag_o_OBUF_inst_i_3_n_0),
        .I3(valid_tag_o_OBUF_inst_i_4_n_0),
        .O(valid_tag_o_OBUF));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    valid_tag_o_OBUF_inst_i_2
       (.I0(tag_epoch_i_IBUF[0]),
        .I1(line_epoch_o_OBUF[0]),
        .I2(line_epoch_o_OBUF[2]),
        .I3(tag_epoch_i_IBUF[2]),
        .I4(line_epoch_o_OBUF[1]),
        .I5(tag_epoch_i_IBUF[1]),
        .O(valid_tag_o_OBUF_inst_i_2_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    valid_tag_o_OBUF_inst_i_3
       (.I0(tag_epoch_i_IBUF[3]),
        .I1(line_epoch_o_OBUF[3]),
        .I2(line_epoch_o_OBUF[5]),
        .I3(tag_epoch_i_IBUF[5]),
        .I4(line_epoch_o_OBUF[4]),
        .I5(tag_epoch_i_IBUF[4]),
        .O(valid_tag_o_OBUF_inst_i_3_n_0));
  LUT4 #(
    .INIT(16'h6FF6)) 
    valid_tag_o_OBUF_inst_i_4
       (.I0(tag_epoch_i_IBUF[6]),
        .I1(line_epoch_o_OBUF[6]),
        .I2(tag_epoch_i_IBUF[7]),
        .I3(line_epoch_o_OBUF[7]),
        .O(valid_tag_o_OBUF_inst_i_4_n_0));
  OBUF wrap_o_OBUF_inst
       (.I(wrap_o_OBUF),
        .O(wrap_o));
  LUT3 #(
    .INIT(8'h80)) 
    wrap_o_OBUF_inst_i_1
       (.I0(inv_v_i_IBUF),
        .I1(inv_epoch_o_OBUF[0]),
        .I2(wrap_o_OBUF_inst_i_2_n_0),
        .O(wrap_o_OBUF));
  LUT2 #(
    .INIT(4'h2)) 
    wrap_o_OBUF_inst_i_2
       (.I0(epochs_r_reg_r1_0_63_0_2_i_13_n_0),
        .I1(wrap_o_OBUF_inst_i_3_n_0),
        .O(wrap_o_OBUF_inst_i_2_n_0));
  LUT4 #(
    .INIT(16'h7FFF)) 
    wrap_o_OBUF_inst_i_3
       (.I0(inv_epoch_o_OBUF[3]),
        .I1(inv_epoch_o_OBUF[1]),
        .I2(inv_epoch_o_OBUF[2]),
        .I3(inv_epoch_o_OBUF[4]),
        .O(wrap_o_OBUF_inst_i_3_n_0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
