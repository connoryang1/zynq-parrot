# Preparation only: one bounded paired process, never a full-CPU build.
set_param general.maxThreads 8
puts "ACTUAL_TOOL_VERSION [version -short]"
puts "ACTUAL_MAX_THREADS [get_param general.maxThreads]"
if {![string match 2024.2* [version -short]] || [get_param general.maxThreads]!=8} {error "tool/thread identity"}
foreach kind {current canonical} {
  foreach suffix {utilization.rpt primitives.tsv synthesized.dcp functional.v} {
    if {[file exists ${kind}-$suffix]} {error "fresh outputs required"}
  }
  create_project -in_memory -part xc7z020clg400-1
  if {$kind eq "current"} {read_verilog -sv current.sv} else {
    read_verilog -sv bp_retained_epoch_ram.sv
    read_verilog -sv canonical-wrapper.sv
  }
  read_xdc clock.xdc
  synth_design -top epoch_probe -part xc7z020clg400-1 -directive AreaOptimized_high -global_retiming on -control_set_opt_threshold 1
  report_utilization -hierarchical -file ${kind}-utilization.rpt
  set f [open ${kind}-primitives.tsv w]
  puts $f "cell\tref_name"
  foreach c [lsort [get_cells -hier -filter {IS_PRIMITIVE == 1}]] {puts $f [join [list $c [get_property REF_NAME $c]] "\t"]}
  close $f
  write_checkpoint ${kind}-synthesized.dcp
  write_verilog -mode funcsim -rename_top epoch_${kind} ${kind}-functional.v
  close_project
}
puts "PAIRED_D_EPOCH_INFERENCE_COMPLETE"
