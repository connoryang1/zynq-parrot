`timescale 1ns/1ps
// Source-extracted production D256x8 epoch feedback probe, not a full backend.
module epoch_probe
 (input logic clk_d_i, reset_d_i, clear_d_i, inv_v_i
  ,input logic [33:0] inv_addr_i, insert_paddr_i
  ,input logic [3:0] state_i
  ,input logic [7:0] set_i
  ,input logic [10:0] clear_slot_i
  ,input logic tag_valid_i
  ,input logic [7:0] tag_epoch_i
  ,output wire [7:0] line_epoch_o, inv_epoch_o
  ,output wire wrap_o, clear_now_o, set_kill_o, valid_tag_o);
  localparam paddr_width_p=34, sets_p=256, epoch_width_p=8;
  localparam lane=1, lines_lp=1792, set_width_lp=8;
  wire [1:0] clk_i={clk_d_i,1'b0};
  wire [1:0] reset_i={reset_d_i,1'b0};
  wire [1:0] clear_i={clear_d_i,1'b0};
  wire [1:0] invalidate_v_i={inv_v_i,1'b0};
  wire [1:0][33:0] invalidate_addr_i={inv_addr_i,34'd0};
  wire [1:0][33:0] insert_addr_i={insert_paddr_i,34'd0};
  wire [7:0] set_r=set_i;
  wire [10:0] clear_slot_r=clear_slot_i;
    typedef enum logic [3:0] {
      e_clear, e_idle, e_lookup_tag, e_lookup_compare, e_lookup_data,
      e_lookup_collect, e_insert_tag, e_insert_compare, e_insert_invalidate,
      e_insert_data
    } state_e;
    state_e state_r;
    assign state_r=state_e'(state_i);
    (* ram_style = "distributed" *) logic [epoch_width_p-1:0] epochs_r [sets_p];
    wire [set_width_lp-1:0] inv_set = set_width_lp'(invalidate_addr_i[lane] >> 6)
                                                    & set_width_lp'(sets_p-1);
    wire set_kill = invalidate_v_i[lane] && (inv_set == set_r);
    wire wrap = (state_r != e_clear) && invalidate_v_i[lane]
                  && (&epochs_r[inv_set]) && (lines_lp != 0);
    wire clear_now = clear_i[lane] || wrap;
    // The idle insert capture and active tag comparison never use their epoch
    // read simultaneously. Invalidation retains its independent async read.
    wire [set_width_lp-1:0] insert_set
      = set_width_lp'(insert_addr_i[lane] >> 6) & set_width_lp'(sets_p-1);
    wire [set_width_lp-1:0] epoch_read_set = (state_r == e_idle) ? insert_set : set_r;
    wire [epoch_width_p-1:0] line_epoch = epochs_r[epoch_read_set];
    wire [set_width_lp-1:0] clear_set
      = set_width_lp'(clear_slot_r) & set_width_lp'(sets_p-1);
      always_ff @(posedge clk_i[lane]) begin
        if (!reset_i[lane]) begin
          if (state_r == e_clear) epochs_r[clear_set] <= '0;
          else if (!clear_now && invalidate_v_i[lane])
            epochs_r[inv_set] <= epochs_r[inv_set] + 1'b1;
        end
      end
  assign inv_epoch_o=epochs_r[inv_set];
  assign line_epoch_o=line_epoch;
  assign wrap_o=wrap;
  assign clear_now_o=clear_now;
  assign set_kill_o=set_kill;
  assign valid_tag_o=tag_valid_i && (tag_epoch_i==line_epoch);
endmodule
