#!/usr/bin/env python3
"""Local source/static contracts and paired admission; no vendor or remote launch."""
from pathlib import Path
import ast,hashlib,json,subprocess,shutil,re
HERE=Path(__file__).resolve().parent

def bind(p):
 raw=p.read_bytes();return dict(path=p.name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def main():
 for n in ('extract_current.py','run_remote.py','run_paired.py','seal.py'):ast.parse((HERE/n).read_text(),filename=n,feature_version=8)
 assert bind(HERE/'bp_retained_epoch_ram.sv')['sha256']=='a7673ffc8151b005fcfbfeb4a9e020098e0a2d409b2b79c0bebb2ebe9e0d8720'
 a=(HERE/'current.sv').read_text();c=(HERE/'canonical-wrapper.sv').read_text();port_end=a.index('  localparam');assert a[:port_end]==c[:port_end],'paired top ports differ'
 for source in (a,c):
  header=source[source.index('module epoch_probe'):source.index(');')]
  ports=set()
  for line in header.splitlines():
   m=re.search(r'(?:input|output)\s+(?:logic|wire)\s*(?:\[[^]]+\]\s*)*(.*)',line)
   if m:ports.update(name.strip() for name in m[1].split(','))
  body=source[source.index(');')+2:]
  declarations=set(re.findall(r'^\s*(?:wire|logic)\s*(?:\[[^]]+\]\s*)*([A-Za-z_]\w*)',body,re.M))
  assert not ports&declarations,'probe port redeclared as internal signal'
  assert "insert_addr_i={insert_paddr_i,34'd0}" in source
 for n in ('declaration','wires','writer','enum'):assert (HERE/('extracted-'+n+'.sv')).read_text() in a,'current fragment changed'
 inputs=('current.sv','canonical-wrapper.sv','bp_retained_epoch_ram.sv','clock.xdc','probe.tcl','run_remote.py');outputs=[k+'-'+s for k in ('current','canonical') for s in ('utilization.rpt','primitives.tsv','synthesized.dcp','functional.v')];assert not set(inputs)&set(outputs)
 assert (HERE/'clock.xdc').read_text()=='create_clock -name D_owning_clock -period 50 [get_ports clk_d_i]\n'
 script='set f [open {'+str(HERE/'probe.tcl')+'} r]\nset s [read $f]\nclose $f\nif {![info complete $s]} {exit 1}\nputs TCL_COMPLETE_ONLY\n';tcl=subprocess.run(['tclsh'],input=script,text=True,capture_output=True,check=True)
 used=int(subprocess.check_output(['du','-s','-B1',str(HERE)],text=True).split()[0]);assert used<=8*1024**2;assert shutil.disk_usage(HERE).free>=3*1024**3
 handoff=json.loads((HERE/'functional-handoff.json').read_text());final=handoff['final_manifest'];assert bind(HERE/final['path'])==final,'final handoff drift'
 names=tuple(inputs)+('extract_current.py','extracted-declaration.sv','extracted-wires.sv','extracted-writer.sv','extracted-enum.sv','current-backend.sv.gz','source-proof.json','epoch_reference.sv','full-backend-reference.json','functional-handoff.json','candidate-functional-handoff.json','README.md','run_paired.py','seal.py')
 admission=dict(state='PREPARED paired inference; final functional proof bound; root launch review required',inputs=[bind(HERE/n) for n in names],functional_handoff=handoff,top='epoch_probe',geometry=dict(sets=256,width=8,paddr=34,lines=1792,owning_clock_period_ns=50),settings=dict(directive='AreaOptimized_high',global_retiming='on',control_set_opt_threshold=1,threads=8,part='xc7z020clg400-1'),limits=dict(native_total_seconds=180,TERM_grace_seconds=15,SSH_seconds=220,prep_bytes=8*1024**2,mapped_top_level_outputs_bytes=32*1024**2,home_free_minimum=3*1024**3),arms=['current','canonical'],one_vendor_invocation=True,retries=0,board_operations=0,limitation='Current-isolated RAM inference would be context limitation. No isolated delta projects to actual fullbackend or FPGA saving/fit.')
 (HERE/'admission.json').write_text(json.dumps(admission,indent=2)+'\n');proof=dict(state='PASS local prep contracts only',admission=bind(HERE/'admission.json'),prep_allocated_bytes=used,Tcl_complete=tcl.stdout,paired_ports_identical=True,current_fragments_exact=True,canonical_source_exact=True,execution_eligible=handoff['final_pass'],vendor_executions=0,remote_operations=0);(HERE/'host-preparation-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
if __name__=='__main__':main()
