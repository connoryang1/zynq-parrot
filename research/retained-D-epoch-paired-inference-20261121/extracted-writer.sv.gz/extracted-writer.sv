      always_ff @(posedge clk_i[lane]) begin
        if (!reset_i[lane]) begin
          if (state_r == e_clear) epochs_r[clear_set] <= '0;
          else if (!clear_now && invalidate_v_i[lane])
            epochs_r[inv_set] <= epochs_r[inv_set] + 1'b1;
        end
      end
