#!/usr/bin/env python3
"""One source-bound paired epoch inference; local plan by default; no board."""
from pathlib import Path
from collections import Counter
import argparse,hashlib,json,re,shlex,shutil,subprocess
HERE=Path(__file__).resolve().parent
REMOTE='/tmp/retained-D-epoch-paired-inference-20261121-01'
HOST='coyang@haight.chillysky.com'
UPLOAD=('current.sv','canonical-wrapper.sv','bp_retained_epoch_ram.sv','clock.xdc','probe.tcl','run_remote.py')

def bind(p):
 raw=Path(p).read_bytes();return dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def check(a,expected):
 assert bind(HERE/'admission.json')['sha256']==expected,'admission drift'
 for row in a['inputs']:assert bind(HERE/row['path'])=={k:row[k] for k in ('bytes','sha256')},'input drift '+row['path']
 assert shutil.disk_usage(HERE).free>=3*1024**3,'home3GiB reserve'
 used=int(subprocess.check_output(['du','-s','-B1',str(HERE)],text=True).split()[0])
 if not (HERE/'run01').exists():assert used<=8*1024**2,'preparation8MiB cap'

def result(folder):
 cases={}
 for kind in ('current','canonical'):
  report=(folder/(kind+'-utilization.rpt')).read_text();m=re.search(r'^\| epoch_probe\s*\|\s*\(top\)\s*\|([^\n]+)\|$',report,re.M);assert m,'missing exact top row'
  values=[int(x.strip().replace(',','')) for x in m[1].split('|')];assert len(values)==8
  resources=dict(zip(('LUT','logic_LUT','LUTRAM','SRL','FF','RAMB36','RAMB18','DSP'),values));refs=Counter()
  rows=(folder/(kind+'-primitives.tsv')).read_text().splitlines();sep='\t' if '\t' in rows[0] else '\\t'
  for line in rows[1:]:name,ref=line.rsplit(sep,1);refs[ref]+=1
  for suffix in ('-synthesized.dcp','-functional.v'):assert (folder/(kind+suffix)).is_file()
  cases[kind]=dict(resources=resources,raw_primitive_refs=dict(refs),artifacts={suffix:bind(folder/(kind+suffix)) for suffix in ('-utilization.rpt','-primitives.tsv','-synthesized.dcp','-functional.v')})
 return dict(cases=cases,isolated_current_already_RAM=cases['current']['resources']['LUTRAM']>0,limits='Both complete results retained, including null/negative deltas. If isolated current infers RAM, that exposes context limitation; actual BP225 fullbackend still2048FF. No isolated delta applies directly to fullbackend/wholeFPGA. Raw macro+leaf refs overlap; use adjusted utilization.')

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execute',action='store_true');ap.add_argument('--admission-sha256');args=ap.parse_args()
 a=json.loads((HERE/'admission.json').read_text());expected=bind(HERE/'admission.json')['sha256'];check(a,expected)
 if not args.execute:print(json.dumps(dict(state='PREPARED ONLY; no remote/tool; functional handoff must be final before execute',admission_sha256=expected,functional_handoff=a['functional_handoff'],top='epoch_probe',upload=list(UPLOAD),limits=a['limits']),indent=2));return
 assert args.admission_sha256==expected,'exact reviewed admission SHA required'
 assert a['functional_handoff']['final_pass'],'final functional handoff pending: execution forbidden'
 out=HERE/'run01';out.mkdir();state=dict(state='RUNNING ONE paired epoch inference',admission_sha256=expected,commands=[],board_operations=0)
 def save():(out/'session.json').write_text(json.dumps(state,indent=2)+'\n')
 def run(label,argv,seconds):
  row=dict(label=label,argv=argv,timeout=seconds);state['commands'].append(row);save()
  try:
   with (out/(label+'.log')).open('wb') as log:r=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,timeout=seconds)
   row['returncode']=r.returncode;return r.returncode
  finally:row['log']=bind(out/(label+'.log'));save()
 ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-p','30041',HOST];launched=False;rc=None
 try:
  assert run('idle-fresh',ssh+["! pgrep -x vivado && test ! -e "+shlex.quote(REMOTE)+" && mkdir "+shlex.quote(REMOTE)],20)==0,'VM busy/output exists'
  assert run('upload',['scp','-q','-P','30041',*[str(HERE/n) for n in UPLOAD],HOST+':'+REMOTE+'/'],30)==0,'upload failed'
  hashes=' && '.join('test "$(sha256sum '+shlex.quote(n)+" | cut -d' ' -f1)"+'" = '+shlex.quote(bind(HERE/n)['sha256']) for n in UPLOAD)
  launched=True;rc=run('paired',ssh+['cd '+shlex.quote(REMOTE)+' && '+hashes+' && python3 -B run_remote.py'],220)
 except BaseException as e:state.update(state='FAIL one paired attempt; no retry',error=repr(e))
 finally:
  if launched:
   try:
    assert run('no-orphans',ssh+['! pgrep -x vivado'],20)==0,'global Vivado remains'
    script='import pathlib,json,hashlib; p=pathlib.Path('+repr(REMOTE)+'); fs=[f for f in p.iterdir() if f.is_file() and not f.is_symlink()]; assert sum(f.stat().st_size for f in fs)<=32*1024**2; print(json.dumps([dict(name=f.name,bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in fs]))'
    assert run('closed-files',ssh+['python3 -c '+shlex.quote(script)],20)==0,'closed output cap/manifest failure'
    rows=json.loads((out/'closed-files.log').read_text());assert all(re.fullmatch(r'[A-Za-z0-9_.-]+',r['name']) for r in rows)
    folder=out/'remote';folder.mkdir()
    assert run('collect',['scp','-q','-P','30041',*[HOST+':'+REMOTE+'/'+r['name'] for r in rows],str(folder)+'/'],40)==0,'closed partial collection failure'
    for row in rows:assert bind(folder/row['name'])=={k:row[k] for k in ('bytes','sha256')},'collected byte mismatch'
    remote=json.loads((folder/'session.json').read_text());state['remote_result']=remote
    assert rc==0 and remote['state'].startswith('PASS'),'paired batch failed/limited; preserve partial'
    state.update(state='PASS completed paired inference only; no fullbackend/FPGA benefit or fit claim',comparison=result(folder))
   except BaseException as e:state.update(state='FAIL closed/partial paired evidence',closure_error=repr(e))
  try:check(a,expected);state['source_endcheck']='PASS'
  except BaseException as e:state.update(state='FAIL source/resource endcheck',endcheck_error=repr(e))
  save()
 print(json.dumps(state,indent=2))
 if not state['state'].startswith('PASS'):raise SystemExit(1)
if __name__=='__main__':main()
