    (* ram_style = "distributed" *) logic [epoch_width_p-1:0] epochs_r [sets_p];
