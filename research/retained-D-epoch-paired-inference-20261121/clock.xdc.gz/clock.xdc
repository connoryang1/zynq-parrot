create_clock -name D_owning_clock -period 50 [get_ports clk_d_i]
