#!/usr/bin/env python3
"""Prepare exact current D-epoch slice and candidate wrapper shell; no tools/remote."""
from pathlib import Path
import hashlib,json,subprocess,gzip
HERE=Path(__file__).resolve().parent
BP=Path('/home/coyang/zynq-parrot-retained-dense/import/black-parrot')
REV='225489a435cb0b2a2c0b237077f94418dc89549b'
FILE='bp_common/src/v/bp_retained_line_store.sv'
SHA='bd4cd65c92bdaf8af80c9c6f4643383c8bfa7fd335ca131319d44c2e45ee2e24'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def main():
 raw=subprocess.check_output(['git','-C',str(BP),'show',REV+':'+FILE]);assert sha(raw)==SHA;text=raw.decode()
 enum_start=text.index('    typedef enum logic [3:0]');enum_end=text.index('    state_e state_r;',enum_start)
 enum=text[enum_start:enum_end]
 decl=next(line+'\n' for line in text.splitlines() if 'logic [epoch_width_p-1:0] epochs_r [sets_p]' in line)
 a=text.index('    wire [set_width_lp-1:0] inv_set');z=text.index('    wire publish_metadata',a);wires=text[a:z]
 a=text.index('      always_ff @(posedge clk_i[lane])',text.index('begin : distributed_epochs'));z=text.index('    end else begin : flop_epochs',a);writer=text[a:z]
 header='''`timescale 1ns/1ps
// Source-extracted production D256x8 epoch feedback probe, not a full backend.
module epoch_probe
 (input logic clk_d_i, reset_d_i, clear_d_i, inv_v_i
  ,input logic [33:0] inv_addr_i, insert_paddr_i
  ,input logic [3:0] state_i
  ,input logic [7:0] set_i
  ,input logic [10:0] clear_slot_i
  ,input logic tag_valid_i
  ,input logic [7:0] tag_epoch_i
  ,output wire [7:0] line_epoch_o, inv_epoch_o
  ,output wire wrap_o, clear_now_o, set_kill_o, valid_tag_o);
  localparam paddr_width_p=34, sets_p=256, epoch_width_p=8;
  localparam lane=1, lines_lp=1792, set_width_lp=8;
  wire [1:0] clk_i={clk_d_i,1'b0};
  wire [1:0] reset_i={reset_d_i,1'b0};
  wire [1:0] clear_i={clear_d_i,1'b0};
  wire [1:0] invalidate_v_i={inv_v_i,1'b0};
  wire [1:0][33:0] invalidate_addr_i={inv_addr_i,34'd0};
  wire [1:0][33:0] insert_addr_i={insert_paddr_i,34'd0};
  wire [7:0] set_r=set_i;
  wire [10:0] clear_slot_r=clear_slot_i;
'''
 aliases="    state_e state_r;\n    assign state_r=state_e'(state_i);\n"
 footer='''  assign line_epoch_o=line_epoch;
  assign wrap_o=wrap;
  assign clear_now_o=clear_now;
  assign set_kill_o=set_kill;
  assign valid_tag_o=tag_valid_i && (tag_epoch_i==line_epoch);
endmodule
'''
 current=header+enum+aliases+decl+wires+writer+'  assign inv_epoch_o=epochs_r[inv_set];\n'+footer
 (HERE/'current.sv').write_text(current)
 # Only the storage boundary changes. Feedback/operator priority stays the same.
 cwires=wires.replace('(&epochs_r[inv_set])','(&inv_epoch)').replace('wire [epoch_width_p-1:0] line_epoch = epochs_r[epoch_read_set];','wire [epoch_width_p-1:0] line_epoch;')
 storage='''    wire [epoch_width_p-1:0] inv_epoch;
    wire epoch_write_v = !reset_i[lane]
      && ((state_r==e_clear) || (!clear_now && invalidate_v_i[lane]));
    wire [set_width_lp-1:0] epoch_write_addr = (state_r==e_clear) ? clear_set : inv_set;
    wire [epoch_width_p-1:0] epoch_write_data = (state_r==e_clear) ? '0 : (inv_epoch+1'b1);
    bp_retained_epoch_ram #(.sets_p(256),.width_p(8)) epoch_storage
      (.clk_i(clk_i[lane]),.write_v_i(epoch_write_v),.write_addr_i(epoch_write_addr)
       ,.write_data_i(epoch_write_data),.read_addr_i(epoch_read_set)
       ,.invalidate_addr_i(inv_set),.read_data_o(line_epoch),.invalidate_data_o(inv_epoch));
    assign inv_epoch_o=inv_epoch;
'''
 # Declaration precedes wrap's inv_epoch use; no implicit wire is introduced.
 candidate=header+enum+aliases+'    wire [epoch_width_p-1:0] inv_epoch;\n'+cwires+storage.replace('    wire [epoch_width_p-1:0] inv_epoch;\n','')+footer
 (HERE/'canonical-wrapper.sv').write_text(candidate)
 for name,part in [('extracted-enum.sv',enum),('extracted-wires.sv',wires),('extracted-declaration.sv',decl),('extracted-writer.sv',writer)]: (HERE/name).write_text(part)
 (HERE/'current-backend.sv.gz').write_bytes(gzip.compress(raw,mtime=0))
 proof=dict(state='PREPARED current exact slice +candidate shell; canonical source/functional handoff pending',revision=REV,backend_path=FILE,backend_bytes=len(raw),backend_sha256=SHA,fragments={name:sha(part.encode()) for name,part in [('enum',enum),('declaration',decl),('wires',wires),('writer',writer)]},geometry=dict(D_sets=256,epoch_bits=8,paddr_bits=34,clear_slot_bits=11,lines=1792,owning_clock='positive edge of input D clock; global relation excluded'),variable_inputs=['reset','clear','invalidate valid/address','insert address','state','set','clear slot','tag valid/epoch'],observed_outputs=['line epoch8','invalidation epoch8','wrap','clear_now','set_kill','valid_tag'],limits='Epoch-only all-variable external state/read observation is not the actual full backend; current isolated RAM inference would establish a context limitation, not override actual2048FF full design.')
 (HERE/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
if __name__=='__main__':main()
