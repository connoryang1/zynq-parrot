    wire [set_width_lp-1:0] inv_set = set_width_lp'(invalidate_addr_i[lane] >> 6)
                                                    & set_width_lp'(sets_p-1);
    wire set_kill = invalidate_v_i[lane] && (inv_set == set_r);
    wire wrap = (state_r != e_clear) && invalidate_v_i[lane]
                  && (&epochs_r[inv_set]) && (lines_lp != 0);
    wire clear_now = clear_i[lane] || wrap;
    // The idle insert capture and active tag comparison never use their epoch
    // read simultaneously. Invalidation retains its independent async read.
    wire [set_width_lp-1:0] insert_set
      = set_width_lp'(insert_addr_i[lane] >> 6) & set_width_lp'(sets_p-1);
    wire [set_width_lp-1:0] epoch_read_set = (state_r == e_idle) ? insert_set : set_r;
    wire [epoch_width_p-1:0] line_epoch = epochs_r[epoch_read_set];
    wire [set_width_lp-1:0] clear_set
      = set_width_lp'(clear_slot_r) & set_width_lp'(sets_p-1);
