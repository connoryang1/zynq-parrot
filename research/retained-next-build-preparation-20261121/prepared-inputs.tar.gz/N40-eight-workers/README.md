This is a separate, unlaunched eight-worker N40 preparation. It preserves the frozen three-worker5898 helper and changes no RTL, guest, source worktree, model, stage or launch admission. Coordinator CPU HOLD and root review/release remain prerequisites for any actual preflight/build/runtime/audit.

The coordinator compile02 proof binds the exact b912 model and all275real compiler dependencies. Plain3/8/12-worker generated-C++ builds take129.65/81.45/79.87hostseconds and produce identical b912 bytes. Eight workers are the selected future setting. This is compile-only evidence: RTL elaboration and guest behavior were not benchmarked. The historical3-worker control was requalified by excluding only the396-entry generated __ver.d tracker; real compiler inputs remain checked.

The derivative fixes VERILATOR_BUILD_JOBS=8 and requires exactly --build-jobs8 in actual command metadata. It rejects3/12/80 and duplicate worker flags. Explicit OBJCACHE= disables compiler caching; strict ccache/no-PCH integration remains pending and is not enabled. Its separate cold118.90/warm2.03seconds are not used as expected N40/fullflow timing. Coordinator eight-worker sampled process-group sumRSS is2,775,130,112B; it can double-count shared pages and is distinct from the640MiB artifact limit and largest-child memory.

Everything else remains the N40-only gate: exact TOPeb7d/BP8df source, CLI delay40 only, old1792 integrity6dc1/f856 and cold083fe/627 ELF/NBF, static16KiB L2/20MHz/2resident4logical/1792lines/sets256/epoch8, unchanged assertion/guest/CORE/strict512b/eightrealwrites/Iretirement/counter/16geometry/source-ingestion/stamp checks. Correct NEWroot checker scripts remain required. Source and guest bytes are unchanged. Native b912 HP0 independent baseline remains d098.

Combined source/output RAM cap640MiB, durable HOME128MiB, RAM1GiB and HOME3GiB plus remaining allocation are unchanged. Eight compiler processes' host physical memory is a separate root scheduling/resource consideration. Build3600s/integrity600s/cold08180s native and150MiB/runtime FST bounds, no retry/extensions, and exact postPASS-only teardown allowance remain. A separate positive107 HP0 audit is required after the closed N40 cold08 trace. N200 is sequential and requires a separate admission only after complete N40 closure; this driver cannot launch it.

Future root preparation command, only after review and coordinator release (NOT executed and NOT an admission):

PYTHONDONTWRITEBYTECODE=1 python3 /home/coyang/fpga-artifacts/context-resume/retained-canonical-latency40-8workers-preparation-20261121/run_full.py --out /dev/shm/zp-canonical-latency40-8workers-20261121-01/prepared01 --prepare-only

Future execution would use the same helper with fresh full01 and an explicitly root-reviewed prepared01/session.json, exactly as the maintained gate. No prepared record/admission/stage exists yet. close_full.py uses only the distinct new RAM path and retains the same lossless model/source/rawFST evidence.
