#!/usr/bin/env python3
"""Read-only R7 snapshot; CONFIG is supplied by the pinned local monitor, never a shell."""
from pathlib import Path
import datetime,hashlib,json,os,re,shutil,socket,subprocess,time
JOB=CONFIG['job']
WORK_ROOT=Path(CONFIG['work_root'])
WORK=WORK_ROOT/('zynq-parrot-fpga-'+JOB)
LOGS=Path(CONFIG['log_root'])/JOB
DESIGN=WORK/'cosim/black-parrot-example/vivado'
RUN=DESIGN/'black_parrot_bd_proj.runs/synth_1'
EXPECTED=CONFIG['expected_defines']

def volume(path):
 p=Path(path)
 while not p.exists():
  if p==p.parent:raise RuntimeError('no existing volume ancestor')
  p=p.parent
 return dict(device=p.stat().st_dev,free_bytes=shutil.disk_usage(p).free,observed_path=str(p.resolve()))
def allocated(path):
 if not path.exists():return 0
 return int(subprocess.check_output(['du','-s','-B1',str(path)],text=True).split()[0])
def resources():
 home=volume('/home/coyang');work=volume(WORK_ROOT);shm=volume('/dev/shm')
 evidence_roots=[Path(CONFIG['log_root']),Path(CONFIG['evidence_root'])]
 if any(volume(p)['device']!=home['device'] for p in evidence_roots):
  raise RuntimeError('evidence roots are not on the measured HOME filesystem')
 return dict(volumes=dict(work=work,home=home,shm=shm),work_allocated_bytes=allocated(WORK_ROOT),evidence_allocated_bytes=sum(allocated(p) for p in evidence_roots),work_root_exists=WORK_ROOT.exists())

def binding(p):
 raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),raw.decode(errors='replace')
def process_table():
 rows={}
 for p in Path('/proc').glob('[0-9]*'):
  try:
   raw=(p/'stat').read_text();f=raw[raw.rfind(')')+2:].split()
   rows[int(p.name)]=dict(pid=int(p.name),ppid=int(f[1]),pgrp=int(f[2]),sid=int(f[3]),state=f[0],startticks=int(f[19]),utime_ticks=int(f[11]),stime_ticks=int(f[12]),RSS_bytes=int(f[21])*os.sysconf('SC_PAGE_SIZE'),threads=int(f[17]),comm=(p/'comm').read_text().strip(),argv=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace'))
  except (FileNotFoundError,ProcessLookupError,PermissionError,ValueError):pass
 return rows

def main():
 now=time.time();hz=os.sysconf('SC_CLK_TCK');up=float(Path('/proc/uptime').read_text().split()[0]);allprocs=process_table();owner_pid=int((LOGS/'pid').read_text().strip()) if (LOGS/'pid').exists() else -1;owner=allprocs.get(owner_pid)
 descendants={owner_pid};changed=True
 while changed:
  changed=False
  for pid,row in allprocs.items():
   if row['ppid'] in descendants and pid not in descendants:descendants.add(pid);changed=True
 result=dict(job=JOB,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),epoch=now,status=(LOGS/'status').read_text().strip() if (LOGS/'status').exists() else 'NOT_STARTED',ticks_per_second=hz,worker=owner,worker_elapsed_seconds=None if not owner else up-owner['startticks']/hz,
   descendants=[r for p,r in allprocs.items() if p in descendants],worker_group=[r for r in allprocs.values() if owner and r['pgrp']==owner['pgrp']],all_vivado=[r for r in allprocs.values() if r['comm']=='vivado'],files={},reports=[],identity_violations=[],definitions=[],feature_state='PENDING childTcl',feedback_warnings=[],inference=[],milestones=[],source={},resources={})
 result['resources']=resources()
 result['hostname']=socket.gethostname()
 if result['hostname']!=CONFIG['expected_hostname']:result['identity_violations'].append(dict(kind='hostname',actual=result['hostname'],expected=CONFIG['expected_hostname']))
 result['memory_kB']={k:int(v.split()[0]) for k,v in (line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines()) if k in ('MemAvailable','SwapFree','SwapTotal')}
 paths=[DESIGN/'bsg_blackparrot_pkg.v',DESIGN/'bsg_blackparrot_pkg.sv',LOGS/'revisions.txt',LOGS/'console.log',LOGS/'summary.txt',DESIGN/'config.tcl',RUN/'runme.log',RUN/'vivado.tcl',RUN/'black_parrot_bd_1_wrapper.tcl',DESIGN/'black_parrot_bd_proj.xpr']
 child=RUN/'black_parrot_bd_1_wrapper.tcl'
 for p in paths:
  if not p.is_file():continue
  record,text=binding(p);result['files'][str(p)]=record;lines=text.splitlines()
  if p.name in ('console.log','runme.log','summary.txt'):result.setdefault('tails',{})[str(p)]=lines[-10:]
  for number,line in enumerate(lines,1):
   if ('BP_RETAINED_' in line or 'BP_AXI_RESPONSE_DELAY' in line) and ('BP-EXPERIMENT-CONFIG:' in line or p in (child,DESIGN/'black_parrot_bd_proj.xpr')):result['definitions'].append(dict(path=str(p),line=number,text=line))
   if 'Synth 8-326' in line:result['feedback_warnings'].append(dict(path=str(p),line=number,text=line))
   if any(s in line for s in ('payload_mem','tag_mem','prefetch_fill_bank','epochs_r','epoch_ram','rr_r')) and not line.lstrip().startswith(('##','# ')):
    result['inference'].append(dict(path=str(p),line=number,context=lines[max(0,number-3):number+5]))
   if any(s in line for s in ('Starting Synth','Finished Synth','Start Technology','Starting Technology','Start RTL','Finished RTL','Start Part','End Part','Start Timing','Finished Timing','Start Optimization','Finished Optimization','Start Logic','Finished Logic','Start Phase','Phase ','synth_design completed','route_design completed','place_design completed','write_bitstream completed','ERROR:','CRITICAL WARNING:','BP-EXPERIMENT-CONFIG: project=black_parrot_bd_proj','CLKOUT1_REQUESTED_OUT_FREQ','PCW_FPGA0_PERIPHERAL_FREQMHZ','Multithreading enabled','set ::env(THREADS)','set ::env(ACLK','set ::env(CFG)','bp_cfg_gp','prefetch_fill_bank','posedge_clk')):result['milestones'].append(dict(path=str(p),line=number,text=line))
  if p==child and 'synth_design' in text:
   actual={key:sorted(set(int(v) for v in re.findall(r'\b'+key+r'\s*=\s*(\d+)',text))) for key in EXPECTED}
   result['child_actual_features']=actual
   if all(actual[k]==[v] for k,v in EXPECTED.items()):result['feature_state']='PASS all six actual child defines'
   elif now-p.stat().st_mtime>10:
    result['feature_state']='FAIL actual child defines';result['identity_violations'].append(dict(kind='child_actual_defines',actual=actual,expected=EXPECTED))
 # Bind every generated selected-config package actually copied into the IP.
 for p in DESIGN.glob('**/bsg_blackparrot_pkg.sv'):
  record,text=binding(p);selected=re.findall(r'bp_cfg_gp\s*=\s*(\w+)',text)
  result.setdefault('selected_configuration',[]).append(dict(binding=record,selected=selected,text=text))
  if selected and selected!=['e_bp_unicore_zynqparrot_prefetch16k_cfg']:
   result['identity_violations'].append(dict(kind='generated_static_cfg',path=str(p),actual=selected))
 rev=(LOGS/'revisions.txt').read_text() if (LOGS/'revisions.txt').exists() else ''
 for key,value in {'top_commit':'eb7d390134a0025331a2366a979a774263b146d5','black_parrot_commit':'8dfdbdeec84cb47f902bc1426d69ecb3efd91c7c','cfg':'e_bp_unicore_zynqparrot_prefetch16k_cfg','vivado_threads':'8','aclk_mhz':'20','sparse_source':'1'}.items():
  actual=re.findall(r'^'+key+r'=(.*)$',rev,re.M)
  if rev and actual!=[value]:result['identity_violations'].append(dict(kind='revision_configuration',key=key,actual=actual,expected=value))
 # Actual final PS configuration is read as text; no Vivado property query.
 for p in list(DESIGN.glob('**/*processing_system7*.xci'))+list(DESIGN.glob('**/*clk_wiz*.xci')):
  record,text=binding(p);hits=[line.strip() for line in text.splitlines() if any(s in line for s in ('PCW_FPGA0_PERIPHERAL_FREQMHZ','PCW_FCLK0_PERIPHERAL_CLKSRC','FCLK_CLK0_FREQ','FREQ_HZ','CLKOUT1_REQUESTED_OUT_FREQ'))]
  if hits:result.setdefault('clock_configuration',[]).append(dict(binding=record,lines=hits))
 for name,repo,expected in [('top',WORK,'eb7d390134a0025331a2366a979a774263b146d5'),('bp',WORK/'import/black-parrot','8dfdbdeec84cb47f902bc1426d69ecb3efd91c7c')]:
  if (repo/'.git').exists():
   head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip();result['source'][name]=head
   if head!=expected:result['identity_violations'].append(dict(kind='source_revision',repo=str(repo),actual=head,expected=expected))
 for p in [WORK/'import/black-parrot/bp_common/src/v/bp_retained_line_store.sv',WORK/'import/black-parrot/bp_me/src/v/cce/bp_uce.sv',WORK/'cosim/black-parrot-example/v/top_zynq.sv',WORK/'cosim/black-parrot-example/v/bp_common_pkg.sv']:
  if p.is_file():
   result['source'][str(p)]=binding(p)[0]
   relative=str(p.relative_to(WORK));expected=CONFIG['critical_sources'][relative]
   if result['source'][str(p)]['sha256']!=expected['sha256'] or result['source'][str(p)]['bytes']!=expected['bytes']:
    result['identity_violations'].append(dict(kind='critical_source',path=relative,actual=result['source'][str(p)],expected=expected))
 candidates=set(LOGS.glob('*.rpt'))
 for folder in (RUN,DESIGN/'black_parrot_bd_proj.runs/impl_1'):
  if folder.exists():candidates.update(folder.glob('*.rpt'))
 for p in sorted(candidates):
  record,text=binding(p)
  if record['bytes']<=2*1024**2:result['reports'].append(dict(binding=record,text=text))
  else:result['reports'].append(dict(binding=record,text='OMITTED oversized report; binding retained'))
 result['run_files']={str(folder):[dict(name=p.name,bytes=p.stat().st_size) for p in folder.iterdir() if p.is_file()] for folder in (RUN,DESIGN/'black_parrot_bd_proj.runs/impl_1') if folder.exists()}
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
