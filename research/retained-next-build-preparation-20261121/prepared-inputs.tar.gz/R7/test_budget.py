#!/usr/bin/env python3
"""Pure budget failure witnesses; never launches SSH, builds or a monitor."""
import copy,unittest
from budget import GiB,MiB,LIMITS,violations

def snapshot(work_free=None,home_free=None,shm_free=512*MiB):
    return dict(work_allocated_bytes=0,evidence_allocated_bytes=0,volumes=dict(work=dict(device=1,free_bytes=work_free if work_free is not None else GiB+LIMITS['work_cap_bytes']),home=dict(device=2,free_bytes=home_free if home_free is not None else 3*GiB+384*MiB),shm=dict(device=3,free_bytes=shm_free)))
class Budgets(unittest.TestCase):
    def test_exact_separate_reserves_pass(self):self.assertEqual(violations(snapshot(),0),[])
    def test_home_cannot_borrow_tmpfs(self):
        s=snapshot(work_free=100*GiB,home_free=3*GiB+384*MiB-1)
        r=violations(s,0);self.assertEqual(len(r),1);self.assertEqual(r[0]['names'],['home'])
    def test_tmpfs_cannot_borrow_home(self):
        s=snapshot(work_free=GiB+LIMITS['work_cap_bytes']-1,home_free=100*GiB)
        r=violations(s,0);self.assertEqual(len(r),1);self.assertEqual(r[0]['names'],['work'])
    def test_shm_floor_is_independent(self):
        self.assertEqual(violations(snapshot(100*GiB,100*GiB,512*MiB-1),0)[0]['names'],['shm'])
    def test_used_capacity_reduces_only_remaining_not_floor(self):
        s=snapshot();s['work_allocated_bytes']=LIMITS['work_cap_bytes'];s['evidence_allocated_bytes']=LIMITS['evidence_cap_bytes'];s['volumes']['work']['free_bytes']=GiB;s['volumes']['home']['free_bytes']=3*GiB
        self.assertEqual(violations(s,0),[])
        s['volumes']['work']['free_bytes']-=1;self.assertEqual(violations(s,0)[0]['names'],['work'])
    def test_both_caps_reject_even_with_abundant_other_space(self):
        s=snapshot(100*GiB,100*GiB);s['work_allocated_bytes']=LIMITS['work_cap_bytes']+1;s['evidence_allocated_bytes']=LIMITS['evidence_cap_bytes']+1
        self.assertEqual([r['name'] for r in violations(s,0)],['work','evidence'])
    def test_shared_work_home_sums_remaining_uses_max_floor(self):
        s=snapshot();need=3*GiB+LIMITS['work_cap_bytes']+384*MiB
        for name in ('work','home'):s['volumes'][name]=dict(device=1,free_bytes=need)
        self.assertEqual(violations(s,0),[])
        s['volumes']['work']['free_bytes']-=1;r=violations(s,0)
        self.assertEqual(len(r),1);self.assertEqual(r[0]['names'],['work','home']);self.assertEqual(r[0]['minimum'],need)
    def test_all_shared_does_not_duplicate_floor(self):
        s=snapshot();need=3*GiB+LIMITS['work_cap_bytes']+384*MiB
        for name in s['volumes']:s['volumes'][name]=dict(device=1,free_bytes=need)
        self.assertEqual(violations(s,0),[])
    def test_missing_or_malformed_snapshot_fails_closed(self):
        s=snapshot();del s['volumes']['work']
        with self.assertRaises(KeyError):violations(s,0)
        s=snapshot();s['work_allocated_bytes']=-1
        with self.assertRaises(ValueError):violations(s,0)
    def test_fixed_deadline(self):
        self.assertEqual(violations(snapshot(),10800),[])
        self.assertEqual(violations(snapshot(),10800.01)[0]['kind'],'elapsed_bound')
if __name__=='__main__':unittest.main(verbosity=2)
