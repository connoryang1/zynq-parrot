"""Source-only admission/oracle/resource negative checks. No model/reader."""
import copy
import json
from pathlib import Path
import unittest
from unittest.mock import patch
import profile256 as c
import clone_bridge as bridge
import supplement_fillwidth as fill

PROGRAM=Path('/home/coyang/fpga-artifacts/context-resume/retained-capacity1792-fixtures-20261121/preparation01/build01/manifest.json')

class Profile(unittest.TestCase):
 def test_same_first_way_full_payload_oracles_and_negative(self):
  program=json.loads(PROGRAM.read_text())
  for role in c.ORDER:
   actual=c.Validator(program,role);large=c.original.Validator(program,role)
   self.assertEqual(actual.targets,{a:r for a,r in large.targets.items() if r['slot']<256})
   self.assertEqual(len(actual.targets),256)
   self.assertEqual(len({r['index'] for r in actual.targets.values()}),256)
   self.assertTrue(all(len(r['words'])==8 for r in actual.targets.values()))
  self.assertEqual(c.counters_for('d-enabled'),[0,256,0,256,0,2048])
  self.assertEqual(c.counters_for('d-off'),[0]*6)
  self.assertEqual(c.counters_for('i-enabled'),[256,0,256,0,2048,0])
  self.assertEqual(len(c.original.audit.selection()),167)
 def test_phase_allocation_and_combined_negative(self):
  m=1024**2
  self.assertEqual(c.CAPS['stage_total'],256*m)
  self.assertEqual(c.CAPS['raw_per_case'],64*m);self.assertEqual(c.CAPS['audit_per_case'],16*m)
  self.assertEqual(c.CAPS['raw_total']+c.CAPS['audit_total']+c.CAPS['other_total'],c.CAPS['stage_total'])
  self.assertEqual(tuple(c.ORDER),('d-enabled','d-off','i-enabled'))
  self.assertEqual(c.CAPS['native_ms'],1800000);self.assertEqual(c.CAPS['native_outer_s'],1980)
  with self.assertRaisesRegex(ValueError,'actual own/R7 separate caps'):
   c.shared.work_requirement(768*m+1,0,99*1024**3)
 def test_wrong_closed_clone_anchor_rejected(self):
  true=bridge.bind
  def changed(p):
   row=true(p)
   if Path(p)==bridge.ROOT/'closed01/build/evidence/build.json':row['sha256']='0'*64
   return row
  with patch.object(bridge,'bind',side_effect=changed):
   with self.assertRaisesRegex(ValueError,'closed anchor'):bridge.read()
 def test_fillwidth_aliases_zero_drift_and_missing_EOF_rejected(self):
  parse=fill.parser()
  lines=['#FST\t0\t100\t-12\n']+['#SIGNAL\t'+k+'\t32\t91\tTOP.x.unicore_lite.'+k+'\n' for k in fill.EXPECTED]
  lines+=['0\t91\t'+format(64,'032b')+'\n','#END\n']
  self.assertEqual(parse(lines)['values'],fill.EXPECTED)
  for bad in [lines[:-1],lines[:-2]+['0\t91\t'+format(32,'032b')+'\n','#END\n'],lines+['#END\n']]:
   with self.assertRaises(ValueError):parse(bad)
 def test_frozen_transitive_sources_and_maintained_checker(self):
  paths=[r['path'] for r in c.runtime_sources()]
  self.assertEqual(len(paths),len(set(paths)))
  for name in ['budget256_v2.py','prepare256.py','geometry256.py','software_owned_v2.py','check_run.py','archive_stream.py']:
   self.assertTrue(any(p.endswith('/'+name) for p in paths),name)
  run=(c.HERE/'run_capacity256.py').read_text()
  self.assertIn("ROOT=Path('/home/coyang/zp-retained256-source-20261122')",run)
  self.assertIn("(c.CAPS['raw_per_case'], c.CAPS['raw_per_case'])",run)
  self.assertNotIn('128*1024**2',run)
if __name__=='__main__':unittest.main()
