#!/usr/bin/env python3
"""ROOT reader-only supplement on closed ORIGINAL256 FST, never a target."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import profile256 as c

EXPECTED=dict(icache_fill_width_p=64,dcache_fill_width_p=64,l2_fill_width_p=64)
FST=c.shared.BASE/'full01/advisory/trace.fst'
FST_SHA='8f4c13bfca1e54cd38d4e2747e0c9849f18cd89c9d85d980fba83c8e6307e813'
OUT=c.HERE/'fillwidth-original01'

def parser():
    path=c.QUAL/'geometry256.py'
    spec=importlib.util.spec_from_file_location('unchanged_parameter_parser',path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    # Reuse the unchanged strict path/32bit/alias/order/constant/EOF parser;
    # only its requested dictionary is narrowed to three additional parameters.
    mod.EXPECTED=EXPECTED
    return mod.parse

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execute-reader',action='store_true');a=ap.parse_args()
    c.require(a.execute_reader,'ROOT reader-only opt-in required')
    c.require(not OUT.exists(),'one fresh supplement; no retry')
    before=c.bind(FST);c.require(before['sha256']==FST_SHA,'closed actual original full256 cold08 FST')
    proposal,_,_,_=c.bridge.read();reader=proposal['reader'];c.old.verify(reader)
    c.shared.check();c.require(__import__('shutil').disk_usage(c.HERE).free>=3*1024**3+8*1024**2,'HOME3GiB plus own helper allocation');c.require(c.shared.size(c.HERE)<7*1024**2,'1MiB supplement output reservation in8MiB helper family')
    OUT.mkdir()
    selection=OUT/'selection.tsv';selection.write_text(''.join(k+'\tunicore_lite.'+k+'\n' for k in EXPECTED))
    command=[reader['path'],str(FST),str(selection)]
    def guard():
        c.shared.check();c.require(c.shared.size(OUT)<=1024**2 and c.shared.size(c.HERE)<=8*1024**2,'fixed1MiB supplement/8MiB helper cap')
    cp=c.native.owned_run(command,OUT,dict(os.environ),OUT/'events.tsv',600,None,guard,lambda:1024**2-c.shared.size(OUT)-65536)
    c.require(cp.returncode==0,'reader actual0')
    with (OUT/'events.tsv').open() as f:facts=parser()(f)
    c.require(c.bind(FST)==before,'closed input unchanged')
    life=json.loads((OUT/'events.owned.json').read_text());c.require(life['failure'] is None and not life['owned_group_remaining'],'owned reader fully closed')
    record=dict(state='PASS original256 actual fillwidth triple64 cleanEOF',facts=facts,
        bindings=dict(fst=before,reader=reader,auditor=c.bind(__file__),parser=c.bind(c.QUAL/'geometry256.py'),selection=c.bind(selection),events=c.bind(OUT/'events.tsv'),ownership=c.bind(OUT/'events.owned.json')),
        scope='Only original fullmodel raw parameter observations. Same eval/source clone qualified separately; scoped414 FST does not declare these three constants. Original16parameter audit unchanged. No fit/performance claim.')
    c.archive.write_json(OUT/'verification.json',record);guard();print(json.dumps(c.bind(OUT/'verification.json')))
if __name__=='__main__':main()
