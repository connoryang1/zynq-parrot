"""Exact256 all-slot profile; unchanged full167 parser/Validator/stream archive."""
import importlib.util
import json
from pathlib import Path
import sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
QUAL=Path('/home/coyang/zynq-parrot-linux-host-observer/research/retained256-qualification-20261122')
sys.path.insert(0,str(QUAL))
OLD=QUAL.parent/'retained1792-stream-cohort-20261121/contract.py'
import clone_bridge as bridge
spec=importlib.util.spec_from_file_location('frozen1792foundation',OLD)
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
require,bind=old.require,old.bind
require(bind(OLD)['sha256']=='73972d62e8b185fa482d22be6386d65c55db550c4b3966a2e9ba065f6a87b402','unchanged established full167 foundation')
ORDER=old.ORDER
native,original,archive=old.native,old.original,old.archive
FOUNDATION=old.FOUNDATION
resource_phase=old.resource_phase
CAPS=dict(old.CAPS,raw_per_case=64*1024**2,raw_total=192*1024**2,audit_per_case=16*1024**2,audit_total=48*1024**2,other_total=16*1024**2,stage_total=256*1024**2)
GEOMETRY=dict(old.GEOMETRY,i_lines=256,d_lines=256)
BASE=Path('/run/user/1001/zp-retained256-scoped-capacity-20261122-01')
import budget256_v2 as shared


class Validator(original.audit.Validator):
    def __init__(self,program,role):
        require(program['max_lines']==1792 and program['max_sets']==256,'same062a runtime-geometry ELF bounds')
        super().__init__(program,role)
        self.lines,self.sets=256,256;self.targets={}
        for slot in range(256):
            index=(slot*0xaaaaaaaaaaaaaaab)&255
            address=program['code_base']+192*index if self.lane=='i' else program['data_base']+64*slot
            self.targets[address]=dict(slot=slot,index=index,words=original.generate.code_words(index) if self.lane=='i' else original.generate.data_words(slot))

    def finish(self):
        result=super().finish();result['sets']=256
        result['limits']='Exact256 retained lines/side,256sets,full64B actual payload; unchanged ordinary L1/16KiBL2. Simulation correctness only; no FPGA/performance claim.'
        return result


def counters_for(role):return [0,256,0,256,0,2048] if role=='d-enabled' else [256,0,256,0,2048,0] if role=='i-enabled' else [0]*6


def runtime_sources():
    names=('profile256.py','run_capacity256.py','audit_capacity256.py','prepare_capacity256.py','clone_bridge.py','supplement_fillwidth.py','test_profile.py')
    sources=[bind(HERE/name) for name in names]+old.runtime_sources()
    sources += [bind(QUAL/name) for name in ('budget256_v2.py','prepare256.py','software_owned_v2.py','geometry256.py')]
    sources += [bind('/home/coyang/zp-retained256-source-20261122/testing/check_run.py')]
    return sources


def check_budget(stage,p):
    stage=Path(stage);require(stage==BASE,'fixed own capacity stage')
    raw=sum(f.stat().st_size for f in stage.glob('*/trace.fst'))
    audits=[sum(f.stat().st_size for f in (stage/(r+'-audit')).rglob('*') if f.is_file()) for r in ORDER]
    total=shared.size(stage);full=shared.size(shared.BASE)+shared.size(shared.FAILED_BASE);r7=shared.size(shared.R7)
    require(total<=CAPS['stage_total'] and raw<=CAPS['raw_total'] and sum(audits)<=CAPS['audit_total'] and total-raw-sum(audits)<=CAPS['other_total'],'fixed256MiB phase split')
    require(all(f.stat().st_size<=CAPS['raw_per_case'] for f in stage.glob('*/trace.fst')) and all(n<=CAPS['audit_per_case'] for n in audits),'fixed64MiB raw/16MiB audit per case')
    require(shared.size(HERE)<=8*1024**2,'new HOME helper cap8MiB')
    shared.home.check_budget()
    durable=shared.size(shared.DURABLE)
    require(durable<=shared.DURABLE_CAP and __import__('shutil').disk_usage(shared.home.HERE).free>=shared.home.HOME_FLOOR+
        max(0,shared.home.SOURCE_CAP-shared.size(shared.home.SOURCE))+max(0,shared.home.HELPER_CAP-shared.size(shared.home.HERE))+shared.DURABLE_CAP-durable+max(0,8*1024**2-shared.size(HERE)),'same HOME source/helper/durable reserve plus own8MiB')
    require(shared.BASE.is_dir() and shared.R7.is_dir() and stage.parent.stat().st_dev==shared.BASE.stat().st_dev==shared.R7.stat().st_dev,'actual ROOT same-volume full/capacity/R7 stages')
    require(stage.stat().st_dev!=shared.home.HERE.stat().st_dev,'no HOME borrowing')
    shared.work_requirement(full+total,r7,__import__('shutil').disk_usage(stage).free)
    if p:
        st=stage.stat();require(p['stage_identity']==dict(path=str(stage),device=st.st_dev,inode=st.st_ino),'same owned stage/inode')


def bridge_bindings():
    return [bind(bridge.ROOT/rel) for rel in bridge.ANCHORS]+[bind(bridge.FULL)]


def load(path,expected_sha):
    require(bind(path)['sha256']==expected_sha and len(expected_sha)==64,'external exact256 preparation SHA')
    p=json.loads(Path(path).read_text())
    require(p['schema']=='retained256-scoped-capacity-cohort-v1' and p['state']=='ROOT-APPROVED exact256 complete-audit simulation only','DRAFT UNLAUNCHABLE')
    require(Path(path)==BASE/'preparation.json' and p['stage']==str(BASE),'fixed new256 preparation')
    require(p['geometry']==GEOMETRY and p['caps']==CAPS and p['runtime_sources']==runtime_sources(),'exact256 profile/same fixed caps/source identity')
    for row in p['runtime_sources']+[p['fullcore'],p['compiled_sources'],p['model'],p['program'],p['reader'],p['fillwidth_supplement']]:old.verify(row)
    proposal,q,b,arc=bridge.read()
    require(p['clone_bridge']==bridge_bindings(),'fixed actual qualified scoped bridge')
    full=json.loads(Path(p['fullcore']['path']).read_text())
    require(full['state']=='PASS matched256 composite cleanbuild/integrity/cold08 strict512b-eight-real-writes-Iretire-counter-geometry-source-audits','actual full256 composite gate first; producer failure preserved')
    require(bind(p['fullcore']['path'])['sha256']==bridge.COMPOSITE_SHA,'exact composite anchor')
    require(p['model']==b['binary'] and p['model']['sha256']==bridge.SCOPED,'same actually qualified trace-only model')
    require(full['model']['sha256']==bridge.ORIGINAL and full['inherited_native_attempt']==proposal['original_session'],'original composite model/producer bridge')
    for row in full['closed_audits'].values():old.verify(row)
    source=json.loads(Path(p['compiled_sources']['path']).read_text())
    old.verify(full['actual_source_list']);old.verify(proposal['model_stamp'])
    raw=json.loads(Path(full['actual_source_list']['path']).read_text())['sources']
    require(source=={path:{k:row[k] for k in ('path','bytes','sha256')} for path,row in raw.items()}==proposal['compiled_sources'],'all actual compiled sources, same clone unchanged eval inputs')
    for row in source.values():old.verify(row)
    original.source_bindings(Path(p['compiled_sources']['path']))
    supplement=json.loads(Path(p['fillwidth_supplement']['path']).read_text())
    require(supplement['state']=='PASS original256 actual fillwidth triple64 cleanEOF' and supplement['facts']['values']==dict(icache_fill_width_p=64,dcache_fill_width_p=64,l2_fill_width_p=64),'actual original fill widths, not guessed or scoped aliases')
    require(supplement['bindings']['auditor']==bind(HERE/'supplement_fillwidth.py'),'supplement source pin')
    for row in supplement['bindings'].values():old.verify(row)
    require(p['environment']==proposal['environment'] and p['linked_libraries']==proposal['linked_libraries'],'same qualified environment and libraries')
    program=json.loads(Path(p['program']['path']).read_text())
    require(p['program']['sha256']=='88546c8afc17c482e42cb731459f44c2a40f2f6aeee2c172321534c872dabd72' and program['elf']['sha256']=='062a3dd884d64bc1fdf7f0048f312cc5efc84280eb89006c21ef6b60f1f43ed6','unchanged062a runtime geometry program')
    old.verify(program['elf'])
    for role in ORDER:old.verify(program['cases'][role]['nbf'])
    require(p['reader']==dict(path='/home/coyang/fpga-artifacts/context-resume/retained-use-observation-20261121/fst-reader/fst_events',bytes=151200,sha256='a9227fe2368ab376b7700a08e044b81c18261432dadeb89e8baeafab021f7541'),'same maintained reader')
    require(set(p['environment'])=={'LD_LIBRARY_PATH'},'exact model environment scope')
    for row in p['linked_libraries']:old.verify(row)
    return p,program


def check_native(stage, role, p, preparation_path, expected_sha):
    case=Path(stage)/role; path=case/'verification.json'
    require(bind(path)['sha256'] == expected_sha, 'external native-proof anchor mismatch')
    run=json.loads(path.read_text()); require(run['role'] == role and run['state'].startswith('PASS'), 'complete exact native role')
    require(run['counters'] == counters_for(role), 'all actual GP0 counters exact/nonsaturated')
    require(run['admission'] == bind(case/'admission.json'), 'fixed native admission path')
    ad=json.loads((case/'admission.json').read_text())
    require(ad['preparation'] == bind(preparation_path) and ad['model'] == p['model'] and ad['program'] == p['program'], 'native exact approved inputs')
    require(ad['schema'] == 'retained-capacity256-stream-native-v1' and ad['role'] == role, 'new native schema')
    require(ad['reader'] == p['reader'] and ad['compiled_sources'] == p['compiled_sources'], 'native reader/source identity')
    expected=[bind(case/name) for name in ('prog.riscv','prog.nbf','run.log','process.json','trace.fst')]
    require(run['files'] == expected, 'native fixed file paths and hashes')
    require(ad['elf'] == bind(case/'prog.riscv') and ad['nbf'] == bind(case/'prog.nbf'), 'actual loaded inputs')
    program=json.loads(Path(p['program']['path']).read_text())
    require(ad['elf']['sha256'] == program['elf']['sha256'] and ad['nbf']['sha256'] == program['cases'][role]['nbf']['sha256'], 'loaded fixture bytes')
    require(json.loads(Path(ad['runtime_sources']['path']).read_text()) == p['runtime_sources'] and ad['runtime_sources'] == bind(Path(stage)/'runtime-sources.json'), 'exact runtime snapshot')
    return run


def verify_audit(stage, role, p, preparation_path, expected_sha):
    out=Path(stage)/(role+'-audit'); accepted=out/'acceptance.json'
    require(bind(accepted)['sha256'] == expected_sha, 'external audit acceptance anchor mismatch')
    receipt=json.loads(accepted.read_text())
    require(receipt['schema'] == 'retained256-stream-acceptance-v1' and receipt['role'] == role, 'new exact audit role')
    require(receipt['preparation'] == bind(preparation_path) and receipt['sources'] == p['runtime_sources'], 'trusted source/admission set')
    run=check_native(stage,role,p,preparation_path,receipt['native_sha256'])
    expected_names=('verification.json','selection.tsv','gp0-counter-projection.tsv.gz','counter-check-input/verification.json','counter-words.json','counter-checker.log','counter-checker.owned.json','reader.stderr','reader.owned.json')
    require(receipt['files'] == [bind(out/name) for name in expected_names], 'all archive paths fixed inside owned case; no unsigned path redirection')
    full=json.loads((out/'verification.json').read_text()); adapter_path=out/'counter-check-input/verification.json';adapter=json.loads(adapter_path.read_text());counter=json.loads((out/'counter-words.json').read_text())
    require(full['state'].startswith('PASS') and full['lane'] == role[0] and full['lines'] == 256 and full['sets'] == 256 and len(full['targets']) == 256, 'full configured targets')
    require(bind(out/'selection.tsv')['sha256'] == '2c38d34248a066f58ed9526784955dab7d0b23b1cc15b240129530ec1f81086c', 'exact raw167 selection bytes')
    require(full['bindings'] == dict(fst=bind(Path(stage)/role/'trace.fst'), run=bind(Path(stage)/role/'verification.json'), admission=bind(Path(stage)/role/'admission.json'), program=p['program'], model=p['model'], reader=p['reader'], selection=bind(out/'selection.tsv'), preparation=bind(preparation_path)), 'exact complete proof provenance')
    archive_info=full['archive'];projection=bind(out/'gp0-counter-projection.tsv.gz')
    require(archive_info['counter_projection'] == projection and archive_info['schema'] == 'full167-digest-explicit-counter-projection-v1', 'projection cannot impersonate full167 events')
    stream=archive_info['full_stream'];require(stream['reader_returncode'] == 0 and stream['exact_end_records'] == 1 and stream['lines'] == stream['events']+169 and stream['bytes']>0 and len(stream['sha256']) == 64, 'complete full167 stream digest/count receipt')
    require(adapter == dict(schema='counter-projection-input-only-v1', full_audit=bind(out/'verification.json'), bindings=dict(events=projection,run=bind(Path(stage)/role/'verification.json'))), 'exact adapter to full proof chain')
    checker=next(r for r in FOUNDATION if r['path'].endswith('/check_counter_words.py'))
    require(counter['state'] == 'PASS final FST counter words equal actual GP0 reads' and counter['values'] == run['counters'] and counter['auditor'] == checker and counter['audit'] == bind(adapter_path) and counter['run'] == adapter['bindings']['run'] and counter['events'] == projection, 'unchanged checker source/state/all six values and adapter chain')
    life=json.loads((out/'reader.owned.json').read_text());require(life['returncode'] == 0 and life['failure'] is None and life['owned_group_remaining'] is False, 'actual reader0 and owned cleanup')
    require(life['argv'] == [p['reader']['path'],str(Path(stage)/role/'trace.fst'),str(out/'selection.tsv')], 'actual complete reader invocation')
    counter_life=json.loads((out/'counter-checker.owned.json').read_text())
    require(counter_life['returncode'] == 0 and counter_life['failure'] is None and counter_life['owned_group_remaining'] is False, 'counter checker actual0 and bounded cleanup')
    return receipt
