#!/usr/bin/env python3
"""ROOT source/budget preflight and fresh all256 stage only; never a model/reader."""
import argparse
import json
from pathlib import Path
import shutil
import profile256 as c

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--prepare',action='store_true');ap.add_argument('--supplement-sha256',required=True);a=ap.parse_args()
    c.require(a.prepare,'explicit ROOT prepare only')
    p,q,b,arc=c.bridge.read()
    c.require(p['original_TOP']=='596e4677fdcbbf59706be254384f778861f0cc36' and p['original_BP']==c.shared.home.BP,'exact configured baseline source')
    supplement=c.HERE/'fillwidth-original01/verification.json';c.require(c.bind(supplement)['sha256']==a.supplement_sha256,'external actual triple64 proof anchor')
    full_path=c.shared.BASE/'full01/postprocess02/session.json'
    c.require(c.bind(full_path)['sha256']==c.bridge.COMPOSITE_SHA,'correct composite, no promotion of failed producer')
    full=json.loads(full_path.read_text());c.require(full['state'].startswith('PASS matched256 composite '),'closed full composite')
    for row in full['closed_audits'].values():c.old.verify(row)
    c.old.verify(full['actual_source_list']);c.old.verify(b['binary']);c.old.verify(p['model_stamp'])
    raw=json.loads(Path(full['actual_source_list']['path']).read_text())['sources']
    sources={path:{k:row[k] for k in ('path','bytes','sha256')} for path,row in raw.items()}
    c.require(sources==p['compiled_sources'],'clone original exact compiled source inventory')
    for row in sources.values():c.old.verify(row)
    for row in p['linked_libraries']:c.old.verify(row)
    used=c.shared.size(c.shared.BASE)+c.shared.size(c.shared.FAILED_BASE)
    c.require(used+c.CAPS['stage_total']<=c.shared.OWN_CAP,'full+failed+clone actualbytes must leave complete new256MiB phase under768MiB')
    # Actual ROOT namespace identity, no private /run/user substitution.
    sentinel=Path(p['namespace_sentinel']);st=sentinel.stat()
    c.require(dict(device=st.st_dev,inode=st.st_ino)==p['namespace_identity'],'actual ROOT namespace sentinel')
    c.shared.check();c.require(not c.BASE.exists(),'fresh one-shot exact256 stage; no retry')
    c.BASE.mkdir();st=c.BASE.stat();c.check_budget(c.BASE,{})
    out=c.BASE/'compiled-sources.json';c.archive.write_json(out,sources)
    draft=json.loads((c.QUAL.parent/'retained1792-stream-cohort-20261121/preparation.DRAFT.json').read_text())
    record=dict(schema='retained256-scoped-capacity-cohort-v1',state='ROOT-APPROVED exact256 complete-audit simulation only',
        stage=str(c.BASE),stage_identity=dict(path=str(c.BASE),device=st.st_dev,inode=st.st_ino),geometry=c.GEOMETRY,caps=c.CAPS,
        runtime_sources=c.runtime_sources(),fullcore=c.bind(full_path),clone_bridge=c.bridge_bindings(),model=b['binary'],
        compiled_sources=c.bind(out),program=draft['program'],reader=p['reader'],environment=p['environment'],linked_libraries=p['linked_libraries'],fillwidth_supplement=c.bind(supplement),
        resource_preflight=dict(full_failed_clone_bytes=used,future_phase_bytes=c.CAPS['stage_total'],combined_cap_bytes=c.shared.OWN_CAP,
          allocation_headroom_bytes=c.shared.OWN_CAP-used-c.CAPS['stage_total'],free_bytes=shutil.disk_usage(c.BASE).free),
        limitation='All-slot synthetic correctness only. D-enabled then D-off then I-enabled; complete per-address167 audit before next role. No FPGA/fit/application/performance claim.')
    path=c.BASE/'preparation.json';c.archive.write_json(path,record);c.load(path,c.bind(path)['sha256']);c.check_budget(c.BASE,record)
    print(json.dumps(c.bind(path),sort_keys=True));print(json.dumps(record['resource_preflight'],sort_keys=True))
if __name__=='__main__':main()
