#!/usr/bin/env python3
"""Only future D-off/I native bridge after actual RO prior-role acceptance."""
import argparse,importlib.util,json,sys
from pathlib import Path
import ro_contract as c


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--role',choices=c.ORDER[1:],required=True);parser.add_argument('--continuation-sha256',required=True);parser.add_argument('--adapter-sha256',required=True);parser.add_argument('--prior-audit-sha256',action='append',default=[]);parser.add_argument('--execute',action='store_true');a=parser.parse_args()
    c.require(a.execute,'explicit future ROOT command required; never D-enabled retry')
    adapter=c.bind(__file__);c.require(adapter['sha256']==a.adapter_sha256,'exact externally reviewed future adapter SHA')
    c.CONTINUATION_SHA=a.continuation_sha256;prep=c.BASE/'preparation.json';p,_=c.load(prep,c.PREP_SHA)
    c.require(len(a.prior_audit_sha256)==c.ORDER.index(a.role),'all prior RO acceptance anchors')
    for role,sha in zip(c.ORDER,a.prior_audit_sha256):c.verify_audit(c.BASE,role,p,prep,sha)
    c.check_budget(c.BASE,p)
    wrapper=c.BASE/(a.role+'-bridge-admission.json');c.require(not wrapper.exists(),'one fixed remaining-role native, no retry')
    c.archive.write_json(wrapper,dict(schema='retained256-ro-prior-native-bridge-v1',role=a.role,continuation=c.bind(c.A),sources=c.new_sources(),adapter=adapter,prior_audits=a.prior_audit_sha256,preparation=c.bind(prep),limits='Original model/program/1800s/1980s/caps/checkers unchanged; only prior acceptance output path and efficient accounting bridged.'))
    path=c.base.HERE/'run_capacity256.py';spec=importlib.util.spec_from_file_location('frozen256_native',path);runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
    # Reuse the immutable runner/guest/checkers. Bind the explicit RO path and
    # single-pass accounting via this admitted outer adapter, never edit source.
    runner.c=c;runner.check_budget=c.check_budget
    sys.argv=[str(path),'--preparation',str(prep),'--preparation-sha256',c.PREP_SHA,'--role',a.role,'--execute']
    for sha in a.prior_audit_sha256:sys.argv+=['--prior-audit-sha256',sha]
    runner.main()
    c.require(c.bind(__file__)==adapter,'future adapter source changed during native')
    proof=c.BASE/a.role/'verification.json';c.check_native(c.BASE,a.role,p,prep,c.bind(proof)['sha256']);c.load(prep,c.PREP_SHA);c.check_budget(c.BASE,p)
    c.archive.write_json(c.BASE/(a.role+'-bridge-verification.json'),dict(state='PASS original native with admitted RO-prior bridge',native=c.bind(proof),bridge=c.bind(wrapper),continuation=c.bind(c.A),sources=c.new_sources(),adapter=adapter))
if __name__=='__main__':main()
