This prepares a separate read-only audit continuation on the complete, unchanged D-enabled256 native trace. It does not rerun the model or promote the original operational audit failure. Full167 semantic validation,512-bit payload/real SRAM writes/coherence, all256 targets, counter corroboration and complete EOF remain unchanged.

Original native65140 completed with counters0/256/0/256/0/2048; proof2086bd00f119241843bc93493598c31c4b82b8dfaa8bda5f9ac0cfcf79b3fa87. Its10095979B rawFST is ea9e1663f65d0e580db82db0abe686e18b84259ec39d12d3c75e82ba00f24d08. Audit3201 failed `phase resource poll gap over1s` before acceptance. The reader was killed/reaped (PG1099707,return−9,GeneratorExit), with its own distinct monitor's maximum gap0.251879s. The failed audit directory and lossless HOME preservation remain immutable; they supply no accepted per-address result.

Five later ROOT measurements of the old check_budget were0.50327/0.49029/0.52298/0.49352/0.50047s. These demonstrate substantial later recursive-scan cost under stated host conditions, not the exact failed duration or an exclusive CPU-contention cause. The old phase poll measured start-to-next-start across the preceding expensive scan. Separate resource-phase, reader-monitor and every512-event callbacks could all run that scan.

The new guard uses a single os.scandir/stat pass per root and one scanner. It preserves every byte-count/cap/reserve, includes failed plus RO audit outputs together in the same16MiB per-role allowance, and additionally counts all original/failure/new helper files within the same8MiB helper allocation. Independent background scans still run every0.25s with the same1s start-gap limit; cheap event/reader callbacks enforce snapshot age≤1s. Each scan must complete within an additional prospective0.5s bound. Full scans run at entry and exit, and actual timings are retained. No poll-gap relaxation or static-directory-size guess is used. Preparation compares exact old recursive counts with the one-pass counts on all actual roots, then requires five fast scans≤0.5s before a reader is eligible.

The original acceptance verifier is copied byte-for-byte except its function name and the explicit output directory `ROLE-audit-ro01`; a host test proves this exact substitution. The validator, complete167 selection/parser/archive semantics, reader ownership guard and counter checker are the same frozen objects. Original model/scoped proof/program/native/preparation/source hashes remain bound. Only the explicitly labeled GP0 projection is archived; every raw167 event is validated and included in the complete-input digest.

ROOT preparation (no reader/native):

```sh
python3 -B /home/coyang/fpga-artifacts/context-resume/retained256-scoped-allslots-20261122/readonly-audit-continuation01/prepare_ro.py --prepare
```

ROOT reviews returned admission SHA and actual count/timing/reserve proof, then may run only the read-only D-enabled continuation:

```sh
python3 -B /home/coyang/fpga-artifacts/context-resume/retained256-scoped-allslots-20261122/readonly-audit-continuation01/audit_ro.py --execute --preparation /run/user/1001/zp-retained256-scoped-capacity-20261122-01/preparation.json --preparation-sha256 55e995d4cc748bfe4786eb309fd8e103499557b745bba6ab7b38809bc147d587 --role d-enabled --native-sha256 2086bd00f119241843bc93493598c31c4b82b8dfaa8bda5f9ac0cfcf79b3fa87 --continuation-sha256 ROOT_REVIEWED_CONTINUATION_SHA
```

Same reader3600s/audit3665s/owned5s cleanup; no target invocation or automatic retry. Same256MiB phase and768MiB combined allocation; no trace/model limit change. The new acceptance is written only after the resource phase closes successfully and pins that receipt. Any failure leaves no usable acceptance.

After that new acceptance passes, `run_remaining.py` provides the explicit prior-acceptance bridge for future ROOT-authorized D-off then I-enabled native commands, reusing the immutable original runner, unchanged ELF/NBF, same native1800s/outer1980s and all checkers. D-enabled is excluded from that wrapper's role choices. Supply the reviewed continuation SHA and all prior RO audit acceptance SHAs in order. Each future native is followed by the same new fast-accounting full audit; no subsequent role is automatic. The original failed directory is never overwritten.

Six host tests cover exact symlink/file accounting, joint failed+RO charging, literal verifier-source equivalence, no duplicate scans from5000 callbacks, strict1s stale rejection, and unchanged semantic validator/limits. These fixtures run no ROOT reader/native/vendor. Actual ROOT resource preflight and new audit completion remain pending. No FPGA/fit/application/performance inference follows from this diagnostic correction.
