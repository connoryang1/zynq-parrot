"""Anchored operational continuation; unchanged semantic validator/counter gates."""
import json,hashlib,sys
from pathlib import Path
sys.dont_write_bytecode=True
OLD=Path('/home/coyang/fpga-artifacts/context-resume/retained256-scoped-allslots-20261122/preparation01')
sys.path.insert(0,str(OLD))
import profile256 as base
from profile256 import *
import fast_budget
HERE=Path(__file__).resolve().parent
A=HERE/'admission.json'
FAIL=HERE.parent/'ROOT-audit-failure01'
PREP_SHA='55e995d4cc748bfe4786eb309fd8e103499557b745bba6ab7b38809bc147d587'
NATIVE_SHA='2086bd00f119241843bc93493598c31c4b82b8dfaa8bda5f9ac0cfcf79b3fa87'
FST_SHA='ea9e1663f65d0e580db82db0abe686e18b84259ec39d12d3c75e82ba00f24d08'
CONTINUATION_SHA=None

def new_sources():
    return [bind(HERE/n) for n in ('fast_budget.py','ro_contract.py','audit_ro.py','prepare_ro.py','run_remaining.py','test_ro.py')]
def audit_path(stage,role):
    require(role in ORDER,'only fixed three roles')
    return Path(stage)/(role+'-audit-ro01')
def check_budget(stage,p):return fast_budget.check(stage,p)
resource_phase=fast_budget.phase

def load(path,expected_sha):
    require(expected_sha==PREP_SHA,'unchanged actual original preparation anchor')
    p,program=base.load(path,expected_sha)
    require(CONTINUATION_SHA is not None and bind(A)['sha256']==CONTINUATION_SHA,'externally reviewed continuation SHA required')
    a=json.loads(A.read_text())
    require(a['schema']=='retained256-readonly-operational-continuation-v1' and a['state']=='ROOT-PREPARED pending exact execution review','new continuation schema/state')
    require(a['original_preparation']==bind(path) and a['new_sources']==new_sources(),'all frozen/new executed sources bound')
    require(a['caps']==CAPS and a['native_sha256']==NATIVE_SHA and a['FST_sha256']==FST_SHA,'same original caps/native/trace')
    require(a['preserved_failure']==[bind(r['path']) for r in a['preserved_failure']],'original failure HOME preservation')
    for r in a['failed_audit_inventory']:old.verify(r)
    require(not (BASE/'d-enabled-audit/acceptance.json').exists(),'original failed audit never promoted')
    require(bind(BASE/'d-enabled/verification.json')['sha256']==NATIVE_SHA,'unchanged complete native proof')
    run=base.check_native(BASE,'d-enabled',p,path,NATIVE_SHA)
    require(next(r for r in run['files'] if r['path'].endswith('/trace.fst'))['sha256']==FST_SHA,'exact same rawFST')
    return p,program

def semantic_verify_audit(stage, role, p, preparation_path, expected_sha):
    out=audit_path(stage,role); accepted=out/'acceptance.json'
    require(bind(accepted)['sha256'] == expected_sha, 'external audit acceptance anchor mismatch')
    receipt=json.loads(accepted.read_text())
    require(receipt['schema'] == 'retained256-stream-acceptance-v1' and receipt['role'] == role, 'new exact audit role')
    require(receipt['preparation'] == bind(preparation_path) and receipt['sources'] == p['runtime_sources'], 'trusted source/admission set')
    run=check_native(stage,role,p,preparation_path,receipt['native_sha256'])
    expected_names=('verification.json','selection.tsv','gp0-counter-projection.tsv.gz','counter-check-input/verification.json','counter-words.json','counter-checker.log','counter-checker.owned.json','reader.stderr','reader.owned.json')
    require(receipt['files'] == [bind(out/name) for name in expected_names], 'all archive paths fixed inside owned case; no unsigned path redirection')
    full=json.loads((out/'verification.json').read_text()); adapter_path=out/'counter-check-input/verification.json';adapter=json.loads(adapter_path.read_text());counter=json.loads((out/'counter-words.json').read_text())
    require(full['state'].startswith('PASS') and full['lane'] == role[0] and full['lines'] == 256 and full['sets'] == 256 and len(full['targets']) == 256, 'full configured targets')
    require(bind(out/'selection.tsv')['sha256'] == '2c38d34248a066f58ed9526784955dab7d0b23b1cc15b240129530ec1f81086c', 'exact raw167 selection bytes')
    require(full['bindings'] == dict(fst=bind(Path(stage)/role/'trace.fst'), run=bind(Path(stage)/role/'verification.json'), admission=bind(Path(stage)/role/'admission.json'), program=p['program'], model=p['model'], reader=p['reader'], selection=bind(out/'selection.tsv'), preparation=bind(preparation_path)), 'exact complete proof provenance')
    archive_info=full['archive'];projection=bind(out/'gp0-counter-projection.tsv.gz')
    require(archive_info['counter_projection'] == projection and archive_info['schema'] == 'full167-digest-explicit-counter-projection-v1', 'projection cannot impersonate full167 events')
    stream=archive_info['full_stream'];require(stream['reader_returncode'] == 0 and stream['exact_end_records'] == 1 and stream['lines'] == stream['events']+169 and stream['bytes']>0 and len(stream['sha256']) == 64, 'complete full167 stream digest/count receipt')
    require(adapter == dict(schema='counter-projection-input-only-v1', full_audit=bind(out/'verification.json'), bindings=dict(events=projection,run=bind(Path(stage)/role/'verification.json'))), 'exact adapter to full proof chain')
    checker=next(r for r in FOUNDATION if r['path'].endswith('/check_counter_words.py'))
    require(counter['state'] == 'PASS final FST counter words equal actual GP0 reads' and counter['values'] == run['counters'] and counter['auditor'] == checker and counter['audit'] == bind(adapter_path) and counter['run'] == adapter['bindings']['run'] and counter['events'] == projection, 'unchanged checker source/state/all six values and adapter chain')
    life=json.loads((out/'reader.owned.json').read_text());require(life['returncode'] == 0 and life['failure'] is None and life['owned_group_remaining'] is False, 'actual reader0 and owned cleanup')
    require(life['argv'] == [p['reader']['path'],str(Path(stage)/role/'trace.fst'),str(out/'selection.tsv')], 'actual complete reader invocation')
    counter_life=json.loads((out/'counter-checker.owned.json').read_text())
    require(counter_life['returncode'] == 0 and counter_life['failure'] is None and counter_life['owned_group_remaining'] is False, 'counter checker actual0 and bounded cleanup')
    return receipt


def verify_audit(stage,role,p,preparation_path,expected_sha):
    receipt=semantic_verify_audit(stage,role,p,preparation_path,expected_sha)
    require(receipt['continuation']==bind(A) and receipt['new_sources']==new_sources(),'operational continuation/source binding')
    require(receipt['original_failed_audit_preserved'] is True,'no old failed-audit overwrite')
    require(receipt['resource_phase']==bind(audit_path(stage,role)/'resource-phase.json'),'resource monitor receipt exact bytes')
    life=json.loads((audit_path(stage,role)/'resource-phase.json').read_text())
    require(life['failure'] is None and life['poll_gap_limit_s']==1 and life['max_poll_gap_s']<=1 and life['max_scan_seconds']<=.5,'unchanged1s poll guard and measured efficient scan')
    return receipt
