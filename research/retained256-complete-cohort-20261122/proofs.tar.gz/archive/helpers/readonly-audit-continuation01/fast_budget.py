"""One-pass accounting; one scanner, unchanged .25s polling/1s gap limit."""
from contextlib import contextmanager
import json,os,shutil,threading,time
from pathlib import Path
import sys
OLD=Path('/home/coyang/fpga-artifacts/context-resume/retained256-scoped-allslots-20261122/preparation01')
sys.path.insert(0,str(OLD))
import profile256 as base
HERE=Path(__file__).resolve().parent

def scan(root):
    """Match Path.rglob file semantics: no symlink-directory recursion."""
    root=Path(root);rows={};todo=[root]
    if not root.exists():return rows
    while todo:
        directory=todo.pop()
        with os.scandir(directory) as entries:
            for entry in entries:
                if entry.is_dir(follow_symlinks=False):todo.append(Path(entry.path))
                elif entry.is_file(follow_symlinks=True):rows[Path(entry.path)]=entry.stat(follow_symlinks=True).st_size
    return rows

def snapshot(stage):
    s=base.shared;home=s.home
    roots=dict(stage=Path(stage),full=s.BASE,failed=s.FAILED_BASE,r7=s.R7,source=home.SOURCE,old_helper=home.HERE,durable=s.DURABLE,helpers=HERE.parent)
    # helpers covers the original preparation, failure preservation AND this
    # continuation under their existing shared8MiB allocation, not exclusions.
    rows={k:scan(p) for k,p in roots.items()};totals={k:sum(v.values()) for k,v in rows.items()}
    raw=sum(n for p,n in rows['stage'].items() if p.name=='trace.fst' and p.parent.parent==Path(stage))
    audits={role:sum(n for p,n in rows['stage'].items() if p.relative_to(stage).parts[0] in (role+'-audit',role+'-audit-ro01')) for role in base.ORDER}
    return dict(totals=totals,raw=raw,audits=audits,rows=rows)

def check(stage,p=None):
    s=base.shared;h=s.home;q=snapshot(stage);t=q['totals'];require=base.require;C=base.CAPS
    require(Path(stage)==base.BASE,'fixed existing capacity stage')
    require(t['stage']<=C['stage_total'] and q['raw']<=C['raw_total'] and sum(q['audits'].values())<=C['audit_total'] and t['stage']-q['raw']-sum(q['audits'].values())<=C['other_total'],'same phase/sum caps, failed and RO audit charged together')
    require(all(n<=C['raw_per_case'] for path,n in q['rows']['stage'].items() if path.name=='trace.fst' and path.parent.parent==Path(stage)) and all(n<=C['audit_per_case'] for n in q['audits'].values()),'same pertrace/combined perrole audit caps')
    require(t['source']<=h.SOURCE_CAP and t['old_helper']<=h.HELPER_CAP and t['durable']<=s.DURABLE_CAP and t['helpers']<=8*1024**2,'unchanged HOME source/helper/durable caps')
    need=h.HOME_FLOOR+max(0,h.SOURCE_CAP-t['source'])+max(0,h.HELPER_CAP-t['old_helper'])+s.DURABLE_CAP-t['durable']+8*1024**2-t['helpers']
    require(shutil.disk_usage(HERE).free>=need,'same HOME3GiB and all remaining allocations')
    r=json.loads(s.R7_ADMISSION.read_text());require(r['configuration']['work_root']==str(s.R7) and r['resources']['work_cap_bytes']==s.R7_CAP,'same R7 allocation')
    st=Path(stage).stat();require(st.st_dev==s.BASE.stat().st_dev==s.R7.stat().st_dev!=HERE.stat().st_dev,'same actual ROOT volume, no HOME borrowing')
    if p:require(p['stage_identity']==dict(path=str(stage),device=st.st_dev,inode=st.st_ino),'unchanged stage inode')
    s.work_requirement(t['full']+t['failed']+t['stage'],t['r7'],shutil.disk_usage(stage).free)
    return dict(totals=t,raw_bytes=q['raw'],per_role_audit_bytes=q['audits'],HOME_required_free_bytes=need)

@contextmanager
def phase(check,receipt):
    """The event hot path checks freshness, not a duplicate directory walk."""
    stop=threading.Event();errors=[];stats=dict(interval_s=.25,poll_gap_limit_s=1,scans=0,max_poll_gap_s=0,max_scan_seconds=0,max_callback_age_s=0);last=[None];prior=[None]
    def sweep():
        start=time.monotonic()
        if prior[0] is not None:
            gap=start-prior[0];stats['max_poll_gap_s']=max(stats['max_poll_gap_s'],gap);base.require(gap<=1,'phase resource poll gap over1s')
        prior[0]=start;check();elapsed=time.monotonic()-start
        stats['max_scan_seconds']=max(stats['max_scan_seconds'],elapsed);base.require(elapsed<=.5,'efficient scan exceeded predeclared0.5s budget')
        stats['scans']+=1;last[0]=time.monotonic()
    def guarded():
        if errors:raise errors[0]
        age=time.monotonic()-last[0];stats['max_callback_age_s']=max(stats['max_callback_age_s'],age);base.require(age<=1,'phase resource snapshot stale over1s')
    def poll():
        while not stop.wait(.25):
            try:sweep()
            except BaseException as e:errors.append(e);return
    sweep();thread=threading.Thread(target=poll,daemon=True);thread.start()
    try:
        yield guarded
        guarded()
    except BaseException as e:
        errors.append(e)
        raise
    finally:
        stop.set();thread.join(timeout=1)
        if thread.is_alive():errors.append(ValueError('phase resource guard did not stop'))
        if not errors:
            # Final complete accounting before any acceptance can survive.
            prior[0]=None
            try:sweep()
            except BaseException as e:errors.append(e)
        stats['failure']=repr(errors[0]) if errors else None
        Path(receipt).write_text(json.dumps(stats,indent=2)+'\n')
        if errors:raise errors[0]
