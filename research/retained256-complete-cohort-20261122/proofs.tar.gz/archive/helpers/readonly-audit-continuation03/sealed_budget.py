"""Seal inactive trees at entry/exit; live accounting touches mutable output only."""
from contextlib import contextmanager
import gzip,hashlib,json,os,shutil,time
from pathlib import Path
import fast_budget as f
from process_monitor import phase as monitor_phase
base=f.base

def bind(p):return base.bind(p)
def classify(path,stage):
    rel=Path(path).relative_to(stage);top=rel.parts[0]
    if len(rel.parts)==2 and rel.parts[1]=='trace.fst':return 'raw'
    for role in base.ORDER:
        if top==role+'-audit' or top.startswith(role+'-audit-ro'):return role
    return 'other'
def inventory(root,exclude=None):
    root=Path(root);result={};todo=[root]
    if not root.exists():return result
    while todo:
        directory=todo.pop()
        with os.scandir(directory) as entries:
            for e in entries:
                p=Path(e.path)
                if exclude is not None and (p==exclude or exclude in p.parents):continue
                if e.is_dir(follow_symlinks=False):todo.append(p)
                elif e.is_file(follow_symlinks=True):
                    st=e.stat(follow_symlinks=True);r=bind(p)
                    r.update(device=st.st_dev,inode=st.st_ino,mtime_ns=st.st_mtime_ns,ctime_ns=st.st_ctime_ns,mode=st.st_mode)
                    result[str(p)]=r
    return result

class Ledger:
    def __init__(self,stage,p,out,extra_sources):
        start=time.monotonic();self.stage=Path(stage);self.p=p;self.out=Path(out);self.extra_sources=extra_sources
        s=base.shared;h=s.home
        base.require(self.stage==base.BASE and self.out.parent==self.stage,'fixed cohort/direct mutable audit output')
        self.role=next((r for r in base.ORDER if self.out.name.startswith(r+'-audit-ro')),None)
        base.require(self.role is not None,'explicit fixed role audit output')
        self.roots=dict(stage=self.stage,full=s.BASE,failed=s.FAILED_BASE,r7=s.R7,source=h.SOURCE,old_helper=h.HERE,durable=s.DURABLE)
        self.root_ids={name:(root.stat().st_dev,root.stat().st_ino) for name,root in self.roots.items()}
        self.seals={name:inventory(root,self.out if name=='stage' else None) for name,root in self.roots.items()}
        self.totals={name:sum(r['bytes'] for r in rows.values()) for name,rows in self.seals.items()}
        self.charge=dict(raw=0,other=0,**{r:0 for r in base.ORDER})
        for path,r in self.seals['stage'].items():self.charge[classify(path,self.stage)]+=r['bytes']
        base.require(all(r['bytes']<=base.CAPS['raw_per_case'] for path,r in self.seals['stage'].items() if classify(path,self.stage)=='raw'),'same immutable rawtrace percase cap')
        st=self.stage.stat();base.require(p['stage_identity']==dict(path=str(self.stage),device=st.st_dev,inode=st.st_ino),'unchanged stage inode')
        base.require(st.st_dev==s.BASE.stat().st_dev==s.R7.stat().st_dev!=Path(__file__).stat().st_dev,'same actual ROOT work volume')
        a=json.loads(s.R7_ADMISSION.read_text());base.require(a['configuration']['work_root']==str(s.R7) and a['resources']['work_cap_bytes']==s.R7_CAP,'same preserved R7 reservation')
        self.helper_root=Path(__file__).resolve().parent.parent
        base.require(sum(f.scan(self.helper_root).values())<=8*1024**2,'helper family fits precharged full8MiB')
        self.entry_seconds=time.monotonic()-start
        self.out.mkdir(exist_ok=True)
        self.manifest=self.out/'sealed-inactive-inputs.json.gz'
        data=json.dumps(dict(roots={k:str(v) for k,v in self.roots.items()},files=self.seals,totals=self.totals,stage_charges=self.charge,extra_sources=extra_sources,helpers_charge_bytes=8*1024**2),sort_keys=True).encode()
        self.manifest.write_bytes(gzip.compress(data,mtime=0));self.check()
    def check(self):
        # No repeated inactive scans/stats/hashes here: all bytes are sealed.
        s=base.shared;h=s.home;C=base.CAPS;t=self.totals;c=self.charge
        mutable=sum(f.scan(self.out).values());audit={r:c[r]+(mutable if r==self.role else 0) for r in base.ORDER}
        total=t['stage']+mutable
        base.require(total<=C['stage_total'] and c['raw']<=C['raw_total'] and sum(audit.values())<=C['audit_total'] and c['other']<=C['other_total'],'same stage/raw/audit/other caps with ALL sealed failures')
        base.require(all(n<=C['audit_per_case'] for n in audit.values()),'same perrole failed+allRO audit cap')
        base.require(t['source']<=h.SOURCE_CAP and t['old_helper']<=h.HELPER_CAP and t['durable']<=s.DURABLE_CAP,'same HOME sealed source/helper/durable caps')
        need=h.HOME_FLOOR+max(0,h.SOURCE_CAP-t['source'])+max(0,h.HELPER_CAP-t['old_helper'])+s.DURABLE_CAP-t['durable']+8*1024**2
        base.require(shutil.disk_usage(self.out).free>=s.FLOOR+(s.OWN_CAP-t['full']-t['failed']-total)+(s.R7_CAP-t['r7']),'same1GiB work floor plus BOTH remaining caps')
        base.require(t['full']+t['failed']+total<=s.OWN_CAP and t['r7']<=s.R7_CAP,'same768MiB own/R7 caps')
        base.require(shutil.disk_usage(self.helper_root).free>=need,'same3GiB HOME and conservative full8MiB helper reserve')
        return dict(sealed_totals=t,mutable_output_bytes=mutable,per_role_audit_bytes=audit,stage_total_bytes=total,HOME_required_free_bytes=need,helpers_precharged_bytes=8*1024**2)
    def verify_exit(self):
        start=time.monotonic()
        for name,root in self.roots.items():
            base.require((root.stat().st_dev,root.stat().st_ino)==self.root_ids[name],'sealed root identity changed: '+name)
            actual=inventory(root,self.out if name=='stage' else None)
            base.require(actual==self.seals[name],'sealed inactive inventory/content changed: '+name)
        for row in self.extra_sources:base.old.verify(row)
        base.require(sum(f.scan(self.helper_root).values())<=8*1024**2,'actual helpers remain within precharged full8MiB')
        resources=self.check()
        (self.out/'sealed-exit.json').write_text(json.dumps(dict(state='PASS all sealed inactive bytes/inventories unchanged',inventory=bind(self.manifest),entry_seconds=self.entry_seconds,exit_seconds=time.monotonic()-start,resources=resources),indent=2)+'\n')
        self.check()
    @contextmanager
    def phase(self,receipt):
        error=None
        try:
            with monitor_phase(self.check,receipt) as guard:yield guard
        except BaseException as e:error=e
        try:self.verify_exit()
        except BaseException as e:
            if error is None:error=e
        if error is not None:raise error
