#!/usr/bin/env python3
"""ROOT source/count/timing preflight only. Never reader/native/vendor."""
import argparse,json,time,fcntl
from pathlib import Path
import ro_contract as c
import parser_fixture


def main():
    a=argparse.ArgumentParser();a.add_argument('--prepare',action='store_true');args=a.parse_args();c.require(args.prepare,'explicit ROOT source-only preparation')
    c.require(not c.A.exists(),'one fresh continuation admission')
    prep=c.BASE/'preparation.json';p,program=c.base.load(prep,c.PREP_SHA)
    native=c.base.check_native(c.BASE,'d-enabled',p,prep,c.NATIVE_SHA)
    c.require(next(x for x in native['files'] if x['path'].endswith('/trace.fst'))['sha256']==c.FST_SHA,'same rawFST')
    failure=c.FAIL/'ROOT-exit.json';facts=json.loads(failure.read_text())
    c.require(facts['error']=='phase resource poll gap over1s' and not facts['acceptance_created'] and not facts['native_retried'],'exact preserved operational failure only')
    life=json.loads((c.FAIL/'d-enabled-audit/reader.owned.json').read_text())
    c.require(life['returncode']==-9 and life['failure']=='GeneratorExit()' and not life['owned_group_remaining'] and life['max_observed_poll_gap_s']<1,'preserved reader killed/reaped, its own poller stayed within1s')
    oldout=c.BASE/'d-enabled-audit';priorout=c.BASE/'d-enabled-audit-ro02';earlierout=c.BASE/'d-enabled-audit-ro01'
    inventory=[c.bind(x) for d in (oldout,earlierout,priorout) for x in sorted(d.rglob('*')) if x.is_file()]
    prior_admission=c.HERE.parent/'readonly-audit-continuation02/admission.json'
    c.require(c.bind(prior_admission)['sha256']=='522f4b44b7a45b46673b9dd37543677a80b1718a87982b22ec2babac07134cf6','preserved RO02 admission')
    phase_failure=json.loads((priorout/'resource-phase.json').read_text())
    c.require(phase_failure['failure'] is not None and '0.5s' in phase_failure['failure'] and phase_failure['owned_group_remaining'] is False,'exact scanner-duration operational failure, owned process gone')
    c.require(not (earlierout/'acceptance.json').exists() and not (priorout/'acceptance.json').exists(),'both failed continuations unpromoted')
    c.require(inventory and not (oldout/'acceptance.json').exists() and not c.audit_path(c.BASE,'d-enabled').exists(),'preserved failed directory and fresh RO output')
    copies=json.loads((c.FAIL/'copy-manifest.json').read_text())+json.loads((c.HERE.parent/'ROOT-audit-failure02/copy-manifest.json').read_text())
    for row in copies:
        original=c.bind(row['source']);copy=c.bind(row['copy']);c.require(all(original[k]==copy[k]==row[k] for k in ('bytes','sha256')),'lossless failure copy')
    # Exact recursive-count equivalence on all roots, including symlink files.
    snap=c.fast_budget.snapshot(c.BASE)
    roots=dict(stage=c.BASE,full=c.shared.BASE,failed=c.shared.FAILED_BASE,r7=c.shared.R7,source=c.shared.home.SOURCE,old_helper=c.shared.home.HERE,durable=c.shared.DURABLE,helpers=c.HERE.parent)
    for name,path in roots.items():c.require(snap['totals'][name]==c.shared.size(path),'onepass bytes differ '+name)
    start=time.monotonic();resources=c.fast_budget.check(c.BASE,p)
    timings=[time.monotonic()-start]  # diagnostic only, never a live-scan threshold
    fixture_out=c.BASE/'d-enabled-audit-ro03-preflight'
    c.require(not fixture_out.exists(),'one fresh charged mutable-output fixture')
    fixture_out.mkdir();fixture_receipt=fixture_out/'resource-phase.json'
    with c.resource_phase(c.BASE,p,fixture_out,fixture_receipt) as guard:
        fixture=parser_fixture.exercise(c,guard,seconds=6,mutable=fixture_out/'mutable-parser-output.bin')
    fixture_monitor=json.loads(fixture_receipt.read_text())
    c.require(fixture_monitor['failure'] is None and fixture_monitor['returncode']==0 and not fixture_monitor['owned_group_remaining'] and fixture_monitor['max_scan_seconds']<=.5 and fixture_monitor['max_poll_gap_s']<=1 and fixture_monitor['max_callback_age_s']<=1,'actual sealed-ledger monitor must pass under CPU-bound exact167 parser and output writes')
    c.require(fixture['event_lines']>=16700 and fixture['rising_samples']>=50 and fixture['mutable_bytes']>0,'nontrivial CPU parser/mutable-output fixture')
    c.require(fixture_monitor['max_mutable_output_bytes']>fixture_monitor['initial_mutable_output_bytes'],'monitor must observe actual mutable output growth')
    c.require(c.bind(prep)['sha256']==c.PREP_SHA and c.bind(c.BASE/'d-enabled/verification.json')['sha256']==c.NATIVE_SHA,'input proof drift during preflight')
    rec=dict(schema='retained256-readonly-operational-continuation-v1',state='ROOT-PREPARED pending exact execution review',original_preparation=c.bind(prep),new_sources=c.new_sources(),caps=c.CAPS,
      native_sha256=c.NATIVE_SHA,FST_sha256=c.FST_SHA,preserved_failure=[c.bind(x) for d in [c.FAIL,c.HERE.parent/'ROOT-audit-failure02'] for x in sorted(d.rglob('*')) if x.is_file()],failed_audit_inventory=inventory,prior_continuation_admission=c.bind(prior_admission),process_parser_fixture=dict(parser=fixture,monitor=fixture_monitor,receipt=c.bind(fixture_receipt),sealed_exit=c.bind(fixture_out/'sealed-exit.json')),
      resource_preflight=dict(exact_old_new_counts_equal=True,onepass_totals=snap['totals'],entry_full_budget_seconds=timings,actual_resources=resources,poll_interval_s=.25,poll_gap_bound_s=1,scan_time_bound_s=.5),
      schedule=list(c.ORDER),audit_output_suffix='-audit-ro03',native_retry=False,source_or_program_or_model_change=False,
      limits='same256MiB phase/768MiB combined/64MiB pertrace/16MiB combined failed+RO audit perrole/reader3600s/audit3665s; future native1800/1980 unchanged. No budget extension or acceptance of original failed audit.')
    c.archive.write_json(c.A,rec);c.CONTINUATION_SHA=c.bind(c.A)['sha256'];c.load(prep,c.PREP_SHA);c.fast_budget.check(c.BASE,p)
    print(json.dumps(c.bind(c.A),sort_keys=True));print(json.dumps(rec['resource_preflight'],sort_keys=True))
if __name__=='__main__':
    with (c.BASE/'acquisition.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        main()
