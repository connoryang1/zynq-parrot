"""CPU-bound immutable full167 parser fixture, no FST reader/model."""
import time

def exercise(c,guard,seconds=6):
    chosen=c.original.audit.selection();start=time.monotonic();events=[0];stamps=[0]
    def lines():
        yield '#FST\t0\t999999999999\t-12\n'
        for i,(key,(suffix,width)) in enumerate(chosen.items(),1):yield '#SIGNAL\t%s\t%d\t%d\tTOP.%s\n'%(key,width,i,suffix)
        t=0
        while time.monotonic()-start<seconds:
            for i,(key,(_,width)) in enumerate(chosen.items(),1):
                value=t&1 if key in ('be.clk','i.bclk','i.cclk','d.bclk','d.cclk') else (i+t)&((1<<width)-1)
                events[0]+=1;yield '%d\t%d\t%s\n'%(t,i,format(value,'0%db'%width))
            t+=1;stamps[0]=t
        yield '#END\n'
    edges=0
    for _ in c.original.audit.edges(lines(),chosen):edges+=1;guard()
    guard()
    return dict(scope='CPU-bound exact167 selected-event parser fixture only; no semantic hardware proof',seconds=time.monotonic()-start,event_lines=events[0],timestamps=stamps[0],rising_samples=edges)
