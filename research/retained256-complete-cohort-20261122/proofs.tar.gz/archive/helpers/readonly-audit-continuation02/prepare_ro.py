#!/usr/bin/env python3
"""ROOT source/count/timing preflight only. Never reader/native/vendor."""
import argparse,json,time
from pathlib import Path
import ro_contract as c
import parser_fixture


def main():
    a=argparse.ArgumentParser();a.add_argument('--prepare',action='store_true');args=a.parse_args();c.require(args.prepare,'explicit ROOT source-only preparation')
    c.require(not c.A.exists(),'one fresh continuation admission')
    prep=c.BASE/'preparation.json';p,program=c.base.load(prep,c.PREP_SHA)
    native=c.base.check_native(c.BASE,'d-enabled',p,prep,c.NATIVE_SHA)
    c.require(next(x for x in native['files'] if x['path'].endswith('/trace.fst'))['sha256']==c.FST_SHA,'same rawFST')
    failure=c.FAIL/'ROOT-exit.json';facts=json.loads(failure.read_text())
    c.require(facts['error']=='phase resource poll gap over1s' and not facts['acceptance_created'] and not facts['native_retried'],'exact preserved operational failure only')
    life=json.loads((c.FAIL/'d-enabled-audit/reader.owned.json').read_text())
    c.require(life['returncode']==-9 and life['failure']=='GeneratorExit()' and not life['owned_group_remaining'] and life['max_observed_poll_gap_s']<1,'preserved reader killed/reaped, its own poller stayed within1s')
    oldout=c.BASE/'d-enabled-audit';priorout=c.BASE/'d-enabled-audit-ro01'
    inventory=[c.bind(x) for d in (oldout,priorout) for x in sorted(d.rglob('*')) if x.is_file()]
    prior_admission=c.HERE.parent/'readonly-audit-continuation01/admission.json'
    c.require(c.bind(prior_admission)['sha256']=='19967d30a124269b2fb86b69b7e65912e2883cf8cf1441fa6efcabc3f47ea103','preserved RO01 admission')
    priorfacts=json.loads((c.HERE.parent/'ROOT-audit-failure02/ROOT-exit.json').read_text())
    c.require(priorfacts['error']=='phase resource snapshot stale over1s' and not priorfacts['acceptance_created'] and not priorfacts['native_retried'],'exact second operational failure')
    c.require(not (priorout/'acceptance.json').exists(),'failed RO01 unpromoted')
    c.require(inventory and not (oldout/'acceptance.json').exists() and not c.audit_path(c.BASE,'d-enabled').exists(),'preserved failed directory and fresh RO output')
    copies=json.loads((c.FAIL/'copy-manifest.json').read_text())+json.loads((c.HERE.parent/'ROOT-audit-failure02/copy-manifest.json').read_text())
    for row in copies:
        original=c.bind(row['source']);copy=c.bind(row['copy']);c.require(all(original[k]==copy[k]==row[k] for k in ('bytes','sha256')),'lossless failure copy')
    # Exact recursive-count equivalence on all roots, including symlink files.
    snap=c.fast_budget.snapshot(c.BASE)
    roots=dict(stage=c.BASE,full=c.shared.BASE,failed=c.shared.FAILED_BASE,r7=c.shared.R7,source=c.shared.home.SOURCE,old_helper=c.shared.home.HERE,durable=c.shared.DURABLE,helpers=c.HERE.parent)
    for name,path in roots.items():c.require(snap['totals'][name]==c.shared.size(path),'onepass bytes differ '+name)
    timings=[]
    for _ in range(5):
        start=time.monotonic();resources=c.fast_budget.check(c.BASE,p);timings.append(time.monotonic()-start)
    c.require(max(timings)<=.5,'efficient accounting must meet fixed0.5s scan bound before fixture')
    fixture_receipt=c.HERE/'ROOT-process-parser-fixture.json'
    c.require(not fixture_receipt.exists(),'one new process/parser fixture')
    with c.resource_phase(lambda:c.fast_budget.check(c.BASE,p),fixture_receipt) as guard:
        fixture=parser_fixture.exercise(c,guard,seconds=6)
    fixture_monitor=json.loads(fixture_receipt.read_text())
    c.require(fixture_monitor['failure'] is None and fixture_monitor['returncode']==0 and not fixture_monitor['owned_group_remaining'] and fixture_monitor['max_scan_seconds']<=.5 and fixture_monitor['max_poll_gap_s']<=1 and fixture_monitor['max_callback_age_s']<=1,'actual process monitor must pass under CPU-bound exact167 parser')
    c.require(fixture['event_lines']>=16700 and fixture['rising_samples']>=50,'nontrivial CPU-bound parser fixture required')
    c.require(c.bind(prep)['sha256']==c.PREP_SHA and c.bind(c.BASE/'d-enabled/verification.json')['sha256']==c.NATIVE_SHA,'input proof drift during preflight')
    rec=dict(schema='retained256-readonly-operational-continuation-v1',state='ROOT-PREPARED pending exact execution review',original_preparation=c.bind(prep),new_sources=c.new_sources(),caps=c.CAPS,
      native_sha256=c.NATIVE_SHA,FST_sha256=c.FST_SHA,preserved_failure=[c.bind(x) for d in [c.FAIL,c.HERE.parent/'ROOT-audit-failure02'] for x in sorted(d.rglob('*')) if x.is_file()],failed_audit_inventory=inventory,prior_continuation_admission=c.bind(prior_admission),process_parser_fixture=dict(parser=fixture,monitor=fixture_monitor,receipt=c.bind(fixture_receipt)),
      resource_preflight=dict(exact_old_new_counts_equal=True,onepass_totals=snap['totals'],five_fast_budget_seconds=timings,actual_resources=resources,poll_interval_s=.25,poll_gap_bound_s=1,scan_time_bound_s=.5),
      schedule=list(c.ORDER),audit_output_suffix='-audit-ro02',native_retry=False,source_or_program_or_model_change=False,
      limits='same256MiB phase/768MiB combined/64MiB pertrace/16MiB combined failed+RO audit perrole/reader3600s/audit3665s; future native1800/1980 unchanged. No budget extension or acceptance of original failed audit.')
    c.archive.write_json(c.A,rec);c.CONTINUATION_SHA=c.bind(c.A)['sha256'];c.load(prep,c.PREP_SHA);c.fast_budget.check(c.BASE,p)
    print(json.dumps(c.bind(c.A),sort_keys=True));print(json.dumps(rec['resource_preflight'],sort_keys=True))
if __name__=='__main__':main()
