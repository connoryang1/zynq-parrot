This prepares the minimal RO04 IPC correction on the SAME complete native2086/rawFSTea9e; no model rerun. Original and RO01/02/03 operational failures, sources and admissions remain preserved. RO03 failed with a concrete two-consumer Pipe receive race: the event parser and the existing reader-monitor thread called guard concurrently and could both enter parent.recv. The prior fixture had only one caller; no data/semantic failure is inferred from its UnpicklingError.

One threading.Lock now serializes the complete parent poll/recv transaction, decoded heartbeat state, freshness check and shared-state snapshots. Parent final-send/close also use that lock. Child scanner, sealed-ledger accounting, caps,1s gap/freshness,0.5s mutable scan, reader/validator/counter/EOF gates and ownership cleanup are unchanged. ROOT preflight now starts an actual reader-monitor-style callback thread every0.25s while the CPU-bound full167 parser concurrently calls guard and grows mutable output. It requires at least10 successful background calls, joined thread, no callback errors, observed output growth and clean resource-process/seal completion before admission.

ROOT source/count/concurrency fixture only:

```sh
python3 -B /home/coyang/fpga-artifacts/context-resume/retained256-scoped-allslots-20261122/readonly-audit-continuation04/prepare_ro.py --prepare
```

ROOT reviews the returned admission, then uses the same audit command as RO03 with source path readonly-audit-continuation04 and its new continuation SHA. Original55e995 preparation/roleD/native2086 stay fixed. Output is fresh d-enabled-audit-ro04; all old failed/preflight/audit outputs plus new ones remain charged together under the same16MiB D audit/48MiB audit/256MiB phase/768MiB combined caps. No rawtrace/model limit, reader3600s/audit3665s deadline or cleanup limit is enlarged.

Static inputs are still fully counted/hashed/sealed at entry and verified again at exit, with only the current output+statvfs monitored live and helpers conservatively charged8MiB. Complete unchanged167/512-bit/eight real L1 writes/coherence/256-target/counter/EOF checks remain. Acceptance additionally pins the monitor's serialization flag and successful sealed-input exit. Failed RO03 remains unaccepted; its source/admission4e916 and lossless ROOT-audit-failure04 copies are bound.

Eleven local tests pass, including two actual concurrent callback threads receiving real monitor heartbeats, monitor failure/reap, strict stale1s rejection, no inactive live scans, all failed/RO04 charges, sealed same-size corruption rejection, literal semantic-verifier equivalence and corrected future-native path. These tests launch no FST reader/native/vendor. ROOT preflight and new audit are pending; no performance/fit/FPGA claim.
