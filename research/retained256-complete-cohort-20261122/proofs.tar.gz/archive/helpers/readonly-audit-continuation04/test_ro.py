"""Local source/accounting fixtures only; no ROOT reader/native/vendor."""
import inspect,json,tempfile,time,unittest,threading
from pathlib import Path
from unittest.mock import patch
import fast_budget as f
import process_monitor as monitor
import ro_contract as c
import sealed_budget as sealed
from types import SimpleNamespace

class Continuation(unittest.TestCase):
 def test_scandir_exact_file_symlink_semantics(self):
  with tempfile.TemporaryDirectory(prefix='ro-count-test-') as d:
   r=Path(d);(r/'a').write_bytes(b'a'*11);(r/'sub').mkdir();(r/'sub'/'b').write_bytes(b'b'*7)
   (r/'filelink').symlink_to(r/'a');(r/'dirlink').symlink_to(r/'sub',target_is_directory=True);(r/'broken').symlink_to(r/'absent')
   rows=f.scan(r)
   self.assertEqual(sum(rows.values()),29);self.assertEqual(sum(rows.values()),c.shared.size(r))
   self.assertEqual(len(rows),3)
 def test_failed_and_RO_charged_together(self):
  stage=Path('/nonexecuted-fixture')
  rows={stage/'d-enabled-audit/old':12,stage/'d-enabled-audit-ro01/new':23,stage/'d-enabled-audit-ro02/new':5,stage/'d-enabled-audit-ro03/current':7,stage/'d-enabled-audit-ro03-preflight/fixture':9,stage/'d-enabled-audit-ro04/current':11,stage/'d-enabled-audit-ro04-preflight/fixture':13,stage/'d-enabled/trace.fst':31,stage/'misc':3}
  with patch.object(f,'scan',side_effect=lambda p:rows if p==stage else {}):snap=f.snapshot(stage)
  self.assertEqual(snap['audits']['d-enabled'],80);self.assertEqual(snap['raw'],31)
  self.assertEqual(snap['totals']['stage'],114)
 def test_semantic_verifier_only_explicit_output_path_changed(self):
  old=inspect.getsource(c.base.verify_audit)
  changed=old.replace('def verify_audit(','def semantic_verify_audit(',1).replace("out=Path(stage)/(role+'-audit'); accepted=out/'acceptance.json'","out=audit_path(stage,role); accepted=out/'acceptance.json'",1)
  self.assertEqual(inspect.getsource(c.semantic_verify_audit),changed)
 def test_callbacks_do_not_duplicate_scans(self):
  with tempfile.TemporaryDirectory(prefix='ro-phase-test-') as d:
   receipt=Path(d)/'phase.json';calls=[]
   with monitor.phase(lambda:calls.append(time.monotonic()),receipt) as guard:
    for _ in range(5000):guard()
    time.sleep(.3);guard()
   report=json.loads(receipt.read_text());self.assertIsNone(report['failure']);self.assertGreaterEqual(report['scans'],3);self.assertLess(report['scans'],10);self.assertEqual(report['returncode'],0);self.assertFalse(report['owned_group_remaining'])
   self.assertLessEqual(report['max_poll_gap_s'],1);self.assertLessEqual(report['max_scan_seconds'],.5)
 def test_stale_snapshot_still_rejected_at_one_second(self):
  with tempfile.TemporaryDirectory(prefix='ro-stale-test-') as d:
   receipt=Path(d)/'phase.json'
   with self.assertRaisesRegex(ValueError,'stale over1s'):
    with monitor.phase(lambda:None,receipt) as guard:
     now=time.monotonic()
     with patch.object(monitor,'clock',return_value=now+2):guard()
   self.assertIn('stale over1s',json.loads(receipt.read_text())['failure'])
 def test_future_native_path_is_original256_not_foundation_file(self):
  self.assertEqual(c.OLD,c.base.HERE);self.assertTrue((c.OLD/'run_capacity256.py').is_file())
 def test_monitor_failure_reaped(self):
  with tempfile.TemporaryDirectory(prefix='ro-process-failure-test-') as d:
   receipt=Path(d)/'phase.json';count=[0]
   def check():
    count[0]+=1
    if count[0]>1:raise ValueError('fixture accounting failure')
   with self.assertRaisesRegex(ValueError,'fixture accounting failure'):
    with monitor.phase(check,receipt) as guard:
     time.sleep(.3);guard()
   life=json.loads(receipt.read_text());self.assertFalse(life['owned_group_remaining']);self.assertEqual(life['group_states'][-1]['members'],[])
 def test_live_monitor_never_scans_inactive_roots(self):
  with tempfile.TemporaryDirectory(prefix='sealed-live-test-') as d:
   out=Path(d)/'current';out.mkdir();x=sealed.Ledger.__new__(sealed.Ledger)
   x.out=out;x.helper_root=Path(d);x.role='d-enabled'
   x.totals=dict(stage=80,full=0,failed=0,r7=0,source=0,old_helper=0,durable=0)
   x.charge=dict(raw=10,other=50,**{'d-enabled':20,'d-off':0,'i-enabled':0})
   def current_only(p):
    self.assertEqual(p,out);return {out/'mutable':31}
   with patch.object(f,'scan',side_effect=current_only) as scan,patch.object(sealed.shutil,'disk_usage',return_value=SimpleNamespace(free=10*1024**3)):
    report=x.check();self.assertEqual(scan.call_count,1)
   self.assertEqual(report['per_role_audit_bytes']['d-enabled'],51)
   with patch.object(f,'scan',return_value={out/'mutable':16*1024**2}),patch.object(sealed.shutil,'disk_usage',return_value=SimpleNamespace(free=10*1024**3)):
    with self.assertRaisesRegex(ValueError,'perrole'):x.check()
 def test_sealed_exit_rejects_same_size_content_change(self):
  with tempfile.TemporaryDirectory(prefix='sealed-exit-test-') as d:
   root=Path(d);stage=root/'stage';stage.mkdir();out=stage/'d-enabled-audit-ro03';out.mkdir();static=stage/'closed';static.write_bytes(b'abcd')
   x=sealed.Ledger.__new__(sealed.Ledger);x.out=out;x.stage=stage;x.roots={'stage':stage};x.root_ids={'stage':(stage.stat().st_dev,stage.stat().st_ino)}
   x.seals={'stage':sealed.inventory(stage,out)};x.extra_sources=[];x.helper_root=root;x.entry_seconds=0
   x.manifest=out/'inventory.gz';x.manifest.write_bytes(b'fixture');x.check=lambda:{}
   (out/'new-output').write_bytes(b'allowed current output')
   x.verify_exit()
   static.write_bytes(b'wxyz')
   with self.assertRaisesRegex(ValueError,'inactive inventory/content'):x.verify_exit()
 def test_concurrent_parent_callbacks_share_one_pipe_receiver(self):
  with tempfile.TemporaryDirectory(prefix='serialized-pipe-test-') as d:
   receipt=Path(d)/'phase.json';stop=threading.Event();errors=[];calls=[0]
   with monitor.phase(lambda:None,receipt) as guard:
    def reader_callbacks():
     while not stop.wait(.001):
      try:guard();calls[0]+=1
      except BaseException as e:errors.append(repr(e));return
    t=threading.Thread(target=reader_callbacks,daemon=True);t.start()
    try:
     end=time.monotonic()+.8
     while time.monotonic()<end:guard()
    finally:stop.set();t.join(timeout=1)
    self.assertFalse(t.is_alive());self.assertFalse(errors);self.assertGreater(calls[0],10)
   result=json.loads(receipt.read_text());self.assertTrue(result['parent_pipe_serialized']);self.assertEqual(result['returncode'],0);self.assertFalse(result['owned_group_remaining'])
 def test_parser_and_limits_unchanged(self):
  self.assertIs(c.Validator,c.base.Validator);self.assertIs(c.archive,c.base.archive)
  self.assertEqual(len(c.original.audit.selection()),167)
  self.assertEqual(c.CAPS['reader_s'],3600);self.assertEqual(c.CAPS['audit_outer_s'],3665)
  self.assertEqual(c.CAPS['raw_per_case'],64*1024**2);self.assertEqual(c.CAPS['audit_per_case'],16*1024**2)
  self.assertNotEqual(c.audit_path(c.BASE,'d-enabled'),c.BASE/'d-enabled-audit')
if __name__=='__main__':unittest.main()
