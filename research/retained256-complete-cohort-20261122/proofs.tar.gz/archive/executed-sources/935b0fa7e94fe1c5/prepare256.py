#!/usr/bin/env python3
"""Bounded exact sparse source preparation only; no compiler/model/reader."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
SOURCE=Path('/home/coyang/zp-retained256-source-20261122')
TOP='596e4677fdcbbf59706be254384f778861f0cc36'
BP='8dfdbdeec84cb47f902bc1426d69ecb3efd91c7c'
LARGE_TOP='eb7d390134a0025331a2366a979a774263b146d5'
MAIN=Path('/home/coyang/zynq-parrot-linux-capacity')
DENSE=Path('/home/coyang/zynq-parrot-retained-dense')
BASEJUMP='6cd7d830b732079ab7316c6288e2e819e3fab474'
REPOS=[('',Path('/home/coyang/zynq-parrot-retained-small256'),TOP),
 ('import/basejump_stl',DENSE/'import/basejump_stl',BASEJUMP),
 ('import/black-parrot',MAIN/'import/black-parrot',BP),
 ('import/black-parrot/external/basejump_stl',MAIN/'import/black-parrot/external/basejump_stl','3dff9f43af8e1bb850da0b41696514396fa0fa7e'),
 ('import/black-parrot/external/HardFloat',MAIN/'import/black-parrot/external/HardFloat','5b7d5fe2df7e297b5ba095b3eb8a9517dc2e9d88'),
 ('import/black-parrot/external/bedrock',MAIN/'import/black-parrot/external/bedrock','ed68e749079df57afa4b2e153184bf9301137bf2'),
 ('import/black-parrot-subsystems',MAIN/'import/black-parrot-subsystems','f6ce99ea7ebdcb97a46f73c296505071e9fb22ab'),
 ('import/black-parrot-subsystems/import/riscv-dbg',DENSE/'import/black-parrot-subsystems/import/riscv-dbg','618ee6e0e2610ef47e0dcc4df6748af3dffff731'),
 ('import/bsg_replicant',DENSE/'import/bsg_replicant','83e2441b3bab646a69159fa9dee80de2af9b24ae')]
COMPILED=Path('/home/coyang/fpga-artifacts/context-resume/retained1792-stream-canonical-20261121/stopped-audit01/compiled-sources.json')
COMPILED_SHA='3f5e4b2c2691275e57ec8b790832e9bbb87827c9bb84925351b8170ff58ca3e8'
SOURCE_CAP=4*1024**2
HELPER_CAP=8*1024**2
HOME_FLOOR=3*1024**3


def require(ok,message):
    if not ok:raise ValueError(message)


def bind(path):
    path=Path(path).resolve();data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())


def git(repo,*args,input=None):
    # Never permit Git to discover an ancestor of an uninitialized child.
    require((repo/'.git').is_file() or (repo/'.git').is_dir(),'initialized reference/worktree required: '+str(repo))
    return subprocess.check_output(['git','-C',str(repo),*args],input=input,timeout=60)


def tree(repo,pin):
    rows={}
    for line in git(repo,'ls-tree','-r','-l','-z',pin).split(b'\0'):
        if not line:continue
        head,name=line.split(b'\t',1);mode,kind,sha,size=head.split()
        if kind==b'blob':rows[name.decode()]=dict(mode=mode.decode(),blob=sha.decode(),bytes=int(size))
    return rows


def plan():
    require(bind(COMPILED)['sha256']==COMPILED_SHA,'fixed canonical compiled source inventory')
    raw=json.loads(COMPILED.read_text());compiled=raw.get('sources',raw)
    needed={path.split('/zp-linux-canonical-fulltop-20261121-01/',1)[1]
            for path in compiled if '/zp-linux-canonical-fulltop-20261121-01/' in path}
    result=[]
    for relative,repo,pin in REPOS:
        require(git(repo,'rev-parse','--show-toplevel').decode().strip()==str(repo.resolve()),'real reference repository identity')
        git(repo,'cat-file','-e',pin+'^{commit}')
        files=tree(repo,pin);selected={}
        for name,row in files.items():
            full=relative+'/'+name if relative else name
            make=(Path(name).name.startswith('Makefile') or Path(name).suffix in ('.mk','.flist'))
            if not relative:make=make and (name.startswith(('cosim/','software/')) or '/' not in name or name=='testing/Makefile')
            else:make=make and ('/' not in name or name.endswith('.flist'))
            python=(not relative and name.startswith('cosim/py/') and name.endswith('.py'))
            python|=(relative=='import/black-parrot' and name.startswith('bp_common/software/py/') and name.endswith('.py'))
            python|=(relative=='import/basejump_stl' and name=='bsg_mem/bsg_ascii_to_rom.py')
            extra=(not relative and (name.startswith('software/include/') or name in ('AGENTS.md','testing/mt_seed.h','testing/rtl/large_retained_system_test.c','testing/rtl/retained_advisory_full_line_test.c','testing/check_run.py','testing/rtl/scoped-assertions/bsg_clkgate_optional.sv','cosim/v/waiver.vlt')))
            if full in needed or make or python or extra:selected[name]=row
        # Keep repository gitlink entries selected without checking their trees
        # into this parent's index; each child is a real sparse Git worktree.
        children=[r[len(relative)+1:] if relative else r for r,_,_ in REPOS if r and (r.startswith(relative+'/') if relative else True)]
        children=[r for r in children if not any(r.startswith(q+'/') for q in children if q!=r)]
        result.append(dict(relative=relative,reference=str(repo),commit=pin,files=selected,children=children))
    total=sum(v['bytes'] for r in result for v in r['files'].values())
    require(total+4096<=SOURCE_CAP,'planned sparse files exceed4MiB; no checkout: '+str(total)+' '+str({r['relative']:sum(v['bytes'] for v in r['files'].values()) for r in result}))
    # Exact defaults-only TOP source bridge, no normalized permissive diff.
    repo=REPOS[0][1];paths=git(repo,'diff','--name-only',LARGE_TOP,TOP).decode().splitlines()
    require(paths==['cosim/black-parrot-example/Makefile.design'],'only two retained defaults may change')
    before=git(repo,'show',LARGE_TOP+':'+paths[0]);after=git(repo,'show',TOP+':'+paths[0])
    wanted=before.replace(b'BP_RETAINED_I_LINES ?= 1792',b'BP_RETAINED_I_LINES ?= 256').replace(b'BP_RETAINED_D_LINES ?= 1792',b'BP_RETAINED_D_LINES ?= 256')
    require(after==wanted and before!=after,'exact two macro-default replacements')
    return dict(schema='retained256-sparse-source-plan-v1',source=str(SOURCE),source_cap=SOURCE_CAP,planned_file_bytes=total,repositories=result,
        canonical_inventory=bind(COMPILED),large_top=LARGE_TOP,small_top=TOP,BP=BP,defaults_only_file=paths[0],
        defaults_before_sha256=hashlib.sha256(before).hexdigest(),defaults_after_sha256=hashlib.sha256(after).hexdigest())


def check_budget():
    import shutil
    used=sum(p.stat().st_size for p in SOURCE.rglob('*') if p.is_file()) if SOURCE.exists() else 0
    helpers=sum(p.stat().st_size for p in HERE.rglob('*') if p.is_file())
    require(used<=SOURCE_CAP and helpers<=HELPER_CAP,'bounded source4MiB/helpers8MiB')
    require(shutil.disk_usage(HERE).free>=HOME_FLOOR+(SOURCE_CAP-used)+(HELPER_CAP-helpers),'HOME3GiB plus remaining source/helper allocation')
    return dict(source_bytes=used,helper_bytes=helpers)


def materialize(proposal):
    require(not SOURCE.exists(),'fresh source only; preserve failed preparation')
    for row in proposal['repositories']:
        check_budget();target=SOURCE/row['relative'];reference=Path(row['reference'])
        # Mutation is confined to new working directories/Git worktree metadata.
        git(reference,'worktree','add','--detach','--no-checkout',str(target),row['commit'])
        require((target/'.git').is_file(),'new child real.git before Git-C')
        admin=Path(git(target,'rev-parse','--absolute-git-dir').decode().strip());(admin/'info').mkdir(exist_ok=True)
        git(target,'sparse-checkout','init','--no-cone');check_budget()
        patterns=['/'+name for name in sorted(row['files'])]+['/'+name for name in row['children']]
        require(patterns,'bounded nonempty sparse selection')
        git(target,'sparse-checkout','set','--no-cone','--stdin',input=('\n'.join(patterns)+'\n').encode())
        require(git(target,'rev-parse','HEAD').decode().strip()==row['commit'],'exact new Git HEAD')
        for name,expected in row['files'].items():
            path=target/name
            data=os.readlink(path).encode() if expected['mode']=='120000' else path.read_bytes()
            require(len(data)==expected['bytes'] and hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==expected['blob'],'exact Git blob bytes '+str(path))
        check_budget()
    return check_budget()


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--prepare',action='store_true')
    args=parser.parse_args();proposal=plan();check_budget()
    path=HERE/'source-plan.json'
    if path.exists():require(json.loads(path.read_text())==proposal,'prepared sparse source plan changed')
    else:
        with path.open('x') as f:json.dump(proposal,f,indent=2);f.write('\n')
    record=dict(state='PASS source plan only; no source checkout/compiler/model/reader',plan=bind(path),script=bind(__file__))
    try:
        if args.prepare:record.update(resources=materialize(proposal),state='PASS exact sparse source prepared; no compiler/model/reader')
    except BaseException as error:record.update(state='FAIL source preparation preserved; no automatic retry',error=repr(error));raise
    finally:
        output=HERE/('source-materialization.json' if args.prepare else 'source-preparation.json')
        with output.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
    print(json.dumps(record,sort_keys=True))


if __name__=='__main__':main()
