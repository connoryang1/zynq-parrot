"""Own unique /run/user stage; reserve remaining immutable R7 cap, no borrowing."""
import json
from pathlib import Path
import shutil
import prepare256 as home

BASE=Path('/run/user/1001/zp-retained256-fullcore-20261122-02')
FAILED_BASE=Path('/run/user/1001/zp-retained256-fullcore-20261122-01')
R7=Path('/run/user/1001/zp-linux-canonical-r7-20261121')
OWN_CAP=768*1024**2
R7_CAP=2560*1024**2
FLOOR=1024**3
R7_ADMISSION=Path('/home/coyang/fpga-artifacts/context-resume/native1792-canonical-r7-preparation-20261121/admission.json')
DURABLE=Path('/home/coyang/fpga-artifacts/context-resume/retained256-qualification-20261122')
DURABLE_CAP=128*1024**2


def size(path):return sum(p.stat().st_size for p in Path(path).rglob('*') if p.is_file()) if Path(path).exists() else 0


def work_requirement(own,r7,free):
    home.require(0<=own<=OWN_CAP and 0<=r7<=R7_CAP,'actual own/R7 separate caps')
    required=FLOOR+(OWN_CAP-own)+(R7_CAP-r7)
    home.require(free>=required,'same-volume1GiB floor plus BOTH remaining caps')
    return required


def check(out=None):
    home.check_budget()
    durable=size(DURABLE)
    home.require(durable<=DURABLE_CAP and shutil.disk_usage(home.HERE).free>=home.HOME_FLOOR+
        max(0,home.SOURCE_CAP-size(home.SOURCE))+max(0,home.HELPER_CAP-size(home.HERE))+DURABLE_CAP-durable,'HOME3GiB plus all remaining source/helper/durable allocation')
    q=json.loads(R7_ADMISSION.read_text())
    home.require(q['configuration']['work_root']==str(R7) and q['resources']['work_cap_bytes']==R7_CAP,'immutable R7 work reservation')
    home.require(BASE.parent.is_dir() and R7.is_dir() and BASE.parent.stat().st_dev==R7.stat().st_dev,'actual ROOT same /run/user filesystem; no private shm substitution')
    home.require(BASE.parent.stat().st_dev!=home.HERE.stat().st_dev,'work stage separate filesystem from HOME')
    if out is not None:home.require(Path(out)==BASE or BASE in Path(out).parents,'own fixed model stage only')
    own=size(BASE)+size(FAILED_BASE);r7=size(R7)
    remaining_own=OWN_CAP-own;remaining_r7=R7_CAP-r7
    free=shutil.disk_usage(BASE.parent).free
    required=work_requirement(own,r7,free)
    return dict(filesystem_device=BASE.parent.stat().st_dev,free_bytes=free,own_bytes=own,r7_bytes=r7,
        failed_stage_bytes=size(FAILED_BASE),own_cap_bytes=OWN_CAP,r7_cap_bytes=R7_CAP,reserve_bytes=FLOOR,
        required_free_bytes=required,R7_admission=home.bind(R7_ADMISSION))
