"""Small temp-file archive fixtures only; no native/reader/CAD/process launch."""
import importlib.util,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
s=importlib.util.spec_from_file_location('arch',Path(__file__).with_name('archive_cohort.py'));a=importlib.util.module_from_spec(s);s.loader.exec_module(a)
class Tests(unittest.TestCase):
 def test_entire_inventory_and_roundtrip(self):
  with tempfile.TemporaryDirectory() as d:
   r=Path(d);source=r/'source';source.mkdir();(source/'empty').mkdir();(source/'data').write_bytes(bytes(range(256))*4);(source/'zero').write_bytes(b'\0'*4096);(source/'link').symlink_to('data')
   rows=a.inventory(source,'stage');self.assertEqual(len(rows),4)
   with patch.object(a,'guard',lambda:None):a.write_archive(rows,r/'proof.gz');self.assertEqual(a.roundtrip(r/'proof.gz',rows),4)
 def test_missing_and_corrupt_byte_rejection(self):
  with tempfile.TemporaryDirectory() as d:
   r=Path(d);source=r/'source';source.mkdir();(source/'data').write_bytes(b'correct');rows=a.inventory(source,'stage');(source/'data').write_bytes(b'changed')
   with patch.object(a,'guard',lambda:None):
    a.write_archive(rows,r/'proof.gz')
    with self.assertRaisesRegex(ValueError,'lossless archive member'):a.roundtrip(r/'proof.gz',rows)
   with self.assertRaisesRegex(ValueError,'missing executed source'):a.record_sources([dict(path=str(r/'absent'),bytes=1,sha256='0'*64)])
 def test_duplicate_member_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   r=Path(d);source=r/'source';source.mkdir();(source/'data').write_bytes(b'x');rows=a.inventory(source,'stage')
   with patch.object(a,'guard',lambda:None):
    a.write_archive(rows+rows,r/'proof.gz')
    with self.assertRaisesRegex(ValueError,'duplicate archive member'):a.roundtrip(r/'proof.gz',rows)
 def test_roots_and_exact_anchors(self):
  self.assertEqual(a.STAGE.name,'zp-retained256-scoped-capacity-20261122-01');self.assertEqual(a.CAP,24*1024**2);self.assertEqual(a.HOME_FLOOR,2684354560);self.assertEqual(a.HOME_OTHER,(384+64+24)*1024**2);self.assertEqual(a.RAM_CAD,2560*1024**2)
  self.assertEqual(list(a.ACCEPT),['d-enabled','d-off','i-enabled']);self.assertEqual(a.bind(a.RES)['sha256'],a.RES_SHA);self.assertEqual(a.bind(a.FULL)['sha256'],a.FULL_SHA)
if __name__=='__main__':unittest.main()
