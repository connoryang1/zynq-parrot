#!/usr/bin/env python3
"""Lossless terminal OLD256 closure only: no target, reader or vendor subprocess."""
import sys
sys.dont_write_bytecode=True
import argparse,gzip,hashlib,importlib.util,json,os,signal,stat,tarfile,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
STAGE=Path('/run/user/1001/zp-retained256-scoped-capacity-20261122-01')
HELPERS=Path('/home/coyang/fpga-artifacts/context-resume/retained256-scoped-allslots-20261122')
DEST=Path('/home/coyang/fpga-artifacts/context-resume/retained256-qualification-20261122/cohort-ro04-closed01')
RES=Path('/home/coyang/fpga-artifacts/context-resume/reservation-closures-20261122/control256-ro04-reservation.json')
RES_SHA='ee8ffe8bb7dd9f804edb5a98f6ced38a869d9fc9cd6533fd84cfaf4effb57ffc'
FULL=DEST.parent/'closed02/archive.json'
FULL_SHA='e9b134b8cd2a723ee0a766423242939a4b1bf73d0b06241583ab773e4fd1e7f3'
PREP_SHA='55e995d4cc748bfe4786eb309fd8e103499557b745bba6ab7b38809bc147d587'
ACCEPT={'d-enabled':'7ee90c878a551e030f0c16a55ee0fa28fc11b16762be87907e5f5c50d2c2b2f9','d-off':'15a5f76e0295337c1af25e5777ef0c722c55e7101f519f5be2f2f60b7ec7fcd7','i-enabled':'7c4ffe1808c07f6aad04dd8dd4b14d69169d933bb31605b5ab0f9b526fb5d2d4'}
CAP=24*1024**2; HELPER_CAP=1024**2; HOME_FLOOR=5*1024**3//2
HOME_OTHER=(384+64+24)*1024**2
RAM_FLOOR=1024**3; RAM_CAD=2560*1024**2
START=None

def need(v,msg):
 if not v:raise ValueError(msg)
def save(p,x):
 text=json.dumps(x,indent=2)+'\n'
 if p.parent==DEST:need(len(text.encode())<=1024**2,'reserved1MiB terminal manifest cap')
 p.write_text(text)
def digest(p,guard=lambda:None):
 h=hashlib.sha256();n=0
 with Path(p).open('rb') as f:
  while True:
   b=f.read(256*1024)
   if not b:break
   h.update(b);n+=len(b);guard()
 return n,h.hexdigest()
def bind(p,guard=lambda:None):
 n,h=digest(p,guard);return dict(path=str(p),bytes=n,sha256=h)
def check(row,guard=lambda:None):need(bind(row['path'],guard)==row,'source/receipt drift '+row['path'])
def size(p):return sum(x.lstat().st_size for x in p.rglob('*') if not x.is_dir()) if p.exists() else 0
def free(p):s=os.statvfs(p);return s.f_bavail*s.f_frsize

def resources():
 used=size(DEST);helpers=size(HERE)
 need(used<=CAP and helpers<=HELPER_CAP,'fixed24MiB archive/1MiB helper cap')
 need(free(HERE)>=HOME_FLOOR+HOME_OTHER+CAP-used+HELPER_CAP-helpers,'prospective2.5GiB HOME floor plus full384MiB CAD evidence+64MiB future native+24MiB small source/helpers+remaining own caps')
 need(free('/run/user/1001')>=RAM_FLOOR+RAM_CAD,'RAM1GiB floor+full2.5GiB CAD work; archive writes no RAM')
 return dict(archive_bytes=used,helper_bytes=helpers,HOME_free=free(HERE),RAM_free=free('/run/user/1001'))
def guard():
 if START is not None:need(time.monotonic()-START<600,'fixed600s archive deadline')
 return resources()

def inventory(root,prefix,guard=lambda:None):
 rows=[]
 for p in sorted(root.rglob('*')):
  s=p.lstat();name=prefix+'/'+p.relative_to(root).as_posix()
  if stat.S_ISDIR(s.st_mode):rows.append(dict(path=str(p),member=name,type='directory',mode=stat.S_IMODE(s.st_mode)))
  elif stat.S_ISLNK(s.st_mode):rows.append(dict(path=str(p),member=name,type='symlink',link=os.readlink(p),mode=stat.S_IMODE(s.st_mode)))
  else:
   need(stat.S_ISREG(s.st_mode),'unsupported special input '+str(p));rows.append(dict(bind(p,guard),member=name,type='file',mode=stat.S_IMODE(s.st_mode)))
  guard()
 return rows

def record_sources(rows):
 result={}
 def visit(x):
  if isinstance(x,dict):
   if all(k in x for k in ('path','bytes','sha256')):
    need(Path(x['path']).is_file(),'missing executed source '+str(x['path']))
    row={k:x[k] for k in ('path','bytes','sha256')};need(row['path'] not in result or row==result[row['path']],'contradictory executed source binding');result[row['path']]=row
   else:
    for v in x.values():visit(v)
  elif isinstance(x,list):
   for v in x:visit(v)
 visit(rows);return list(result.values())

def verified_inputs():
 need(bind(RES)['sha256']==RES_SHA and bind(FULL)['sha256']==FULL_SHA,'exact durable reservation/old complete source/model archive')
 r=json.loads(RES.read_text());need(r['existing_logical_bytes']==81337196 and r['prospective_cohort_archive_bytes']==CAP,'same ROOT released reservation')
 for row in r['existing_family_files']:check(row,guard)
 prep=STAGE/'preparation.json';need(bind(prep)['sha256']==PREP_SHA,'same original complete cohort preparation')
 p=json.loads(prep.read_text());st=STAGE.stat();need(p['stage_identity']==dict(path=str(STAGE),device=st.st_dev,inode=st.st_ino),'actual frozen stage/inode')
 sys.path.insert(0,str(HELPERS/'readonly-audit-continuation04'))
 import ro_contract as c
 c.CONTINUATION_SHA=bind(c.A)['sha256']
 need(c.new_sources()==json.loads(c.A.read_text())['new_sources'],'exact RO04 executed source set')
 for role,sha in ACCEPT.items():c.verify_audit(STAGE,role,p,prep,sha)
 # Each original failure remains a failure; never promote its missing acceptance.
 for name in ('d-enabled-audit','d-enabled-audit-ro01','d-enabled-audit-ro02','d-enabled-audit-ro03'):
  need((STAGE/name).is_dir() and not (STAGE/name/'acceptance.json').exists(),'failed audit directory/absence preserved '+name)
 executed=record_sources([p['runtime_sources'],c.new_sources()])
 for row in executed:check(row,guard)
 return p,executed

def collect_rows(executed):
 rows=inventory(STAGE,'stage',guard)+inventory(HELPERS,'helpers',guard)
 included={r['path'] for r in rows}
 extras=[dict(path=str(RES),**{k:v for k,v in bind(RES).items() if k!='path'}),bind(FULL)]+executed
 for row in extras:
  if row['path'] in included:continue
  check(row,guard);p=Path(row['path']);rows.append(dict(row,member='executed-sources/'+hashlib.sha256(row['path'].encode()).hexdigest()[:16]+'/'+p.name,type='file',mode=stat.S_IMODE(p.stat().st_mode)));included.add(row['path'])
 # Preserve external symlink targets unless an explicit old durable record covers them.
 prior={x['path']:x for x in json.loads(RES.read_text())['existing_family_files']}
 for row in list(rows):
  if row['type']!='symlink':continue
  target=Path(row['path']).resolve(strict=True)
  need(target.is_file(),'directory/special symlink target requires explicit review '+str(target))
  if str(target) not in included and str(target) not in prior:
   rows.append(dict(bind(target,guard),member='symlink-targets/'+hashlib.sha256(str(target).encode()).hexdigest()[:16]+'/'+target.name,type='file',mode=stat.S_IMODE(target.stat().st_mode)));included.add(str(target))
 need(len({x['member'] for x in rows})==len(rows),'unique complete archive names')
 return rows

def helper_sources():return [bind(HERE/n) for n in ('archive_cohort.py','test_archive.py','README.md')]
def prepare():
 need(not (HERE/'admission.json').exists() and not DEST.exists(),'fresh preparation/output required')
 guard();p,executed=verified_inputs();rows=collect_rows(executed)
 a=dict(schema='OLD256-complete-lossless-archive-v1',state='ROOT-PREPARED archive-only; no target/reader/vendor',stage=str(STAGE),destination=str(DEST),reservation=bind(RES),old_full_archive=bind(FULL),preparation=bind(STAGE/'preparation.json'),accepted_audits=ACCEPT,helpers=helper_sources(),executed_sources=executed,inventory=rows,limits=dict(archive_bytes=CAP,helper_bytes=HELPER_CAP,seconds=600,HOME_floor_bytes=HOME_FLOOR,HOME_other_full_reservations_bytes=HOME_OTHER,RAM_floor_bytes=RAM_FLOOR,RAM_CAD_full_reservation_bytes=RAM_CAD),resource_preflight=guard())
 save(HERE/'admission.json',a);guard();print(json.dumps(bind(HERE/'admission.json')))

class CheckedFile:
 def __init__(self,f):self.f=f
 def read(self,n=-1):b=self.f.read(n);guard();return b

class CappedWriter:
 def __init__(self,f):self.f=f;self.used=0
 def write(self,b):
  need(self.used+len(b)<=CAP-1024**2,'archive cap before write, reserve1MiB terminal manifest')
  n=self.f.write(b);self.used+=n;return n
 def flush(self):return self.f.flush()

def write_archive(rows,path):
 with path.open('xb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=CappedWriter(raw),mtime=0,compresslevel=6) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
  for row in rows:
   info=tarfile.TarInfo(row['member']);info.mode=row['mode'];info.mtime=0;info.uid=info.gid=0
   if row['type']=='directory':info.type=tarfile.DIRTYPE;tar.addfile(info)
   elif row['type']=='symlink':info.type=tarfile.SYMTYPE;info.linkname=row['link'];tar.addfile(info)
   else:
    info.size=row['bytes']
    with Path(row['path']).open('rb') as f:tar.addfile(info,CheckedFile(f))
   guard()

def roundtrip(path,rows):
 expected={r['member']:r for r in rows};seen=set()
 with tarfile.open(path,'r|gz') as tar:
  for m in tar:
   need(m.name in expected and m.name not in seen,'unlisted/duplicate archive member');seen.add(m.name);r=expected[m.name];need(m.mode==r['mode'],'mode preserved')
   if r['type']=='directory':need(m.isdir(),'directory retained')
   elif r['type']=='symlink':need(m.issym() and m.linkname==r['link'],'symlink retained')
   else:
    need(m.isfile() and m.size==r['bytes'],'regular bytes/size retained');h=hashlib.sha256();f=tar.extractfile(m);n=0
    while True:
     b=f.read(256*1024)
     if not b:break
     n+=len(b);h.update(b);guard()
    need(n==r['bytes'] and h.hexdigest()==r['sha256'],'lossless archive member '+m.name)
   guard()
 need(seen==set(expected),'ALL members roundtrip, no exclusions')
 return len(seen)

def execute(sha):
 global START
 START=time.monotonic();a=json.loads((HERE/'admission.json').read_text());need(bind(HERE/'admission.json')['sha256']==sha,'ROOT-reviewed exact archive admission')
 need(a['schema']=='OLD256-complete-lossless-archive-v1' and a['stage']==str(STAGE) and a['destination']==str(DEST) and a['accepted_audits']==ACCEPT,'fixed complete cohort closure identity')
 need(a['reservation']==bind(RES) and a['old_full_archive']==bind(FULL) and a['preparation']==bind(STAGE/'preparation.json'),'all original anchor identities')
 need(a['helpers']==helper_sources(),'helper source frozen');need(not DEST.exists(),'fresh one-shot closure, preserve all attempts')
 guard();p,executed=verified_inputs();need(executed==a['executed_sources'] and collect_rows(executed)==a['inventory'],'all entry bytes/inventories exact');DEST.mkdir()
 state=dict(state='RUNNING archive-only',admission=bind(HERE/'admission.json'),no_target_reader_vendor_or_cleanup=True)
 def interrupted(sig,frame):raise RuntimeError('archive-only signal '+str(sig))
 for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGALRM):signal.signal(sig,interrupted)
 signal.alarm(600)
 try:
  archive=DEST/'entire-stage-helpers-executed-sources.tar.gz';write_archive(a['inventory'],archive);count=roundtrip(archive,a['inventory'])
  _,end_sources=verified_inputs();need(end_sources==executed and collect_rows(end_sources)==a['inventory'],'all sources/stage/helpers unchanged after archive')
  need(a['helpers']==helper_sources(),'archive helper endcheck')
  state.update(state='PASS OLD256 complete lossless closure; prior operational failures preserved',archive=bind(archive,guard),all_members=count,all_regular_bytes=sum(r.get('bytes',0) for r in a['inventory']),inventory=a['inventory'],accepted_audits=ACCEPT,prior_failures_remain_failed=True,old_full_archive=bind(FULL),reservation=bind(RES),resources=guard(),elapsed_seconds=time.monotonic()-START)
 except BaseException as e:state.update(state='FAIL archive-only attempt preserved; no retry or cleanup',error=repr(e));raise
 finally:
  signal.alarm(0);save(DEST/'manifest.json',state)
 guard();print(json.dumps(bind(DEST/'manifest.json')))

def main():
 p=argparse.ArgumentParser();p.add_argument('--prepare',action='store_true');p.add_argument('--execute',action='store_true');p.add_argument('--admission-sha256');a=p.parse_args();need(a.prepare!=a.execute,'one explicit archive action')
 if a.prepare:prepare()
 else:need(a.admission_sha256 is not None,'exact ROOT admission hash required');execute(a.admission_sha256)
if __name__=='__main__':main()
