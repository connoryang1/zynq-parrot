#!/usr/bin/env python3
"""Modest read-only polling of one job, with only explicitly admitted bound cancellation."""
from pathlib import Path
import hashlib,json,subprocess,time
HERE=Path(__file__).resolve().parent
JOB='20261121T220319Z-eb7d39013'
TOP='eb7d390134a0025331a2366a979a774263b146d5'
LOGROOT='/home/coyang/fpga-logs-linux-retained-native1792-canonical-r6'
FARM=Path('/home/coyang/zynq-parrot-linux-capacity/codex-skills/bp-synthesis-farm/scripts/farm_synthesis.sh')
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-p','30041','coyang@haight.chillysky.com','python3','-B','-']

def bind(p):
 raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def write(p,v):
 tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(v,indent=2)+'\n');tmp.replace(p)
def poll(index):
 r=subprocess.run(SSH,input=(HERE/'remote_probe.py').read_bytes(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40)
 if r.returncode:
  (HERE/('poll-%03d-SSH-error.log'%index)).write_bytes(r.stderr);raise RuntimeError('read-only SSH poll failed; job not signalled')
 s=json.loads(r.stdout);(HERE/('poll-%03d.json'%index)).write_bytes(r.stdout);return s

def violations(s):
 reasons=list(s['identity_violations']);r=s['resources']
 for key,operator,limit in [('work_allocated_bytes','max',1536*1024**2),('shm_free_bytes','min',512*1024**2),('home_free_bytes','min',3*1024**3)]:
  if (operator=='max' and r[key]>limit) or (operator=='min' and r[key]<limit):reasons.append(dict(kind='resource_bound',key=key,actual=r[key],operator=operator,limit=limit))
 work_left=max(0,1536*1024**2-r['work_allocated_bytes'])
 evidence_used=sum(x.stat().st_size for q in [Path(LOGROOT),HERE] if q.exists() for x in q.rglob('*') if x.is_file())
 evidence_left=max(0,384*1024**2-evidence_used)
 if evidence_used>384*1024**2:reasons.append(dict(kind='evidence_bound',actual=evidence_used,limit=384*1024**2))
 if r['home_free_bytes']<3*1024**3+work_left+evidence_left:reasons.append(dict(kind='remaining_allocation_reserve',actual=r['home_free_bytes'],minimum=3*1024**3+work_left+evidence_left))
 if s['worker_elapsed_seconds'] is not None and s['worker_elapsed_seconds']>10800:reasons.append(dict(kind='elapsed_bound',actual=s['worker_elapsed_seconds'],limit=10800))
 return reasons

def ownership(s,baseline):
 w=s.get('worker');first=baseline['worker'];desc={p['pid'] for p in s['descendants']}
 return bool(w and first and w['pid']==first['pid'] and w['startticks']==first['startticks'] and w['pgrp']==w['sid']==first['pid'] and ('worker '+JOB+' '+TOP) in w['argv'] and all(p['pid'] in desc for p in s['worker_group']) and all(p['pid'] in desc for p in s['all_vivado']))

def main():
 baseline=json.loads((HERE/'poll-001.json').read_text());prior=baseline;index=1;failures=0
 identity=dict(job=JOB,worker=baseline['worker'],admission=bind(Path('/home/coyang/fpga-artifacts/context-resume/native1792-canonical-r6-preparation-20261121/admission.json')),farm_cancellation=bind(FARM),probe=bind(HERE/'remote_probe.py'),monitor=bind(Path(__file__)),poll_interval_seconds=90,mutations='Only maintained cancellation on explicit bounds/features with exact owner/startticks/ancestry reverified; no vendor/board launch')
 write(HERE/'monitor-identity.json',identity)
 while True:
  delay=max(0,90-(time.time()-prior['epoch']))
  if delay:time.sleep(delay)
  index+=1
  try:s=poll(index);failures=0
  except Exception as e:
   failures+=1;print('MONITOR_OBSERVATION_FAILURE '+repr(e),flush=True)
   if failures>=3:raise
   time.sleep(90);continue
  if s['epoch']-prior['epoch']<60:raise RuntimeError('poll interval guard')
  reasons=violations(s)
  record=dict(utc=s['utc'],status=s['status'],poll='poll-%03d.json'%index,resources=s['resources'],worker_elapsed_seconds=s['worker_elapsed_seconds'],features=s['feature_state'],reports=[r['binding'] for r in s['reports']],feedback_warnings=s['feedback_warnings'],identity_violations=s['identity_violations'],bound_violations=reasons,latest_milestones=s['milestones'][-6:])
  old={p['pid']:p for p in prior['all_vivado']};record['CPU_advancement']=[]
  for p in s['all_vivado']:
   q=old.get(p['pid'])
   if q and q['startticks']==p['startticks'] and '/unwrapped/' in p['argv']:
    record['CPU_advancement'].append(dict(pid=p['pid'],CPU_seconds=((p['utime_ticks']+p['stime_ticks'])-(q['utime_ticks']+q['stime_ticks']))/s['ticks_per_second']))
  write(HERE/'live-status.json',record)
  changed=s['status']!=prior['status'] or s['feature_state']!=prior['feature_state'] or [r['binding']['sha256'] for r in s['reports']]!=[r['binding']['sha256'] for r in prior['reports']] or bool(s['feedback_warnings'])!=bool(prior['feedback_warnings']) or bool(reasons)
  stage=lambda x: [(m['path'],m['line'],m['text']) for m in x['milestones'] if not any(w in m['text'] for w in ('WARNING','ERROR','posedge_clk','CONFIG','set ::env'))][-1:]
  if changed or stage(s)!=stage(prior):print(json.dumps(record),flush=True)
  if s['status']!='RUNNING':
   write(HERE/'terminal-status.json',record);print('MONITOR_TERMINAL '+s['status'],flush=True);return
  if reasons:
   # Reverify now before using the maintained exact-job cancellation command.
   verify=subprocess.run(SSH,input=(HERE/'remote_probe.py').read_bytes(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40)
   if verify.returncode:raise RuntimeError('cannot reverify cancellation identity; no signal sent')
   fresh=json.loads(verify.stdout);(HERE/'pre-cancel-identity.json').write_bytes(verify.stdout)
   if fresh['status']!='RUNNING':print('BOUND_TERMINAL_NO_CANCEL',flush=True);prior=s;continue
   if not violations(fresh):print('BOUND_RECHECK_CLEARED_NO_CANCEL',flush=True);prior=s;continue
   if not ownership(fresh,baseline) or bind(FARM)!=identity['farm_cancellation']:raise RuntimeError('exact ownership/cancellation-source proof failed; no signal sent')
   write(HERE/'cancellation-reason.json',dict(reasons=violations(fresh),worker=fresh['worker'],verified_all_vivado_descendants=True,argv=[str(FARM),'cancel','bp1',JOB,LOGROOT]))
   with (HERE/'maintained-cancel.log').open('wb') as log:result=subprocess.run([str(FARM),'cancel','bp1',JOB,LOGROOT],stdout=log,stderr=subprocess.STDOUT,timeout=50)
   print('MAINTAINED_CANCEL_EXIT '+str(result.returncode),flush=True)
   post=poll(index+1);write(HERE/'post-cancel-status.json',post)
   if post['all_vivado'] or post['worker']:raise RuntimeError('post-cancel process disappearance not proven')
   if post['status']!='CANCELLED':raise RuntimeError('maintained cancellation not terminalCANCELLED')
   write(HERE/'terminal-status.json',dict(status='CANCELLED',cause=violations(fresh),post_snapshot='poll-%03d.json'%(index+1)))
   print('MONITOR_TERMINAL CANCELLED_BOUND_OR_IDENTITY',flush=True);return
  prior=s
if __name__=='__main__':main()
