//
// this is an example of "host code" that can either run in cosim or on the PS
// we can use the same C host code and
// the API we provide abstracts away the
// communication plumbing differences.

#include <bitset>
#include <errno.h>
#include <locale.h>
#include <queue>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <type_traits>
#include <unistd.h>
#include <utility>

#include "ps.hpp"

#include "bsg_host.h"
#include "bsg_printing.h"
#include "bsg_utils.h"
#include "bsg_tag_bitbang.h"
#include "bsg_zynq_pl.h"

#ifndef DRAM_ALLOCATE_SIZE_MB
#define DRAM_ALLOCATE_SIZE_MB 128
#endif
#define DRAM_ALLOCATE_SIZE (DRAM_ALLOCATE_SIZE_MB * 1024 * 1024)

// Hardware builds provide these through Makefile.design. Keep zero-valued
// fallbacks so the shared host source still compiles in environments that do
// not describe the two clock domains.
#ifndef ACLK_MHZ
#define ACLK_MHZ 0
#endif
#ifndef RTCLK_MHZ
#define RTCLK_MHZ 0
#endif

// Helper functions
void nbf_load(bsg_zynq_pl *zpl, char *filename);

// Older PYNQ deployment checkouts expose done() as void, while current
// simulation and hardware backends return a status code. Keep the shared host
// program source-compatible with both interfaces.
template <typename Zpl>
typename std::enable_if<std::is_void<decltype(std::declval<Zpl &>().done())>::value,
                        int>::type
finish(Zpl *zpl) {
    zpl->done();
    return 0;
}

template <typename Zpl>
typename std::enable_if<!std::is_void<decltype(std::declval<Zpl &>().done())>::value,
                        int>::type
finish(Zpl *zpl) {
    return zpl->done();
}

int ps_main(bsg_zynq_pl *zpl, int argc, char **argv) {

    unsigned long long max_runtime_ms = 0;
    if (argc >= 3) {
        char *end = nullptr;
        errno = 0;
        max_runtime_ms = strtoull(argv[2], &end, 0);
        if (errno || end == argv[2] || *end != '\0') {
            bsg_pr_err("ps.cpp: invalid max runtime in milliseconds: %s\n",
                       argv[2]);
            return -1;
        }
        bsg_pr_info("ps.cpp: limiting target runtime to %llu ms\n",
                    max_runtime_ms);
    }

    // Counter sampling is opt-in because GP reads perturb host-side polling
    // throughput. It is intended for localizing boot stalls, not timed runs.
    unsigned long long liveness_interval_ms = 0;
    const char *liveness_env = getenv("BSG_LIVENESS_INTERVAL_MS");
    if (liveness_env && *liveness_env) {
        char *end = nullptr;
        errno = 0;
        liveness_interval_ms = strtoull(liveness_env, &end, 0);
        if (errno || end == liveness_env || *end != '\0'
            || liveness_interval_ms == 0) {
            bsg_pr_err(
                "ps.cpp: invalid BSG_LIVENESS_INTERVAL_MS value: %s\n",
                liveness_env);
            return -1;
        }
        bsg_pr_info("ps.cpp: liveness sampling every %llu host ms\n",
                    liveness_interval_ms);
    }

    double aclk_hz = ((double)ACLK_MHZ) * 1000000.0;
    double rtclk_hz = ((double)RTCLK_MHZ) * 1000000.0;
    const char *aclk_env = getenv("BSG_ACLK_HZ");
    const char *rtclk_env = getenv("BSG_RTCLK_HZ");
    if (aclk_env && *aclk_env) {
        char *end = nullptr;
        errno = 0;
        double value = strtod(aclk_env, &end);
        if (errno || end == aclk_env || *end != '\0' || value <= 0.0) {
            bsg_pr_err("ps.cpp: invalid BSG_ACLK_HZ value: %s\n", aclk_env);
            return -1;
        }
        aclk_hz = value;
    }
    if (rtclk_env && *rtclk_env) {
        char *end = nullptr;
        errno = 0;
        double value = strtod(rtclk_env, &end);
        if (errno || end == rtclk_env || *end != '\0' || value <= 0.0) {
            bsg_pr_err("ps.cpp: invalid BSG_RTCLK_HZ value: %s\n", rtclk_env);
            return -1;
        }
        rtclk_hz = value;
    }
    if (aclk_hz > 0.0 && rtclk_hz > 0.0)
        bsg_pr_info("ps.cpp: counter clocks ACLK=%.0f Hz RTCLK=%.0f Hz\n",
                    aclk_hz, rtclk_hz);
    else
        bsg_pr_warn(
            "ps.cpp: counter clock normalization unavailable; set "
            "BSG_ACLK_HZ and BSG_RTCLK_HZ\n");

    long data;
    long val1 = 0x1;
    long val2 = 0x0;
    long mask1 = 0xf;
    long mask2 = 0xf;

    int32_t val;
    bsg_pr_info("ps.cpp: reading four base registers\n");
    bsg_pr_info(
        "ps.cpp: reset(lo)=%d, bitbang=%d, dram_init=%d, dram_base=%d\n",
        zpl->shell_read(GP0_RD_CSR_SYS_RESETN),
        zpl->shell_read(GP0_RD_CSR_TAG_BITBANG),
        zpl->shell_read(GP0_RD_CSR_DRAM_INITED),
        val = zpl->shell_read(GP0_RD_CSR_DRAM_BASE));

    bsg_pr_info("ps.cpp: attempting to write and read register 0x8\n");

    zpl->shell_write(GP0_WR_CSR_DRAM_BASE, 0xDEADBEEF, mask1);
    assert((zpl->shell_read(GP0_RD_CSR_DRAM_BASE) == (0xDEADBEEF)));
    zpl->shell_write(GP0_WR_CSR_DRAM_BASE, val, mask1);
    assert((zpl->shell_read(GP0_RD_CSR_DRAM_BASE) == (val)));

    bsg_pr_info(
        "ps.cpp: successfully wrote and read registers in bsg_zynq_shell "
        "(verified ARM GP0 connection)\n");

    std::unique_ptr<bsg_tag_bitbang> btb = std::make_unique<bsg_tag_bitbang>(zpl, GP0_WR_CSR_TAG_BITBANG, TAG_NUM_CLIENTS, TAG_MAX_LEN);
    std::unique_ptr<bsg_host> host = std::make_unique<bsg_host>(zpl, GP0_RD_PL2PS_FIFO_CTRS, GP0_RD_PL2PS_FIFO_DATA);
    bsg_tag_client pl_reset_client(TAG_CLIENT_PL_RESET_ID, TAG_CLIENT_PL_RESET_WIDTH);
    bsg_tag_client wd_reset_client(TAG_CLIENT_WD_RESET_ID, TAG_CLIENT_WD_RESET_WIDTH);

    // Reset the bsg tag master
    btb->reset_master();
    // Reset bsg client0
    btb->reset_client(&pl_reset_client);
    // Reset bsg client1
    btb->reset_client(&wd_reset_client);
    // Set bsg client0 to 1 (assert BP reset)
    btb->set_client(&pl_reset_client, 0x1);
    // Set bsg client1 to 1 (assert WD reset)
    btb->set_client(&wd_reset_client, 0x1);
    // Set bsg client0 to 0 (deassert BP reset)
    btb->set_client(&pl_reset_client, 0x0);

    // We need some additional toggles for data to propagate through
    btb->idle(50);
    // Deassert the active-low system reset as we finish initializing the whole
    // system
    zpl->shell_write(GP0_RD_CSR_SYS_RESETN, 0x1, 0xF);

    unsigned long phys_ptr;
    volatile int *buf;
    data = zpl->shell_read(GP0_RD_CSR_DRAM_INITED);
    if (data != 0)
        bsg_pr_warn(
            "ps.cpp: ignoring stale cross-process DRAM base pointer %x\n",
            zpl->shell_read(GP0_RD_CSR_DRAM_BASE));
    zpl->shell_write(GP0_WR_CSR_DRAM_INITED, 0x0, mask2);

    bsg_pr_info("ps.cpp: allocating owned DRAM buffer with size %ld\n",
                (long)DRAM_ALLOCATE_SIZE);
    buf = (volatile int *)zpl->allocate_dram(DRAM_ALLOCATE_SIZE, &phys_ptr);
#ifdef AXI_MEM_ENABLE
    // The simulation AXI RAM is a separate address space, not a mapping of
    // this host allocation. A malloc pointer is neither page aligned nor
    // bounded by that RAM and shifts otherwise legal cache-line bursts across
    // AXI's 4 KiB boundaries. NBF writes initialize the simulated RAM via AXI.
    phys_ptr = 0;
#endif
    bsg_pr_info("ps.cpp: received %p (phys = %lx)\n", buf, phys_ptr);
    zpl->shell_write(GP0_WR_CSR_DRAM_BASE, phys_ptr, mask1);
    assert((zpl->shell_read(GP0_RD_CSR_DRAM_BASE) == (int32_t)(phys_ptr)));
    bsg_pr_info("ps.cpp: wrote and verified base register\n");
    zpl->shell_write(GP0_WR_CSR_DRAM_INITED, 0x1, mask2);
    assert(zpl->shell_read(GP0_RD_CSR_DRAM_INITED) == 1);

    if (argc == 1) {
        bsg_pr_warn(
            "No nbf file specified, sleeping for 2^31 seconds (this will hold "
            "onto allocated DRAM)\n");
        sleep(1U << 31);
        return -1;
    }

    bsg_pr_info("ps.cpp: attempting to read mtime reg in BP CFG space, should "
                "increase monotonically  (testing ARM GP1 connections)\n");

    for (int q = 0; q < 10; q++) {
        int z = get_counter_64(zpl, GP1_CSR_BASE_ADDR + 0x30bff8);
        bsg_pr_dbg_ps("ps.cpp: %d-%d\n", q, z);
    }

    bsg_pr_info(
        "ps.cpp: attempting to read and write mtime reg in BP CFG space "
        "(testing ARM GP1 connections)\n");

    bsg_pr_info("ps.cpp: reading mtimecmp\n");
    int y = zpl->shell_read(GP1_CSR_BASE_ADDR + 0x304000);

    bsg_pr_info("ps.cpp: writing mtimecmp\n");
    zpl->shell_write(GP1_CSR_BASE_ADDR + 0x304000, y + 1, mask1);

    bsg_pr_info("ps.cpp: reading mtimecmp\n");
    assert(zpl->shell_read(GP1_CSR_BASE_ADDR + 0x304000) == y + 1);

    int outer = 1024 / 4;
#ifdef DRAM_TEST
    long num_times = DRAM_ALLOCATE_SIZE / 32768;
    bsg_pr_info(
        "ps.cpp: attempting to write L2 %ld times over %ld MB (testing ARM GP1 "
        "and HP0 connections)\n",
        num_times * outer, (long)((DRAM_ALLOCATE_SIZE) >> 20));
    zpl->shell_write(GP1_DRAM_BASE_ADDR, 0x12345678, mask1);

    for (int s = 0; s < outer; s++)
        for (int t = 0; t < num_times; t++) {
            zpl->shell_write(GP1_DRAM_BASE_ADDR + 32768 * t + s * 4,
                             0x1ADACACA + t + s, mask1);
        }
    bsg_pr_info("ps.cpp: finished write L2 %ld times over %ld MB\n",
                num_times * outer, (long)((DRAM_ALLOCATE_SIZE) >> 20));

    int mismatches = 0;
    int matches = 0;

#ifdef ZYNQ
    for (int s = 0; s < outer; s++)
        for (int t = 0; t < num_times; t++)
            if (buf[(32768 * t + s * 4) / 4] == 0x1ADACACA + t + s)
                matches++;
            else
                mismatches++;

    bsg_pr_info("ps.cpp: DIRECT access from ARM to DDR (some L1/L2 coherence "
                "mismatches expected) %d matches, %d mismatches, %f\n",
                matches, mismatches,
                ((float)matches) / (float)(mismatches + matches));
#endif

    bsg_pr_info(
        "ps.cpp: attempting to read L2 %ld times over %ld MB (testing ARM GP1 "
        "and HP0 connections)\n",
        num_times * outer, (long)((DRAM_ALLOCATE_SIZE) >> 20));
    for (int s = 0; s < outer; s++)
        for (int t = 0; t < num_times; t++)
            if (zpl->shell_read(GP1_DRAM_BASE_ADDR + 32768 * t + s * 4) ==
                0x1ADACACA + t + s)
                matches++;
            else
                mismatches++;

    bsg_pr_info("ps.cpp: READ access through BP (some L1 coherence mismatch "
                "expected): %d matches, %d mismatches, %f\n",
                matches, mismatches,
                ((float)matches) / (float)(mismatches + matches));

#endif // DRAM_TEST

    // Must zero DRAM for FPGA Linux boot, because opensbi payload mode
    //   obliterates the section names of the payload (Linux)
#if defined(ZERO_DRAM) && ZERO_DRAM
    bsg_pr_info("ps.cpp: Zero-ing DRAM (%d bytes)\n",
                (int)DRAM_ALLOCATE_SIZE);
    for (int i = 0; i < DRAM_ALLOCATE_SIZE; i += 4) {
        if (i % (1024 * 1024) == 0)
            bsg_pr_info("ps.cpp: zero-d %d MB\n", i / (1024 * 1024));
        zpl->shell_write(gp1_addr_base + i, 0x0, mask1);
    }
#endif // defined(ZERO_DRAM) && ZERO_DRAM

    bsg_pr_info("ps.cpp: beginning config\n");
    uintptr_t base_addr = GP1_CSR_BASE_ADDR;
    zpl->shell_write(base_addr + 0x200008, 1, mask1); // freeze
    zpl->shell_write(base_addr + 0x200010, 0x80000000, mask1); // npc
    zpl->shell_write(base_addr + 0x200208, 1, mask1); // icache mode
    zpl->shell_write(base_addr + 0x200408, 1, mask1); // dcache mode
    zpl->shell_write(base_addr + 0x200608, 1, mask1); // cce mode

    bsg_pr_info("ps.cpp: beginning nbf load\n");
    nbf_load(zpl, argv[1]);
    zpl->shell_write(base_addr + 0x200008, 0, mask1); // unfreeze
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    unsigned long long minstret_start = get_counter_64(zpl, GP0_RD_MINSTRET);
    unsigned long long mtime_start =
        get_counter_64(zpl, GP1_CSR_BASE_ADDR + 0x30bff8);
    bsg_pr_info("ps.cpp: finished nbf load\n");

    // Set bsg client1 to 0 (deassert WD reset)
    btb->set_client(&wd_reset_client, 0x1);
    bsg_pr_info("ps.cpp: starting watchdog\n");
    // We need some additional toggles for data to propagate through
    btb->idle(50);
    zpl->start();

    bsg_spack_t spack;
    bool runtime_limit_reached = false;
    unsigned long long empty_poll_count = 0;
    unsigned long long next_liveness_ms = liveness_interval_ms;
    unsigned long long last_liveness_minstret = minstret_start;
    unsigned long long last_liveness_mtime = mtime_start;
    unsigned long long liveness_sample_count = 0;
    do {
        if (host->get_next_packet(&spack)) {
            host->process_spack(&spack);
        } else {
            for (int i = 0; i < 10; i++) {
#ifdef SIMULATION
                // Keep asynchronous host AXI transactions moving while the
                // guest runs.  Advancing only RTL clocks can let a short
                // response pulse pass while its coroutine is suspended.
                zpl->service();
#else
                zpl->tick();
#endif
            }
        }
        empty_poll_count++;
        bool runtime_check_due =
            max_runtime_ms && ((empty_poll_count & 0x3ff) == 0);
        bool liveness_check_due =
            liveness_interval_ms && ((empty_poll_count & 0x3f) == 0);
        if (runtime_check_due || liveness_check_due) {
            struct timespec now;
            clock_gettime(CLOCK_MONOTONIC, &now);
            long long elapsed_ns =
                1000000000LL * (now.tv_sec - start.tv_sec)
                + (now.tv_nsec - start.tv_nsec);
            unsigned long long elapsed_ms = elapsed_ns / 1000000LL;
            if (liveness_check_due && elapsed_ms >= next_liveness_ms) {
                struct timespec read_start, read_stop;
                liveness_sample_count++;
                clock_gettime(CLOCK_MONOTONIC, &read_start);
                bsg_pr_info("ps.cpp: liveness_begin host_ms=%llu sample=%llu\n",
                            elapsed_ms, liveness_sample_count);
                fflush(stdout);
                fflush(stderr);
                unsigned long long current_minstret =
                    get_counter_64(zpl, GP0_RD_MINSTRET);
                unsigned long long current_mtime =
                    get_counter_64(zpl, GP1_CSR_BASE_ADDR + 0x30bff8);
                clock_gettime(CLOCK_MONOTONIC, &read_stop);
                long long read_ns =
                    1000000000LL * (read_stop.tv_sec - read_start.tv_sec)
                    + (read_stop.tv_nsec - read_start.tv_nsec);
                bsg_pr_info(
                    "ps.cpp: liveness host_ms=%llu minstret=%llu "
                    "retired_delta=%llu retired_since_last=%llu mtime=%llu "
                    "mtime_delta=%llu mtime_since_last=%llu sample=%llu "
                    "read_ns=%lld\n",
                    elapsed_ms, current_minstret,
                    current_minstret - minstret_start,
                    current_minstret - last_liveness_minstret, current_mtime,
                    current_mtime - mtime_start,
                    current_mtime - last_liveness_mtime,
                    liveness_sample_count, read_ns);
                fflush(stdout);
                fflush(stderr);
                last_liveness_minstret = current_minstret;
                last_liveness_mtime = current_mtime;
                next_liveness_ms =
                    (elapsed_ms / liveness_interval_ms + 1)
                    * liveness_interval_ms;
            }
            if (runtime_check_due && elapsed_ms >= max_runtime_ms) {
                bsg_pr_warn(
                    "ps.cpp: target runtime limit reached after %llu ms\n",
                    elapsed_ms);
                runtime_limit_reached = true;
                break;
            }
        }
    } while (!host->is_finished());

    // Set bsg client1 to 1 (assert WD reset)
    btb->set_client(&wd_reset_client, 0x1);
    bsg_pr_info("ps.cpp: stopping watchdog\n");
    // We need some additional toggles for data to propagate through
    btb->idle(50);
    zpl->stop();

    unsigned long long minstret_stop = get_counter_64(zpl, GP0_RD_MINSTRET);
    unsigned long long mtime_stop =
        get_counter_64(zpl, GP1_CSR_BASE_ADDR + 0x30bff8);
    // test delay for reading counter
    unsigned long long counter_data = get_counter_64(zpl, GP0_RD_MINSTRET);
    clock_gettime(CLOCK_MONOTONIC, &end);
    setlocale(LC_NUMERIC, "");
    bsg_pr_info("ps.cpp: end polling i/o\n");
    bsg_pr_info("ps.cpp: minstret (instructions retired): %'16llu (%16llx)\n",
                minstret_start, minstret_start);
    bsg_pr_info("ps.cpp: minstret (instructions retired): %'16llu (%16llx)\n",
                minstret_stop, minstret_stop);
    unsigned long long minstret_delta = minstret_stop - minstret_start;
    bsg_pr_info("ps.cpp: minstret delta:                  %'16llu (%16llx)\n",
                minstret_delta, minstret_delta);
    bsg_pr_info("ps.cpp: MTIME start:                     %'16llu (%16llx)\n",
                mtime_start, mtime_start);
    bsg_pr_info("ps.cpp: MTIME stop:                      %'16llu (%16llx)\n",
                mtime_stop, mtime_stop);
    unsigned long long mtime_delta = mtime_stop - mtime_start;
    bsg_pr_info("ps.cpp: MTIME delta (RTCLK ticks):       %'16llu (%16llx)\n",
                mtime_delta, mtime_delta);
    double target_cycles = 0.0;
    if (aclk_hz > 0.0 && rtclk_hz > 0.0) {
        target_cycles = ((double)mtime_delta) * aclk_hz / rtclk_hz;
        bsg_pr_info("ps.cpp: target time (seconds):          %'16.6f\n",
                    ((double)mtime_delta) / rtclk_hz);
        bsg_pr_info("ps.cpp: normalized BP cycles:           %'16.3f\n",
                    target_cycles);
        bsg_pr_info("ps.cpp: IPC        :                     %'16f\n",
                    target_cycles > 0.0
                        ? ((double)minstret_delta) / target_cycles
                        : 0.0);
    } else {
        bsg_pr_info("ps.cpp: IPC        :                     unavailable\n");
    }
    bsg_pr_info("ps.cpp: minstret (instructions retired): %'16llu (%16llx)\n",
                counter_data, counter_data);
    unsigned long long diff_ns =
        1000LL * 1000LL * 1000LL *
            ((unsigned long long)(end.tv_sec - start.tv_sec)) +
        (end.tv_nsec - start.tv_nsec);
    bsg_pr_info(
        "ps.cpp: wall clock time                : %'16llu (%16llx) ns\n",
        diff_ns, diff_ns);
    if (target_cycles > 0.0)
        bsg_pr_info(
            "ps.cpp: sim/emul speed                 : %'16.2f BP cycles "
            "per minute\n",
            target_cycles
                / ((double)(diff_ns)
                   / (60.0 * 1000.0 * 1000.0 * 1000.0)));

    bsg_pr_info(
        "ps.cpp: BP DRAM USAGE MASK (each bit is 8 MB): "
        "%-8.8d%-8.8d%-8.8d%-8.8d\n",
        zpl->shell_read(GP0_RD_MEM_PROF_3), zpl->shell_read(GP0_RD_MEM_PROF_2),
        zpl->shell_read(GP0_RD_MEM_PROF_1), zpl->shell_read(GP0_RD_MEM_PROF_0));
    bsg_pr_info("ps.cpp: freeing DRAM buffer\n");
#if defined(BP_RETAINED_OBSERVE) && BP_RETAINED_OBSERVE
    // Optional separately built diagnostic host; the accepted board runner is
    // unchanged. Read after the existing stop, before freeing owned DRAM.
    const uint32_t retained_hits = zpl->shell_read(GP0_RD_RETAINED_HITS);
    const uint32_t retained_published = zpl->shell_read(GP0_RD_RETAINED_PUBLISHED);
    const uint32_t retained_writes = zpl->shell_read(GP0_RD_RETAINED_WRITES);
    bsg_pr_info("RETAINED_USE_COUNTERS version=1 i_hits=%u d_hits=%u i_published=%u d_published=%u i_write_beats=%u d_write_beats=%u saturating_bits=16 reset=axi_only\n",
                retained_hits & 0xffffU, retained_hits >> 16,
                retained_published & 0xffffU, retained_published >> 16,
                retained_writes & 0xffffU, retained_writes >> 16);
#endif
    zpl->free_dram((void *)buf);
    zpl->shell_write(GP0_WR_CSR_DRAM_INITED, 0x0, mask2);

    int done_rc = finish(zpl);
    return runtime_limit_reached ? 124 : done_rc;
}

void nbf_load(bsg_zynq_pl *zpl, char *nbf_filename) {
    std::string nbf_command;
    std::string tmp;
    std::string delimiter = "_";

    long long int nbf[3];
    int pos = 0;
    long unsigned int base_addr;
    int data;
    std::ifstream nbf_file(nbf_filename);

    if (!nbf_file.is_open()) {
        bsg_pr_err("ps.cpp: error opening nbf file.\n");
        return;
    }

    int line_count = 0;
    while (getline(nbf_file, nbf_command)) {
        line_count++;
        int i = 0;
        while ((pos = nbf_command.find(delimiter)) != std::string::npos) {
            tmp = nbf_command.substr(0, pos);
            nbf[i] = std::stoull(tmp, nullptr, 16);
            nbf_command.erase(0, pos + 1);
            i++;
        }
        nbf[i] = std::stoull(nbf_command, nullptr, 16);

        if (nbf[0] == 0x3 || nbf[0] == 0x2 || nbf[0] == 0x1 || nbf[0] == 0x0) {
            // we map BP physical addresses for DRAM (0x8000_0000 - 0x9FFF_FFFF)
            // (256MB)
            // to the same ARM physical addresses
            // see top_zynq.v for more details

            // we map BP physical address for CSRs etc (0x0000_0000 -
            // 0x0FFF_FFFF) to ARM address to 0xA0000_0000 - 0xAFFF_FFFF
            // (256MB)
            if (nbf[1] >= DRAM_BASE_ADDR)
                base_addr = gp1_addr_base - DRAM_BASE_ADDR;
            else
                base_addr = GP1_CSR_BASE_ADDR;

            if (nbf[0] == 0x3) {
                zpl->shell_write(base_addr + nbf[1], nbf[2], 0xf);
                zpl->shell_write(base_addr + nbf[1] + 4, nbf[2] >> 32, 0xf);
            } else if (nbf[0] == 0x2) {
                zpl->shell_write(base_addr + nbf[1], nbf[2], 0xf);
            } else if (nbf[0] == 0x1) {
                int offset = nbf[1] % 4;
                int shift = 2 * offset;
                data = zpl->shell_read(base_addr + nbf[1] - offset);
                data = data & rotl((uint32_t)0xffff0000, shift) + nbf[2] &
                       ((uint32_t)0x0000ffff << shift);
                zpl->shell_write(base_addr + nbf[1] - offset, data, 0xf);
            } else {
                int offset = nbf[1] % 4;
                int shift = 2 * offset;
                data = zpl->shell_read(base_addr + nbf[1] - offset);
                data = data & rotl((uint32_t)0xffffff00, shift) + nbf[2] &
                       ((uint32_t)0x000000ff << shift);
                zpl->shell_write(base_addr + nbf[1] - offset, data, 0xf);
            }
        } else if (nbf[0] == 0xfe) {
            continue;
        } else if (nbf[0] == 0xff) {
            bsg_pr_dbg_ps("ps.cpp: nbf finish command, line %d\n", line_count);
            continue;
        } else {
            bsg_pr_dbg_ps("ps.cpp: unrecognized nbf command, line %d : %llx\n",
                          line_count, nbf[0]);
            return;
        }
    }

    bsg_pr_dbg_ps("ps.cpp: finished loading %d lines of nbf.\n", line_count);
}
