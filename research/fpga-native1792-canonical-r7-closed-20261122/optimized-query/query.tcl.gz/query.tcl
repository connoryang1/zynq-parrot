set_param general.maxThreads 2
set input /home/coyang/fpga-artifacts/context-resume/native1792-canonical-r7-preparation-20261121/closed-terminal01/optimized.dcp
set expected 3606b688093265dffdc26f1057873bc92a3ce1e7cd05eb9810e31b7f6ca057ef
if {[lindex [exec sha256sum $input] 0] ne $expected} {error "input DCP identity mismatch"}
open_checkpoint $input
report_utilization -file utilization_flat.rpt
report_utilization -hierarchical -file utilization_hierarchical.rpt
report_control_sets -file control_sets.rpt
set f [open focused-hierarchy.tsv w]
puts $f "index\tname\tref_name\treport"
set index 0
foreach c [lsort [get_cells -hierarchical -filter {IS_PRIMITIVE == 0}]] {
  set ref [get_property REF_NAME $c]
  if {[regexp {^(bp_retained_line_store|bp_uce|bp_be_dcache|bp_fe_icache|bp_core_minimal|bp_retained_use_counters)} $ref]} {
    set filename [format focused-%02d.rpt $index]
    report_utilization -cells [list $c] -file $filename
    puts $f [join [list $index $c $ref $filename] "\t"]
    incr index
    if {$index > 20} {error "unexpectedly many focused hierarchy roots"}
  }
}
close $f
set detail [open retained-and-UCE-primitives.tsv w]
puts $detail "component\tname_group\tref_name\tname"
set detail_rows 0
set ram [open retained-RAM-ports.tsv w]
puts $ram "name\tref_name\tram_mode\tread_a\twrite_a\tread_b\twrite_b\tclock_a\tclock_b"
set counts [dict create]
set samples [dict create]
foreach c [get_cells -hierarchical -filter {IS_PRIMITIVE == 1}] {
  set name [get_property NAME $c]
  set ref [get_property REF_NAME $c]
  set component other_wrapper_uncore
  set function all
  if {[string match *retained_observe* $name]} {
    set component observer
  } elseif {[string match *retained_store* $name]} {
    set component retained_common
    if {[regexp {lane_fsm\[([01])\]} $name unused lane]} {
      if {$lane == 0} {set component retained_I} else {set component retained_D}
    }
    set function unattributed_named_store_logic
    if {[regexp {(epochs_r|epoch_ram|distributed_epochs|line_epoch|epoch_read|insert_epoch|inv_set|set_kill|wrap)} $name]} {set function epoch_storage_or_access_named}
    if {[string match *rr_r* $name]} {set function RR_storage_or_access_named}
    if {[string match *payload_mem* $name]} {set function payload_RAM_or_interface_named}
    if {[string match *tag_mem* $name]} {set function tag_RAM_or_interface_named}
    if {[string match *insert_data_r* $name]} {set function capture_line_registers_or_mux_named}
    if {[string match *resp_data_r* $name]} {set function response_line_registers_or_mux_named}
    if {[regexp {(state_r|slot_r|clear_slot_r|word_r)} $name]} {set function controller_named}
  } elseif {[string match *cache_miss_trace* $name] || [string match *tracer* $name]} {
    set component trace_named
  } elseif {[string match *icache_uce* $name]} {set component I_UCE
  } elseif {[string match *dcache_uce* $name]} {set component D_UCE
  } elseif {[string match *core_minimal*icache* $name]} {set component ordinary_L1I
  } elseif {[string match *pipe_mem*dcache* $name]} {set component ordinary_L1D
  } elseif {[string match *l2s* $name]} {set component L2
  } elseif {[string match *context_cache* $name]} {set component context_cache_named
  } elseif {[string match *core_minimal* $name]} {set component CPU_core_other}
  if {$component in {I_UCE D_UCE}} {
    if {[string match *prefetch_fill_bank* $name]} {set function staging_RAM_or_interface_named
    } elseif {[string match *prefetch_install_line* $name]} {set function staging_read_line_registers_named
    } elseif {[regexp {retained.*(data|line).*_r} $name]} {set function retained_capture_response_buffer_or_mux_named
    } elseif {[string match *retained_* $name]} {set function retained_control_named
    } elseif {[string match *prefetch_* $name]} {set function detached_prefetch_control_named
    } else {set function ordinary_UCE_other}
  }
  if {[string match retained_* $component] || ($component in {I_UCE D_UCE} && $function ne "ordinary_UCE_other")} {
    puts $detail [join [list $component $function $ref $name] "\t"]
    incr detail_rows
    if {$detail_rows > 20000} {error "bounded named primitive detail exceeded"}
  }
  if {[string match retained_* $component] && [string match RAM* $ref]} {
    set row [list $name $ref]
    foreach prop {RAM_MODE READ_WIDTH_A WRITE_WIDTH_A READ_WIDTH_B WRITE_WIDTH_B} {
      if {[lsearch -exact [list_property $c] $prop] >= 0} {lappend row [get_property $prop $c]} else {lappend row "-"}
    }
    foreach pin {CLKARDCLK CLKBWRCLK} {
      set pins [get_pins -quiet $c/$pin]
      if {[llength $pins]} {lappend row [join [lsort [get_nets -quiet -of_objects $pins]] ,]} else {lappend row "-"}
    }
    puts $ram [join $row "\t"]
  }
  set key [list $component $function $ref]
  dict incr counts $key
  if {![dict exists $samples $key] || [llength [dict get $samples $key]] < 4} {
    dict lappend samples $key $name
  }
}
close $detail
close $ram
set f [open primitive-counts.tsv w]
puts $f "component\tname_group\tref_name\tprimitive_count"
foreach key [lsort [dict keys $counts]] {puts $f [join [concat $key [list [dict get $counts $key]]] "\t"]}
close $f
set f [open primitive-name-samples.tsv w]
puts $f "component\tname_group\tref_name\tname"
foreach key [lsort [dict keys $samples]] {
  foreach name [dict get $samples $key] {puts $f [join [concat $key [list $name]] "\t"]}
}
close $f
if {[lindex [exec sha256sum $input] 0] ne $expected} {error "DCP changed during read query"}
puts "READ_ONLY_HIERARCHY_QUERY_COMPLETE_NO_SYNTH_OPT_PLACE_ROUTE"
