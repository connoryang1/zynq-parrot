#!/usr/bin/env python3
"""Static immutable-leaf/netlist/reference binding; no remote or vendor launch."""
from pathlib import Path
from collections import Counter
import ast,hashlib,json,re,shutil
P=Path(__file__).resolve().parent
OLD=Path('/home/coyang/fpga-artifacts/context-resume/retained-D-epoch-paired-inference-20261121/preparation01');R=OLD/'run01/remote'
FULL=Path('/home/coyang/fpga-artifacts/context-resume/retained-epoch-mapped-equivalence-20261121/preparation01')
EXT={n:R/n for n in ('canonical-functional.v','canonical-synthesized.dcp','canonical-utilization.rpt','canonical-primitives.tsv')}
EXT.update({n:OLD/n for n in ('bp_retained_epoch_ram.sv','canonical-wrapper.sv','current.sv','source-proof.json')});EXT.update({n:FULL/n for n in ('component-final.json','root-component-manifest.json')});EXT['candidate-final.sv']=FULL/'run01/remote/candidate-final.sv'
LOCAL=('miter.sv','reference.sv','run.tcl','pipeline.py','owner.py','acquire.py','prepare.py','README.md','prior-failure.json','watchdog-only.diff')
def bind(p,name=None):
 b=p.read_bytes();return dict(path=name or p.name,source=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def main():
 old=Path('/home/coyang/fpga-artifacts/context-resume/retained-epoch-compositional-mapped-20261121/preparation01')
 assert (P/'miter.sv').read_bytes()==(old/'miter.sv').read_bytes().replace(b'#10000000000;',b"#(64'd10000000000);",1)
 for name in ('pipeline.py','owner.py','reference.sv','run.tcl','README.md'):assert (P/name).read_bytes()==(old/name).read_bytes()
 assert (P/'acquire.py').read_bytes()==(old/'acquire.py').read_bytes().replace(b'retained-epoch-compositional-mapped-20261121-01',b'retained-epoch-compositional-mapped-20261121-02',1)
 for n in ('pipeline.py','owner.py','acquire.py','prepare.py'):ast.parse((P/n).read_text(),filename=n,feature_version=8)
 leaf=(OLD/'bp_retained_epoch_ram.sv').read_bytes();whole=EXT['candidate-final.sv'].read_bytes();assert hashlib.sha256(leaf).hexdigest()=='a7673ffc8151b005fcfbfeb4a9e020098e0a2d409b2b79c0bebb2ebe9e0d8720' and hashlib.sha256(whole).hexdigest()=='68d1dd0c7df7e56ffe76317f9bae5a3ca3e09d13cb44d1167c0f737acefcbea6' and whole.count(leaf)==1
 raw=(OLD/'current.sv').read_bytes();assert hashlib.sha256(raw).hexdigest()=='8187a0b2deb107a9df92deccea59c985054de31edaf88a998674b806e2d3a6e6';assert (P/'reference.sv').read_bytes()==raw.replace(b'module epoch_probe\n',b'module epoch_reference_probe\n',1)
 net=(R/'canonical-functional.v').read_text();assert hashlib.sha256(net.encode()).hexdigest()=='4b1bbda88862edae221f93b914fc5932fef311eb29c2357283f5e6834849d951'
 assert bind(R/'canonical-synthesized.dcp')['sha256']=='c4aa54f4c0016a4ad4b8547ada624b8b3d37b4aa5422ea537f3c4806f3955be2'
 body=net[net.index('module epoch_canonical\n'):].split('endmodule',1)[0];ports={}
 for m in re.finditer(r'(?m)^\s*(input|output)\s+(?:\[(\d+):0\]\s*)?(\w+)\s*;',body):
  d,h,n=m.groups();ports[n]=(d,int(h)+1 if h else 1)
 expected={n:('input',1) for n in ('clk_d_i','reset_d_i','clear_d_i','inv_v_i','tag_valid_i')};expected.update({n:('input',34) for n in ('inv_addr_i','insert_paddr_i')});expected.update(state_i=('input',4),set_i=('input',8),clear_slot_i=('input',11),tag_epoch_i=('input',8));expected.update({n:('output',8) for n in ('line_epoch_o','inv_epoch_o')});expected.update({n:('output',1) for n in ('wrap_o','clear_now_o','set_kill_o','valid_tag_o')});assert ports==expected
 refs=Counter(line.rsplit('\t',1)[1] for line in (R/'canonical-primitives.tsv').read_text().splitlines()[1:]);assert refs['RAM64M']==24 and refs['RAMD64E']==96 and not any(v for k,v in refs.items() if k.startswith(('FD','LD','RAMB')))
 rows=[x for x in (R/'canonical-utilization.rpt').read_text().splitlines() if re.match(r'^\| epoch_probe\s*\|\s*\(top\)',x)];assert len(rows)==1;values=[int(v.strip()) for v in rows[0].split('|')[3:-1]];assert values==[151,55,96,0,0,0,0,0]
 inputs=[bind(P/n) for n in LOCAL]+[bind(path,n) for n,path in EXT.items()];assert len({r['path'] for r in inputs})==len(inputs) and all(Path(r['source']).name==r['path'] for r in inputs)
 a=dict(state='PREPARED ONLY actual isolated compositional changed-memory proof; root launch required',component_final_pass=True,inputs=inputs,leaf_proof=dict(a767_exact_in68d=True,byte_offset=whole.index(leaf),BP_final_commit='8dfdbdeec84cb47f902bc1426d69ecb3efd91c7c',actual_netlist_ports=ports,actual_adjusted_resources=dict(LUT=151,logic_LUT=55,LUTRAM=96,FF=0,BRAM=0)),limits=dict(Xsim_total_seconds=240,compile_total_seconds=30,simulation_seconds=150,TERM_grace_seconds=15,acquisition_seconds=300,RAM_scratch_bytes=128*1024**2,RAM_reserve_plus_remaining=1024**3,HOME_minimum=3*1024**3,collection_bytes=32*1024**2),synthesis_invocations=0,DCP_queries=0,retries=0,scope='Changed-memory compositional function only; actual fullbackend mapping/fullRTL component/fullcore separate. Fullbackend mapped coverage open.')
 (P/'admission.json').write_text(json.dumps(a,indent=2)+'\n');r=dict(state='PASS static source/signature/mapping checks only',admission=bind(P/'admission.json'),HOME_free=shutil.disk_usage(P).free,launch_HOME_eligible=shutil.disk_usage(P).free>=3*1024**3+32*1024**2,vendor_executions=0,remote_operations=0);(P/'host-preparation-proof.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':main()
