#!/usr/bin/env python3
"""One small actual isolated canonical mapped memory proof; no synthesis/query."""
from pathlib import Path
from collections import Counter
import argparse,hashlib,json,re,shutil,subprocess,time
P=Path(__file__).resolve().parent;V=Path('/tools/Xilinx/Vivado/2024.2')
MARKER='EPOCH_CANONICAL_MAPPED_PASS cells=256x8 async_ports=2 unique=256 allones=256 clears=512 rmw=65280 wrap=1 reset_block=2'
def bind(p):
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(path,value):
 t=path.with_suffix(path.suffix+'.tmp');t.write_text(json.dumps(value,indent=2)+'\n');t.replace(path)
def verify(expected):
 assert bind(P/'admission.json')['sha256']==expected;a=json.loads((P/'admission.json').read_bytes());assert a['component_final_pass']
 for r in a['inputs']:assert bind(P/r['path'])=={k:r[k] for k in ('bytes','sha256')},'input drift '+r['path']
 return a
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--admission-sha256',required=True);args=ap.parse_args();verify(args.admission_sha256)
 state=dict(state='RUNNING small mapped memory only',commands=[],synthesis_invocations=0);started=None
 def step(label,argv):
  nonlocal started
  now=time.monotonic()
  if started is None:started=now
  row=dict(label=label,argv=list(map(str,argv)),domain='xsim',tool_start=now,domain_start=started);state['commands'].append(row);save(P/'pipeline.json',state);save(P/'phase.json',row)
  with (P/(label+'.log')).open('wb') as f:r=subprocess.run(row['argv'],cwd=P/'xsim-run',stdout=f,stderr=subprocess.STDOUT)
  row.update(returncode=r.returncode,seconds=time.monotonic()-now,log=bind(P/(label+'.log')));save(P/'pipeline.json',state);assert r.returncode==0,label+' failed'
 try:
  net=P/'canonical-functional.v';dcp=P/'canonical-synthesized.dcp';before=dict(netlist=bind(net),DCP=bind(dcp))
  assert before['netlist']['sha256']=='4b1bbda88862edae221f93b914fc5932fef311eb29c2357283f5e6834849d951' and before['DCP']['sha256']=='c4aa54f4c0016a4ad4b8547ada624b8b3d37b4aa5422ea537f3c4806f3955be2'
  counts=Counter(line.rsplit('\t',1)[1] for line in (P/'canonical-primitives.tsv').read_text().splitlines()[1:]);assert counts['RAM64M']==24 and counts['RAMD64E']==96 and not any(v for k,v in counts.items() if k.startswith(('FD','LD','RAMB')))
  state['mapping']=dict(artifacts=before,raw_refs=dict(counts),scope='Closed isolated canonical epoch_probe real distributed RAM; macro/leaf counts overlap')
  text=net.read_text();assert text.count('module epoch_canonical\n')==1 and '`timescale' in text
  if re.search(r'(?m)^\s*module\s+glbl\b',text):assert re.search(r'`ifndef\s+GLBL\s+`define\s+GLBL\s+(?:`timescale[^\n]*\n\s*)?module\s+glbl\b',text)
  assert (P/'miter.sv').read_text().startswith('`timescale 1ps/1ps\n') and (P/'reference.sv').read_text().startswith('`timescale 1ns/1ps\n')
  glbl=V/'data/verilog/src/glbl.v';shutil.copyfile(glbl,P/'glbl.v');state['vendor_glbl']=dict(original=str(glbl),identity=bind(glbl));assert bind(P/'glbl.v')==bind(glbl)
  (P/'xsim-run').mkdir();b=V/'bin'
  for label,argv in [('xvlog-global',[b/'xvlog',P/'glbl.v']),('xvlog-netlist',[b/'xvlog','-d','GLBL',net]),('xvlog-reference',[b/'xvlog','--sv',P/'reference.sv',P/'miter.sv']),('xelab',[b/'xelab','-L','unisims_ver','-L','unimacro_ver','-L','secureip','work.epoch_memory_miter','work.glbl','-s','epoch_memory_miter']),('xsim',[b/'xsim','epoch_memory_miter','-tclbatch',P/'run.tcl'])]:step(label,argv)
  log=(P/'xsim.log').read_text();assert log.count(MARKER)==1 and not re.search(r'(?:FATAL_ERROR|Fatal:|\$fatal|Error:)',log),'miter failed/missing';assert before==dict(netlist=bind(net),DCP=bind(dcp));assert bind(glbl)==state['vendor_glbl']['identity'] and bind(P/'glbl.v')==bind(glbl);verify(args.admission_sha256)
  state.update(state='PASS actual isolated changed-memory compositional function only; fullbackend mapped equivalence remains open',marker=MARKER)
 except BaseException as e:state.update(state='FAIL preserve compositional attempt; no retry',error=repr(e));raise
 finally:save(P/'pipeline.json',state)
 print(state['state'])
if __name__=='__main__':main()
