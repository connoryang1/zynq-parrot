#!/usr/bin/env python3
"""Read immutable e06 netlist; extract exact module and characterize its boundary."""
from pathlib import Path
from collections import Counter
import hashlib,json,re
P=Path(__file__).resolve().parent
SRC=Path('/home/coyang/fpga-artifacts/context-resume/retained-epoch-mapped-equivalence-20261121/preparation01/run01/remote/candidate-functional.v')
def binding(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def main():
 raw=SRC.read_bytes();assert binding(raw)['sha256']=='e06ac16adec7d02b4cfb227902c563d985bb2554bdcbf86b1555571d8e63b35e';s=raw.decode();found=list(re.finditer(r'(?m)^module bp_retained_epoch_ram\b',s));assert len(found)==1;start=found[0].start();end=s.index('\nendmodule',start)+len('\nendmodule');part=raw[start:end];assert part.decode()==s[start:end]
 (P/'module-raw.v').write_bytes(part);(P/'mapped-epoch-extracted.v').write_bytes(b'`timescale 1ps/1ps\n'+part+b'\n')
 body=part.decode();ports=[]
 for m in re.finditer(r'(?m)^\s*(input|output)\s+(?:\[(\d+):(\d+)\]\s*)?(\\[^\s]+|[A-Za-z_]\w*)\s*;',body):
  d,h,l,n=m.groups();ports.append(dict(direction=d,width=int(h)-int(l)+1 if h else 1,name=n.lstrip('\\')))
 refs=Counter(re.findall(r'(?m)^  ([A-Za-z_]\w*)\s*(?:#\s*\(|(?:\\\S+|[A-Za-z_]\w*)\s*\()',body));refs.pop('wire',None)
 allowed={'RAM64M','LUT1','LUT2','LUT3','LUT4','LUT5','LUT6','CARRY4'};assert set(refs)<=allowed and refs['RAM64M']==24,'unexpected module dependency'
 api={'clk_i','write_v_i','write_addr_i','write_data_i','read_addr_i','invalidate_addr_i','read_data_o','invalidate_data_o'};present=api&{r['name'] for r in ports};assert len(ports)==199 and not present
 proof=dict(state='EXACT syntactically self-contained extraction; canonical functional adapter NOT established',source=dict(path=str(SRC),**binding(raw)),module='bp_retained_epoch_ram',slice=dict(byte_start=start,byte_end_exclusive=end,**binding(part)),standalone=dict(prefix='`timescale 1ps/1ps newline',suffix='newline only',**binding((P/'mapped-epoch-extracted.v').read_bytes())),port_count=len(ports),ports=ports,instance_types=dict(refs),dependencies='Vendor primitives only; no BRAMpayload/FF/submodule dependency in this extracted module',original_API_names_present=sorted(present),functional_boundary_limit='Optimization moved parent FSM/tag/payload/response combinational cones into the named epoch module;199contextual ports replace the original8port canonical memory API. No safe two-async-read/write semantic adapter derived; inventing constants or independently driving arbitrary parent state would not prove original memory semantics.',vendor_executions=0,resynthesis=0,DCP_queries=0)
 (P/'extraction.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items() if k!='ports'},indent=2));print('manifest',binding((P/'extraction.json').read_bytes()))
if __name__=='__main__':main()
