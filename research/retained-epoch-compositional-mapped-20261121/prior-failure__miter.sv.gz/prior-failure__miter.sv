`timescale 1ps/1ps
module epoch_memory_miter;
  logic clk_d_i=0,reset_d_i=1,clear_d_i=0,inv_v_i=0;
  logic [33:0] inv_addr_i=0,insert_paddr_i=0;
  logic [3:0] state_i=0;
  logic [7:0] set_i=0,tag_epoch_i=0;
  logic [10:0] clear_slot_i=0;
  logic tag_valid_i=0;
  wire [7:0] r_line,r_inv,m_line,m_inv;
  wire r_wrap,r_clear,r_kill,r_tag,m_wrap,m_clear,m_kill,m_tag;
  epoch_reference_probe reference_rtl
   (.clk_d_i(clk_d_i),.reset_d_i(reset_d_i),.clear_d_i(clear_d_i),.inv_v_i(inv_v_i),.inv_addr_i(inv_addr_i),.insert_paddr_i(insert_paddr_i),.state_i(state_i),.set_i(set_i),.clear_slot_i(clear_slot_i),.tag_valid_i(tag_valid_i),.tag_epoch_i(tag_epoch_i),.line_epoch_o(r_line),.inv_epoch_o(r_inv),.wrap_o(r_wrap),.clear_now_o(r_clear),.set_kill_o(r_kill),.valid_tag_o(r_tag));
  epoch_canonical hardware
   (.clk_d_i(clk_d_i),.reset_d_i(reset_d_i),.clear_d_i(clear_d_i),.inv_v_i(inv_v_i),.inv_addr_i(inv_addr_i),.insert_paddr_i(insert_paddr_i),.state_i(state_i),.set_i(set_i),.clear_slot_i(clear_slot_i),.tag_valid_i(tag_valid_i),.tag_epoch_i(tag_epoch_i),.line_epoch_o(m_line),.inv_epoch_o(m_inv),.wrap_o(m_wrap),.clear_now_o(m_clear),.set_kill_o(m_kill),.valid_tag_o(m_tag));
  bit [7:0] score[256];
  bit qualified=0;
  integer checks=0,rmw=0,clear_writes=0,unique_checks=0,ones_checks=0,reset_blocks=0,wrap_checks=0;
  function automatic logic [33:0] address(input int row);
    return 34'h100000000+(34'(row)<<6);
  endfunction
  task automatic check_outputs;
    int line_set,inv_set;
    bit expected_wrap,expected_clear,expected_kill,expected_tag;
    if(qualified)begin
      line_set=(state_i==1)?int'((insert_paddr_i>>6)&255):int'(set_i);
      inv_set=int'((inv_addr_i>>6)&255);
      expected_wrap=(state_i!=0)&&inv_v_i&&(score[inv_set]==255);
      expected_clear=clear_d_i||expected_wrap;expected_kill=inv_v_i&&(inv_set==set_i);
      expected_tag=tag_valid_i&&(tag_epoch_i==score[line_set]);
      if({m_line,m_inv,m_wrap,m_clear,m_kill,m_tag} !== {r_line,r_inv,r_wrap,r_clear,r_kill,r_tag})
        $fatal(1,"mapped/reference mismatch time=%0t line=%0d inv=%0d mapped=%h/%h reference=%h/%h",$time,line_set,inv_set,m_line,m_inv,r_line,r_inv);
      if({m_line,m_inv,m_wrap,m_clear,m_kill,m_tag} !== {score[line_set],score[inv_set],expected_wrap,expected_clear,expected_kill,expected_tag})
        $fatal(1,"independent scoreboard mismatch time=%0t line=%0d inv=%0d",$time,line_set,inv_set);
      checks++;
    end
  endtask
  task automatic cycle;
    int inv_set;
    bit wrap_before;
    #1000;check_outputs();inv_set=int'((inv_addr_i>>6)&255);
    wrap_before=(state_i!=0)&&inv_v_i&&(score[inv_set]==255);
    clk_d_i=1;
    if(!reset_d_i)begin
      if(state_i==0)begin score[int'(clear_slot_i)&255]=0;clear_writes++;end
      else if(!clear_d_i&&!wrap_before&&inv_v_i)begin score[inv_set]++;rmw++;end
    end
    #1000;check_outputs();#24000;clk_d_i=0;#24000;
  endtask
  task automatic async_check;
    #1000;check_outputs();
  endtask
  initial begin
    // No observation of uninitialized memory. glbl GSR falls at100ns.
    #200000;reset_d_i=0;state_i=0;clear_d_i=1;
    for(int row=0;row<256;row++)begin clear_slot_i=11'(1536+row);cycle();end
    qualified=1;clear_d_i=0;state_i=1;tag_valid_i=1;
    // Unique full8-bit values make address aliases and both read-port errors observable.
    for(int row=0;row<256;row++)begin
      inv_addr_i=address(row);insert_paddr_i=address(row);set_i=8'(row);inv_v_i=1;
      for(int n=0;n<row;n++)cycle();
      inv_v_i=0;
    end
    for(int row=0;row<256;row++)begin
      state_i=1;insert_paddr_i=address(row);inv_addr_i=address(255-row);set_i=8'(row^85);tag_epoch_i=8'(row);async_check();
      if(m_line!==8'(row)||m_inv!==8'(255-row))$fatal(1,"unique all8-bit location mismatch");unique_checks++;
      state_i=2;set_i=8'(255-row);tag_epoch_i=8'(255-row);async_check();
      tag_epoch_i=8'(row^165);tag_valid_i=0;async_check();tag_valid_i=1;
    end
    // Reset suppresses both clear and RMW writes; external clear inhibits RMW.
    state_i=0;clear_slot_i=42;reset_d_i=1;cycle();reset_blocks++;
    state_i=1;inv_addr_i=address(43);insert_paddr_i=address(43);inv_v_i=1;cycle();reset_blocks++;
    reset_d_i=0;clear_d_i=1;cycle();clear_d_i=0;inv_v_i=0;
    // Every bit in every physical logical cell reaches1 then returns0.
    for(int row=0;row<256;row++)begin
      state_i=1;inv_addr_i=address(row);insert_paddr_i=address(row);set_i=8'(row);inv_v_i=1;
      for(int n=row;n<255;n++)cycle();
      inv_v_i=0;async_check();if(m_line!==255||m_inv!==255)$fatal(1,"allones cell mismatch");ones_checks++;
    end
    // At255 the actual wrapper asserts wrap/clear and inhibits the RMW until its controller sweeps.
    state_i=1;inv_addr_i=address(17);insert_paddr_i=address(17);set_i=17;inv_v_i=1;async_check();
    if(!m_wrap||!m_clear)$fatal(1,"8bit wrap missing");cycle();if(m_inv!==255)$fatal(1,"wrap wrote without sweep");wrap_checks++;
    state_i=0;clear_d_i=1;
    for(int row=0;row<256;row++)begin clear_slot_i=11'(row);set_i=8'(row);inv_addr_i=address(row);cycle();end
    inv_v_i=0;clear_d_i=0;state_i=1;
    for(int row=0;row<256;row++)begin insert_paddr_i=address(row);inv_addr_i=address(255-row);tag_epoch_i=0;async_check();if(m_line!==0||m_inv!==0)$fatal(1,"clear coverage missing");end
    if(rmw!=65280||clear_writes!=512||unique_checks!=256||ones_checks!=256||reset_blocks!=2||wrap_checks!=1)$fatal(1,"coverage counter mismatch");
    $display("EPOCH_CANONICAL_MAPPED_PASS cells=256x8 async_ports=2 unique=256 allones=256 clears=512 rmw=65280 wrap=1 reset_block=2");
    $display("EPOCH_CANONICAL_MAPPED_COUNTS checks=%0d",checks);$finish;
  end
  initial begin #10000000000;$fatal(1,"fixed simulation-time watchdog");end
endmodule
