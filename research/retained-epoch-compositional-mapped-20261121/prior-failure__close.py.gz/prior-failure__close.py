#!/usr/bin/env python3
"""Preserve the failed watchdog attempt using closed local receipts only."""
from pathlib import Path
import json,hashlib,gzip
C=Path(__file__).resolve().parent;P=C.parent;R=P/'run01'
def bind(p):
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def main():
 assert bind(P/'admission.json')['sha256']=='0bf0a209b7f17f6ac84dfd17082e774a41557a79458964e1a7925ee594cc5aa2';a=json.loads((P/'admission.json').read_bytes());s=json.loads((R/'session.json').read_bytes());q=json.loads((R/'remote/pipeline.json').read_bytes());o=json.loads((R/'remote/owner.json').read_bytes())
 assert s['source_endcheck']=='PASS' and o['owned_group_gone'] and not o['terminal_vendor_processes'];assert [(x['label'],x['returncode']) for x in s['commands']]==[('idle-fresh',0),('upload',0),('pipeline',1),('no-orphans',0),('closed-files',0),('collect',0)];assert all(x['returncode']==0 for x in q['commands']) and q['error']=="AssertionError('miter failed/missing')"
 log=(R/'remote/xsim.log').read_text();compilelog=(R/'remote/xvlog-reference.log').read_text();assert 'Fatal: fixed simulation-time watchdog' in log and 'Time: 1410065408 ps' in log and 'VRFC 10-8884' in compilelog and 'using 1410065408 instead' in compilelog;assert 10000000000%(2**32)==1410065408
 for x in a['inputs']:assert bind(Path(x['source']))=={k:x[k] for k in ('bytes','sha256')} and bind(R/'remote'/x['path'])=={k:x[k] for k in ('bytes','sha256')}
 rows=json.loads((R/'closed-files.log').read_bytes())
 for x in rows:assert bind(R/'remote'/x['name'])=={k:x[k] for k in ('bytes','sha256')}
 files={'admission.json':P/'admission.json'}
 for x in a['inputs']:files['input/'+x['path']]=Path(x['source'])
 for base,label in [(R,'local'),(R/'remote','remote')]:
  for p in base.iterdir():
   if p.is_file():files[label+'/'+p.name]=p
 snaps=[]
 for name,p in sorted(files.items()):
  b=p.read_bytes();dest=C/(name.replace('/','__')+'.gz');dest.write_bytes(gzip.compress(b,mtime=0));assert gzip.decompress(dest.read_bytes())==b;snaps.append(dict(original=str(p),logical=name,raw=bind(p),gzip=dict(path=dest.name,**bind(dest))))
 result=dict(state='CLOSED FAIL unsized watchdog overflow; no completed compositional proof',root_execution=dict(session=9769,exit_code=1,basis='Root actual exit acknowledgment'),admission_sha256=bind(P/'admission.json')['sha256'],testbench_error=dict(source='#10000000000',intended_ps=10000000000,actual_ps=1410065408,relation='10^10 modulo2^32',tool_warning='VRFC10-8884'),tool_commands=[dict(label=x['label'],returncode=x['returncode'],seconds=x['seconds']) for x in q['commands']],owner_seconds=o['seconds'],source_endcheck='PASS',cleanup=dict(owned_group_gone=True,global_vendor=[],independent_no_orphans_exit=0,collection_exit=0),mismatch_reported=False,complete_coverage=False,scope='Simulation ended on testbench watchdog before required~3.3ms sequence. Absence of mismatch is not a fullproof. No hardware/source/coverage/wallbudget change authorized by this closure.',snapshots=snaps,closure_script=bind(C/'close.py'));(C/'manifest.json').write_text(json.dumps(result,indent=2)+'\n');print('failuremanifest',bind(C/'manifest.json'))
if __name__=='__main__':main()
