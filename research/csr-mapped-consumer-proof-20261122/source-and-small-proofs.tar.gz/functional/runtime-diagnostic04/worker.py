#!/usr/bin/env python3
"""One45s runtime-only progress diagnostic of exact closed03 compiled bytes."""
import argparse, hashlib, json, os, resource, shutil, signal, socket, sys, tarfile, time, uuid
from pathlib import Path
sys.dont_write_bytecode = True
import qualified_worker as q
import software_owned_v2 as owned
HERE = Path(__file__).resolve().parent
PLAN = HERE/'plan.json'
FINAL = HERE/'admission.FINAL.json'
RUN = Path('/run/user/1001/zp-csr-snapshot-runtime-diagnostic-20261122-04')
CAP = 32*1024**2
HOME_CAP = 8*1024**2
CLAIM = 'ONE45s compiled03 runtime progress diagnostic only; no functional rerun or compilation'


def require(v, message):
    if not v: raise ValueError(message)


def bind(p):
    p = Path(p); h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1024**2), b''): h.update(b)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=h.hexdigest())


def usage(p):
    return sum(x.stat().st_size for x in p.rglob('*') if x.is_file()) if p.exists() else 0


def load(expected=None, execute=False):
    p = json.loads(PLAN.read_text())
    for file in (Path(__file__).resolve(), Path(q.__file__).resolve(), Path(owned.__file__).resolve()):
        require(bind(file) in p['inputs'], 'actual loaded helper source binding')
    for row in p['inputs'] + [p['failure_manifest'], p['failure_archive']]:
        require(bind(row['path']) == row, 'frozen diagnostic source/input drift '+row['path'])
    if not execute: return p, None
    require(expected and bind(FINAL)['sha256'] == expected, 'exact ROOT FINAL required')
    a = json.loads(FINAL.read_text())
    require(a['launchable'] is True and a['source_plan'] == bind(PLAN), 'DRAFT cannot run')
    require(bind(a['ROOT_release']['path']) == a['ROOT_release'], 'ROOT release bytes')
    release = json.loads(Path(a['ROOT_release']['path']).read_text())
    require(release.get('allow_csr_mapped03_runtime_diagnostic') is True and release.get('failure_manifest_sha256') == p['failure_manifest']['sha256'] and release.get('linux_claim') == CLAIM, 'exact diagnostic ROOT release')
    require(a['fixed_OTHER_reservations'] == release.get('fixed_OTHER_reservations'), 'ROOT-priced OTHER reservations')
    require(set(a['fixed_OTHER_reservations']) == {'RUN_bytes','HOME_bytes'} and all(type(v) is int and v >= 0 for v in a['fixed_OTHER_reservations'].values()), 'explicit fixed OTHER charges')
    require(socket.gethostname() == 'blackparrot1', 'actual tool host')
    return p, a


def copy_snapshot(plan):
    """Copy exact closed regular files to a physical xsim.dir; no old writes."""
    manifest = json.loads(Path(plan['failure_manifest']['path']).read_text())
    require(manifest['archive'] == plan['failure_archive'] and manifest['owned_groups_gone'] is True and manifest['source_endcheck'] == 'PASS', 'closed03 failure/cleanup')
    rows = {x['relative']: x for x in manifest['members']}
    result = []
    with tarfile.open(plan['failure_archive']['path'], 'r:gz') as tar:
        for name in plan['snapshot_members']:
            row = rows[name]; member = tar.getmember(name)
            require(member.isfile() and member.size == row['bytes'], 'regular exact compiled input')
            raw = tar.extractfile(member).read()
            require(hashlib.sha256(raw).hexdigest() == row['sha256'], 'compiled member SHA')
            relative = Path(name).relative_to('build')
            require(relative.parts[0] == 'xsim.dir' and '..' not in relative.parts, 'fixed physical snapshot destination')
            dest = RUN/relative; dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(raw); dest.chmod(member.mode)
            result.append(dict(relative=str(relative), base_member=name, base_sha256=row['sha256'], bytes=len(raw), mode=member.mode))
    require(len(result) == 20 and sum(x['bytes'] for x in result) == 6027101, 'closed03 snapshot inventory')
    return result


def main():
    ap = argparse.ArgumentParser(description=__doc__); ap.add_argument('--execute', action='store_true'); ap.add_argument('--admission-sha256'); args = ap.parse_args()
    plan, admission = load(args.admission_sha256, args.execute)
    if not args.execute:
        print(json.dumps(dict(state='DRAFT source-only diagnostic; no tools', source_plan=bind(PLAN), command=plan['command']), indent=2)); return
    require(not RUN.exists(), 'fresh one-shot diagnostic only')
    q.empty_inventory()
    def budget():
        used, home = usage(RUN), usage(HERE.parent); other = admission['fixed_OTHER_reservations']
        require(used <= CAP and home <= HOME_CAP, 'fixed32MiB RUN/whole8MiB HOME')
        require(shutil.disk_usage(RUN.parent).free >= 1024**3+CAP-used+other['RUN_bytes'], 'RUN floor/reservations')
        require(shutil.disk_usage(HERE).free >= 2684354560+HOME_CAP-home+other['HOME_bytes'], 'HOME floor/reservations')
    budget(); RUN.mkdir()
    r = q.stat_row(os.getpid()); identity = dict(hostname=socket.gethostname(), pid=os.getpid(), pgid=os.getpgrp(), startticks=r['startticks'], nonce=uuid.uuid4().hex)
    receipt = dict(schema='bp1-root-pervm-cad-ownership-receipt-v1', **identity, admission_sha256=args.admission_sha256, linux_claim_state='ACK', linux_claim=CLAIM, basis='coordinator conditional release + ROOT perVM onejobprotocol', atomic_global_lock=False)
    ack = RUN/'ROOT-ownership.json'; q.save(ack, receipt); q.save(RUN/'ROOT-ownership-initial.json', receipt)
    state = dict(state='RUNNING runtime progress diagnostic; no functional result', source_plan=bind(PLAN), admission=bind(FINAL), own_samples=[], commands=[])
    start = time.monotonic(); active = None; armed = False; last_sample = -1
    def guard():
        nonlocal active, last_sample
        require(time.monotonic()-start < 60, 'fixed60s diagnostic total'); budget()
        require(bind(FINAL)['sha256'] == args.admission_sha256, 'FINAL drift')
        q.validate_ack(json.loads(ack.read_text()), identity, args.admission_sha256, CLAIM)
        rows = q.process_rows()
        if armed and active is None:
            children = [x for x in rows if x['ppid'] == os.getpid() and x['pgid'] == x['pid']]
            require(len(children) <= 1, 'one owned diagnostic group')
            if children: active = {k:children[0][k] for k in ('pid','pgid','startticks')}
        leader = next((x for x in rows if active and x['pid'] == active['pid'] and x['startticks'] == active['startticks']), None)
        foreign = q.vendor_inventory(rows, active['pgid'] if leader else None)
        require(not foreign, 'foreign vendor; abort only owned group '+json.dumps(foreign))
        now = time.monotonic()-start
        if active and int(now) != last_sample:
            sample = []
            for x in rows:
                if x['pgid'] != active['pgid']: continue
                try:
                    proc = Path('/proc')/str(x['pid']); text = (proc/'stat').read_text(); f = text[text.rfind(')')+2:].split()
                    if int(f[19]) != x['startticks']: continue
                    sample.append(dict(pid=x['pid'], comm=x['comm'], state=f[0], startticks=x['startticks'], utime_ticks=int(f[11]), stime_ticks=int(f[12]), wchan=(proc/'wchan').read_text().strip()))
                except (FileNotFoundError, ProcessLookupError): pass
            state['own_samples'].append(dict(wall_seconds=now, members=sample)); last_sample=int(now)
            q.save(RUN/'session.json', state)
    def limits():
        resource.setrlimit(resource.RLIMIT_CORE, (0,0)); resource.setrlimit(resource.RLIMIT_FSIZE, (CAP,CAP))
    def interrupted(sig, frame): raise RuntimeError('ROOT diagnostic signal '+str(sig))
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP): signal.signal(sig, interrupted)
    try:
        state['base_snapshot'] = copy_snapshot(plan); guard(); armed=True
        row = dict(argv=plan['command'], cwd=str(RUN), timeout_seconds=45); state['commands'].append(row); q.save(RUN/'session.json',state)
        with (RUN/'console.log').open('wb') as log:
            try: row['owned']=owned.run(row['argv'], RUN, dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), log, 45, guard, limits)
            except BaseException as e: row['owned']=getattr(e,'owned_receipt',dict(failure=repr(e),owned_group_remaining=False)); raise
        armed=False; active=None; require(row['owned']['returncode']==0 and not row['owned']['owned_group_remaining'], 'native diagnostic failed')
        text=(RUN/'console.log').read_text()
        for marker in ('CSR_RUNTIME_PROGRESS begin ', 'CSR_RUNTIME_PROGRESS after500ns ', 'CSR_RUNTIME_PROGRESS after10us_increment ', 'CSR_RUNTIME_DIAGNOSTIC_COMPLETE functional_result=none cumulative_requested=10.5us'):
            require(text.count(marker)==1, 'complete diagnostic progress marker '+marker)
        require('CSR_SNAPSHOT_MAPPED_PASS' not in text and 'CSR_SNAPSHOT_MAPPED_NEGATIVE_REJECTED' not in text, 'no full-functional result at diagnostic scope')
        state['state']='PASS runtime progress diagnostic only; complete functional result remains unqualified'; guard()
    except BaseException as e:
        state.update(state='FAIL runtime diagnostic; no functional result',error=repr(e)); raise
    finally:
        for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP): signal.signal(sig,signal.SIG_IGN)
        armed=False
        try: load(args.admission_sha256,True); state['source_endcheck']='PASS'
        except BaseException as e: state.update(state='FAIL diagnostic source endcheck',source_endcheck_error=repr(e))
        state['changed_snapshot_files']=[]
        for row in state.get('base_snapshot',[]):
            path=RUN/row['relative']; current=bind(path) if path.is_file() else None
            if current is None or current['sha256']!=row['base_sha256']: state['changed_snapshot_files'].append(dict(base=row,current=current))
        remaining=bool(active and owned.group_state(active['pgid'])) or any(x.get('owned',{}).get('owned_group_remaining',False) for x in state['commands'])
        if remaining: state['state']='FAIL owned group remains; claim HELD'
        release=dict(receipt,linux_claim_state='HELD_OWNED_GROUP_REMAINS' if remaining else 'RELEASED',owned_group_remaining=remaining,outcome=state['state'])
        current=json.loads(ack.read_text())
        if all(current.get(k)==identity[k] for k in identity) and current.get('linux_claim_state')=='ACK': q.save(ack,release)
        else: q.save(RUN/'ROOT-ownership-final.json',release)
        state.update(elapsed_seconds=time.monotonic()-start,ownership_final=release); q.save(RUN/'session.json',state)
        print(state['state'],flush=True)
    require(state['state'].startswith('PASS runtime progress'), 'diagnostic final acceptance')


if __name__ == '__main__': main()
