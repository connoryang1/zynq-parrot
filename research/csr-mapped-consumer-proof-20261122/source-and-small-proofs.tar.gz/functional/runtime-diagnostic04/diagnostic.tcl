puts "CSR_RUNTIME_PROGRESS begin wall_ms=[clock milliseconds] sim=[current_time]"
flush stdout
run 500ns
puts "CSR_RUNTIME_PROGRESS after500ns wall_ms=[clock milliseconds] sim=[current_time]"
flush stdout
run 10us
puts "CSR_RUNTIME_PROGRESS after10us_increment wall_ms=[clock milliseconds] sim=[current_time]"
puts "CSR_RUNTIME_DIAGNOSTIC_COMPLETE functional_result=none cumulative_requested=10.5us"
flush stdout
quit
