#!/usr/bin/env python3
"""One ROOT-admitted mapped05 consumer miter; offline unless --execute."""
import argparse
import hashlib
import json
import os
import re
import resource
import shutil
import signal
import socket
import sys
import tarfile
import time
import uuid
from pathlib import Path
sys.dont_write_bytecode = True
import software_owned_v2 as owned
import qualified_worker as protocol

HERE = Path(__file__).resolve().parent
PLAN = HERE / 'plan.json'
ADMISSION = HERE / 'admission.FINAL.json'
RUN = Path('/run/user/1001/zp-csr-snapshot-mapped-functional-20261122-03')
HOME_FAMILY = HERE.parent
V = Path('/tools/Xilinx/Vivado/2024.2')
CAP = 128 * 1024**2
HOME_CAP = 8 * 1024**2
RUN_FLOOR = 1024**3
HOME_FLOOR = 2684354560
MARKER = 'CSR_SNAPSHOT_MAPPED_PASS cycles=22054 checks=705712 raw_combinations=8192 walk_writes=13328 contexts=4 bits=1666'
NEGATIVE = 'CSR_SNAPSHOT_MAPPED_NEGATIVE_REJECTED gate=full1666payload bit=1665'
CLAIM = 'ONE actual05 mapped CSR consumer positive plus bit1665 negative; no synthesis'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def bind(path):
    path = Path(path)
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024**2), b''):
            h.update(b)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=h.hexdigest())


def verify(row):
    require(bind(row['path']) == row, 'frozen input drift: ' + row['path'])


def usage(path):
    return sum(p.stat().st_size for p in path.rglob('*') if p.is_file()) if path.exists() else 0


def budget(other):
    run = usage(RUN)
    home = usage(HOME_FAMILY)
    require(run <= CAP and home <= HOME_CAP, 'fixed128MiB RUN/whole8MiB HOME cap')
    require(shutil.disk_usage(RUN.parent).free >= RUN_FLOOR + CAP-run + other['RUN_bytes'], 'RUN floor plus remaining and fixed OTHER')
    require(shutil.disk_usage(HOME_FAMILY).free >= HOME_FLOOR + HOME_CAP-home + other['HOME_bytes'], 'HOME floor plus remaining and fixed OTHER')
    return dict(RUN_bytes=run, HOME_bytes=home)


def load(expected, executing=False):
    plan = json.loads(PLAN.read_text())
    for path in (Path(__file__).resolve(), Path(owned.__file__).resolve(), Path(protocol.__file__).resolve()):
        require(any(row == bind(path) for row in plan['inputs']), 'actual loaded helper is not source-bound: '+str(path))
    for row in plan['inputs']:
        verify(row)
    verify(plan['mapping_manifest'])
    verify(plan['mapping_archive'])
    require(plan['schema'] == 'csr-mapped05-functional-source-plan-v2', 'fixed05 schema')
    require(plan['stage'] == str(RUN), 'fixed fresh RUN stage')
    if not executing:
        return plan, None
    require(expected and bind(ADMISSION)['sha256'] == expected, 'exact ROOT-reviewed FINAL SHA required')
    final = json.loads(ADMISSION.read_text())
    verify(final['source_plan'])
    require(final['source_plan'] == bind(PLAN), 'FINAL binds this exact source plan')
    require(final['schema'] == 'csr-mapped05-functional-admission-v2' and final['launchable'] is True, 'DRAFT cannot execute')
    require(final['linux_claim'] == CLAIM, 'fixed one-shot claim')
    verify(final['ROOT_release'])
    release = json.loads(Path(final['ROOT_release']['path']).read_text())
    require(release.get('allow_csr_mapped_functional05') is True and release.get('mapping_manifest_sha256') == plan['mapping_manifest']['sha256'], 'explicit actual05 ROOT release')
    require(release.get('linux_claim') == CLAIM, 'ROOT release scope')
    other = final['fixed_OTHER_reservations']
    require(set(other) == {'RUN_bytes', 'HOME_bytes'} and all(type(v) is int and v >= 0 for v in other.values()), 'explicit prospective fixed OTHER charges')
    require(release.get('fixed_OTHER_reservations') == other, 'ROOT release binds resource charges')
    require(socket.gethostname() == plan['target_hostname'], 'wrong actual tool host')
    return plan, final


def mapping(plan, extract=None):
    """Exact named regular members only; never trust archive extraction paths."""
    manifest = json.loads(Path(plan['mapping_manifest']['path']).read_text())
    require(manifest['archive'] == plan['mapping_archive'], 'closed05 archive binding')
    rows = {r['relative']: r for r in manifest['members']}
    selected = {}
    with tarfile.open(plan['mapping_archive']['path'], 'r:gz') as tar:
        for name in plan['mapping_members']:
            row = rows[name]
            member = tar.getmember(name)
            require(member.isfile() and member.size == row['bytes'], 'exact regular archive member')
            raw = tar.extractfile(member).read()
            require(hashlib.sha256(raw).hexdigest() == row['sha256'], 'mapping05 member drift')
            selected[name] = raw
            if extract is not None and name in ('resetless-unmasked/functional.v', 'resetless-unmasked/synthesized.dcp'):
                (extract / Path(name).name).write_bytes(raw)
    session = json.loads(selected['session.json'])
    require(session['admission'] == plan['mapping_admission'], 'actual05 source admission')
    require(session['state'] == 'PASS single unmasked CSR counterfactual mapping; no wholeCPU/fit or mapped-function claim', 'actual05 complete mapping')
    require(session['source_endcheck'] == 'PASS' and not session['foreign_inventory_events'], 'mapping source/foreign closure')
    require(session['ownership_final']['linux_claim_state'] == 'RELEASED' and not session['ownership_final']['owned_group_remaining'], 'mapping ownership released')
    require(len(session['arms']) == 1 and session['arms'][0]['arm'] == 'resetless-unmasked', '05 only, not masked04')
    life = session['arms'][0]['owned_receipt']
    require(life['returncode'] == 0 and not life['owned_group_remaining'], 'actual05 native success')
    require(not selected['resetless-unmasked/blackboxes.txt'].strip(), 'no mapped blackbox')
    text = selected['resetless-unmasked/functional.v'].decode()
    require(len(re.findall(r'(?m)^module\s+csr_snapshot_consumer_wrapper\b', text)) == 1, 'unmodified mapped consumer top')
    if re.search(r'(?m)^\s*module\s+glbl\b', text):
        require(re.search(r'`ifndef\s+GLBL\s+`define\s+GLBL\s+(?:`timescale[^\n]*\n\s*)?module\s+glbl\b', text), 'known optional glbl guard, no netlist rewrite')
    return dict(resources=manifest['resources'], netlist=rows['resetless-unmasked/functional.v'], DCP=rows['resetless-unmasked/synthesized.dcp'])


def commands():
    build = RUN / 'build'
    snapshot = 'csr_snapshot_mapped_miter'
    return [
        ('xvlog-global', 60, build, [V/'bin/xvlog', V/'data/verilog/src/glbl.v']),
        ('xvlog-netlist', 60, build, [V/'bin/xvlog', '-d', 'GLBL', RUN/'inputs/functional.v']),
        ('xvlog-reference', 60, build, [V/'bin/xvlog', '--sv', '-d', 'CSR_SNAPSHOT_BASELINE', HERE/'reference.sv', HERE/'reference-wrapper.sv', HERE/'miter.sv']),
        ('xelab', 180, build, [V/'bin/xelab', '-L', 'unisims_ver', '-L', 'unimacro_ver', '-L', 'secureip', 'work.csr_snapshot_mapped_miter', 'work.glbl', '-s', snapshot]),
        ('positive', 120, RUN/'positive', [V/'bin/xsim', snapshot, '-tclbatch', HERE/'run.tcl']),
        ('negative', 120, RUN/'negative', [V/'bin/xsim', snapshot, '-testplusarg', 'NEGATIVE', '-tclbatch', HERE/'run.tcl'])]


def check_log(text, negative=False):
    require(not re.search(r'(?:FATAL_ERROR|Fatal:|\$fatal|Error:)', text), 'native simulation error')
    if negative:
        require(text.count(NEGATIVE) == 1 and MARKER not in text, 'exact bit1665 negative payload rejection only')
    else:
        require(text.count(MARKER) == 1 and 'CSR_SNAPSHOT_MAPPED_NEGATIVE_REJECTED' not in text, 'exact complete positive miter marker')
        require(text.count('CSR_SNAPSHOT_CONSUMER_COUNTS ') == 1, 'all consumer coverage counters')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--execute', action='store_true')
    ap.add_argument('--admission-sha256')
    args = ap.parse_args()
    plan, final = load(args.admission_sha256, args.execute)
    if not args.execute:
        print(json.dumps(dict(state='DRAFT no tools', plan=bind(PLAN), mapping=mapping(plan), commands=[dict(label=n, seconds=t, cwd=str(c), argv=list(map(str,a))) for n,t,c,a in commands()]), indent=2))
        return
    require(not RUN.exists(), 'one-shot fresh RUN only; no retry')
    protocol.empty_inventory()
    budget(final['fixed_OTHER_reservations'])
    RUN.mkdir()
    identity = protocol.stat_row(os.getpid())
    identity = dict(hostname=socket.gethostname(), pid=os.getpid(), startticks=identity['startticks'], pgid=os.getpgrp(), nonce=uuid.uuid4().hex)
    receipt = dict(schema='bp1-root-pervm-cad-ownership-receipt-v1', **identity, utc=protocol.utc(), admission_sha256=args.admission_sha256, linux_claim_state='ACK', linux_claim=CLAIM, basis='coordinator conditional release + ROOT perVM onejobprotocol', atomic_global_lock=False)
    ack = RUN/'ROOT-ownership.json'
    protocol.save(ack, receipt)
    protocol.save(RUN/'ROOT-ownership-initial.json', receipt)
    state = dict(state='RUNNING mapped05 consumer only', admission=bind(ADMISSION), source_plan=bind(PLAN), commands=[], no_synthesis_or_board=True)
    started = time.monotonic()
    active = None
    armed = False

    def guard():
        nonlocal active
        require(time.monotonic()-started < 480, 'fixed480s whole batch')
        budget(final['fixed_OTHER_reservations'])
        require(bind(ADMISSION)['sha256'] == args.admission_sha256, 'FINAL changed')
        protocol.validate_ack(json.loads(ack.read_text()), identity, args.admission_sha256, CLAIM)
        rows = protocol.process_rows()
        if armed and active is None:
            children = [r for r in rows if r['ppid'] == os.getpid() and r['pgid'] == r['pid']]
            require(len(children) <= 1, 'one owned group')
            if children:
                active = {k: children[0][k] for k in ('pid', 'pgid', 'startticks')}
        leader = next((r for r in rows if active and r['pid'] == active['pid'] and r['startticks'] == active['startticks']), None)
        foreign = protocol.vendor_inventory(rows, active['pgid'] if leader else None)
        require(not foreign, 'foreign vendor/launcher; stop only owned group: '+json.dumps(foreign))

    def limits():
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        resource.setrlimit(resource.RLIMIT_FSIZE, (CAP, CAP))

    def interrupted(sig, frame):
        raise RuntimeError('ROOT mapped worker signal '+str(sig))

    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(sig, interrupted)

    try:
        (RUN/'inputs').mkdir()
        state['mapping'] = mapping(plan, RUN/'inputs')
        for name in ('build', 'positive', 'negative'):
            (RUN/name).mkdir()
        for name in ('positive', 'negative'):
            (RUN/name/'xsim.dir').symlink_to('../build/xsim.dir', target_is_directory=True)
        for label, timeout, cwd, argv in commands():
            load(args.admission_sha256, True)
            guard()
            row = dict(label=label, argv=list(map(str, argv)), cwd=str(cwd), timeout_seconds=timeout)
            state['commands'].append(row)
            protocol.save(RUN/'session.json', state)
            armed = True
            active = None
            with (RUN/(label+'.log')).open('wb') as log:
                try:
                    row['owned'] = owned.run(row['argv'], cwd, dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), log, timeout, guard, limits)
                except BaseException as e:
                    row['owned'] = getattr(e, 'owned_receipt', dict(failure=repr(e), owned_group_remaining=False, scope='prePopen refusal'))
                    raise
            armed = False
            require(row['owned']['returncode'] == 0 and not row['owned']['owned_group_remaining'], 'native phase failed')
            if active:
                require(row['owned']['owned_pgid'] == active['pgid'], 'actual group identity')
            active = None
            if label in ('positive', 'negative'):
                check_log((RUN/(label+'.log')).read_text(), label == 'negative')
            row['log'] = bind(RUN/(label+'.log'))
            guard()
            protocol.save(RUN/'session.json', state)
        require(len(state['commands']) == 6, 'six native commands only')
        state['state'] = 'PASS mapped05 complete consumer function plus exact bit1665 negative; no fullCPU/fit claim'
    except BaseException as e:
        state.update(state='FAIL preserved; no retry', error=repr(e))
        raise
    finally:
        for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
            signal.signal(sig, signal.SIG_IGN)
        armed = False
        try:
            load(args.admission_sha256, True)
            mapping(plan)
            state['source_endcheck'] = 'PASS'
        except BaseException as e:
            state.update(state='FAIL source endcheck', source_endcheck_error=repr(e))
        remaining = bool(active and owned.group_state(active['pgid'])) or any(r.get('owned', {}).get('owned_group_remaining') for r in state['commands'])
        if remaining:
            state['state'] = 'FAIL owned group remains; claim HELD'
        release = dict(receipt, linux_claim_state='HELD_OWNED_GROUP_REMAINS' if remaining else 'RELEASED', owned_group_remaining=remaining, outcome=state['state'], release_utc=protocol.utc())
        try:
            current = json.loads(ack.read_text())
            if all(current.get(k) == identity[k] for k in identity) and current.get('linux_claim_state') == 'ACK':
                protocol.save(ack, release)
            else:
                protocol.save(RUN/'ROOT-ownership-final.json', release)
        except BaseException as e:
            state.update(state='FAIL ownership release receipt', ownership_release_error=repr(e))
            protocol.save(RUN/'ROOT-ownership-final.json', release)
        state.update(elapsed_seconds=time.monotonic()-started, ownership_final=release)
        protocol.save(RUN/'session.json', state)
        print(state['state'], flush=True)
    require(state['state'].startswith('PASS mapped05'), 'final worker acceptance failed')


if __name__ == '__main__':
    main()
