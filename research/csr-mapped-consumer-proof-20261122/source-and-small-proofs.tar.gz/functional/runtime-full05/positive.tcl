puts "CSR_RUNTIME_FULL_PROGRESS begin wall_ms=[clock milliseconds] sim=[current_time]"
flush stdout
for {set chunk 1} {$chunk <= 10} {incr chunk} {
    run 100us
    puts "CSR_RUNTIME_FULL_PROGRESS chunk=$chunk wall_ms=[clock milliseconds] sim=[current_time]"
    flush stdout
}
run all
quit
