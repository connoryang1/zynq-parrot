#!/usr/bin/env python3
"""ROOT-admitted negative then complete positive using exact compiled03 bytes."""
import argparse, hashlib, json, os, re, resource, shutil, signal, socket, sys, tarfile, time, uuid
from pathlib import Path
sys.dont_write_bytecode = True
import qualified_worker as q
import software_owned_v2 as owned
HERE = Path(__file__).resolve().parent
PLAN = HERE/'plan.json'
FINAL = HERE/'admission.FINAL.json'
RUN = Path('/run/user/1001/zp-csr-snapshot-runtime-full-20261122-05')
CAP = 64*1024**2
HOME_CAP = 8*1024**2
CLAIM = 'ONE compiled03 mapped05 consumer negative45 then positive1800; no compilation or synthesis'
MARKER = 'CSR_SNAPSHOT_MAPPED_PASS cycles=22054 checks=705712 raw_combinations=8192 walk_writes=13328 contexts=4 bits=1666'


def require(v, message):
    if not v: raise ValueError(message)


def bind(p):
    p = Path(p); h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1024**2), b''): h.update(b)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=h.hexdigest())


def usage(p):
    return sum(x.stat().st_size for x in p.rglob('*') if x.is_file()) if p.exists() else 0


def load(expected=None, execute=False):
    p = json.loads(PLAN.read_text())
    for file in (Path(__file__).resolve(), Path(q.__file__).resolve(), Path(owned.__file__).resolve()):
        require(bind(file) in p['inputs'], 'actual loaded helper source binding')
    for row in p['inputs'] + [p['failure_manifest'], p['failure_archive']]:
        require(bind(row['path']) == row, 'frozen diagnostic source/input drift '+row['path'])
    if not execute: return p, None
    require(expected and bind(FINAL)['sha256'] == expected, 'exact ROOT FINAL required')
    a = json.loads(FINAL.read_text())
    require(a['launchable'] is True and a['source_plan'] == bind(PLAN), 'DRAFT cannot run')
    require(bind(a['ROOT_release']['path']) == a['ROOT_release'], 'ROOT release bytes')
    release = json.loads(Path(a['ROOT_release']['path']).read_text())
    require(release.get('allow_csr_mapped03_runtime_full05') is True and release.get('failure_manifest_sha256') == p['failure_manifest']['sha256'] and release.get('progress_manifest_sha256') == p['progress_manifest']['sha256'] and release.get('linux_claim') == CLAIM, 'exact full05 ROOT release')
    require(a['fixed_OTHER_reservations'] == release.get('fixed_OTHER_reservations'), 'ROOT-priced OTHER reservations')
    require(set(a['fixed_OTHER_reservations']) == {'RUN_bytes','HOME_bytes'} and all(type(v) is int and v >= 0 for v in a['fixed_OTHER_reservations'].values()), 'explicit fixed OTHER charges')
    require(socket.gethostname() == 'blackparrot1', 'actual tool host')
    return p, a


def copy_snapshot(plan, destination):
    """Copy exact closed regular files to a physical xsim.dir; no old writes."""
    manifest = json.loads(Path(plan['failure_manifest']['path']).read_text())
    require(manifest['archive'] == plan['failure_archive'] and manifest['owned_groups_gone'] is True and manifest['source_endcheck'] == 'PASS', 'closed03 failure/cleanup')
    rows = {x['relative']: x for x in manifest['members']}
    result = []
    with tarfile.open(plan['failure_archive']['path'], 'r:gz') as tar:
        for name in plan['snapshot_members']:
            row = rows[name]; member = tar.getmember(name)
            require(member.isfile() and member.size == row['bytes'], 'regular exact compiled input')
            raw = tar.extractfile(member).read()
            require(hashlib.sha256(raw).hexdigest() == row['sha256'], 'compiled member SHA')
            relative = Path(name).relative_to('build')
            require(relative.parts[0] == 'xsim.dir' and '..' not in relative.parts, 'fixed physical snapshot destination')
            dest = destination/relative; dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(raw); dest.chmod(member.mode)
            result.append(dict(relative=str(relative), base_member=name, base_sha256=row['sha256'], bytes=len(raw), mode=member.mode))
    require(len(result) == 20 and sum(x['bytes'] for x in result) == 6027101, 'closed03 snapshot inventory')
    return result


def check_log(text, negative):
    lines = [line.rstrip('\r') for line in text.splitlines()]
    require(not any(re.match(r'^(?:Fatal:|FATAL_ERROR|ERROR:|Error:)', line) for line in lines), 'native/HDL fatal or error')
    if negative:
        hits = [line for line in lines if re.fullmatch(r'CSR_SNAPSHOT_MAPPED_NEGATIVE_REJECTED gate=full1666payload bit=1665 cycle=\d+ checks=\d+', line)]
        require(len(hits) == 1 and not any(line.startswith('CSR_SNAPSHOT_MAPPED_PASS') for line in lines), 'exact anchored HDL bit1665 negative only')
        return dict(HDL_negative=hits[0])
    require(lines.count(MARKER) == 1 and not any(line.startswith('CSR_SNAPSHOT_MAPPED_NEGATIVE_REJECTED') for line in lines), 'complete exact anchored705712check PASS')
    counts = [line for line in lines if re.fullmatch(r'CSR_SNAPSHOT_CONSUMER_COUNTS cold=\d+ warm=\d+ common_bypass=\d+ prior=\d+', line)]
    require(len(counts) == 1, 'full consumer coverage counts')
    chunks = [re.fullmatch(r'CSR_RUNTIME_FULL_PROGRESS chunk=(\d+) wall_ms=(\d+) sim=(.+)', line) for line in lines]
    chunks = [m.groups() for m in chunks if m]
    require([int(x[0]) for x in chunks] == list(range(1,11)), 'ten actual anchored progress outputs')
    return dict(HDL_PASS=MARKER, consumer_counts=counts[0], progress=chunks)


def main():
    ap = argparse.ArgumentParser(description=__doc__); ap.add_argument('--execute', action='store_true'); ap.add_argument('--admission-sha256'); args = ap.parse_args()
    plan, admission = load(args.admission_sha256, args.execute)
    if not args.execute:
        print(json.dumps(dict(state='DRAFT source-only complete mapped consumer gate; no tools', source_plan=bind(PLAN), commands=plan['commands']), indent=2)); return
    require(not RUN.exists(), 'fresh one-shot diagnostic only')
    q.empty_inventory()
    def budget():
        used, home = usage(RUN), usage(HERE.parent); other = admission['fixed_OTHER_reservations']
        require(used <= CAP and home <= HOME_CAP, 'fixed64MiB RUN/whole8MiB HOME')
        require(shutil.disk_usage(RUN.parent).free >= 1024**3+CAP-used+other['RUN_bytes'], 'RUN floor/reservations')
        require(shutil.disk_usage(HERE).free >= 2684354560+HOME_CAP-home+other['HOME_bytes'], 'HOME floor/reservations')
    budget(); RUN.mkdir()
    r = q.stat_row(os.getpid()); identity = dict(hostname=socket.gethostname(), pid=os.getpid(), pgid=os.getpgrp(), startticks=r['startticks'], nonce=uuid.uuid4().hex)
    receipt = dict(schema='bp1-root-pervm-cad-ownership-receipt-v1', **identity, admission_sha256=args.admission_sha256, linux_claim_state='ACK', linux_claim=CLAIM, basis='coordinator conditional release + ROOT perVM onejobprotocol', atomic_global_lock=False)
    ack = RUN/'ROOT-ownership.json'; q.save(ack, receipt); q.save(RUN/'ROOT-ownership-initial.json', receipt)
    state = dict(state='RUNNING mapped consumer full gate; no fullCPU result', source_plan=bind(PLAN), admission=bind(FINAL), own_samples=[], commands=[])
    start = time.monotonic(); active = None; armed = False; last_sample = -1
    def guard():
        nonlocal active, last_sample
        require(time.monotonic()-start < 1900, 'fixed1900s whole gate'); budget()
        require(bind(FINAL)['sha256'] == args.admission_sha256, 'FINAL drift')
        q.validate_ack(json.loads(ack.read_text()), identity, args.admission_sha256, CLAIM)
        rows = q.process_rows()
        if armed and active is None:
            children = [x for x in rows if x['ppid'] == os.getpid() and x['pgid'] == x['pid']]
            require(len(children) <= 1, 'one owned diagnostic group')
            if children: active = {k:children[0][k] for k in ('pid','pgid','startticks')}
        leader = next((x for x in rows if active and x['pid'] == active['pid'] and x['startticks'] == active['startticks']), None)
        foreign = q.vendor_inventory(rows, active['pgid'] if leader else None)
        require(not foreign, 'foreign vendor; abort only owned group '+json.dumps(foreign))
        now = time.monotonic()-start
        if active and int(now) != last_sample:
            sample = []
            for x in rows:
                if x['pgid'] != active['pgid']: continue
                try:
                    proc = Path('/proc')/str(x['pid']); text = (proc/'stat').read_text(); f = text[text.rfind(')')+2:].split()
                    if int(f[19]) != x['startticks']: continue
                    sample.append(dict(pid=x['pid'], comm=x['comm'], state=f[0], startticks=x['startticks'], utime_ticks=int(f[11]), stime_ticks=int(f[12]), wchan=(proc/'wchan').read_text().strip()))
                except (FileNotFoundError, ProcessLookupError): pass
            state['own_samples'].append(dict(wall_seconds=now, members=sample)); last_sample=int(now)
            q.save(RUN/'session.json', state)
    def limits():
        resource.setrlimit(resource.RLIMIT_CORE, (0,0)); resource.setrlimit(resource.RLIMIT_FSIZE, (CAP,CAP))
    def interrupted(sig, frame): raise RuntimeError('ROOT diagnostic signal '+str(sig))
    for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP): signal.signal(sig, interrupted)
    try:
        for label, timeout in [('negative',45),('positive',1800)]:
            folder=RUN/label; folder.mkdir()
            row=dict(label=label,argv=plan['commands'][label],cwd=str(folder),timeout_seconds=timeout)
            row['base_snapshot']=copy_snapshot(plan,folder); state['commands'].append(row); guard(); armed=True; active=None
            q.save(RUN/'session.json',state)
            with (RUN/(label+'.log')).open('wb') as log:
                try: row['owned']=owned.run(row['argv'],folder,dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),log,timeout,guard,limits)
                except BaseException as e: row['owned']=getattr(e,'owned_receipt',dict(failure=repr(e),owned_group_remaining=False)); raise
            armed=False; active=None; require(row['owned']['returncode']==0 and not row['owned']['owned_group_remaining'],'native '+label+' failed')
            row['analysis']=check_log((RUN/(label+'.log')).read_text(),label=='negative')
            load(args.admission_sha256,True); guard(); q.save(RUN/'session.json',state)
        state['state']='PASS actual mapped05 full consumer705712checks plus exact bit1665 negative; no fullCPU/fit claim'; guard()
    except BaseException as e:
        state.update(state='FAIL complete mapped gate; no accepted full result',error=repr(e)); raise
    finally:
        for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP): signal.signal(sig,signal.SIG_IGN)
        armed=False
        try: load(args.admission_sha256,True); state['source_endcheck']='PASS'
        except BaseException as e: state.update(state='FAIL diagnostic source endcheck',source_endcheck_error=repr(e))
        state['changed_snapshot_files']=[]
        for command in state['commands']:
            for row in command.get('base_snapshot',[]):
                path=Path(command['cwd'])/row['relative']; current=bind(path) if path.is_file() else None
                if current is None or current['sha256']!=row['base_sha256']: state['changed_snapshot_files'].append(dict(run=command['label'],base=row,current=current))
        remaining=bool(active and owned.group_state(active['pgid'])) or any(x.get('owned',{}).get('owned_group_remaining',False) for x in state['commands'])
        if remaining: state['state']='FAIL owned group remains; claim HELD'
        release=dict(receipt,linux_claim_state='HELD_OWNED_GROUP_REMAINS' if remaining else 'RELEASED',owned_group_remaining=remaining,outcome=state['state'])
        current=json.loads(ack.read_text())
        if all(current.get(k)==identity[k] for k in identity) and current.get('linux_claim_state')=='ACK': q.save(ack,release)
        else: q.save(RUN/'ROOT-ownership-final.json',release)
        state.update(elapsed_seconds=time.monotonic()-start,ownership_final=release); q.save(RUN/'session.json',state)
        print(state['state'],flush=True)
    require(state['state'].startswith('PASS actual mapped05'), 'full gate final acceptance')


if __name__ == '__main__': main()
