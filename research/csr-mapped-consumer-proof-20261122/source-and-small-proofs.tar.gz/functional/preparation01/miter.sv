`timescale 1ps/1ps
module csr_snapshot_mapped_miter;
  logic clk_i=0,reset_i=1;
  logic instret_i=0,csrw_i=0,ctxtsw_i=0,addr801_i=0,rebind_i=0;
  logic [1:0] legacy_access_i=0;
  logic current_bank_i=0,retire_bank_i=0,save_bank_i=0,reservation_bank_i=0;
  logic [1:0] save_context_i=0,seed_context_i=0,read_context_i=0;
  logic cache_restore_i=0,resident_init_i=0;
  logic [1665:0] bank0_data_i='0,bank1_data_i='0,prior_image_i='0;
  wire r_save,r_seed,r_rvalid,r_owner,r_restore,r_reset;
  wire m_save,m_seed,m_rvalid,m_owner,m_restore,m_reset;
  wire [3:0] r_valid,m_valid;
  wire [1665:0] r_image,m_image;
  bit negative=0,mutation_window=0,qualified=0;
  localparam logic [1665:0] mutation_mask_lp=(1666'd1<<1665);
  wire [1665:0] mapped_bank0=bank0_data_i ^ ((negative&&mutation_window)?mutation_mask_lp:1666'd0);
  wire [1665:0] mapped_bank1=bank1_data_i ^ ((negative&&mutation_window)?mutation_mask_lp:1666'd0);
  csr_snapshot_consumer_reference reference_rtl
   (.*,.save_intent_o(r_save),.seed_intent_o(r_seed),.read_valid_o(r_rvalid)
    ,.reservation_owner_o(r_owner),.valid_vector_o(r_valid),.restore_v_o(r_restore)
    ,.restore_reset_o(r_reset),.restored_image_o(r_image));
  // Exact unmodified mapped functional.v from the resetless-single arm.
  csr_snapshot_consumer_wrapper hardware
   (.*,.bank0_data_i(mapped_bank0),.bank1_data_i(mapped_bank1)
    ,.save_intent_o(m_save),.seed_intent_o(m_seed),.read_valid_o(m_rvalid)
    ,.reservation_owner_o(m_owner),.valid_vector_o(m_valid),.restore_v_o(m_restore)
    ,.restore_reset_o(m_reset),.restored_image_o(m_image));
  bit [1665:0] score[4];
  bit [3:0] valid_score='0;
  int cycles=0,checks=0,raw_combinations=0,walk_writes=0;
  int cold_checks=0,warm_checks=0,bypass_checks=0,prior_checks=0;
  function automatic bit save_intent;
    return (current_bank_i==retire_bank_i)&&instret_i&&ctxtsw_i;
  endfunction
  function automatic bit seed_intent;
    return (current_bank_i==retire_bank_i)&&csrw_i&&!ctxtsw_i&&addr801_i
      &&legacy_access_i[current_bank_i]&&(rebind_i||!valid_score[seed_context_i]);
  endfunction
  function automatic logic [1665:0] common_data;
    return save_bank_i?bank1_data_i:bank0_data_i;
  endfunction
  task automatic check_one;
    logic [1665:0] expected;
    bit sv,dv,rv,rst;
    if(qualified)begin
      sv=save_intent();dv=seed_intent();rv=cache_restore_i||resident_init_i;
      rst=cache_restore_i&&!valid_score[read_context_i];
      if(!rv)begin expected=prior_image_i;prior_checks++;end
      else if(rst)begin expected=1666'd3;cold_checks++;end
      else if(cache_restore_i)begin expected=score[read_context_i];warm_checks++;end
      else begin expected=common_data();bypass_checks++;end
      if(sv&&dv)$fatal(1,"production complementary gates violated");
      if({r_save,r_seed,r_rvalid,r_owner,r_valid,r_restore,r_reset} !==
         {sv,dv,valid_score[read_context_i],reservation_bank_i,valid_score,rv,rst})
        $fatal(1,"reference independent control/ownership mismatch cycle=%0d",cycles);
      if({m_save,m_seed,m_rvalid,m_owner,m_valid,m_restore,m_reset} !==
         {r_save,r_seed,r_rvalid,r_owner,r_valid,r_restore,r_reset})
        $fatal(1,"mapped control/valid/ownership mismatch cycle=%0d",cycles);
      if(r_image!==expected)$fatal(1,"reference/oracle consumer mismatch cycle=%0d",cycles);
      checks++;
      if(m_image!==expected)begin
        if(negative&&cache_restore_i&&valid_score[read_context_i]
           &&((m_image^expected)===mutation_mask_lp))begin
          $display("CSR_SNAPSHOT_MAPPED_NEGATIVE_REJECTED gate=full1666payload bit=1665 cycle=%0d checks=%0d",cycles,checks);
          $finish;
        end
        $fatal(1,"mapped full1666consumer mismatch cycle=%0d context=%0d",cycles,read_context_i);
      end
    end
  endtask
  task automatic check_all;
    for(int ctx=0;ctx<4;ctx++)for(int mode=0;mode<4;mode++)begin
      read_context_i=2'(ctx);cache_restore_i=1'(mode>>1);resident_init_i=1'(mode);
      #1000;check_one();
    end
  endtask
  task automatic cycle;
    bit sv,dv;
    clk_i=0;check_all();sv=save_intent();dv=seed_intent();
    #8000;mutation_window=negative&&!reset_i&&(sv||dv);
    #1000;clk_i=1;cycles++;
    if(reset_i)begin valid_score='0;for(int a=0;a<4;a++)score[a]='0;end
    else if(sv||dv)begin
      if(dv)begin valid_score[seed_context_i]=1;score[seed_context_i]=common_data();end
      else begin valid_score[save_context_i]=1;score[save_context_i]=common_data();end
    end
    // Actual vendor RAM32M and FDRE use100ps functional update delays.
    #1000;mutation_window=0;
    #1000;qualified=1;check_all();#7000;clk_i=0;
  endtask
  task automatic pattern(input int b);
    bank0_data_i='0;bank0_data_i[b]=1;bank1_data_i=~bank0_data_i;
    prior_image_i=(1666'd1<<((b+31)%1666))|(1666'd1<<((b+71)%1666));
  endtask
  longint unsigned random_state=64'h9f130ccfa2376d45;
  function automatic int unsigned random_word;
    random_state^=random_state<<13;random_state^=random_state>>7;random_state^=random_state<<17;
    return 32'(random_state);
  endfunction
  initial begin
    negative=$test$plusargs("NEGATIVE");
    // Vendor glbl.GSR falls at100ns. No initial payload-zero assumption.
    #200000;pattern(0);cycle();reset_i=0;instret_i=1;ctxtsw_i=1;
    for(int a=0;a<4;a++)begin save_context_i=2'(a);pattern(100+a);cycle();end
    reset_i=1;csrw_i=1;addr801_i=1;rebind_i=1;legacy_access_i=3;
    for(int i=0;i<4;i++)begin ctxtsw_i=1'(i);seed_context_i=2'(i);cycle();end
    reset_i=0;instret_i=0;csrw_i=0;cycle();
    instret_i=0;csrw_i=1;ctxtsw_i=0;addr801_i=1;legacy_access_i=1;current_bank_i=0;retire_bank_i=0;
    for(int a=0;a<4;a++)begin
      seed_context_i=2'(a);save_bank_i=1'(a);rebind_i=0;pattern(400+a);cycle();
      pattern(500+a);cycle();rebind_i=1;pattern(600+a);cycle();
    end
    for(int raw=0;raw<128;raw++)for(int bank=0;bank<16;bank++)for(int a=0;a<4;a++)begin
      instret_i=1'(raw);csrw_i=1'(raw>>1);ctxtsw_i=1'(raw>>2);addr801_i=1'(raw>>3);
      rebind_i=1'(raw>>4);legacy_access_i=2'(raw>>5);
      current_bank_i=1'(bank);retire_bank_i=1'(bank>>1);save_bank_i=1'(bank>>2);reservation_bank_i=1'(bank>>3);
      save_context_i=2'(a);seed_context_i=2'(3-a);pattern((raw+17*bank+a)%1666);cycle();raw_combinations++;
    end
    current_bank_i=1;retire_bank_i=1;reservation_bank_i=0;instret_i=1;csrw_i=1;
    addr801_i=1;rebind_i=1;legacy_access_i=2;
    for(int a=0;a<4;a++)for(int b=0;b<1666;b++)for(int w=0;w<2;w++)begin
      save_context_i=2'(a);seed_context_i=2'(a);save_bank_i=1'(a+b+w);ctxtsw_i=!1'(w);
      pattern(b);cycle();walk_writes++;
    end
    for(int i=0;i<512;i++)begin
      reset_i=(i%113)==0;instret_i=1'(random_word());csrw_i=1'(random_word());ctxtsw_i=1'(random_word());
      addr801_i=1'(random_word());rebind_i=1'(random_word());legacy_access_i=2'(random_word());
      current_bank_i=1'(random_word());retire_bank_i=1'(random_word());save_bank_i=1'(random_word());reservation_bank_i=1'(random_word());
      save_context_i=2'(random_word());seed_context_i=2'(random_word());
      // Preserve the original C++ producer's53pairs of32bit PRNG words,
      // including its final2bit truncation; prior image consumes no PRNG.
      for(int w=0;w<53;w++)begin
        logic [31:0] d0,d1;
        d0=random_word();d1=random_word();
        for(int b=0;b<32;b++)if(32*w+b<1666)begin
          bank0_data_i[32*w+b]=d0[b];bank1_data_i[32*w+b]=d1[b];
        end
      end
      prior_image_i=(bank0_data_i<<31)^1666'd3;
      cycle();
    end
    if(negative)$fatal(1,"negative mutation escaped");
    if(cycles!=22054||checks!=705712||raw_combinations!=8192||walk_writes!=13328
       ||cold_checks==0||warm_checks==0||bypass_checks==0||prior_checks==0)$fatal(1,"coverage incomplete");
    $display("CSR_SNAPSHOT_MAPPED_PASS cycles=22054 checks=705712 raw_combinations=8192 walk_writes=13328 contexts=4 bits=1666");
    $display("CSR_SNAPSHOT_CONSUMER_COUNTS cold=%0d warm=%0d common_bypass=%0d prior=%0d",cold_checks,warm_checks,bypass_checks,prior_checks);
    $finish;
  end
  initial begin #(64'd2000000000);$fatal(1,"fixed2ms simulation-time watchdog");end
endmodule
