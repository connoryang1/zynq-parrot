#!/usr/bin/env python3
"""One bounded canonical fullbackend epoch synthesis batch, with only its own child-group cleanup."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

OUT=Path('/tmp/retained-epoch-fullbackend-inference-20261121-01')
WRAPPER='/home/coyang/zynq-parrot/codex-skills/bp-fpga-synthesis/scripts/run_vivado_2024_2.sh'



def bind(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())


def group(pgid):
    try:os.killpg(pgid,0);return True
    except ProcessLookupError:return False


def reap(pgid):
    while True:
        try:
            pid,_=os.waitpid(-pgid,os.WNOHANG)
            if not pid:return
        except ChildProcessError:return


def stop(p):
    for sig in (signal.SIGTERM,signal.SIGKILL):
        if group(p.pid):os.killpg(p.pid,sig)
        try:p.wait(timeout=(15 if sig==signal.SIGTERM else 5))
        except subprocess.TimeoutExpired:continue
        until=time.monotonic()+5
        while time.monotonic()<until:
            reap(p.pid)
            if not group(p.pid):return
            time.sleep(.05)
    p.wait(timeout=5);reap(p.pid)
    assert not group(p.pid),'own candidate process group remains'


def main():
    assert subprocess.run(['pgrep','-x','vivado'],stdout=subprocess.PIPE).returncode==1,'builder is not idle'
    assert shutil.disk_usage('/home/coyang').free>=3*1024**3,'home3GiB reserve'
    assert ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0
    argv=[WRAPPER,'-mode','batch','-source','probe.tcl','-log','vivado.log','-journal','vivado.jou']
    r=dict(state='RUNNING canonical fullbackend epoch inference',argv=argv,timeout_seconds=580,
        probe=bind(OUT/'probe.tcl'),physical_operations=0,planned_synthesis_arms=1)
    input_names=('candidate-backend.sv','wrapper.sv','bp_retained_epoch_ram.sv','clock.xdc','probe.tcl','run_remote.py')
    r['inputs']=[bind(OUT/n) for n in input_names]
    p=None;started=time.monotonic()
    def interrupted(*_):raise RuntimeError('candidate inference interrupted')
    for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,interrupted)
    try:
        with (OUT/'console.log').open('wb') as f:
            p=subprocess.Popen(argv,cwd=OUT,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
            r['pid']=p.pid
            while p.poll() is None:
                if time.monotonic()-started>=580:raise RuntimeError('fixed580s candidate inference limit')
                # This candidate probe writes small reports only; refuse unexpected output growth.
                assert sum(x.stat().st_size for x in OUT.iterdir() if x.is_file())<32*1024**2,'candidate outputs exceed32MiB'
                assert shutil.disk_usage('/home/coyang').free>=3*1024**3,'home3GiB reserve violation'
                time.sleep(.25)
            r['returncode']=p.wait();reap(p.pid)
            assert not group(p.pid),'candidate batch left descendants'
        assert sum(x.stat().st_size for x in OUT.iterdir() if x.is_file())<32*1024**2,'final candidate output cap'
        assert r['inputs']==[bind(OUT/n) for n in input_names],'candidate input changed during inference'
        assert r['returncode']==0
        assert 'FULLBACKEND_CANONICAL_INFERENCE_COMPLETE' in (OUT/'console.log').read_text()
        assert shutil.disk_usage('/home/coyang').free>=3*1024**3,'home3GiB reserve'
        assert subprocess.run(['pgrep','-x','vivado'],stdout=subprocess.PIPE).returncode==1,'Vivado remains after candidate batch'
        r.update(state='PASS one canonical fullbackend epoch inference only; no fullbackend/FPGA saving or fit proof',outputs=[bind(x) for x in sorted(OUT.iterdir()) if x.is_file()])
    except BaseException as e:r.update(state='FAIL preserved candidate inference',error=repr(e));raise
    finally:
        if p is not None:
            if p.poll() is None or group(p.pid):stop(p)
            r['returncode']=p.returncode
        r['elapsed_seconds']=time.monotonic()-started
        (OUT/'session.json').write_text(json.dumps(r,indent=2)+'\n')
        print(r['state'])


if __name__=='__main__':main()
