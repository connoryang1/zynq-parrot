#!/usr/bin/env python3
"""Static local source binding only; no remote or vendor operation."""
from pathlib import Path
import ast,hashlib,json,subprocess,shutil
P=Path(__file__).resolve().parent
OLD=Path('/home/coyang/fpga-artifacts/context-resume/retained-metadata-production-controls-20261121')
def bind(p):
 raw=p.read_bytes();return dict(path=p.name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def main():
 for name in ('prepare.py','run_candidate.py','run_remote.py'):ast.parse((P/name).read_text(),filename=name,feature_version=8)
 assert (P/'wrapper.sv').read_bytes()==(OLD/'wrapper.sv').read_bytes(),'wrapper drift'
 assert bind(P/'candidate-backend.sv')['sha256']=='b69e51e216e6aa17f51be17aa2054a87ff800ab117f44cf91e525a78674ea4e9'
 assert bind(P/'bp_retained_epoch_ram.sv')['sha256']=='a7673ffc8151b005fcfbfeb4a9e020098e0a2d409b2b79c0bebb2ebe9e0d8720'
 assert bind(P/'functional-handoff.json')['sha256']=='c5fc1eaf9c7af5d167bdc1d40f0d7b51142821e285d3513c63cc17ae63119546'
 t=(P/'probe.tcl').read_text();assert t.index('synth_design')<t.index('foreach pin'),'port query before synthesized design'
 assert t.count('synth_design -top')==1 and '-generic i_lines_p=1792 -generic d_lines_p=1792 -generic sets_p=256' in t
 assert 'read_xdc clock.xdc' in t and 'IS_BLACKBOX == 1' in t and 'candidate-primitives.tsv' in t
 xdc='create_clock -name I_owning_clock -period 50 -waveform {0 25} [get_ports {clk_i[0]}]\ncreate_clock -name D_owning_clock -period 50 -waveform {25 50} [get_ports {clk_i[1]}]\n';assert (P/'clock.xdc').read_text()==xdc
 for name in ('clock.xdc','probe.tcl'):
  s='set f [open {'+str(P/name)+'} r];set s [read $f];close $f;if {![info complete $s]} {exit 1};puts TCL_COMPLETE_ONLY\n';subprocess.run(['tclsh'],input=s,text=True,check=True,stdout=subprocess.PIPE)
 used=int(subprocess.check_output(['du','-s','-B1',str(P)],text=True).split()[0]);assert used<=8*1024**2;assert shutil.disk_usage(P).free>=3*1024**3
 names=('candidate-backend.sv','wrapper.sv','bp_retained_epoch_ram.sv','clock.xdc','probe.tcl','run_remote.py','run_candidate.py','prepare.py','functional-handoff.json','proposal.json','README.md','candidate-source.diff','production-reference.sv.gz','prior-wrapper.sv.gz','prior-probe.tcl.gz')
 a=dict(state='PREPARED ONLY single constrained fullbackend inference; root exact SHA launch required',inputs=[bind(P/n) for n in names],functional_handoff=dict(final_pass=True,manifest_sha256=bind(P/'functional-handoff.json')['sha256']),limits=dict(native_total_seconds=580,TERM_grace_seconds=15,SSH_seconds=620,mapped_top_level_outputs_bytes=32*1024**2,home_free_minimum=3*1024**3,prep_bytes=8*1024**2),geometry=dict(I_lines=1792,D_lines=1792,sets=256,epoch_bits=8,PA=34),clock_scope='Explicit50ns opposite-phase owning clocks; old1280 no-XDC controls are context only, no matched totalarea delta',vendor_invocations=1,retries=0,board_operations=0)
 (P/'admission.json').write_text(json.dumps(a,indent=2)+'\n');r=dict(state='PASS static local preparation only',admission=bind(P/'admission.json'),allocated_prep_bytes=used,HOME_free_bytes=shutil.disk_usage(P).free,wrapper_byte_identical=True,exact_candidate_and_corrected_functional_handoff=True,Tcl_and_Python38_syntax='PASS',vendor_executions=0,remote_operations=0);(P/'host-preparation-proof.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':main()
