create_clock -name I_owning_clock -period 50 -waveform {0 25} [get_ports {clk_i[0]}]
create_clock -name D_owning_clock -period 50 -waveform {25 50} [get_ports {clk_i[1]}]
