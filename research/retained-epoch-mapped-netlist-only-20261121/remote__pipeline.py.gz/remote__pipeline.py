#!/usr/bin/env python3
"""One netlist-only Xsim continuation; no synthesis, no altered mapped artifacts."""
from pathlib import Path
from collections import Counter
import argparse,hashlib,json,re,shutil,subprocess,time
from generate_adapter import generate
P=Path(__file__).resolve().parent;V=Path('/tools/Xilinx/Vivado/2024.2')
MARKER='RETAINED_EPOCH_MAPPED_MITER_PASS I=1792 D=1792 sets=256 full512=1 ways=7 lastslot=1791 invalidations=258 wrap8=1 cancels=2 held=10 clears=5'
def bind(p):
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(path,value):
 t=path.with_suffix(path.suffix+'.tmp');t.write_text(json.dumps(value,indent=2)+'\n');t.replace(path)
def verify(expected):
 assert bind(P/'admission.json')['sha256']==expected; a=json.loads((P/'admission.json').read_bytes());assert a['component_final_pass']
 for row in a['inputs']:assert bind(P/row['path'])=={k:row[k] for k in ('bytes','sha256')},'input drift '+row['path']
 return a
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--admission-sha256',required=True);args=ap.parse_args();verify(args.admission_sha256)
 state=dict(state='RUNNING one netlist-only mapped miter',admission_sha256=args.admission_sha256,commands=[],synthesis_invocations=0);started=None
 def step(label,argv):
  nonlocal started
  now=time.monotonic()
  if started is None:started=now
  row=dict(label=label,argv=list(map(str,argv)),domain='xsim',tool_start=now,domain_start=started);state['commands'].append(row);save(P/'pipeline.json',state);save(P/'phase.json',row)
  with (P/(label+'.log')).open('wb') as f:r=subprocess.run(row['argv'],cwd=P/'xsim-run',stdout=f,stderr=subprocess.STDOUT)
  row.update(returncode=r.returncode,seconds=time.monotonic()-now,log=bind(P/(label+'.log')));save(P/'pipeline.json',state);assert r.returncode==0,label+' failed: no retry'
 try:
  net=P/'candidate-functional.v';dcp=P/'candidate-synthesized.dcp';before=dict(netlist=bind(net),DCP=bind(dcp));assert before['netlist']['sha256']=='e06ac16adec7d02b4cfb227902c563d985bb2554bdcbf86b1555571d8e63b35e' and before['DCP']['sha256']=='ab718a9843d8cb3f6849f2febc5b1d5f52d05c4fea94d48f25d89b0d00969c6d'
  generate(net,P/'adapter-verified.sv');assert (P/'adapter-verified.sv').read_bytes()==(P/'adapter.sv').read_bytes(),'exact prior adapter mismatch'
  refs=Counter()
  for line in (P/'candidate-primitives.tsv').read_text().splitlines()[1:]:
   name,ref=line.rsplit('\t',1)
   if 'distributed_epochs.epoch_ram' in name:refs[ref]+=1
  assert refs['RAM64M']>0 and not any(v for k,v in refs.items() if k.startswith(('FD','LD')));assert not (P/'blackboxes.txt').read_text().strip()
  state['mapping']=dict(artifacts=before,D_epoch_raw_refs=dict(refs),actual_prior_clocks=(P/'clocks.tsv').read_text())
  text=net.read_text();assert '`timescale' in text
  if re.search(r'(?m)^\s*module\s+glbl\b',text):assert re.search(r'`ifndef\s+GLBL\s+`define\s+GLBL\s+(?:`timescale[^\n]*\n\s*)?module\s+glbl\b',text)
  for n in ['reference-timed.sv','adapter.sv','miter.sv']:assert (P/n).read_text().startswith('`timescale 1ps/1ps\n')
  glbl=V/'data/verilog/src/glbl.v';shutil.copyfile(glbl,P/'glbl.v');state['vendor_glbl']=dict(original=str(glbl),identity=bind(glbl));assert bind(P/'glbl.v')==bind(glbl)
  (P/'xsim-run').mkdir();b=V/'bin'
  for label,argv in [('xvlog-global',[b/'xvlog',P/'glbl.v']),('xvlog-netlist',[b/'xvlog','-d','GLBL',net]),('xvlog-reference',[b/'xvlog','--sv',P/'reference-timed.sv',P/'adapter.sv',P/'miter.sv']),('xelab',[b/'xelab','-L','unisims_ver','-L','unimacro_ver','-L','secureip','work.retained_epoch_miter','work.glbl','-s','retained_epoch_miter']),('xsim',[b/'xsim','retained_epoch_miter','-tclbatch',P/'run.tcl'])]:step(label,argv)
  log=(P/'xsim.log').read_text();assert log.count(MARKER)==1 and not re.search(r'(?:FATAL_ERROR|Fatal:|\$fatal|Error:)',log),'miter failed/missing'
  assert before==dict(netlist=bind(net),DCP=bind(dcp));assert bind(glbl)==state['vendor_glbl']['identity'] and bind(P/'glbl.v')==bind(glbl);verify(args.admission_sha256)
  state.update(state='PASS immutable mapped-netlist client cycle/full512 equivalence only; no wholeCPU/route/benefit claim',marker=MARKER)
 except BaseException as e:state.update(state='FAIL preserve netlist-only attempt; no retry',error=repr(e));raise
 finally:save(P/'pipeline.json',state)
 print(state['state'])
if __name__=='__main__':main()
