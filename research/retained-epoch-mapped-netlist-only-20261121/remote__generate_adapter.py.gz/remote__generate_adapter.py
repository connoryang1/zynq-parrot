#!/usr/bin/env python3
"""Verify exact mapped top port schema, emit only wires; never rewrite the netlist."""
from pathlib import Path
import argparse,hashlib,json,re
HERE=Path(__file__).resolve().parent
TOP='retained_production_controls'
SMALL={'clk_i':'input','reset_i':'input','clear_i':'input','invalidate_v_i':'input','lookup_v_i':'input','lookup_ready_o':'output','resp_v_o':'output','resp_ready_i':'input','resp_hit_o':'output','insert_v_i':'input','insert_ready_o':'output','insert_replace_i':'input','insert_cancel_i':'input','insert_done_o':'output','insert_published_o':'output','busy_o':'output','epoch_wrap_o':'output'}
ARRAY={'invalidate_addr_i':('input',34),'lookup_addr_i':('input',34),'resp_data_o':('output',512),'insert_addr_i':('input',34),'insert_data_i':('input',512)}
def generate(netlist,out):
 raw=netlist.read_bytes();s=raw.decode();heads=list(re.finditer(r'(?m)^module\s+'+TOP+r'\s*\(',s));assert len(heads)==1,'exact one mapped top required';body=s[heads[0].end():].split('endmodule',1)[0];end=body.index(');');listed=[x.strip().lstrip('\\') for x in body[:end].split(',')]
 expected={k:(v,2) for k,v in SMALL.items()}
 for k,(direction,width) in ARRAY.items():
  for lane in (0,1):expected[k+'['+str(lane)+']']=(direction,width)
 actual={}
 for m in re.finditer(r'(?m)^\s*(input|output)\s+(?:wire\s+)?(?:\[(\d+):(\d+)\]\s*)?(\\[^\s]+|[A-Za-z_]\w*)\s*;',body):
  direction,high,low,name=m.groups();name=name.lstrip('\\');assert name not in actual,'duplicate mapped port';assert low is None or low=='0','unsupported ascending/nonzero port';actual[name]=(direction,int(high)+1 if high else 1)
 assert actual==expected and set(listed)==set(expected) and len(listed)==len(expected),'mapped top port schema changed'
 declarations=[];connections=[]
 for name in SMALL:declarations.append('  '+SMALL[name]+' wire [1:0] '+name)
 for name,(direction,width) in ARRAY.items():declarations.append('  '+direction+' wire [1:0]['+str(width-1)+':0] '+name)
 for name in listed:
  escaped='\\'+name+' ' if '[' in name else name
  connections.append('    .'+escaped+'('+name+')')
 text='`timescale 1ps/1ps\nmodule mapped_adapter (\n'+',\n'.join(declarations)+'\n);\n  '+TOP+' mapped (\n'+',\n'.join(connections)+'\n  );\nendmodule\n'
 out.write_text(text);proof=dict(state='PASS exact27 mapped top ports/directions/widths; adapter wires only',netlist=dict(path=str(netlist),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),ports=actual,adapter_sha256=hashlib.sha256(text.encode()).hexdigest(),netlist_unmodified=netlist.read_bytes()==raw);(out.parent/'adapter-proof.json').write_text(json.dumps(proof,indent=2)+'\n');return proof
if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('netlist',type=Path);ap.add_argument('output',type=Path);a=ap.parse_args();print(json.dumps(generate(a.netlist,a.output),indent=2))
