#!/usr/bin/env python3
"""Bind a fresh netlist-only plan to already closed artifacts; no remote/tool."""
from pathlib import Path
import ast,hashlib,json,shutil
P=Path(__file__).resolve().parent
OLD=Path('/home/coyang/fpga-artifacts/context-resume/retained-epoch-mapped-equivalence-20261121/preparation01');R=OLD/'run01/remote'
EXTERNAL={n:R/n for n in ('candidate-functional.v','candidate-synthesized.dcp','adapter.sv','candidate-primitives.tsv','candidate-utilization.rpt','clocks.tsv','blackboxes.txt','candidate-final.sv')}
EXTERNAL.update({n:OLD/n for n in ('miter.sv','reference-original.sv','reference-timed.sv','generate_adapter.py','run.tcl','component-final.json','root-component-manifest.json')})
LOCAL=('acquire.py','owner.py','pipeline.py','prepare.py','README.md','prior-failure-manifest.json','prior-mapped-admission.json','prior-adapter-proof.json')
def bind(p,name=None):
 b=p.read_bytes();return dict(path=name or p.name,source=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def main():
 for n in ('acquire.py','owner.py','pipeline.py','prepare.py'):ast.parse((P/n).read_text(),filename=n,feature_version=8)
 assert bind(R/'candidate-functional.v')['sha256']=='e06ac16adec7d02b4cfb227902c563d985bb2554bdcbf86b1555571d8e63b35e'
 assert bind(R/'candidate-synthesized.dcp')['sha256']=='ab718a9843d8cb3f6849f2febc5b1d5f52d05c4fea94d48f25d89b0d00969c6d'
 assert bind(P/'prior-failure-manifest.json')['sha256']=='dc0f542b035f64855a5b5c2afecdb058da62ce1643765faa688a0a190ebe9c0e'
 assert bind(R/'candidate-final.sv')['sha256']=='68d1dd0c7df7e56ffe76317f9bae5a3ca3e09d13cb44d1167c0f737acefcbea6'
 ref=(OLD/'reference-original.sv').read_bytes();assert hashlib.sha256(ref).hexdigest()=='bd4cd65c92bdaf8af80c9c6f4643383c8bfa7fd335ca131319d44c2e45ee2e24';assert (OLD/'reference-timed.sv').read_bytes()==b'`timescale 1ps/1ps\n'+ref.replace(b'module bp_retained_line_store\n',b'module bp225_reference\n',1)
 assert 'synth_design' not in (P/'pipeline.py').read_text() and 'run_vivado' not in (P/'pipeline.py').read_text()
 inputs=[bind(P/n) for n in LOCAL]+[bind(path,name) for name,path in EXTERNAL.items()];assert len({r['path'] for r in inputs})==len(inputs);assert all(Path(r['source']).name==r['path'] for r in inputs)
 a=dict(state='PREPARED ONLY immutable netlist-only Xsim continuation; root launch review required',component_final_pass=True,inputs=inputs,limits=dict(compile_total_seconds=30,Xelab_seconds=600,simulation_seconds=150,pipeline_total_seconds=800,TERM_grace_seconds=15,acquisition_seconds=860,actual_host_RAM_scratch_bytes=128*1024**2,RAM_free_plus_remaining_reserve=1024**3,HOME_minimum=3*1024**3,collection_bytes=32*1024**2),synthesis_invocations=0,Xsim_attempts=1,retries=0,board_operations=0,scope='Exact prior miter/adapter/reference/netlist; warnings unresolved, not stimulus-modified. No new fullCPU/route/performance claim.')
 (P/'admission.json').write_text(json.dumps(a,indent=2)+'\n');free=shutil.disk_usage(P).free;proof=dict(state='PASS static binding only; launch eligibility separately guarded',admission=bind(P/'admission.json'),source_checks='PASS immutable netlist/DCP/source/reference/old-failure inputs',HOME_free=free,required_launch_free=3*1024**3+32*1024**2,launch_HOME_eligible=free>=3*1024**3+32*1024**2,Python38_AST='PASS',vendor_executions=0,remote_operations=0);(P/'host-preparation-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
if __name__=='__main__':main()
