`timescale 1ps/1ps
module retained_epoch_miter;
  logic core_clk=0;
  always #25000 core_clk=~core_clk;
  wire [1:0] clk_i={~core_clk,core_clk};
  logic [1:0] reset_i=3,clear_i=0,invalidate_v_i=0,lookup_v_i=0,resp_ready_i=3;
  logic [1:0] insert_v_i=0,insert_replace_i=0,insert_cancel_i=0;
  logic [1:0][33:0] invalidate_addr_i='0,lookup_addr_i='0,insert_addr_i='0;
  logic [1:0][511:0] insert_data_i='0;
  wire [1:0] r_lookup_ready,r_resp_v,r_resp_hit,r_insert_ready,r_done,r_pub,r_busy,r_wrap;
  wire [1:0] h_lookup_ready,h_resp_v,h_resp_hit,h_insert_ready,h_done,h_pub,h_busy,h_wrap;
  wire [1:0][511:0] r_data,h_data;
  bp225_reference #(.paddr_width_p(34),.sets_p(256),.i_lines_p(1792),.d_lines_p(1792),.epoch_width_p(8)) reference_rtl
   (.clk_i(clk_i),.reset_i(reset_i),.clear_i(clear_i),
    .invalidate_v_i({invalidate_v_i[1],1'b0}),.invalidate_addr_i({invalidate_addr_i[1],34'd0}),
    .lookup_v_i(lookup_v_i),.lookup_addr_i(lookup_addr_i),.lookup_ready_o(r_lookup_ready),
    .resp_v_o(r_resp_v),.resp_ready_i(resp_ready_i),.resp_hit_o(r_resp_hit),.resp_data_o(r_data),
    .insert_v_i(insert_v_i),.insert_ready_o(r_insert_ready),.insert_addr_i(insert_addr_i),.insert_data_i(insert_data_i),
    .insert_replace_i(insert_replace_i),.insert_cancel_i(insert_cancel_i),
    .insert_done_o(r_done),.insert_published_o(r_pub),.busy_o(r_busy),.epoch_wrap_o(r_wrap));
  mapped_adapter hardware
   (.clk_i(clk_i),.reset_i(reset_i),.clear_i(clear_i),.invalidate_v_i(invalidate_v_i),.invalidate_addr_i(invalidate_addr_i),
    .lookup_v_i(lookup_v_i),.lookup_addr_i(lookup_addr_i),.lookup_ready_o(h_lookup_ready),
    .resp_v_o(h_resp_v),.resp_ready_i(resp_ready_i),.resp_hit_o(h_resp_hit),.resp_data_o(h_data),
    .insert_v_i(insert_v_i),.insert_ready_o(h_insert_ready),.insert_addr_i(insert_addr_i),.insert_data_i(insert_data_i),
    .insert_replace_i(insert_replace_i),.insert_cancel_i(insert_cancel_i),
    .insert_done_o(h_done),.insert_published_o(h_pub),.busy_o(h_busy),.epoch_wrap_o(h_wrap));
  bit qualified=0;
  integer checked[2]='{0,0},done_count[2]='{0,0},pub_count[2]='{0,0},wrap_count[2]='{0,0};
  integer insert_checks[2]='{0,0},hit_checks[2]='{0,0},miss_checks[2]='{0,0};
  integer held_checks=0,cancel_checks=0,clear_checks=0,invalidations=0;
  task automatic compare_lane(input int lane);
    if (qualified) begin
      if ({r_lookup_ready[lane],r_resp_v[lane],r_insert_ready[lane],r_done[lane],r_pub[lane],r_busy[lane],r_wrap[lane]}
        !=={h_lookup_ready[lane],h_resp_v[lane],h_insert_ready[lane],h_done[lane],h_pub[lane],h_busy[lane],h_wrap[lane]})
        $fatal(1,"protocol mismatch lane=%0d time=%0t",lane,$time);
      if (r_resp_v[lane]) begin
        if (r_resp_hit[lane] !== h_resp_hit[lane]) $fatal(1,"hit mismatch lane=%0d time=%0t",lane,$time);
        if (r_resp_hit[lane] && (r_data[lane] !== h_data[lane]))
          $fatal(1,"all512 mismatch lane=%0d time=%0t rtl=%h mapped=%h",lane,$time,r_data[lane],h_data[lane]);
      end
      checked[lane]++;
      if (h_done[lane]) done_count[lane]++;
      if (h_pub[lane]) pub_count[lane]++;
      if (h_wrap[lane]) wrap_count[lane]++;
    end
  endtask
  always @(posedge clk_i[0]) begin #1; compare_lane(0); end
  always @(posedge clk_i[1]) begin #1; compare_lane(1); end
  task automatic tick(input int lane); @(posedge clk_i[lane]); #2; endtask
  task automatic drive(input int lane); @(negedge clk_i[lane]); #2; endtask
  task automatic wait_idle(input int lane);
    int n=0;
    while (h_busy[lane]!==1'b0) begin tick(lane);n++;if(n>4096)$fatal(1,"idle timeout lane%0d",lane);end
  endtask
  function automatic logic [33:0] address(input int tag,input int setno);
    return 34'h100000000+(34'(tag)<<14)+(34'(setno)<<6);
  endfunction
  function automatic logic [511:0] payload(input int seed);
    logic [511:0] value;
    for(int w=0;w<8;w++)value[64*w+:64]=64'h7e2d9a4100000000^(64'(seed)*64'h0000000100010193)^(64'(w)*64'h13579bdf2468ace1);
    return value;
  endfunction
  task automatic begin_insert(input int lane,input logic [33:0] addr,input int seed,output int olddone,output int oldpub);
    int n=0;
    drive(lane);
    while(h_insert_ready[lane]!==1'b1)begin tick(lane);drive(lane);n++;if(n>4096)$fatal(1,"insert ready timeout");end
    olddone=done_count[lane];oldpub=pub_count[lane];
    insert_addr_i[lane]=addr;insert_data_i[lane]=payload(seed);insert_replace_i[lane]=0;insert_v_i[lane]=1;
    tick(lane);drive(lane);insert_v_i[lane]=0;
  endtask
  task automatic finish_insert(input int lane,input int olddone,input int oldpub,input bit published);
    int n=0;
    while(done_count[lane]==olddone)begin tick(lane);n++;if(n>4096)$fatal(1,"insert terminal timeout");end
    if(done_count[lane]!=olddone+1 || pub_count[lane]!=oldpub+int'(published))$fatal(1,"insert outcome lane%0d",lane);
    wait_idle(lane);insert_checks[lane]++;
  endtask
  task automatic put(input int lane,input int tag,input int setno,input int seed);
    int a,b;begin_insert(lane,address(tag,setno),seed,a,b);finish_insert(lane,a,b,1);
  endtask
  task automatic begin_lookup(input int lane,input logic[33:0] addr,input bit hit,input int seed);
    int n=0;
    drive(lane);resp_ready_i[lane]=0;
    while(h_lookup_ready[lane]!==1'b1)begin tick(lane);drive(lane);n++;if(n>4096)$fatal(1,"lookup ready timeout");end
    lookup_addr_i[lane]=addr;lookup_v_i[lane]=1;
    tick(lane);drive(lane);lookup_v_i[lane]=0;n=0;
    while(h_resp_v[lane]!==1'b1)begin tick(lane);n++;if(n>4096)$fatal(1,"response timeout");end
    if(h_resp_hit[lane]!==hit)$fatal(1,"unexpected hit lane%0d addr%h",lane,addr);
    if(hit && h_data[lane]!==payload(seed))$fatal(1,"independent full512 expected mismatch lane%0d",lane);
    if(hit)hit_checks[lane]++;else miss_checks[lane]++;
  endtask
  task automatic release_response(input int lane);
    drive(lane);resp_ready_i[lane]=1;tick(lane);wait_idle(lane);
  endtask
  task automatic check_line(input int lane,input int tag,input int setno,input bit hit,input int seed);
    begin_lookup(lane,address(tag,setno),hit,seed);release_response(lane);
  endtask
  task automatic invalidate_D(input int tag,input int setno);
    drive(1);invalidate_addr_i[1]=address(tag,setno);invalidate_v_i[1]=1;
    tick(1);drive(1);invalidate_v_i[1]=0;invalidations++;
  endtask
  task automatic clear_lane(input int lane);
    drive(lane);clear_i[lane]=1;tick(lane);drive(lane);clear_i[lane]=0;wait_idle(lane);clear_checks++;
  endtask
  initial begin : program_sequence
    int a,b,wrap_before;
    // Vendor glbl holds GSR for100ns. Explicit reset remains asserted beyond it.
    #300000;qualified=1;
    drive(0);reset_i=0;wait_idle(0);wait_idle(1);
    // Seven same-set ways include physical slot6*256+255=1791 in each partition.
    for(int lane=0;lane<2;lane++)begin
      check_line(lane,0,255,0,0);
      for(int way=0;way<7;way++)put(lane,way,255,1000+lane*100+way);
      for(int way=0;way<7;way++)check_line(lane,way,255,1,1000+lane*100+way);
      begin_lookup(lane,address(6,255),1,1000+lane*100+6);
      repeat(5)begin tick(lane);if(!h_resp_v[lane]||!h_resp_hit[lane]||h_data[lane]!==payload(1000+lane*100+6))$fatal(1,"held512 changed");held_checks++;end
      release_response(lane);
      begin_insert(lane,address(9,250),1900+lane,a,b);
      repeat(3)tick(lane);drive(lane);insert_cancel_i[lane]=1;tick(lane);drive(lane);insert_cancel_i[lane]=0;
      finish_insert(lane,a,b,0);cancel_checks++;check_line(lane,9,250,0,0);
      begin_insert(lane,address(10,251),2000+lane,a,b);repeat(3)tick(lane);clear_lane(lane);finish_insert(lane,a,b,0);
      check_line(lane,10,251,0,0);
      put(lane,11,252,2100+lane);begin_lookup(lane,address(11,252),1,2100+lane);clear_lane(lane);
      if(h_resp_v[lane]!==0)$fatal(1,"clear retained response");drive(lane);resp_ready_i[lane]=1;
      check_line(lane,11,252,0,0);
    end
    put(1,21,255,3001);begin_lookup(1,address(21,255),1,3001);
    invalidate_D(22,254);if(!h_resp_v[1]||!h_resp_hit[1]||h_data[1]!==payload(3001))$fatal(1,"unrelated invalidation harmed held hit");
    invalidate_D(22,255);if(!h_resp_v[1]||h_resp_hit[1]!==0)$fatal(1,"same-set invalidation did not revoke held hit");release_response(1);
    check_line(1,21,255,0,0);put(1,21,255,3002);check_line(1,21,255,1,3002);
    clear_lane(1);put(1,31,7,4001);wrap_before=wrap_count[1];
    for(int n=0;n<256;n++)begin invalidate_D(33,7);wait_idle(1);end
    if(wrap_count[1]!=wrap_before+1)$fatal(1,"8bit wrap missing or duplicate");
    check_line(1,31,7,0,0);put(1,31,7,4002);check_line(1,31,7,1,4002);
    // Explicit client reset with a held response; compare cleanup/reinitialization.
    put(0,41,9,5001);begin_lookup(0,address(41,9),1,5001);
    drive(0);reset_i=3;repeat(4)tick(0);drive(0);reset_i=0;resp_ready_i=3;wait_idle(0);wait_idle(1);
    check_line(0,41,9,0,0);check_line(1,31,7,0,0);
    put(0,51,255,6001);put(1,51,255,6002);check_line(0,51,255,1,6001);check_line(1,51,255,1,6002);
    if(hit_checks[0]<10||hit_checks[1]<11||cancel_checks!=2||held_checks!=10||invalidations!=258||clear_checks!=5)$fatal(1,"coverage incomplete");
    $display("RETAINED_EPOCH_MAPPED_MITER_PASS I=1792 D=1792 sets=256 full512=1 ways=7 lastslot=1791 invalidations=258 wrap8=1 cancels=2 held=10 clears=5");
    $display("RETAINED_EPOCH_MAPPED_COUNTS edgesI=%0d edgesD=%0d hitI=%0d hitD=%0d doneI=%0d doneD=%0d",checked[0],checked[1],hit_checks[0],hit_checks[1],done_count[0],done_count[1]);
    $finish;
  end
  initial begin #5000000000;$fatal(1,"fixed simulation-time watchdog");end
endmodule
