
import pathlib,hashlib,json,tarfile,subprocess,shlex,os
root=pathlib.Path('/home/xilinx/bp-logs/retained-observer-host-build-20261121')
old=pathlib.Path('/home/xilinx/zynq-parrot/cosim/black-parrot-example/zynq/control-program')
oldsha='2dd9c411614af25025b0b3770fba133c35f3652ad0fa6bf51786a3754a217c30'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(old)==oldsha,'accepted runner changed'
assert subprocess.run(['pgrep','-x','control-program'],stdout=subprocess.PIPE).returncode==1,'active program'
v=os.statvfs(root);assert v.f_bavail*v.f_frsize>=24*1024*1024,'compile peak space reserve'
archive=root/'source.tar.gz';assert sha(archive)=='6c53393a78123253c8647841a6bb1a0d67bd312841f75ba7d4364f1020809855','archive'
with tarfile.open(str(archive),'r:gz') as t:
 members=t.getmembers();assert all(m.isfile() and not m.name.startswith('/') and '..' not in pathlib.PurePosixPath(m.name).parts for m in members),'safe files only'
 assert len(members)==20 and len({m.name for m in members})==20,'members'
 t.extractall(str(root))
m=json.loads((root/'manifest.json').read_text())
for name,b in m['sources'].items():assert sha(root/name)==b['sha256'] and (root/name).stat().st_size==b['bytes'],'source binding'
assert m['definitions']['DRAM_ALLOCATE_SIZE_MB']==46 and m['definitions']['BP_RETAINED_OBSERVE']==1
args=m['compiler_argv_before_python_includes_and_libs'];inc=shlex.split(subprocess.check_output(['python3-config','--includes']).decode());libs=shlex.split(subprocess.check_output(['python3-config','--libs']).decode())
cmd=args[:1]+inc+args[1:]+libs+['-lpthread'];(root/'compiler-argv.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (root/'compile.log').open('w') as log:p=subprocess.run(cmd,cwd=str(root),stdout=log,stderr=subprocess.STDOUT,timeout=240)
result=dict(state='PASS compile only; runner unexecuted/uninstalled' if p.returncode==0 else 'FAIL compile only',returncode=p.returncode,accepted_runner_after=sha(old),board_runtime_artifacts_changed=False)
for name,b in m['sources'].items():assert sha(root/name)==b['sha256'],'source changed during compile'
assert sha(old)==oldsha,'accepted runner changed during compile'
if p.returncode==0:
 out=root/'control-program-observe1';result['runner']=dict(bytes=out.stat().st_size,sha256=sha(out));result['readelf']=subprocess.check_output(['readelf','-h',str(out)]).decode()
(root/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));raise SystemExit(p.returncode)
