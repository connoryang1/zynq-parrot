/* Separate full64B capacity correctness fixture; no performance measurement.
 * Only the declared config word varies across D/I and enabled/negative cases.
 * D's populate+verify body is handwritten no-store assembly, not compiler C.
 */
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include "bp_utils.h"

#ifndef CAP_MAX_LINES
#error "Generated payload bounds required"
#endif
#define MAGIC UINT64_C(0xc640000000000000)
#define SEED UINT64_C(0x9e3779b97f4a7c15)
#define LINE_MUL UINT64_C(0xd1b54a32d192ed03)
#define WORD_MUL UINT64_C(0x94d049bb133111eb)
#define POLL_LIMIT 10000U
#define HOT __attribute__((section(".text.retained_capacity_hot"), noinline, noclone))
volatile uint64_t retained_capacity_config __attribute__((used,aligned(8))) = MAGIC | 2;
extern unsigned char retained_capacity_data_base[],retained_capacity_code_base[];
extern uint64_t retained_capacity_d_region(uint64_t,uint64_t,uint64_t,uint64_t,uint64_t,uint64_t);

static inline uint64_t status(void)
{ uint64_t raw;__asm__ volatile("csrr %0,0x5c2":"=r"(raw)::"memory");return raw; }
static inline void control(unsigned mode)
{ __asm__ volatile("csrw 0x5c2,%0"::"r"((uint64_t)mode):"memory"); }
static HOT __attribute__((noreturn)) void fail(unsigned phase,uint64_t detail)
{
  printf("[BSG-FAIL] retained capacity phase=%u detail=0x%016" PRIx64 "\n",phase,detail);
  bp_finish(1);__builtin_unreachable();
}
static HOT void wait_i(unsigned mask,unsigned require_activity,unsigned phase)
{
  unsigned seen=0;
  for (unsigned n=0;n<POLL_LIMIT;n++) {
    uint64_t raw=status(),ready;
    __asm__ volatile("csrr %0,0x7c0":"=r"(ready)::"memory");
    if (!(raw>>63)||(raw&15)!=mask)fail(phase,raw);
    seen|=(unsigned)(raw&0x100);
    if (!(raw&0x300)&&(ready&1)&&(!require_activity||seen))return;
  }
  fail(phase,status());
}
static HOT void wait_all(unsigned mask,unsigned phase)
{
  for (unsigned n=0;n<POLL_LIMIT;n++) {
    uint64_t raw=status(),i,d;
    __asm__ volatile("csrr %0,0x7c0\ncsrr %1,0x9c0":"=r"(i),"=r"(d)::"memory");
    if (!(raw>>63)||(raw&15)!=mask)fail(phase,raw);
    if (!(raw&0x300)&&(i&1)&&(d&1))return;
  }
  fail(phase,status());
}
static HOT unsigned code_index(unsigned slot,unsigned sets)
{
  /* inverse3 in Z/(2^k); maps each logical slot to physical retained set slot%sets. */
  return (slot&~(sets-1U))+((slot*UINT64_C(0xaaaaaaaaaaaaaaab))&(sets-1U));
}
static HOT uint64_t code_expected(unsigned index)
{
  uint64_t value=index;
  for (unsigned k=1;k<=7;k++)value=(value<<6)^(((index+1U)*(2U*k+1U)+37U*k)&2047U);
  return value;
}
static HOT void instruction_case(unsigned lines,unsigned sets,unsigned mode)
{
  __asm__ volatile(".global retained_capacity_i_populate_begin\nretained_capacity_i_populate_begin: nop":::"memory");
  for (unsigned slot=0;slot<lines;slot++) {
    uintptr_t address=(uintptr_t)retained_capacity_code_base+192U*code_index(slot,sets);
    wait_i(mode,0,20);
    __asm__ volatile("csrw 0x7c0,%0"::"r"(address):"memory");
    wait_i(mode,1,21);
  }
  __asm__ volatile(".global retained_capacity_i_verify_begin\nretained_capacity_i_verify_begin: nop":::"memory");
  for (unsigned slot=0;slot<lines;slot++) {
    unsigned index=code_index(slot,sets);
    uint64_t expected=code_expected(index);
    uint64_t (*function)(void)=(void *)((uintptr_t)retained_capacity_code_base+192U*index);
    if (function()!=expected)fail(22,slot);
  }
  __asm__ volatile(".global retained_capacity_i_verified\nretained_capacity_i_verified: nop":::"memory");
}
int HOT main(void)
{
  /* Same normal-M-mode ELF/NBF for simulator and future FPGA; no debug DRET. */
  __asm__ volatile("csrci mstatus,8":::"memory");
  uint64_t config=retained_capacity_config,raw=status();
  if ((config&~UINT64_C(3))!=MAGIC||!(raw>>63)||((raw>>56)&3)!=3||(raw&15))fail(1,raw);
  unsigned instruction=config&1,active=(config>>1)&1,log_sets=(raw>>48)&255;
  if (log_sets>15)fail(2,raw);
  unsigned sets=1U<<log_sets,lines=(raw>>(instruction?16:32))&65535U;
  if (!lines||lines>CAP_MAX_LINES||sets>CAP_MAX_SETS||((lines+sets-1U)/sets)*sets>CAP_CODE_FUNCTIONS)fail(3,raw);
  unsigned mode=active?(instruction?1:2):0;
  control(mode);wait_all(mode,4);
  if (instruction)instruction_case(lines,sets,mode);
  else {
    uint64_t result=retained_capacity_d_region((uintptr_t)retained_capacity_data_base,lines,mode,SEED,LINE_MUL,WORD_MUL);
    if (result)fail(10,result);
  }
  wait_all(mode,5);control(0);wait_all(0,6);
  printf("RETAINED_CAPACITY_CONFIG version=1 lane=%s active=%u lines=%u sets=%u max_lines=%u line_bytes=64 data_base=0x%016" PRIxPTR
         " code_base=0x%016" PRIxPTR " code_stride=192 copy=0\n",instruction?"i":"d",active,lines,sets,CAP_MAX_LINES,
         (uintptr_t)retained_capacity_data_base,(uintptr_t)retained_capacity_code_base);
  bp_print_string("[BSG-PASS] retained capacity checked all full64B payloads completed\n");
  bp_finish(0);return 0;
}
