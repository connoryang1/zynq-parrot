/* All saves/drain precede the protected region. Its success CFG has no store,
 * call, fence.I, table read, or cleanup until every target word is checked.
 */
.section .text.retained_capacity_d,"ax",@progbits
.option push
.option norvc
.balign 64
.global retained_capacity_d_region
.type retained_capacity_d_region,@function
retained_capacity_d_region:
  addi sp,sp,-96
  sd s0,0(sp)
  sd s1,8(sp)
  sd s2,16(sp)
  sd s3,24(sp)
  sd s4,32(sp)
  sd s5,40(sp)
  sd s6,48(sp)
  sd s7,56(sp)
  sd s8,64(sp)
  sd s9,72(sp)
  sd s10,80(sp)
  sd s11,88(sp)
  mv s0,a0
  mv s1,a1
  mv s2,a2
  mv s3,a3
  mv s4,a4
  mv s5,a5
  fence rw,rw
.global retained_capacity_d_populate_begin
retained_capacity_d_populate_begin:
  mv s6,s0
  li s7,0
.Lpopulate:
  li t1,10000
.Lready:
  csrr t0,0x9c0
  csrr t3,0x5c2
  andi t4,t3,15
  bne t4,s2,.Lcontrol_error
  srli t4,t3,63
  beqz t4,.Lcontrol_error
  andi t4,t3,512
  andi t5,t0,1
  bnez t4,.Lready_next
  bnez t5,.Lsubmit
.Lready_next:
  addi t1,t1,-1
  bnez t1,.Lready
  li a0,1
  j .Lout
.Lsubmit:
  csrw 0x9c0,s6
  li t1,10000
  li t2,0
.Lcomplete:
  csrr t0,0x9c0
  csrr t3,0x5c2
  andi t4,t3,15
  bne t4,s2,.Lcontrol_error
  andi t4,t3,512
  or t2,t2,t4
  andi t5,t0,1
  bnez t5,.Lpreview_idle
  ori t2,t2,512
.Lpreview_idle:
  bnez t4,.Lcomplete_next
  beqz t5,.Lcomplete_next
  bnez t2,.Lpublished
.Lcomplete_next:
  addi t1,t1,-1
  bnez t1,.Lcomplete
  li a0,2
  j .Lout
.Lpublished:
  addi s6,s6,64
  addi s7,s7,1
  bltu s7,s1,.Lpopulate
.global retained_capacity_d_verify_begin
retained_capacity_d_verify_begin:
  mv s6,s0
  li s7,0
.Lline:
  addi s8,s7,1
  mul s8,s8,s4
  xor s8,s8,s3
  li s9,3
  li s10,8
.Lword:
  slli t0,s9,3
  add t1,s6,t0
  ld t2,0(t1)
  addi t3,s9,1
  mul t3,t3,s5
  xor t3,t3,s8
  bne t2,t3,.Ldata_error
  addi s9,s9,1
  andi s9,s9,7
  addi s10,s10,-1
  bnez s10,.Lword
  addi s6,s6,64
  addi s7,s7,1
  bltu s7,s1,.Lline
.global retained_capacity_d_verified
retained_capacity_d_verified:
  li a0,0
  j .Lout
.Lcontrol_error:
  li a0,3
  j .Lout
.Ldata_error:
  li a0,4
.Lout:
  ld s0,0(sp)
  ld s1,8(sp)
  ld s2,16(sp)
  ld s3,24(sp)
  ld s4,32(sp)
  ld s5,40(sp)
  ld s6,48(sp)
  ld s7,56(sp)
  ld s8,64(sp)
  ld s9,72(sp)
  ld s10,80(sp)
  ld s11,88(sp)
  addi sp,sp,96
  ret
.size retained_capacity_d_region,.-retained_capacity_d_region
.option pop
#include "capacity_targets.inc"
