#!/usr/bin/env python3
"""One bounded read-only netlist query, with only its own child-group cleanup."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

OUT=Path('/tmp/retained-dense-r5b-hierarchy-20261121-01')
WRAPPER='/home/coyang/zynq-parrot/codex-skills/bp-fpga-synthesis/scripts/run_vivado_2024_2.sh'
DCP=Path('/home/coyang/fpga-artifacts/context-resume/native1792-dense-r5b-monitor-20261121/preserved-synthesis/black_parrot_bd_1_wrapper.dcp')
EXPECTED='cb475a12de67cc5c6934292a000add9f5f708a1f2466adb3c358eb576761c1b0'


def bind(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    s=p.stat()
    return dict(path=str(p),bytes=s.st_size,sha256=h.hexdigest(),inode=s.st_ino,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)


def group(pgid):
    try:os.killpg(pgid,0);return True
    except ProcessLookupError:return False


def reap(pgid):
    while True:
        try:
            pid,_=os.waitpid(-pgid,os.WNOHANG)
            if not pid:return
        except ChildProcessError:return


def stop(p):
    for sig in (signal.SIGTERM,signal.SIGKILL):
        if group(p.pid):os.killpg(p.pid,sig)
        try:p.wait(timeout=5)
        except subprocess.TimeoutExpired:continue
        until=time.monotonic()+5
        while time.monotonic()<until:
            reap(p.pid)
            if not group(p.pid):return
            time.sleep(.05)
    p.wait(timeout=5);reap(p.pid)
    assert not group(p.pid),'own query process group remains'


def main():
    assert subprocess.run(['pgrep','-x','vivado'],stdout=subprocess.PIPE).returncode==1,'builder is not idle'
    assert bind(DCP)['sha256']==EXPECTED
    assert shutil.disk_usage('/home/coyang').free>=3*1024**3,'home3GiB reserve'
    assert ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0
    argv=[WRAPPER,'-mode','batch','-source','query.tcl','-log','vivado.log','-journal','vivado.jou']
    r=dict(state='RUNNING read-only query',argv=argv,timeout_seconds=120,input_DCP=bind(DCP),
        query=bind(OUT/'query.tcl'),physical_operations=0,synthesis_operations=0)
    p=None;started=time.monotonic()
    def interrupted(*_):raise RuntimeError('read-only query interrupted')
    for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,interrupted)
    try:
        with (OUT/'console.log').open('wb') as f:
            p=subprocess.Popen(argv,cwd=OUT,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
            r['pid']=p.pid
            while p.poll() is None:
                if time.monotonic()-started>=120:raise RuntimeError('fixed120s query limit')
                # This query writes small reports only; refuse unexpected output growth.
                assert sum(x.stat().st_size for x in OUT.iterdir() if x.is_file())<32*1024**2,'query outputs exceed32MiB'
                assert shutil.disk_usage('/home/coyang').free>=3*1024**3,'home3GiB reserve violation'
                time.sleep(.25)
            r['returncode']=p.wait();reap(p.pid)
            assert not group(p.pid),'query left descendants'
        assert r['returncode']==0
        assert 'READ_ONLY_HIERARCHY_QUERY_COMPLETE_NO_SYNTH_OPT_PLACE_ROUTE' in (OUT/'console.log').read_text()
        assert bind(DCP)==r['input_DCP'],'DCP identity changed during read query'
        assert subprocess.run(['pgrep','-x','vivado'],stdout=subprocess.PIPE).returncode==1,'Vivado remains after query'
        r.update(state='PASS one read-only DCP hierarchy query; no reimplementation',outputs=[bind(x) for x in sorted(OUT.iterdir()) if x.is_file()])
    except BaseException as e:r.update(state='FAIL preserved read-only query',error=repr(e));raise
    finally:
        if p is not None:
            if p.poll() is None or group(p.pid):stop(p)
            r['returncode']=p.returncode
        r['input_DCP_after']=bind(DCP)
        r['DCP_unchanged']=r['input_DCP_after']==r['input_DCP']
        if not r['DCP_unchanged']:r.update(state='FAIL DCP identity drift',error='DCP before/after identity mismatch')
        r['elapsed_seconds']=time.monotonic()-started
        (OUT/'session.json').write_text(json.dumps(r,indent=2)+'\n')
        print(r['state'])
    assert r['state'].startswith('PASS'),'final query identity/outcome check failed'


if __name__=='__main__':main()
