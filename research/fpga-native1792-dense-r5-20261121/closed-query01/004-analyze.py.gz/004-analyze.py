#!/usr/bin/env python3
"""Analyze only CLOSED returned r5b read-only reports; never launches tools."""
from pathlib import Path
from collections import defaultdict,Counter
import hashlib,json,re
HERE=Path(__file__).resolve().parent
DATA=HERE/'run01/remote'
def bind(p):
 raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
def table(p,n):
 lines=p.read_text().splitlines();sep='\t' if '\t' in lines[0] else '\\t'
 return [line.split(sep,n-1) for line in lines[1:]]
def resource(p):
 text=p.read_text()
 def value(label,default=0):
  m=re.search(r'^\|\s*'+re.escape(label)+r'\s*\|\s*(\d+)\s*\|',text,re.M)
  return int(m[1]) if m else default
 r={key:value(label) for key,label in [('LUT','Slice LUTs*'),('logic_LUT','LUT as Logic'),('LUTRAM','LUT as Distributed RAM'),('SRL','LUT as Shift Register'),('FF','Slice Registers'),('RAMB36','RAMB36/FIFO*'),('RAMB18','RAMB18')]}
 r['BRAM_tiles']=r['RAMB36']+r['RAMB18']/2;return r

def main():
 session=json.loads((DATA/'session.json').read_text());outer=json.loads((HERE/'run01/session.json').read_text())
 assert session['state'].startswith('PASS') and session['DCP_unchanged'] and session['returncode']==0
 assert session['input_DCP']==session['input_DCP_after'] and all(c['returncode']==0 for c in outer['commands'])
 for row in session['outputs']:
  p=DATA/Path(row['path']).name;actual=bind(p)
  assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256']
 roots={}
 for row in table(DATA/'focused-hierarchy.tsv',4):
  index,name,ref,filename=row;roots[name.rsplit('/',1)[-1]]=dict(path=name,ref=ref,resources=resource(DATA/filename),report=bind(DATA/filename))
 groups=defaultdict(Counter)
 for component,group,ref,count in table(DATA/'primitive-counts.tsv',4):groups[(component,group)][ref]+=int(count)
 summaries=[]
 for (component,group),counts in sorted(groups.items()):
  summaries.append(dict(component=component,name_group=group,FF=sum(v for k,v in counts.items() if k.startswith('FD')),raw_LUT=sum(v for k,v in counts.items() if k.startswith('LUT')),MUX={k:v for k,v in counts.items() if k.startswith('MUX')},RAM_objects={k:v for k,v in counts.items() if k.startswith('RAM')},all_refs=dict(counts)))
 storage=Counter();uce_ff=defaultdict(Counter);backend_ff=defaultdict(Counter)
 for component,group,ref,name in table(DATA/'retained-and-UCE-primitives.tsv',4):
  if not ref.startswith('FD'):continue
  tail=name.rsplit('/',1)[-1];family=re.sub(r'\[[^]]*\]','[]',tail)
  if component=='retained_D' and 'distributed_epochs.epochs_r_reg' in tail:storage[ref]+=1
  if component in ('I_UCE','D_UCE') and 'buffer_or_mux' in group:uce_ff[component][family]+=1
  if component.startswith('retained_') and group in ('capture_line_registers_or_mux_named','response_line_registers_or_mux_named'):backend_ff[component][group]+=1
 assert sum(storage.values())==2048 and all(sum(v.values())==1536 for v in uce_ff.values())
 ramrows=table(DATA/'retained-RAM-ports.tsv',9);epoch_RAM=[r for r in ramrows if 'epoch' in r[0].lower()]
 assert not epoch_RAM
 store='retained_store.storage';assert roots[store]['resources']==dict(LUT=2564,logic_LUT=2532,LUTRAM=32,SRL=0,FF=4263,RAMB36=54,RAMB18=4,BRAM_tiles=56.0)
 assert sum(r['FF'] for r in summaries if r['component'].startswith('retained_'))==4263
 whole=resource(DATA/'utilization_flat.rpt');assert whole['LUT']==56251 and whole['BRAM_tiles']==140
 controls=(DATA/'control_sets.rpt').read_text();m=re.search(r'\| Total control sets\s*\|\s*(\d+)\s*\|',controls);assert m and int(m[1])==1558
 report=dict(state='PASS CLOSED local attribution; no new execution',query=dict(elapsed_seconds=session['elapsed_seconds'],returncode=session['returncode'],DCP_unchanged=True,input_DCP=session['input_DCP'],all_outer_stages_zero=True),whole_synthesis=whole,focused_modules=roots,primitive_name_groups=summaries,D_epoch_storage_FF=dict(storage),D_epoch_RAM_rows=epoch_RAM,UCE_named_512b_arrays={k:dict(v) for k,v in uce_ff.items()},backend_line_buffers={k:dict(v) for k,v in backend_ff.items()},synthesis_control_sets=1558,placement_control_sets=1437,inputs=[bind(p) for p in sorted(DATA.iterdir()) if p.is_file()],limits=['Focused core contains ordinary caches; nested totals cannot be summed','Raw LUT/MUX/ref-name counts are not adjusted physical LUT sites or guaranteed savings','RAM macro/leaf primitive objects overlap; do not sum RAM32M/RAMD32/RAMS32 or RAM64M/RAMD64E as sites','Name groups are partial source-oriented attribution, not D/CE/fanin cones','Synthesis checkpoint cannot reproduce placement-only optimization/packing counts','No area candidate was implemented or fitted; no larger capacity/FPGA/application acceptance'])
 (HERE/'analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(whole=whole,D_epochs_FF=dict(storage),D_epochs_RAM_rows=len(epoch_RAM),store=roots[store]['resources'],query_seconds=session['elapsed_seconds']),indent=2))
if __name__=='__main__':main()
