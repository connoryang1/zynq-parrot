#!/usr/bin/env python3
"""One admitted read-only r5b checkpoint query; defaults to local plan, never board work."""
from pathlib import Path
import argparse,hashlib,json,re,shlex,shutil,subprocess
HERE=Path(__file__).resolve().parent
REMOTE='/tmp/retained-dense-r5b-hierarchy-20261121-01'
HOST='coyang@haight.chillysky.com'

def bind(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for raw in iter(lambda:f.read(1048576),b''):h.update(raw)
 return dict(bytes=p.stat().st_size,sha256=h.hexdigest())
def check(a,expected):
 assert bind(HERE/'admission.json')['sha256']==expected,'admission drift'
 for row in a['inputs']:assert bind(HERE/row['path'])=={k:row[k] for k in ('bytes','sha256')},'input drift '+row['path']
 assert bind(a['DCP']['path'])=={k:a['DCP'][k] for k in ('bytes','sha256')},'durable inputDCP drift'
 assert shutil.disk_usage(HERE).free>=3*1024**3,'home3GiB reserve'
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execute',action='store_true');ap.add_argument('--admission-sha256');args=ap.parse_args()
 a=json.loads((HERE/'admission.json').read_text());expected=bind(HERE/'admission.json')['sha256'];check(a,expected)
 if not args.execute:print(json.dumps(dict(state='PREPARED ONLY, no remote/query',admission_sha256=expected,remote=REMOTE,DCP=a['DCP'],limits=a['limits']),indent=2));return
 assert args.admission_sha256==expected,'exact reviewed query admission SHA required'
 out=HERE/'run01';out.mkdir();state=dict(state='RUNNING ONE read-only query',admission_sha256=expected,commands=[],physical_operations=0,synthesis_operations=0)
 def save():(out/'session.json').write_text(json.dumps(state,indent=2)+'\n')
 def run(label,argv,seconds):
  row=dict(label=label,argv=argv,timeout=seconds);state['commands'].append(row);save()
  try:
   with (out/(label+'.log')).open('wb') as log:r=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,timeout=seconds)
   row['returncode']=r.returncode;return r.returncode
  finally:row['log']=bind(out/(label+'.log'));save()
 ssh=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-p','30041',HOST]
 launched=False;rc=None
 try:
  command="! pgrep -x vivado && test ! -e "+shlex.quote(REMOTE)+" && mkdir "+shlex.quote(REMOTE)
  assert run('idle-fresh',ssh+[command],20)==0,'VM busy/output exists; no query'
  assert run('upload',['scp','-q','-P','30041',str(HERE/'query.tcl'),str(HERE/'run_remote.py'),HOST+':'+REMOTE+'/'],30)==0,'upload failed'
  # Pin the exact source on the remote before starting the one tool invocation.
  hashes=' && '.join('test "$(sha256sum '+shlex.quote(n)+" | cut -d' ' -f1)"+'" = '+shlex.quote(bind(HERE/n)['sha256']) for n in ('query.tcl','run_remote.py'))
  launched=True;rc=run('query',ssh+['cd '+shlex.quote(REMOTE)+' && '+hashes+' && python3 -B run_remote.py'],180)
 except BaseException as e:state.update(state='FAIL one read-only attempt, no retry',error=repr(e))
 finally:
  if launched:
   try:
    assert run('no-orphans',ssh+['! pgrep -x vivado'],20)==0,'global Vivado still present; no closure'
    script='import pathlib,json,hashlib; p=pathlib.Path('+repr(REMOTE)+'); fs=[f for f in p.iterdir() if f.is_file() and not f.is_symlink()]; assert sum(f.stat().st_size for f in fs)<=32*1024**2; print(json.dumps([dict(name=f.name,bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in fs]))'
    assert run('closed-files',ssh+['python3 -c '+shlex.quote(script)],20)==0,'closed report cap/manifest failed'
    rows=json.loads((out/'closed-files.log').read_text());assert all(re.fullmatch(r'[A-Za-z0-9_.-]+',r['name']) for r in rows)
    folder=out/'remote';folder.mkdir();sources=[HOST+':'+REMOTE+'/'+r['name'] for r in rows]
    assert run('collect',['scp','-q','-P','30041',*sources,str(folder)+'/'],40)==0,'closed partial collection failed'
    for row in rows:assert bind(folder/row['name'])=={k:row[k] for k in ('bytes','sha256')},'closed artifact mismatch'
    result=json.loads((folder/'session.json').read_text());state['remote_result']=result
    assert rc==0 and result['state'].startswith('PASS') and result['DCP_unchanged'],'query failed/limited; preserve partial'
    state['state']='PASS one read-only DCP query only; no implementation/fit'
   except BaseException as e:state.update(state='FAIL closed/partial read-only evidence',closure_error=repr(e))
  try:check(a,expected);state['source_endcheck']='PASS'
  except BaseException as e:state.update(state='FAIL source/resource endcheck',endcheck_error=repr(e))
  save()
 print(json.dumps(state,indent=2))
 if not state['state'].startswith('PASS'):raise SystemExit(1)
if __name__=='__main__':main()
