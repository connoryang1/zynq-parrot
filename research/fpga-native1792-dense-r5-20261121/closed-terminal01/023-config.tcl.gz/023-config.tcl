#### Configure your run with these options
set ::env(ELAB) {1}
set ::env(SYNTH) {1}
set ::env(IMPL) {1}
set ::env(HANDOFF) {1}
set ::env(THREADS) {8}
set ::env(SYNTH_STRATEGY) {Flow_AreaOptimized_high}
set ::env(IMPL_STRATEGY) {Performance_ExplorePostRoutePhysOpt}
