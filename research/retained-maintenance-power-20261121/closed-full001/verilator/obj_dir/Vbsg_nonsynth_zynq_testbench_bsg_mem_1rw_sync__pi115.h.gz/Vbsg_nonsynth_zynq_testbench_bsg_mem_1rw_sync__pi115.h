// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vbsg_nonsynth_zynq_testbench.h for the primary calling header

#ifndef VERILATED_VBSG_NONSYNTH_ZYNQ_TESTBENCH_BSG_MEM_1RW_SYNC__PI115_H_
#define VERILATED_VBSG_NONSYNTH_ZYNQ_TESTBENCH_BSG_MEM_1RW_SYNC__PI115_H_  // guard

#include "verilated.h"


class Vbsg_nonsynth_zynq_testbench__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vbsg_nonsynth_zynq_testbench_bsg_mem_1rw_sync__pi115 final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    VL_IN8(clk_i,0,0);
    VL_IN8(reset_i,0,0);
    VL_IN8(data_i,7,0);
    VL_IN8(v_i,0,0);
    VL_IN8(w_i,0,0);
    VL_OUT8(data_o,7,0);
    CData/*0:0*/ __PVT__synth__DOT__nz__DOT__read_en;
    CData/*0:0*/ __PVT__synth__DOT__nz__DOT__llr__DOT__read_en_dff__DOT__data_r;
    CData/*7:0*/ __PVT__synth__DOT__nz__DOT__llr__DOT__dff_bypass__DOT__dff__DOT__data_r;
    VL_IN16(addr_i,8,0);
    SData/*8:0*/ __PVT__synth__DOT__nz__DOT__addr_r;
    VlUnpacked<CData/*7:0*/, 512> __PVT__synth__DOT__nz__DOT__mem;

    // INTERNAL VARIABLES
    Vbsg_nonsynth_zynq_testbench__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vbsg_nonsynth_zynq_testbench_bsg_mem_1rw_sync__pi115(Vbsg_nonsynth_zynq_testbench__Syms* symsp, const char* v__name);
    ~Vbsg_nonsynth_zynq_testbench_bsg_mem_1rw_sync__pi115();
    VL_UNCOPYABLE(Vbsg_nonsynth_zynq_testbench_bsg_mem_1rw_sync__pi115);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
