module retained_production_controls
 #(parameter int unsigned paddr_width_p = 34
   , parameter int unsigned sets_p = 64
   , parameter int unsigned i_lines_p = 64
   , parameter int unsigned d_lines_p = 64
   , parameter int unsigned epoch_width_p = 8
   )
  (input logic [1:0] clk_i
   , input logic [1:0] reset_i
   , input logic [1:0] clear_i
   , input logic [1:0] invalidate_v_i
   , input logic [1:0][paddr_width_p-1:0] invalidate_addr_i

   , input logic [1:0] lookup_v_i
   , output logic [1:0] lookup_ready_o
   , input logic [1:0][paddr_width_p-1:0] lookup_addr_i
   , output logic [1:0] resp_v_o
   , input logic [1:0] resp_ready_i
   , output logic [1:0] resp_hit_o
   , output logic [1:0][511:0] resp_data_o

   , input logic [1:0] insert_v_i
   , output logic [1:0] insert_ready_o
   , input logic [1:0][paddr_width_p-1:0] insert_addr_i
   , input logic [1:0][511:0] insert_data_i
   , input logic [1:0] insert_replace_i
   , input logic [1:0] insert_cancel_i
   , output logic [1:0] insert_done_o
   , output logic [1:0] insert_published_o
   , output logic [1:0] busy_o
   , output logic [1:0] epoch_wrap_o
   );
  bp_retained_line_store #(.paddr_width_p(paddr_width_p), .i_lines_p(i_lines_p), .d_lines_p(d_lines_p), .sets_p(sets_p), .epoch_width_p(epoch_width_p)) storage (
    .clk_i(clk_i),
    .reset_i(reset_i),
    .clear_i(clear_i),
    .invalidate_v_i({invalidate_v_i[1], 1'b0}),
    .invalidate_addr_i({invalidate_addr_i[1], {paddr_width_p{1'b0}}}),
    .lookup_v_i(lookup_v_i),
    .lookup_ready_o(lookup_ready_o),
    .lookup_addr_i(lookup_addr_i),
    .resp_v_o(resp_v_o),
    .resp_ready_i(resp_ready_i),
    .resp_hit_o(resp_hit_o),
    .resp_data_o(resp_data_o),
    .insert_v_i(insert_v_i),
    .insert_ready_o(insert_ready_o),
    .insert_addr_i(insert_addr_i),
    .insert_data_i(insert_data_i),
    .insert_replace_i(insert_replace_i),
    .insert_cancel_i(insert_cancel_i),
    .insert_done_o(insert_done_o),
    .insert_published_o(insert_published_o),
    .busy_o(busy_o),
    .epoch_wrap_o(epoch_wrap_o)
  );
endmodule
