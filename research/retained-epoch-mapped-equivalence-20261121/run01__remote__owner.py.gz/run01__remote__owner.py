#!/usr/bin/env python3
"""Bound only this fresh RAM-scratch pipeline group, reap it, retain partial proof."""
from pathlib import Path
import argparse,ctypes,hashlib,json,os,shutil,signal,subprocess,time
P=Path(__file__).resolve().parent
CAP=128*1024**2;RAM_RESERVE=1024**3;HOME_RESERVE=3*1024**3+32*1024**2
TOOLS={'vivado','xvlog','xelab','xsim','xsimk'}
def busy():
 rows=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   args=p.joinpath('cmdline').read_bytes().split(b'\0');comm=p.joinpath('comm').read_text().strip();names={Path(x.decode(errors='replace')).name for x in args if x};names.add(comm)
   if any(n.split('.')[0] in TOOLS for n in names):rows.append(dict(pid=int(p.name),comm=comm,argv=[x.decode(errors='replace') for x in args if x]))
  except (OSError,ValueError):pass
 return rows
def used():return int(subprocess.check_output(['du','-s','-B1',str(P)],text=True).split()[0])
def resources():
 size=used();ram=shutil.disk_usage('/dev/shm').free;home=shutil.disk_usage('/home/coyang').free
 assert size<=CAP,'128MiB scratch cap';assert ram>=RAM_RESERVE+CAP-size,'RAM1GiB plus remaining scratch reserve';assert home>=HOME_RESERVE,'HOME3GiB plus32MiB collection reserve';return dict(scratch_allocated=size,RAM_free=ram,HOME_free=home)
def group(pid):
 try:os.killpg(pid,0);return True
 except ProcessLookupError:return False
def reap(pid):
 while True:
  try:
   got,_=os.waitpid(-pid,os.WNOHANG)
   if not got:return
  except ChildProcessError:return
def stop(child):
 for sig,seconds in [(signal.SIGTERM,15),(signal.SIGKILL,5)]:
  if group(child.pid):os.killpg(child.pid,sig)
  try:child.wait(timeout=seconds)
  except subprocess.TimeoutExpired:continue
  end=time.monotonic()+5
  while time.monotonic()<end:
   reap(child.pid)
   if not group(child.pid):return
   time.sleep(.05)
 child.wait(timeout=5);reap(child.pid);assert not group(child.pid),'owned group remains'
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--admission-sha256',required=True);a=ap.parse_args()
 assert P.parent==Path('/dev/shm'),'actual host RAM scratch only';assert hashlib.sha256((P/'admission.json').read_bytes()).hexdigest()==a.admission_sha256
 assert not busy(),'vendor busy: no tool launch';start_resource=resources();assert ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0
 state=dict(state='RUNNING one owned mapped pipeline',initial_resources=start_resource,commands=['python3','-B','pipeline.py','--admission-sha256',a.admission_sha256]);child=None;start=time.monotonic()
 def interrupted(*_):raise RuntimeError('owner interrupted')
 for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,interrupted)
 try:
  with (P/'pipeline-console.log').open('wb') as log:
   child=subprocess.Popen(state['commands'],cwd=P,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);state['pipeline_PID']=child.pid
   while child.poll() is None:
    resources();now=time.monotonic();assert now-start<835,'fixed overall pipeline835s cap'
    phase=P/'phase.json'
    if phase.exists():
     q=json.loads(phase.read_bytes());assert q['domain'] in ('synth','xsim')
     assert now-q['domain_start']<(580 if q['domain']=='synth' else 240),'fixed phase total cap'
     if q['label']=='xsim':assert now-q['tool_start']<150,'fixed simulation150s cap'
    else:assert now-start<30,'pipeline startup stalled'
    time.sleep(.25)
   state['returncode']=child.wait();reap(child.pid);assert not group(child.pid),'pipeline left descendants';assert state['returncode']==0,'pipeline failure'
  state['final_resources']=resources();assert not busy(),'vendor remains';r=json.loads((P/'pipeline.json').read_bytes());assert r['state'].startswith('PASS')
  state.update(state='PASS owned bounded mapped pipeline and cleanup',pipeline_result=r)
 except BaseException as e:state.update(state='FAIL preserve owned pipeline partial',error=repr(e))
 finally:
  if child is not None:
   if child.poll() is None or group(child.pid):stop(child)
   state.update(returncode=child.returncode,owned_group_gone=not group(child.pid))
  state['terminal_vendor_processes']=busy();state['seconds']=time.monotonic()-start
  (P/'owner.json').write_text(json.dumps(state,indent=2)+'\n')
 print(state['state'])
 if not state['state'].startswith('PASS'):raise SystemExit(1)
if __name__=='__main__':main()
