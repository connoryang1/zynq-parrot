set_param general.maxThreads 8
create_project -in_memory -part xc7z020clg400-1
puts "ACTUAL_TOOL_VERSION [version -short]"
puts "ACTUAL_MAX_THREADS [get_param general.maxThreads]"
if {![string match 2024.2* [version -short]] || [get_param general.maxThreads]!=8} {error "tool/thread identity"}
read_verilog -sv candidate-final.sv
read_verilog -sv wrapper.sv
read_xdc clock.xdc
synth_design -top retained_production_controls -part xc7z020clg400-1 -directive AreaOptimized_high -global_retiming on -control_set_opt_threshold 1 -generic i_lines_p=1792 -generic d_lines_p=1792 -generic sets_p=256 -generic paddr_width_p=34 -generic epoch_width_p=8
foreach pin {{clk_i[0]} {clk_i[1]}} {if {[llength [get_ports -quiet $pin]]!=1} {error "owning clock port not resolved"}}
set bb [get_cells -quiet -hier -filter {IS_BLACKBOX == 1}]
set f [open blackboxes.txt w]; puts $f $bb; close $f
if {[llength $bb]!=0} {error "unresolved blackbox cells"}
set f [open clocks.tsv w]
foreach c [get_clocks] {puts $f [join [list $c [get_property PERIOD $c] [get_property WAVEFORM $c]] [format %c 9]]}
close $f
report_utilization -hierarchical -file candidate-utilization.rpt
set f [open primitives.tsv w]
foreach c [lsort [get_cells -hier -filter {REF_NAME =~ RAMB*}]] {
  puts $f [join [list $c [get_property REF_NAME $c] [get_property RAM_MODE $c] [get_property READ_WIDTH_A $c] [get_property WRITE_WIDTH_A $c] [get_property READ_WIDTH_B $c] [get_property WRITE_WIDTH_B $c]] "\t"]
}
close $f
set f [open distributed-primitives.tsv w]
foreach c [lsort [get_cells -hier -filter {REF_NAME =~ RAM* && REF_NAME !~ RAMB*}]] {
  puts $f [join [list $c [get_property REF_NAME $c] [get_property IS_PRIMITIVE $c]] [format %c 9]]
}
close $f
set f [open candidate-primitives.tsv w]
puts $f "name\tREF_NAME"
foreach c [lsort [get_cells -hier -filter {IS_PRIMITIVE == 1}]] {puts $f [join [list $c [get_property REF_NAME $c]] [format %c 9]]}
close $f
write_checkpoint -force candidate-synthesized.dcp
write_verilog -mode funcsim candidate-functional.v
puts "FULLBACKEND_CANONICAL_INFERENCE_COMPLETE"
