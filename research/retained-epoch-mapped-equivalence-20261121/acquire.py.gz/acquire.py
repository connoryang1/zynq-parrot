#!/usr/bin/env python3
"""Prepare by default; one exact admitted fresh RAM-scratch mapped pipeline only."""
from pathlib import Path
import argparse,hashlib,json,re,shlex,shutil,subprocess,time
P=Path(__file__).resolve().parent
REMOTE='/dev/shm/retained-epoch-mapped-equivalence-20261121-01'
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','-p','30041','coyang@haight.chillysky.com']
def bind(p):
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def check(expected):
 assert bind(P/'admission.json')['sha256']==expected,'admission drift';a=json.loads((P/'admission.json').read_bytes())
 for r in a['inputs']:assert bind(P/r['path'])=={k:r[k] for k in ('bytes','sha256')},'input drift '+r['path']
 assert shutil.disk_usage(P).free>=3*1024**3+32*1024**2,'HOME3GiB plus32MiB collection reserve'
 return a
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--execute',action='store_true');ap.add_argument('--admission-sha256');args=ap.parse_args();expected=bind(P/'admission.json')['sha256'];a=check(expected)
 if not args.execute:print(json.dumps(dict(state='PREPARED ONLY; no remote/tool',admission_sha256=expected,component_final_pass=a['component_final_pass'],remote=REMOTE,limits=a['limits']),indent=2));return
 assert args.admission_sha256==expected,'exact reviewed admission SHA required';assert a['component_final_pass'],'ROOT component final PASS pending; execute forbidden'
 out=P/'run01';out.mkdir();state=dict(state='RUNNING one admitted mapped pipeline',admission_sha256=expected,commands=[],board_operations=0);started=time.monotonic();launched=False;rc=None
 def save():(out/'session.json').write_text(json.dumps(state,indent=2)+'\n')
 def run(label,argv,cap):
  left=900-(time.monotonic()-started);assert left>0,'fixed whole acquisition900s cap';row=dict(label=label,argv=argv,timeout=min(cap,left));state['commands'].append(row);save()
  try:
   with (out/(label+'.log')).open('wb') as f:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT,timeout=row['timeout'])
   row['returncode']=r.returncode;return r.returncode
  finally:row['log']=bind(out/(label+'.log'));save()
 try:
  idle="! pgrep -x vivado && ! pgrep -x xvlog && ! pgrep -x xelab && ! pgrep -x xsim && test ! -e "+shlex.quote(REMOTE)+' && mkdir '+shlex.quote(REMOTE)
  assert run('idle-fresh',SSH+[idle],20)==0,'vendor busy/output exists'
  names=[r['path'] for r in a['inputs']]+['admission.json']
  assert run('upload',['scp','-q','-P','30041',*[str(P/n) for n in names],SSH[-1]+':'+REMOTE+'/'],30)==0,'upload failed'
  launched=True;rc=run('pipeline',SSH+['cd '+shlex.quote(REMOTE)+' && python3 -B owner.py --admission-sha256 '+shlex.quote(expected)],850)
 except BaseException as e:state.update(state='FAIL preserve attempt; no retry',error=repr(e))
 finally:
  if launched:
   try:
    assert run('no-orphans',SSH+['cd '+shlex.quote(REMOTE)+' && python3 -B -c '+shlex.quote('from owner import busy; import json; r=busy(); print(json.dumps(r)); assert not r')],20)==0,'vendor remains: no collection until closed'
    code='import pathlib,json,hashlib; p=pathlib.Path('+repr(REMOTE)+'); fs=[f for f in p.iterdir() if f.is_file() and not f.is_symlink()]; assert sum(f.stat().st_size for f in fs)<=32*1024**2; print(json.dumps([dict(name=f.name,bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in fs]))'
    assert run('closed-files',SSH+['python3 -c '+shlex.quote(code)],20)==0,'closed cap/inventory failed'
    rows=json.loads((out/'closed-files.log').read_bytes());assert all(re.fullmatch(r'[A-Za-z0-9_.-]+',r['name']) for r in rows)
    assert shutil.disk_usage(P).free>=3*1024**3+sum(r['bytes'] for r in rows),'collection reserve'
    folder=out/'remote';folder.mkdir();assert run('collect',['scp','-q','-P','30041',*[SSH[-1]+':'+REMOTE+'/'+r['name'] for r in rows],str(folder)+'/'],40)==0,'partial collection failed'
    for r in rows:assert bind(folder/r['name'])=={k:r[k] for k in ('bytes','sha256')},'collected identity mismatch'
    owner=json.loads((folder/'owner.json').read_bytes());state['owner']=owner
    assert rc==0 and owner['state'].startswith('PASS') and owner['owned_group_gone'] and not owner['terminal_vendor_processes'],'pipeline fail/cleanup incomplete'
    check(expected);state.update(state='PASS one final-source mapped client equivalence only; no wholeCPU/fit/performance claim',source_endcheck='PASS')
   except BaseException as e:state.update(state='FAIL preserve closed/partial mapped evidence',closure_error=repr(e))
  try:check(expected);state['source_endcheck']='PASS'
  except BaseException as e:state.update(state='FAIL source/resource endcheck',endcheck_error=repr(e))
  state['seconds']=time.monotonic()-started;save()
 print(json.dumps(state,indent=2))
 if not state['state'].startswith('PASS'):raise SystemExit(1)
if __name__=='__main__':main()
