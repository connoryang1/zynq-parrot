#!/usr/bin/env python3
"""Source/static preparation only; final component receipt is a fail-closed gate."""
from pathlib import Path
import ast,hashlib,json,subprocess,shutil
P=Path(__file__).resolve().parent
NAMES=('candidate-final.sv','wrapper.sv','clock.xdc','probe.tcl','reference-original.sv','reference-timed.sv','miter.sv','generate_adapter.py','pipeline.py','owner.py','acquire.py','run.tcl','prepare.py','component-final.json','README.md','run_vivado_2024_2.sh','root-component-manifest.json')
def bind(p):
 b=p.read_bytes();return dict(path=p.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def main():
 for n in NAMES:
  if n.endswith('.py'):ast.parse((P/n).read_text(),filename=n,feature_version=8)
 assert bind(P/'candidate-final.sv')['sha256']=='68d1dd0c7df7e56ffe76317f9bae5a3ca3e09d13cb44d1167c0f737acefcbea6'
 raw=(P/'reference-original.sv').read_bytes();assert hashlib.sha256(raw).hexdigest()=='bd4cd65c92bdaf8af80c9c6f4643383c8bfa7fd335ca131319d44c2e45ee2e24'
 assert (P/'reference-timed.sv').read_bytes()==b'`timescale 1ps/1ps\n'+raw.replace(b'module bp_retained_line_store\n',b'module bp225_reference\n',1)
 old=Path('/home/coyang/fpga-artifacts/context-resume/retained-metadata-production-controls-20261121/wrapper.sv');assert (P/'wrapper.sv').read_bytes()==old.read_bytes()
 t=(P/'probe.tcl').read_text();assert 'read_verilog -sv candidate-final.sv' in t and 'bp_retained_epoch_ram.sv' not in t and t.count('synth_design -top')==1
 assert t.index('synth_design')<t.index('foreach pin') and '-generic i_lines_p=1792 -generic d_lines_p=1792 -generic sets_p=256' in t
 for n in ['clock.xdc','probe.tcl','run.tcl']:
  code='set f [open {'+str(P/n)+'} r];set s [read $f];close $f;if {![info complete $s]} {exit 1};puts COMPLETE\n';subprocess.run(['tclsh'],input=code,text=True,check=True,stdout=subprocess.PIPE)
 for n in ['miter.sv','reference-timed.sv']:assert (P/n).read_text().startswith('`timescale 1ps/1ps\n')
 used=int(subprocess.check_output(['du','-s','-B1',str(P)],text=True).split()[0]);assert used<=8*1024**2;assert shutil.disk_usage(P).free>=3*1024**3+32*1024**2
 c=json.loads((P/'component-final.json').read_bytes())
 a=dict(state='PREPARED ONLY actual mapped gate; exact root launch required',component_final_pass=c['final_pass'],component_receipt=c,inputs=[bind(P/n) for n in NAMES],limits=dict(synth_seconds=580,TERM_grace_seconds=15,xsim_total_seconds=240,simulation_seconds=150,pipeline_seconds=835,acquisition_seconds=900,actual_host_RAM_scratch_bytes=128*1024**2,RAM_free_plus_remaining_reserve=1024**3,HOME_free_plus_collection_reserve=3*1024**3,collection_bytes=32*1024**2),vendor_pipelines=1,retries=0,board_operations=0)
 (P/'admission.json').write_text(json.dumps(a,indent=2)+'\n');r=dict(state='PASS static local preparation only',admission=bind(P/'admission.json'),component_final_pass=c['final_pass'],prep_bytes=used,source_and_wrapper_exact=True,reference_changes='module rename plus exact timescale prefix only',Python38_AST_Tcl_lexical_complete=True,vendor_executions=0,remote_operations=0);(P/'host-preparation-proof.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':main()
