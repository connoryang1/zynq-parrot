#!/usr/bin/env python3
"""Fresh final-source synthesis then actual-netlist Xsim miter; called only by owner."""
from pathlib import Path
import argparse,hashlib,json,re,shutil,subprocess,time
from collections import Counter
from generate_adapter import generate
P=Path(__file__).resolve().parent
V=Path('/tools/Xilinx/Vivado/2024.2')
WRAPPER='/home/coyang/zynq-parrot/codex-skills/bp-fpga-synthesis/scripts/run_vivado_2024_2.sh'
MARKER='RETAINED_EPOCH_MAPPED_MITER_PASS I=1792 D=1792 sets=256 full512=1 ways=7 lastslot=1791 invalidations=258 wrap8=1 cancels=2 held=10 clears=5'
def bind(p):
 b=p.read_bytes();return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(path,value):
 tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)
def verify(expected):
 assert bind(P/'admission.json')['sha256']==expected,'admission drift'
 a=json.loads((P/'admission.json').read_bytes());assert a['component_final_pass'],'component final pass pending'
 for r in a['inputs']:assert bind(P/r['path'])=={k:r[k] for k in ('bytes','sha256')},'input drift '+r['path']
 return a
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--admission-sha256',required=True);args=ap.parse_args();a=verify(args.admission_sha256)
 assert bind(Path(WRAPPER))==bind(P/'run_vivado_2024_2.sh'),'maintained Vivado helper drift'
 state=dict(state='RUNNING one mapped pipeline',admission_sha256=args.admission_sha256,tool_wrapper=bind(Path(WRAPPER)),commands=[]);xsim_started=None
 def step(label,argv,domain):
  nonlocal xsim_started
  now=time.monotonic()
  if domain=='xsim' and xsim_started is None:xsim_started=now
  row=dict(label=label,argv=list(map(str,argv)),domain=domain,tool_start=now,domain_start=now if domain=='synth' else xsim_started)
  state['commands'].append(row);save(P/'pipeline.json',state);save(P/'phase.json',row)
  with (P/(label+'.log')).open('wb') as f:r=subprocess.run(row['argv'],cwd=P/('xsim-run' if domain=='xsim' else '.'),stdout=f,stderr=subprocess.STDOUT)
  row.update(returncode=r.returncode,seconds=time.monotonic()-now,log=bind(P/(label+'.log')));save(P/'pipeline.json',state)
  assert r.returncode==0,label+' failed: preserve/no retry'
 try:
  step('synth',[WRAPPER,'-mode','batch','-source','probe.tcl','-log','vivado.log','-journal','vivado.jou'],'synth')
  log=(P/'synth.log').read_text();assert 'FULLBACKEND_CANONICAL_INFERENCE_COMPLETE' in log and 'ACTUAL_TOOL_VERSION 2024.2' in log and 'ACTUAL_MAX_THREADS 8' in log
  assert not (P/'blackboxes.txt').read_text().strip(),'blackbox present'
  clocks={}
  for line in (P/'clocks.tsv').read_text().splitlines():
   n,period,wave=line.split('\t');clocks[n]=(float(period),list(map(float,wave.split())))
  assert clocks=={'I_owning_clock':(50.0,[0.0,25.0]),'D_owning_clock':(50.0,[25.0,50.0])},'actual clock phase mismatch'
  counts=Counter()
  for line in (P/'candidate-primitives.tsv').read_text().splitlines()[1:]:
   n,ref=line.rsplit('\t',1)
   if 'distributed_epochs.epoch_ram' in n:counts[ref]+=1
  assert counts['RAM64M']>0 and not any(n for ref,n in counts.items() if ref.startswith(('FD','LD'))),'actual D epoch must be RAM without FF'
  net=P/'candidate-functional.v';dcp=P/'candidate-synthesized.dcp';mapped_before=dict(netlist=bind(net),DCP=bind(dcp));state['mapping']=dict(D_epoch_raw_refs=dict(counts),actual_clocks=clocks,artifacts=mapped_before)
  generate(net,P/'adapter.sv')
  raw=net.read_text();assert raw.lstrip().startswith('//') and '`timescale' in raw
  if re.search(r'(?m)^\s*module\s+glbl\b',raw):assert re.search(r'`ifndef\s+GLBL\s+`define\s+GLBL\s+(?:`timescale[^\n]*\n\s*)?module\s+glbl\b',raw),'unknown embedded glbl form'
  for n in ['reference-timed.sv','adapter.sv','miter.sv']:assert (P/n).read_text().startswith('`timescale 1ps/1ps\n'),'explicit timescale missing '+n
  glbl=V/'data/verilog/src/glbl.v';shutil.copyfile(glbl,P/'glbl.v');state['vendor_glbl']=dict(original=str(glbl),identity=bind(glbl));assert bind(P/'glbl.v')==bind(glbl)
  (P/'xsim-run').mkdir();b=V/'bin'
  for label,argv in [
   ('xvlog-global',[b/'xvlog',P/'glbl.v']),
   ('xvlog-netlist',[b/'xvlog','-d','GLBL',net]),
   ('xvlog-reference',[b/'xvlog','--sv',P/'reference-timed.sv',P/'adapter.sv',P/'miter.sv']),
   ('xelab',[b/'xelab','-L','unisims_ver','-L','unimacro_ver','-L','secureip','work.retained_epoch_miter','work.glbl','-s','retained_epoch_miter']),
   ('xsim',[b/'xsim','retained_epoch_miter','-tclbatch',P/'run.tcl'])]:step(label,argv,'xsim')
  log=(P/'xsim.log').read_text();assert log.count(MARKER)==1 and not re.search(r'(?:FATAL_ERROR|Fatal:|\$fatal|Error:)',log),'miter missing or failed'
  assert mapped_before==dict(netlist=bind(net),DCP=bind(dcp)),'mapped artifact changed';assert bind(glbl)==state['vendor_glbl']['identity'] and bind(P/'glbl.v')==bind(glbl),'vendor global drift';verify(args.admission_sha256);assert bind(Path(WRAPPER))==state['tool_wrapper'],'Vivado helper end drift'
  state.update(state='PASS actual mapped primitive client cycle/full512 equivalence; no timing/fit/wholeCPU claim',marker=MARKER)
 except BaseException as e:state.update(state='FAIL preserved mapped pipeline; no retry',error=repr(e));raise
 finally:save(P/'pipeline.json',state)
 print(state['state'])
if __name__=='__main__':main()
